#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int N = 1000;
int n, root = -1, par[N], col[N];
vector<int> e[N];
int dfs(int x) {
    if (e[x].size() < 2) {
        while (e[x].size() < 2)
            e[x].push_back(n + 1);
    }
    for (int i = 0; i < 2; i++)
        if (col[x] && col[e[x][i]])
            quitf(_wa, "two red vertex on a same edge");
    int p = x > n ? 1 : dfs(e[x][0]);
    int q = x > n ? 1 : dfs(e[x][1]);
    if (p != q) {
        quitf(_wa, "different black height");
    }
    return col[x] ? p : p + 1;
}

int main(int argc, char *argv[]) {
    // registerTestlibCmd(argc, argv);
    registerLemonChecker(argc, argv);
    n = inf.readInt();
    for (int i = 1; i <= n; i++) {
        par[i] = inf.readInt();
        if (par[i]) e[par[i]].push_back(i);
        else root = i;
    }
    string out;
    if (!ouf.seekEof()) {
        ouf.readWordTo(out);
        if (out.size() != n) {
            quitf(_wa, "answer length too short");
        }
        for (int i = 1; i <= n; i++) {
            col[i] = out[i - 1] == 'R';
            if (out[i - 1] != 'R' && out[i - 1] != 'B')
                quitf(_wa, "there should be only R&B");
        }
        dfs(root);
        quitf(_ok, "good job!");
    }
    else {
        quitf(_wa, "answer string not found");
    }
}