#include<bits/stdc++.h>
using namespace std;
#define pb push_back
const int N=5e5+5;
vector<int>E[N];
int n,m,out[N],cnt,q;
map<int,int>vis[N];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		out[u]++;E[v].pb(u);
	}
	for(int i=1;i<=n;i++)cnt+=(out[i]==1);
	scanf("%d",&q);
	while(q--){
		int op,u,v;
		scanf("%d%d",&op,&u);
		if(op==1||op==3)scanf("%d",&v);
		if(op==1){
			vis[v][u]=1;
			cnt-=(out[u]==1);out[u]--;cnt+=(out[u]==1);
		}else if(op==3){
			vis[v][u]=0;
			cnt-=(out[u]==1);out[u]++;cnt+=(out[u]==1);
		}else if(op==2){
			for(int v:E[u])
				if(!vis[u][v]){
					vis[u][v]=1;
					cnt-=(out[v]==1);
					out[v]--;
					cnt+=(out[v]==1);
				}
		}else if(op==4){
			for(int v:E[u])
				if(vis[u][v]){
					vis[u][v]=0;
					cnt-=(out[v]==1);
					out[v]++;
					cnt+=(out[v]==1);
				}
		}
		puts(cnt==n?"YES":"NO");
	}
} 
