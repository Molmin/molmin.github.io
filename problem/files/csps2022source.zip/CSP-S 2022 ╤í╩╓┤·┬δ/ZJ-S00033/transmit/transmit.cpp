#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define ll long long
const int N=2e5+5;
int n,Q,K,fa[N][20],dep[N];
ll w[N],f[10],g[10];
vector<int>E[N];
struct nade{
	ll a[3][3];
	nade(){a[0][0]=a[0][1]=a[0][2]=a[1][0]=a[1][1]=a[1][2]=a[2][0]=a[2][1]=a[2][2]=1e18;}
	nade operator * (const nade &b){
		nade c;
		for(int i=0;i<K;i++)
			for(int j=0;j<K;j++)
				for(int k=0;k<K;k++)
					c.a[i][j]=min(c.a[i][j],a[i][k]+b.a[k][j]);
		return c;
	}
}Up[N][20],Do[N][20];
nade get(ll w){
	nade a;
	for(int i=0;i<K;i++)a.a[i][0]=w;
	for(int j=1;j<K;j++)a.a[j-1][j]=0;
	return a;
}
void dfs(int u,int f){
	Up[u][0]=Do[u][0]=get(w[u]);
	fa[u][0]=f;dep[u]=dep[f]+1;
	for(int v:E[u]){
		if(v==f)continue;
		dfs(v,u);
	}
}
void mul(nade w){
	for(int i=0;i<K;i++)g[i]=1e18;
	for(int j=0;j<K;j++)
		for(int k=0;k<K;k++)
			g[j]=min(g[j],f[k]+w.a[k][j]);
	for(int i=0;i<K;i++)f[i]=g[i];
}
ll LCA(int u,int v){
	int x=u,y=v,l;
	if(dep[x]<dep[y])swap(x,y);
	for(int i=19;i>=0;i--)
		if(dep[fa[x][i]]>=dep[y])x=fa[x][i];
	if(x==y)l=x;
	else{
		for(int i=19;i>=0;i--)
			if(fa[x][i]^fa[y][i])x=fa[x][i],y=fa[y][i];
		l=fa[x][0];
	}
	for(int i=0;i<K;i++)f[i]=1e18;f[0]=w[u];
	vector<nade>g;g.clear();
	for(int i=19;i>=0;i--)
		if(dep[fa[v][i]]>=dep[l])g.pb(Do[v][i]),v=fa[v][i];
	if(u^l)g.pb(Up[l][0]);u=fa[u][0];
	for(int i=19;i>=0;i--)
		if(dep[fa[u][i]]>=dep[l])mul(Up[u][i]),u=fa[u][i];
	for(int i=g.size()-1;i>=0;i--)mul(g[i]);
	g.clear();return f[0];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&K);
	for(int i=1;i<=n;i++)scanf("%lld",&w[i]);
	for(int i=1,u,v;i<n;i++){
		scanf("%d%d",&u,&v);
		E[u].pb(v);E[v].pb(u);
	}
	dfs(1,0);
	for(int j=1;j<=19;j++)
		for(int i=1;i<=n;i++){
			fa[i][j]=fa[fa[i][j-1]][j-1];
			Up[i][j]=Up[i][j-1]*Up[fa[i][j-1]][j-1];
			Do[i][j]=Do[fa[i][j-1]][j-1]*Do[i][j-1];
		}
	for(int i=1,u,v;i<=Q;i++){
		scanf("%d%d",&u,&v);
		printf("%lld\n",LCA(u,v));
	}
}
