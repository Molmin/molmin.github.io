#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define fi first
#define se second
#define mkp make_pair
#define pll pair<ll,ll>
const int N=1e5+5;
int n,m,q;
struct nade{
	ll mn[N<<2],mx[N<<2],a[N],up[N<<2],Do[N<<2];bool fl[N<<2];
	void build(int x,int l,int r){
		if(l==r){
			mn[x]=mx[x]=a[l];fl[x]=(a[l]==0);
			if(a[l]>0)up[x]=a[l];else up[x]=1e18;
			if(a[l]<0)Do[x]=a[l];else Do[x]=-1e18;
			return;
		}
		int mid=(l+r)>>1;
		build(x<<1,l,mid);
		build(x<<1|1,mid+1,r);
		mn[x]=min(mn[x<<1],mn[x<<1|1]);
		mx[x]=max(mx[x<<1],mx[x<<1|1]);
		fl[x]=fl[x<<1]|fl[x<<1|1];
		Do[x]=max(Do[x<<1],Do[x<<1|1]);
		up[x]=min(up[x<<1],up[x<<1|1]);
	}
	pll ask(int x,int l,int r,int L,int R){
		if(l>=L&&r<=R)return mkp(mn[x],mx[x]);
		int mid=(l+r)>>1;
		if(mid<L)return ask(x<<1|1,mid+1,r,L,R);
		if(mid+1>R)return ask(x<<1,l,mid,L,R);
		pll w1=ask(x<<1,l,mid,L,R),w2=ask(x<<1|1,mid+1,r,L,R);
		return mkp(min(w1.fi,w2.fi),max(w1.se,w2.se));
	}
	ll askup(int x,int l,int r,int L,int R){
		if(l>=L&&r<=R)return up[x];
		int mid=(l+r)>>1;
		if(mid<L)return askup(x<<1|1,mid+1,r,L,R);
		if(mid+1>R)return askup(x<<1,l,mid,L,R);
		return min(askup(x<<1,l,mid,L,R),askup(x<<1|1,mid+1,r,L,R));
	}
	ll askdo(int x,int l,int r,int L,int R){
		if(l>=L&&r<=R)return Do[x];
		int mid=(l+r)>>1;
		if(mid<L)return askdo(x<<1|1,mid+1,r,L,R);
		if(mid+1>R)return askdo(x<<1,l,mid,L,R);
		return max(askdo(x<<1,l,mid,L,R),askdo(x<<1|1,mid+1,r,L,R));
	}
	bool query(int x,int l,int r,int L,int R){
		if(l>=L&&r<=R)return fl[x];
		int mid=(l+r)>>1;
		if(mid+1>R)return query(x<<1,l,mid,L,R);
		if(mid<L)return query(x<<1|1,mid+1,r,L,R);
		return query(x<<1,l,mid,L,R)|query(x<<1|1,mid+1,r,L,R);		
	}
}T1,T2; 
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%lld",&T1.a[i]);
	for(int i=1;i<=m;i++)scanf("%lld",&T2.a[i]);
	T1.build(1,1,n);T2.build(1,1,m);
	for(int l1,r1,l2,r2;q--;){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		pll w1=T1.ask(1,1,n,l1,r1),w2=T2.ask(1,1,m,l2,r2);
		ll L1=w1.fi,R1=w1.se,L2=w2.fi,R2=w2.se;
		if(R2<=0){
			if(L1<0){
				if(R2==0)puts("0");
				else printf("%lld\n",L1*R2);
			}else if(L1==0)puts("0");
			else printf("%lld\n",L2*L1);
		}else if(L2>=0){
			if(R1<0)printf("%lld\n",R1*R2);
			else if(R1==0)puts("0");
			else{
				if(L2==0)puts("0");
				else printf("%lld\n",R1*L2);
			}
		}else{
			ll ans=-1e18;
			if(T1.query(1,1,n,l1,r1))ans=max(ans,0ll);
			if(R1<=0)ans=max(ans,R1*R2);
			else if(L1>=0)ans=max(ans,L1*L2);
			else ans=max(ans,max(T1.askup(1,1,n,l1,r1)*L2,T1.askdo(1,1,n,l1,r1)*R2));
			if(T2.query(1,1,n,l2,r2))ans=min(ans,0ll);
			printf("%lld\n",ans);
		}
	}
}
