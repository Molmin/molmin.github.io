#include<bits/stdc++.h>
using namespace std;
#define pb push_back
#define ll long long
#define mkp make_pair
#define fi first
#define se second
#define pii pair<int,int>
const int N=2505;
vector<int>E[N];
int n,m,k,id[N],dis[2][N],f[N][N],vis[N][N];
ll a[N],b[N],ans;
void dij(int s,int op){
	queue<int>que;
	for(int i=1;i<=n;i++)dis[op][i]=1e9;
	dis[op][s]=0;que.push(s);
	while(!que.empty()){
		int u=que.front();que.pop();
		for(int v:E[u])
			if(dis[op][v]>dis[op][u]+1){
				dis[op][v]=dis[op][u]+1;
				que.push(v);
			}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);a[1]=-1e18;k++;
	for(int i=2;i<=n;i++)scanf("%lld",&a[i]),b[i]=a[i],id[i]=i;
	sort(id+2,id+n+1,[](int x,int y){return a[x]>a[y];});
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		E[u].pb(v);E[v].pb(u);
	}
	dij(1,0);
	for(int ii=2;ii<=n;ii++){
		int i=id[ii];dij(i,1);int mx=1;
		for(int j=2;j<=n;j++)
			if(j!=i&&dis[0][j]<=k&&dis[1][j]<=k&&a[j]>a[mx])mx=j;
		if(mx==1)continue;
		ll val=0;
		a[i]=a[mx]=-1e18;
		for(int i=2;i<=n;i++)val=max(val,a[i]);
		queue<pii>que;
		f[n+1][i]=0;vis[n+1][i]=i;
		f[i][i]=0;vis[i][i]=i;
		que.push(mkp(n+1,i));que.push(mkp(i,i));
		while(!que.empty()){
			pii uu=que.front();que.pop();
			int u=uu.se,la=uu.fi;
			if(u!=la&&la!=n+1&&dis[0][u]<=k)ans=max(ans,b[i]+b[mx]+a[u]+a[la]);
			if(la!=n+1)if(ans>b[i]+b[mx]+a[la]+val)continue;
			if(f[la][u]+1>k)continue;
			for(int v:E[u]){
				if(vis[la][v]!=i){
					vis[la][v]=i;f[la][v]=f[la][u]+1;
					que.push(mkp(la,v));
				}if(la==n+1)if(f[u][la]+1<=k&&vis[v][v]!=i){
					f[v][v]=0;vis[v][v]=i;
					que.push(mkp(v,v));
				}
			}
		}
		a[i]=b[i];a[mx]=b[mx];
	}
	printf("%lld\n",ans);
}
