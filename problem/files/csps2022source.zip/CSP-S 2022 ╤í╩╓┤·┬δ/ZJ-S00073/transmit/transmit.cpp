#include<bits/stdc++.h>
using namespace std;
long long n,q,k,a[200001],dep[200001],sum[200001],to[21][200001],ed,ff[200001],f[2001][2001],p[200001],top;
vector<int> v[200001];
inline void dfs(int x,int fa){
sum[x]+=a[x];
for (int i=0;i<v[x].size();++i){
int y=v[x][i]; if (y==fa) continue;
dep[y]=dep[x]+1; sum[y]=sum[x]; dfs(y,x);
to[0][y]=x;
}
}
inline bool dfss(int x,int fa){
if (x==ed){p[++top]=a[x]; return 1;}
for (int i=0;i<v[x].size();++i){
int y=v[x][i]; if (y==fa) continue;
if (dfss(y,x)){p[++top]=a[x]; return 1;}
}
return 0;
}
inline int lca(int x,int y){
if (dep[x]<dep[y]) swap(x,y);
for (int i=20;i>=0;--i) if (dep[to[i][x]]>=dep[y]) x=to[i][x];
if (x==y) return x;
for (int i=20;i>=0;--i) if (to[i][x]!=to[i][y]) x=to[i][x],y=to[i][y];
return to[0][x];
}
inline int dis(int x,int y){
int lcaaa=lca(x,y);
return dep[x]+dep[y]-dep[lcaaa]-dep[lcaaa];
}
int main(){
freopen("transmit.in","r",stdin);
freopen("transmit.out","w",stdout);
ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
cin>>n>>q>>k;
for (int i=1;i<=n;++i) cin>>a[i];
for (int i=1;i<n;++i){
int x,y;
cin>>x>>y;
v[x].push_back(y);
v[y].push_back(x);
}
dfs(1,0); to[0][1]=1;
for (int i=1;i<=20;++i) for (int j=1;j<=n;++j) to[i][j]=to[i-1][to[i-1][j]];
if (k==1){
while (q--){
int x,y;
cin>>x>>y;
int lcaaa=lca(x,y);
cout<<sum[x]+sum[y]-sum[lcaaa]-sum[lcaaa]+a[lcaaa]<<'\n';
}
return 0;
}
if (n<=200){
for (int i=1;i<=n;++i) for (int j=1;j<=n;++j) f[i][j]=1e18;
for (int i=1;i<=n;++i) f[i][i]=0;
for (int i=1;i<=n;++i) for (int j=1;j<=n;++j)
if (i!=j && dis(i,j)<=k) f[i][j]=a[j];
for (int k=1;k<=n;++k) for (int i=1;i<=n;++i) for (int j=1;j<=n;++j)
f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
while (q--){
int x,y;
cin>>x>>y;
cout<<f[x][y]+a[x]<<'\n';
}
return 0;
}
while (q--){
int x,y;
cin>>x>>y;
ed=y; top=0;
dfss(x,0);
ff[0]=0;
for (int i=1;i<=top;++i){
ff[i]=ff[i-1]+a[i];
if (i>1) ff[i]=min(ff[i],ff[i-2]+a[i]);
}
cout<<ff[top]<<'\n';
}
return 0;
}
