#include<bits/stdc++.h>
using namespace std;
long long n,m,a[2501],k,dis[2501],ans=0;
bool b[2501][2501];
vector<int> v[2501],d[2501];
queue<int> q;
inline bool cmp(int aa,int bb){return a[aa]>a[bb];}
inline void bfs(int st){
for (int i=1;i<=n;++i) dis[i]=1e9;
dis[st]=-1;
q.push(st);
while (!q.empty()){
int x=q.front(); q.pop();
b[st][x]=1;
if (dis[x]==k) continue;
for (int i=0;i<v[x].size();++i){
int y=v[x][i];
if (dis[y]==1e9) dis[y]=dis[x]+1,q.push(y);
}
}
}
int main(){
freopen("holiday.in","r",stdin);
freopen("holiday.out","w",stdout);
ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
cin>>n>>m>>k;
for (int i=2;i<=n;++i) cin>>a[i];
for (int i=1;i<=m;++i){
int x,y;
cin>>x>>y;
v[x].push_back(y);
v[y].push_back(x);
}
for (int i=1;i<=n;++i) bfs(i);
//for (int i=1;i<=n;++i) for (int j=1;j<=n;++j) cout<<b[i][j]<<(j==n?'\n':' ');
for (int i=2;i<=n;++i){
for (int j=1;j<=n;++j) if (j!=i && j!=1 && b[1][j] && b[i][j]) d[i].push_back(j);
}
for (int i=2;i<=n;++i) sort(d[i].begin(),d[i].end(),cmp);
//for (int i=2;i<=n;++i){
//cout<<"NOW:"<<i<<':';
//for (int j=0;j<d[i].size();++j) cout<<d[i][j]<<' '; cout<<'\n';
//}
for (int x=2;x<n;++x) for (int y=x+1;y<=n;++y) if (b[x][y]){
if (!(int(d[x].size())) || !(int(d[y].size()))) continue;
int xp=d[x][0],nx=0,yp=d[y][0],ny=0;
if (xp==y){
if (int(d[x].size())>1) xp=d[x][1],nx=1;
else continue; 
}
if (yp==x){
if (int(d[y].size())>1) yp=d[y][1],ny=1;
else continue; 
}
if (xp==yp){
int pp=0;
if (int(d[x].size())>nx+1) pp=d[x][nx+1];
if (int(d[y].size())>ny+1){
if (!pp) pp=d[y][ny+1];
else if (a[d[y][ny+1]]>a[pp]) pp=d[y][ny+1];
}
if (pp){
ans=max(ans,a[x]+a[y]+a[xp]+a[pp]);
}
}
else{
ans=max(ans,a[x]+a[y]+a[xp]+a[yp]);
}
}
cout<<ans;
return 0;
}
