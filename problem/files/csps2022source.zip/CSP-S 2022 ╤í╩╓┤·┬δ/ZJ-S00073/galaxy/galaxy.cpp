#include<bits/stdc++.h>
using namespace std;
long long n,m,q,r[500001],las[5],sum;
unordered_map<long long,int> mp;
vector<int> v[500001],bv[500001];
inline void upd(int x,int z){
if (r[x]==1) --sum;
r[x]+=z;
if (r[x]==1) ++sum;
}
inline void ck(){
if (sum==n) cout<<"YES\n";
else cout<<"NO\n";
}
int main(){
freopen("galaxy.in","r",stdin);
freopen("galaxy.out","w",stdout);
ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
cin>>n>>m;
for (int i=1;i<=m;++i){
int x,y;
cin>>x>>y;
v[x].push_back(y);
bv[y].push_back(x);
++r[x];
mp[x*n+y]=1;
}
for (int i=1;i<=n;++i) if (r[i]==1) ++sum;
cin>>q;
while (q--){
int op;
cin>>op;
if (op==1){
int x,y;
cin>>x>>y;
if (las[1]==1 && las[2]==x && las[3]==y);
else
if (mp[x*n+y]) mp[x*n+y]=0,upd(x,-1);
las[1]=1; las[2]=x; las[3]=y;
}
if (op==2){
int x;
cin>>x;
if (las[1]==2 && las[2]==x);
else
for (int i=0;i<bv[x].size();++i)
if (mp[bv[x][i]*n+x]) mp[bv[x][i]*n+x]=0,upd(bv[x][i],-1);
las[1]=2; las[2]=x;
}
if (op==3){
int x,y;
cin>>x>>y;
if (las[1]==3 && las[2]==x && las[3]==y);
else
if (!mp[x*n+y]) mp[x*n+y]=1,upd(x,1);
las[1]=3; las[2]=x; las[3]=y;
}
if (op==4){
int x;
cin>>x;
if (las[1]==4 && las[2]==x);
else
for (int i=0;i<bv[x].size();++i)
if (!mp[bv[x][i]*n+x]) mp[bv[x][i]*n+x]=1,upd(bv[x][i],1);
las[1]=4; las[2]=x;
}
//for (int i=1;i<=n;++i) cout<<r[i]<<' '; cout<<'\n';
ck();
}
return 0;
}
