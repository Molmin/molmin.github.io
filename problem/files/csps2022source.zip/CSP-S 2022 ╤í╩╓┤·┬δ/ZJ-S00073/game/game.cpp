#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a[200001],b[200001],lg[200001];
long long fp[200001],fm[200001];
struct st{
long long a[21][200001],len,op;
inline void ma(){
for (long long i=1;i<=20;++i) for (long long j=1;j<=len;++j)
a[i][j]=max(a[i-1][j],a[i-1][min(len,j+(1ll<<(i-1)))]);
}
inline void mi(){
for (long long i=1;i<=20;++i) for (long long j=1;j<=len;++j)
a[i][j]=min(a[i-1][j],a[i-1][min(len,j+(1ll<<(i-1)))]);
}
inline long long query(long long l,long long r){
long long now=lg[r-l+1];
if (!op) return max(a[now][l],a[now][r-(1<<now)+1]);
return min(a[now][l],a[now][r-(1<<now)+1]);
}
}s,ds,dss,ss,ms,ps;
int main(){
freopen("game.in","r",stdin);
freopen("game.out","w",stdout);
ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
cin>>n>>m>>q;
for (int i=2;i<=200000;++i) lg[i]=lg[(i>>1)]+1;
for (int i=1;i<=n;++i) cin>>a[i];
for (int i=1;i<=m;++i) cin>>b[i];
for (int i=1;i<=m;++i) fp[i]=fp[i-1]+(b[i]>0);
for (int i=1;i<=m;++i) fm[i]=fm[i-1]+(b[i]<0);
for (int i=1;i<=n;++i) s.a[0][i]=ss.a[0][i]=a[i];
for (int i=1;i<=n;++i) if (a[i]>=0) ps.a[0][i]=a[i]; else ps.a[0][i]=1e18;
for (int i=1;i<=n;++i) if (a[i]<=0) ms.a[0][i]=a[i]; else ms.a[0][i]=-1e18;
s.len=ps.len=ms.len=ss.len=n;
s.op=ms.op=ds.op=0;
ss.op=ps.op=dss.op=1;
ds.len=dss.len=m;
for (int i=1;i<=m;++i) ds.a[0][i]=dss.a[0][i]=b[i];
s.ma(); ms.ma(); ds.ma();
ss.mi(); ps.mi(); dss.mi();
while (q--){
int l,r,ll,rr;
cin>>l>>r>>ll>>rr;
if (fp[rr]-fp[ll-1] && fm[rr]-fm[ll-1]){
long long ans=-1e18;
long long x=ps.query(l,r);
if (x<1e18) ans=max(ans,x*dss.query(ll,rr));
x=ms.query(l,r);
if (x>-1e18) ans=max(ans,x*ds.query(ll,rr));
cout<<ans<<'\n';
}
else if (fp[rr]-fp[ll-1]){
long long x=s.query(l,r);
if (x>=0) cout<<dss.query(ll,rr)*x<<'\n';
else cout<<ds.query(ll,rr)*x<<'\n';
}
else if (fm[rr]-fm[ll-1]){
long long x=ss.query(l,r);
if (x<=0) cout<<x*ds.query(ll,rr)<<'\n';
else cout<<x*dss.query(ll,rr)<<'\n';
}
else cout<<0<<'\n';
}
return 0;
}
