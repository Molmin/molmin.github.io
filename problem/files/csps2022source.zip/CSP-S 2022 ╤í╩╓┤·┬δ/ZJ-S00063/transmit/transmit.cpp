#define ssh(x)<x>
#include ssh(bits/stdc++.h)
#define rfor(x...)for(register x)
#define rep(i,l,r)rfor(ll i=l;i<=r;i++)
#define ref(i,l,r)rfor(ll i=l;i<r;i++)
#define per(i,l,r)rfor(ll i=l;i>=r;i--)
#define rev(i,u,v)rfor(ll i=head[u],v;v=to[i],i;i=next[i])
#define red(i,n)rfor(ll i=n;i;i>>=1)
#define rej(i,s)rfor(ll i=s;i;i=(i-1)&(s))
#define IO(x...)((*#x!='/'||#x[1])&&(*#x&&freopen(#x".in","r",stdin)&&freopen(#x".out","w",stdout),gc=fgc,pc=fpc,atexit(fout)))
typedef long long ll;
typedef unsigned long long ull;
typedef const ll cll;
cll N=1e6+7,mod=1e9+7,iz=1<<21,oz=1<<22,iv2=(mod+1)/2,root=3;
typedef ll aN[N];
char is[iz],*i1=is,*i2=is,os[oz],*o1=os,*o2=os+oz;
int fgc(){
    return i1==i2&&is==(i2=is+fread(i1=is,1,iz,stdin))?-1:*i1++;
}
void fout(){
    fwrite(os,o1-os,1,stdout),o1=os;
}
int fpc(int c){
    if(o1==o2)fout();
    return*o1++=c;
}
int(*gc)()=getchar,(*pc)(int)=putchar,wt[126];
int readchar(int l=33,int r=126){
    if(l>r)std::swap(l,r);
    int c=gc();
    for(;c<l||c>r;c=gc());
    return c;
}
ll readll(){
    ll x=0,w=1;
    int c=gc();
    for(;c<48||c>57;c=gc())c-45||(w=-w);
    for(;c>47&&c<58;c=gc())x=x*10+c-48;
    return x*w;
}
void writell(cll u,int c=32){
    int t=0;
    rfor(ull n=u<0?pc(45),0ull-u:u;n;n/=10)wt[++t]=n%10^48;
    for(t||pc(48);t;)pc(wt[t--]);
    c&&pc(c);
}
int mygets(char*s,int c=0){
    char*t=s+1;
    while((*s=gc())<33);
    while((*t=gc())>32)t++;
    c&&(*t++=c),*t=0;
    return t-s;
}
int myputs(const char*s,int c=10){
    const char*t=s;
    while(*t)pc(*t++);
    c&&pc(c);
    return t-s+(c!=0);
}
cll IO_res=IO(transmit),T=1;
bool p1;
void init(){
}
aN next,to,head;
ll cnt=0;
void add(cll u,cll v){
    next[++cnt]=head[u],to[head[u]=cnt]=v;
}
aN st[23],deep,a,w,dfn,end,f;
ll top;
ll min2(cll u,cll v){
    return deep[u]<deep[v]?u:v;
}
ll lca(ll u,ll v){
    if(u==v)return u;
    //printf("====%lld %lld\n",u,v);
    if((u=dfn[u])>(v=dfn[v]))std::swap(u,v);
    //printf("====%lld %lld\n",u,v);
    cll lg=31^__builtin_clz(v-u++);
    //printf("====%lld %lld %lld\n",u,v,lg);
    return f[min2(st[lg][u],st[lg][v-(1<<lg)+1])];
}
void dfs0(cll u,cll fa){
    w[u]=a[u]+w[fa],deep[u]=deep[fa]+1,f[u]=fa;
    st[0][dfn[u]=++top]=u;
    rev(i,u,v)if(v^fa)dfs0(v,u);
    end[u]=top;
}
struct sgt{
    struct node{
        ll val[2][2];
        //std::vector<ll>z;
        void print()const{
            //for(std::vector<ll>::const_iterator i=z.begin();i!=z.end();)writell(*i++);
            //pc(10);
        }
        void merge(const node&a,const node&b){
            //std::vector<ll>r;
            //for(std::vector<ll>::const_iterator i=a.z.begin();i!=a.z.end();)r.push_back(*i++);
            //for(std::vector<ll>::const_iterator i=b.z.begin();i!=b.z.end();)r.push_back(*i++);
            ll c[2][2];
            memset(c,0x3f,sizeof c);
            rep(i,0,1)rep(j,0,1)rep(k,0,!j)rep(l,0,1)c[i][l]=std::min(c[i][l],a.val[i][j]+b.val[k][l]);
            memcpy(val,c,sizeof c);
            //r.swap(z);
        }
        void reverse(){
            //std::reverse(z.begin(),z.end());
            ll c[2][2];
            rep(i,0,1)rep(j,0,1)c[j][i]=val[i][j];
            memcpy(val,c,sizeof c);
        }
        void set(cll u){
            //z.clear(),z.push_back(u);
            memset(val,0x3f,sizeof val);
            val[1][1]=0,val[0][0]=u;
        }
    };
    node f[N];
    ll n;
    void pushup(cll u){
        f[u].merge(f[u<<1],f[u<<1|1]);
    }
    void set(cll n_,cll a[],cll dfn[]){
        n=2<<(31^__builtin_clz(n_+2));
        rep(i,0,n)memset(f[i+n].val,0x3f,sizeof f[i+n].val);
        rep(i,1,n_)f[n+dfn[i]].set(a[i]);
        per(i,n-1,1)pushup(i);
    }
    node query(ll l,ll r)const{
        //fprintf(stderr,"l=%lld,r=%lld\n",l,r);
        node lres,rres;
        ll emptyl=1,emptyr=1;
        for(l+=n-1,r+=n+1;l^r^1;l>>=1,r>>=1)
            ~l&1&&(emptyl?lres=f[l^1],emptyl=0:(lres.merge(lres,f[l^1]),0)),
            r&1&&(emptyr?rres=f[r^1],emptyr=0:(rres.merge(f[r^1],rres),0));
        node zres=lres;
        ll emptyz=emptyl;
        if(!emptyr)emptyz?zres=rres,emptyz=0:(zres.merge(zres,rres),0);
        //zres.print();
        return zres;
    }
}dt;
sgt::node zs[N];
aN sz,s,tp;
void dfs2(cll u,cll fa){
    w[u]=a[u]+w[fa],deep[u]=deep[fa]+1,f[u]=fa;
    rev(i,u,v)if(v^fa)dfs2(v,u),sz[u]+=sz[v],sz[v]>sz[s[u]]&&(s[u]=v);
}
void dfs3(cll u,cll fa){
    dfn[u]=++top,tp[u]=s[fa]==u?tp[fa]:u;
    zs[u].set(a[u]);
    if(tp[u]!=u)zs[u].merge(zs[u],zs[fa]);
    if(s[u])dfs3(s[u],u);
    rev(i,u,v)if(v^fa&&v^s[u])dfs3(v,u);
    end[u]=top;
}
namespace calc3{
    struct sgt{
        struct node{
            ll val[3][3],sz;
            /*std::vector<ll>z;
            void print()const{
                for(std::vector<ll>::const_iterator i=z.begin();i!=z.end();)writell(*i++);
                pc(10);
            }*/
            void merge(const node&a,const node&b){
            /*a.print(),b.print();
            std::vector<ll>r;
            for(std::vector<ll>::const_iterator i=a.z.begin();i!=a.z.end();)r.push_back(*i++);
            for(std::vector<ll>::const_iterator i=b.z.begin();i!=b.z.end();)r.push_back(*i++);*/
            //printf("a=%lld b=%lld c=%lld d=%lld\n",a.val[0][1],b.val[1][0],a.val[0][1]+b.val[1][0],a.val[0][0]);
                ll c[3][3];
                memset(c,0x3f,sizeof c);
                rep(i,0,2)rep(j,0,2)rep(k,0,2-j)rep(l,0,2)c[i][l]=std::min(c[i][l],a.val[i][j]+b.val[k][l]);
                if(a.sz==1&&b.sz==1)c[1][0]=std::min(c[1][0],b.val[0][0]),
                c[0][1]=std::min(c[0][1],a.val[0][0]);//,printf("???%lld\n",a.val[0][0]);
                if(a.sz==2&&b.sz==1)c[0][2]=std::min(c[0][2],a.val[0][1]);
                if(a.sz==1&&b.sz==2)c[2][0]=std::min(c[2][0],b.val[1][0]);
                sz=a.sz+b.sz;
                memcpy(val,c,sizeof c);
               // printf("???%lld\n",val[0][1]);
            //r.swap(z);
            //print();
            }
            void reverse(){
            //std::reverse(z.begin(),z.end());
                ll c[3][3];
                rep(i,0,2)rep(j,0,2)c[j][i]=val[i][j];
                memcpy(val,c,sizeof c);
            }
            void set(cll u,cll g){
            //z.clear(),z.push_back(u);
                sz=1;
                memset(val,0x3f,sizeof val);
                //val[2][2]=0;
                val[1][1]=g,val[0][0]=u;
            }
        };
        node f[N];
        ll n;
        void pushup(cll u){
            f[u].merge(f[u<<1],f[u<<1|1]);
        }
        void set(cll n_,cll a[],cll g[],cll dfn[]){
            n=2<<(31^__builtin_clz(n_+2));
            rep(i,0,n)memset(f[i+n].val,0x3f,sizeof f[i+n].val);
            rep(i,1,n_)f[n+dfn[i]].set(a[i],g[i]);
            per(i,n-1,1)pushup(i);
        }
        node query(ll l,ll r)const{
            node lres,rres;
            ll emptyl=1,emptyr=1;
            for(l+=n-1,r+=n+1;l^r^1;l>>=1,r>>=1)
                ~l&1&&(emptyl?lres=f[l^1],emptyl=0:(lres.merge(lres,f[l^1]),0)),
                r&1&&(emptyr?rres=f[r^1],emptyr=0:(rres.merge(f[r^1],rres),0));
            node zres=lres;
            ll emptyz=emptyl;
            if(!emptyr)emptyz?zres=rres,emptyz=0:(zres.merge(zres,rres),0);
            return zres;
        }
    }dt;
    sgt::node zs[N];
    aN g;
    void dfs2(cll u,cll fa){
        w[u]=a[u]+w[fa],deep[u]=deep[fa]+1,f[u]=fa;
        g[u]=a[u];
        if(fa)g[u]=std::min(a[u],a[fa]);
        rev(i,u,v)if(v^fa)dfs2(v,u),sz[u]+=sz[v],sz[v]>sz[s[u]]&&(s[u]=v),g[u]=std::min(g[u],a[v]);
    }
    void dfs3(cll u,cll fa){
        dfn[u]=++top,tp[u]=s[fa]==u?tp[fa]:u;
        zs[u].set(a[u],g[u]);
        if(tp[u]!=u)zs[u].merge(zs[u],zs[fa]);
        if(s[u])dfs3(s[u],u);
        rev(i,u,v)if(v^fa&&v^s[u])dfs3(v,u);
        end[u]=top;
    }
    void calc(cll n,cll q,cll k){
        static_cast<void>(k);
        pc=putchar;
        dfs2(1,0),dfs3(1,0),dt.set(n,a,g,dfn);
        //rep(i,1,n)printf("%lld\n",g[i]);
        rep(i,1,q){
            ll u=readll(),v=readll();
            sgt::node lres,rres;
            ll emptyl=1,emptyr=1;
            while(tp[u]!=tp[v]){
                //fprintf(stderr,"u=%lld v=%lld\n",u,v);
                if(deep[tp[u]]<=deep[tp[v]]){
                    sgt::node d=zs[v];
                    d.reverse();
                    emptyr?rres=d,emptyr=0:(rres.merge(d,rres),0);
                    v=f[tp[v]];
                }else{
                    sgt::node d=zs[u];
                    emptyl?lres=d,emptyl=0:(lres.merge(lres,d),0);
                    u=f[tp[u]];
                }
            }
            if(deep[u]<=deep[v]){
                sgt::node d=dt.query(dfn[u],dfn[v]);
                d.reverse();
                emptyr?rres=d,emptyr=0:(rres.merge(d,rres),0);
                v=tp[v];
            }else{
                sgt::node d=dt.query(dfn[v],dfn[u]);
                emptyl?lres=d,emptyl=0:(lres.merge(lres,d),0);
                u=tp[u];
            }
            //exit(0);
            sgt::node zres=lres;
            ll emptyz=emptyl;
            if(!emptyr)emptyz?zres=rres,emptyz=0:(zres.merge(zres,rres),0);
            //zres.print();
            writell(zres.val[0][0],10);
        }
    }
}
void calc(){
    cll n=readll(),q=readll(),k=readll();
    rep(i,1,n)a[i]=readll();
    rep(i,2,n){
        cll u=readll(),v=readll();
        add(u,v),add(v,u);
    }
    if(k==1){
        dfs0(1,0);
        //rep(i,1,n)fprintf(stderr,"%lld%c",dfn[i],i==n?10:32);
        rep(i,0,20)rep(j,1,n-(2<<i)+1)st[i+1][j]=min2(st[i][j],st[i][j+(1<<i)]);
        rep(i,1,q){
            cll u=readll(),v=readll(),l=lca(u,v);
            //fprintf(stderr,"%lld %lld %lld\n",u,v,l);
            writell(w[u]+w[v]-w[l]-w[f[l]],10);
        }
    }
    if(k==2){
        dfs2(1,0),dfs3(1,0),dt.set(n,a,dfn);
        rep(i,1,q){
            ll u=readll(),v=readll();
            sgt::node lres,rres;
            ll emptyl=1,emptyr=1;
            while(tp[u]!=tp[v]){
                //fprintf(stderr,"u=%lld v=%lld\n",u,v);
                if(deep[tp[u]]<=deep[tp[v]]){
                    sgt::node d=zs[v];
                    d.reverse();
                    emptyr?rres=d,emptyr=0:(rres.merge(d,rres),0);
                    v=f[tp[v]];
                }else{
                    sgt::node d=zs[u];
                    emptyl?lres=d,emptyl=0:(lres.merge(lres,d),0);
                    u=f[tp[u]];
                }
            }
            if(deep[u]<=deep[v]){
                sgt::node d=dt.query(dfn[u],dfn[v]);
                d.reverse();
                emptyr?rres=d,emptyr=0:(rres.merge(d,rres),0);
                v=tp[v];
            }else{
                sgt::node d=dt.query(dfn[v],dfn[u]);
                emptyl?lres=d,emptyl=0:(lres.merge(lres,d),0);
                u=tp[u];
            }
            //exit(0);
            sgt::node zres=lres;
            ll emptyz=emptyl;
            if(!emptyr)emptyz?zres=rres,emptyz=0:(zres.merge(zres,rres),0);
            //zres.print();
            writell(zres.val[0][0],10);
        }
    }
    if(k==3)calc3::calc(n,q,k);
}
bool p2;
int main(){
    //fprintf(stderr,"%fMiB\n",(&p2-&p1)/1048576.0);
    init();
    rep(i,1,T)calc();
    return 0;
}
/*
7 4 2
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2
2 4
*/
