#include<bits/stdc++.h>
using namespace std;

int n,m,k;
vector<int>road[2510];
int tmp[2510][2510],dis[2510][2510],ff[2510];
long long sc[2510];

struct node
{
	int id,step;
};

inline void build(int st,int ed)
{
	queue<node>q;
	bool f[2510];
	memset(f,0,sizeof(f));
	f[st]=1;
	node u={st,0};
	q.push(u);
	while(!q.empty())
	{
		u=q.front();
		//cout<<u.id<<endl;
		q.pop();
		int ttmp=road[u.id].size();
		for(int i=0;i<ttmp;i++)
		{
			node v={road[u.id][i],u.step+tmp[u.id][road[u.id][i]]};
			if(v.step>k+1)continue;
			if(f[v.id]==1)continue;
			if(dis[st][v.id]==-1)road[st].push_back(v.id);
			if(dis[st][v.id]==-1)road[v.id].push_back(st);
			if(tmp[v.id][st]==-1 || v.step<tmp[v.id][st])tmp[v.id][st]=tmp[st][v.id]=v.step;
			if(dis[v.id][st]==-1 || (v.step-1)<dis[v.id][st])dis[v.id][st]=dis[st][v.id]=v.step-1;
			if(v.id==ed)
				return ;
			q.push(v);
			f[v.id]=1;
		}
	}
}


unsigned long long ans;

struct edge
{
	int id,x;
	long long st;
};

//int opt[10];
//int cnt=0;

void dfs(int x,unsigned long long st,int id)
{
	if(x==4)
	{
		if(dis[id][1]==-1)return ;/*
		for(int i=1;i<=4;i++)
		{
			cout<<opt[i]<<" ";
		}
		cout<<endl<<st<<endl;*/
		if(ans>st)return ;
		else ans=st;
		return ;
	}
	for(int i=0;i<road[id].size();i++)
	{
		int tmp=road[id][i];
		if(ff[tmp]==1)continue;
		//cout<<id<<"->"<<tmp<<" "<<x<<"\n";
		if(x!=3)
		{
			ff[tmp]=1;
			//opt[++cnt]=tmp;
			dfs(x+1,st+sc[tmp],tmp);
			ff[tmp]=0;
			//cnt--;
		}
		else dfs(x+1,st+sc[tmp],tmp);
	}
	return ;
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(tmp,-1,sizeof(tmp));
	memset(dis,-1,sizeof(dis));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)
		scanf("%lld",&sc[i+1]);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		road[x].push_back(y);
		road[y].push_back(x);
		tmp[x][y]=tmp[y][x]=1;
		dis[x][y]=dis[y][x]=0;
	}
	if(k!=0)
		for(int i=1;i<=n;i++)
			for(int j=i+1;j<=n;j++)
				if(dis[i][j]==-1)build(i,j);
	/*
	for(int i=1;i<=n;i++)
	{
		cout<<i<<": ";
		for(int j=0;j<road[i].size();j++)
			cout<<road[i][j]<<" ";
		puts("");
	}*/
	memset(ff,0,sizeof(ff));
	ff[1]=1;
	dfs(0,0,1);
	printf("%llu\n",ans);
}
