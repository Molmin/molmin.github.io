#include<bits/stdc++.h>
using namespace std;

struct tr
{
	int x,y;
	long long mn;
};

int n,m,q;
int nn[4260],mm[4260];
long long tmp[10010];
tr tree[4260][17010];

long long _min(long long x,long long y)
{
	return x>y? y:x;
}

long long _max(long long x,long long y)
{
	return x>y? x:y;
}

void build(int id,int l,int r,int root)
{
	tree[id][root].x=l;
	tree[id][root].y=r;
	if(l==r)
	{
		tree[id][root].mn=tmp[l];
		return ;
	}
	int mid=(l+r)>>1;
	build(id,l,mid,root*2);
	build(id,mid+1,r,root*2+1);
	tree[id][root].mn=_min(tree[id][root*2].mn,tree[id][root*2+1].mn);
}

long long query(int id,int l,int r,int root)
{
	int ql=tree[id][root].x,qr=tree[id][root].y;
	if(l<=ql && qr<=r)return tree[id][root].mn;
	int mid=(ql+qr)>>1;
	long long mn=0x3f3f3f3f3f3f3f3f;
	if(l<=mid)mn=_min(mn,query(id,l,r,root*2));
	if(r>mid)mn=_min(mn,query(id,l,r,root*2+1));
	return mn;
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&nn[i]);
	for(int j=1;j<=m;j++)
		scanf("%d",&mm[j]);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
			tmp[j]=nn[i]*1ll*mm[j]*1ll;
		build(i,1,m,1);
	}
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long mx;
		for(int i=l1;i<=r1;i++)
		{
			if(i==l1)mx=query(i,l2,r2,1);
			else mx=_max(mx,query(i,l2,r2,1));
		}
		printf("%lld\n",mx);
	}
}
