#include<bits/stdc++.h>
using namespace std;

int n,m,q;
bool f[1010][1010];
vector<int>rd[1010];
vector<int>rdd[1010];
int in[1010];

bool bfs(int st)
{
	queue<int>q;
	q.push(st);
	bool ff[1010];
	memset(ff,0,sizeof(ff));
	ff[st]=1;
	while(!q.empty())
	{
		int u=q.front();
		q.pop();
		int tmp=rd[u].size();
		for(int i=0;i<tmp;i++)
		{
			if(f[u][rdd[u][i]]==0)continue;
			if(ff[rdd[u][i]]==1)return 1;
			q.push(rdd[u][i]);
		}
	}
}

bool check()
{
	for(int i=1;i<=n;i++)
	{
		if(in[i]>1)return 0;
	}
	for(int i=1;i<=n;i++)
		if(bfs(i)==0)return 0;
	return 1;
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		rd[y].push_back(x);
		rdd[x].push_back(y);
		f[x][y]=1;
		in[y]++;
	}
	scanf("%d",&q);
	while(q--)
	{
		int t;
		scanf("%d",&t);
		if(t==1)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			if(f[u][v]==1)in[v]--;
			f[u][v]=0;
		}
		if(t==2)
		{
			int u;
			scanf("%d",&u);
			for(int i=0;i<rd[u].size();i++)
				f[rd[u][i]][u]=0;
			in[u]=0;
		}
		if(t==3)
		{
			int u,v;
			scanf("%d%d",&u,&v);
			if(f[u][v]==1)in[v]++;
			f[u][v]=1;
		}
		if(t==4)
		{
			int u;
			scanf("%d",&u);
			for(int i=0;i<rd[u].size();i++)
				f[rd[u][i]][u]=1;
			in[u]=rd[u].size();
		}
		printf("%s\n",check()==0? "NO":"YES");
	}
}
