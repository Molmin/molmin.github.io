#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int res=0;char ch=getchar();
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res;
}
int n,m,rx,ry,q,k;
int a[5005][5005];
int c[500005];//�����ĳ涴 
 
int f[5005][5005];
inline bool check(){
	for(int i=1;i<=n;i++)if(c[i]!=1)return false;
	return true;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();
	m=read();
	for(int i=1;i<=m;i++){
		rx=read();ry=read();
		a[rx][ry]=true;//���� 
		c[rx]++;
	}
	q=read();
	for(int t=1;t<=q;t++){
		k=read();
		if(k==1){
			rx=read();ry=read();
			f[rx][ry]=true;//���߻� 
			c[rx]--;
		}
		if(k==2){
			ry=read();
			for(int i=1;i<=n;i++){
				if(f[i][ry]==false&&i!=ry&&a[i][ry]==true){
					f[i][ry]=true;
					c[i]--;
				}
			}
		}
		if(k==3){
			rx=read();ry=read();
			f[rx][ry]=false;//���޸�
			c[rx]++;
		}
		if(k==4){
			ry=read();
			for(int i=1;i<=n;i++){
				if(f[i][ry]==true&&i!=ry&&a[i][ry]==true){
					f[i][ry]=false;
					c[i]++;
				}
			}
		}
		if(check()==true)cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
/*

*/
