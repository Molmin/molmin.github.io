#include<bits/stdc++.h>
using namespace std;
inline long long read(){
	long long res=0,f=1;char ch=getchar();
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res*f;
}
long long n,m,q;
long long a[100005],b[100005];
long long la,lb,ra,rb;
long long ca,cb;
bool f,va,vb;
long long ans;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
		if(a[i]<0)va=true;
	}
	for(int i=1;i<=m;i++){
		b[i]=read();
		if(a[i]<0)va=true;
	}
	if(va==false&&vb==false){
		for(int t=1;t<=q;t++){
			ca=-1e9;
			cb=1e9;
			la=read();ra=read();
			lb=read();rb=read();
			for(int i=la;i<=ra;i++)ca=max(ca,a[i]);
			for(int i=lb;i<=rb;i++)cb=min(cb,b[i]);
			cout<<ca*cb<<endl;
		}
	}
	
	else{
		for(int t=1;t<=q;t++){
			la=read();ra=read();
			lb=read();rb=read();
			if(la==ra||lb==rb){
				if(la==ra){
					ca=a[la];
					if(ca==0){
						cout<<0<<endl;
						continue;
					}
					if(ca<0){
						for(int i=lb;i<=rb;i++)cb=max(cb,b[i]);
						cout<<ca*cb<<endl;
						continue;
					}
					if(ca>0){
						for(int i=lb;i<=rb;i++)cb=min(cb,b[i]);
						cout<<ca*cb<<endl;
						continue;
					}
				}
				if(lb==rb){
					cb=b[lb];
					if(cb==0){
						cout<<0<<endl;
					}
					if(cb<0){
						for(int i=lb;i<=rb;i++)ca=min(ca,a[i]);
						cout<<ca*cb<<endl;
					}
					if(cb>0){
						for(int i=lb;i<=rb;i++)ca=max(ca,a[i]);
						cout<<ca*cb<<endl;
					}
				}
			}
			else{
				f=false;
				ca=-1e9;
				cb=1e9;
				for(int i=la;i<=ra;i++){
					if(a[i]==0){
						cout<<0<<endl;
						f=true;
						break;
					}
				}
				if(f==true)continue;
				for(int i=lb;i<=rb;i++){
					if(b[i]==0){
						cout<<0<<endl;
						f=true;
						break;
					}
				}
				
			}
		}
	}
	return 0;
	
}
/*
5 5 2
1 -3 5 -7 9
1 3 -5 7 9
1 3 1 1
4 4 1 2

*/
