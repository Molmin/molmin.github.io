#include<bits/stdc++.h>
using namespace std;
inline long long read(){
	long long res=0;char ch=getchar();
	while(ch>'9'||ch<'0')ch=getchar();
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res;
}
long long rx,ry;
long long n,q,k;
long long a[5005],f[5005][5005];
long long dis[5005][5005];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();q=read();k=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++)dis[i][j]=dis[j][i]=f[i][j]=f[j][i]=1e9;
	}
	for(int i=1;i<=n-1;i++){
		rx=read();ry=read();
		dis[rx][ry]=dis[ry][rx]=1;
	}
	for(int mid=1;mid<=n;mid++){
		for(int i=1;i<=n;i++){
			if(i==mid)continue;
			for(int j=1;j<=n;j++){
				if(i==j||j==mid)continue;
				dis[j][i]=dis[i][j]=min(dis[i][j],dis[i][mid]+dis[mid][j]);
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)if(dis[i][j]<=k&&i!=j){
			f[i][j]=a[j];f[j][i]=a[i];
		}
	}
	for(int mid=1;mid<=n;mid++){
		for(int i=1;i<=n;i++){
			if(i==mid)continue;
			for(int j=1;j<=n;j++){
				if(i==j||j==mid)continue;
				f[i][j]=min(f[i][j],f[i][mid]+f[mid][j]);
			}
		}
	}
	
	for(int t=1;t<=q;t++){
		rx=read();ry=read();
		cout<<f[rx][ry]+a[rx]<<endl;
	}
	
	
	return 0;
	
}
