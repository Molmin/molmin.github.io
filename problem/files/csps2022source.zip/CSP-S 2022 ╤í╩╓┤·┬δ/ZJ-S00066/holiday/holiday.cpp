#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int res=0,f=1;char ch=getchar();
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res*f;
}
int tot=0,nxt[20005],son[20005],fir[2505];
inline void add(int x,int y){
	tot++;
	son[tot]=y;
	nxt[tot]=fir[x];
	fir[x]=tot;
}
int n,m,K;
int rx,ry;
int a[2505];
int ans=0;
bool f;
int x1,x2,x3,x4;
inline void dfs(int step,int k,int now){
	if(now==5){f=true;return;}
	if(k>K)return;
	for(int j=fir[step];j;j=nxt[j]){
		if(f==true)return;
		if(son[j]!=x1&&son[j]!=x2&&son[j]!=x3&&son[j]!=x4&&son[j]!=1)dfs(son[j],k+1,now);
		else if((son[j]==x1&&now==0)||(son[j]==x2&&now==1)||(son[j]==x3&&now==2)||(son[j]==x4&&now==3)||(son[j]==1&&now==4)){
			dfs(son[j],0,now+1);
			
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();K=read();
	for(int i=2;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++){
		rx=read();ry=read();
		add(rx,ry);add(ry,rx);
	}
	for(x1=2;x1<=n;x1++){
		for(x2=2;x2<=n;x2++){
			if(x1==x2)continue;
			for(x3=2;x3<=n;x3++){
				if(x1==x2||x2==x3||x1==x3)continue;
				for(x4=2;x4<=n;x4++){
					if(a[x1]+a[x2]+a[x3]+a[x4]<=ans||x1==x2||x2==x3||x1==x3||x2==x4||x3==x4||x1==x4)continue;
					dfs(1,0,0);
					if(f==true)ans=a[x1]+a[x2]+a[x3]+a[x4],f=false;
					
				}
			}
		}
	}
	cout<<ans;
	return 0;
	
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
