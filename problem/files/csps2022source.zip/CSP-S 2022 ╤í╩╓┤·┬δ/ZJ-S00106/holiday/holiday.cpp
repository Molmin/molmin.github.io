#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=2510;
const ll inf=1e18;
ll score[N];
ll n,m,c;
ll f[N][N];
bool vis[N];
ll maxn;
namespace sub1{
	struct node{
		ll to,nex;
	}e[N*2];
	ll head[N*2],tot;
	void add_edge(ll x,ll y){
		e[++tot].to=y;
		e[tot].nex=head[x];
		head[x]=tot;
	}
	void dfs(ll x,ll fa,ll now,ll k){
		if(k==4){
			bool fl=0;
			for(ll i=head[x];i;i=e[i].nex){
				ll v=e[i].to;
				if(v==1)	fl=1;
			}
			if(fl==0)	return;
			else{
				maxn=max(maxn,now);
				return;
			}
		}
		for(ll i=head[x];i;i=e[i].nex){
			ll v=e[i].to;
			if(v==fa)	continue;
			dfs(v,x,now+score[v],k+1);
		}
	}
	void work(){
		for(ll i=1;i<=m;i++){
			ll x,y;
			cin>>x>>y;
			add_edge(x,y);
			add_edge(y,x);
		}
		dfs(1,0,0,0);
		cout<<maxn<<endl;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>c;
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++){
			if(i==j)	f[i][j]=0;
			else	f[i][j]=inf;
		}
	}
	for(ll i=2;i<=n;i++){
		cin>>score[i];
	}
	if(c==0){
		sub1::work();
		return 0;
	}
	for(ll i=1;i<=m;i++){
		ll x,y;
		cin>>x>>y;
		f[x][y]=1;
		f[y][x]=1;
	}
	for(ll k=1;k<=n;k++){
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=n;j++){
				f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
			}
		}
	}
	c++;
	for(ll i=2;i<=n;i++){
		if(f[1][i]>c)	continue;
		for(ll j=2;j<=n;j++){
			if(j==i)	continue;
			if(f[i][j]>c)	continue;
			for(ll k=2;k<=n;k++){
				if(f[j][k]>c)	continue;
				if(k==i||k==j)	continue;
				for(ll l=2;l<=n;l++){
					if(l==i||l==j||l==k)	continue;
					if(f[k][l]>c||f[l][1]>c)	continue;
					ll now=score[i]+score[j]+score[k]+score[l];
					if(now>maxn){
						maxn=now;
					}
				}
			}
		}
	}
	cout<<maxn<<endl;
	return 0;
}
