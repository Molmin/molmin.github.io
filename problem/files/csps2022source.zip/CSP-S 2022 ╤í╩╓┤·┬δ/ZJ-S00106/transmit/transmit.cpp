#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=2010;
const ll inf=0x3f3f3f3f;
ll dis[N][N];
ll n,q,c;
ll v[N];
ll f[N][N];
bool vis[N];
ll x,y;
ll minn;
struct node{
	ll to,nex;
}e[N*2];
ll head[N*2],tot;
void add_edge(ll x,ll y){
	e[++tot].to=y;
	e[tot].nex=head[x];
	head[x]=tot;
}
namespace sub{
	void dfs(ll x,ll fa,ll now){
		if(x==y){
			minn=min(minn,now);
			return;
		}
		for(ll i=head[x];i;i=e[i].nex){
			ll poll=e[i].to;
			if(poll==fa)	continue;
			dfs(poll,x,now+v[poll]);
		}
	}
	void work(){
		while(q--){
			minn=inf;
			cin>>x>>y;
			dfs(x,0,v[x]);
			cout<<minn<<endl;
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>c;
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++){
			if(i==j)	f[i][j]=0;
			f[i][j]=inf;
		}
	}
	for(ll i=1;i<=n;i++){
		cin>>v[i];
	}
	for(ll i=1;i<n;i++){
		ll a,b;
		cin>>a>>b;
		f[a][b]=1;
		f[b][a]=1;	
		add_edge(a,b);
		add_edge(b,a);
	}
	if(c==1){
		sub::work();
		return 0;
	}
	for(ll k=1;k<=n;k++){
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=n;j++){
				f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
			}
		}
	}
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=n;j++){
		//	if(i==j)	dis[i][j]=0;
			dis[i][j]=inf;
		}
	}
	for(ll i=1;i<=n;i++){
			for(ll j=1;j<=n;j++){
				if(f[i][j]<=c)	dis[i][j]=v[j];
			}
		}
	for(ll k=1;k<=n;k++){
		for(ll i=1;i<=n;i++){
			for(ll j=1;j<=n;j++){
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
			}
		}
	}
	while(q--){		
		cin>>x>>y;
		minn=inf;		
		cout<<dis[x][y]+v[x]<<endl;
	}
	return 0;
}
