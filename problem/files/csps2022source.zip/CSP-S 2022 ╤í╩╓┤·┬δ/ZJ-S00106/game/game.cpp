#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
const int inf=0x3f3f3f3f;
int n,m,q;
int a[N];
int b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	while(q--){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		int maxn=-inf;
		for(int i=l1;i<=r1;i++){
			int now=inf;
			for(int j=l2;j<=r2;j++){
				now=min(now,a[i]*b[j]);
			}
			maxn=max(maxn,now);
		}
		cout<<maxn<<endl;
	}
	return 0;
}
