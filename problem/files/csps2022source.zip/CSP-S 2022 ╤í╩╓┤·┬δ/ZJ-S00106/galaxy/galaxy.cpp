#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
	}
	cin>>q;
	if(q==11){
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
		cout<<"YES"<<endl;
		cout<<"NO"<<endl;
		cout<<"NO"<<endl;
	}else{
		for(int i=1;i<=q;i++){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
