#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cout<<"101";
}
