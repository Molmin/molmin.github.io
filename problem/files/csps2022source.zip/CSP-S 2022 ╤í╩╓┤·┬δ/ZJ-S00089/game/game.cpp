#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int A[10005],B[10005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>A[i];
	for(int i=1;i<=m;i++) cin>>B[i];
	while (q--){
	    int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		int minn=999999;
		int ans=-999999;
		for(int i=l1;i<=r1;i++){
			for(int j=l2;j<=r2;j++){
				minn=min(minn,A[i]*B[j]);
			}
			ans=max(ans,minn);
			minn=999999;
		}
		cout<<ans<<endl;
	}
	return 0;
}
