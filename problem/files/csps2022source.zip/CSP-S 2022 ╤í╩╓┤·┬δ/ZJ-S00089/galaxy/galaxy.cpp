#include<bits/stdc++.h>
using namespace std;
int n,m;//�ݵ��� �涴�� 
int mm[10005][10005];//chngdong
int nn[10005],nnn[10005];
int q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stduot);
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int a,b;
		cin>>a>>b;
		mm[a][b]=1;
	}
	cin>>q;
    while (q--){
    	for(int i=1;i<=n;i++) nn[i]=0;
    	int lll;
    	cin>>lll;
    	if(lll==1) {
    	    int l,ll;
    	    cin>>l>>ll;
    	    mm[l][ll]=-1;
		}
		else if(lll==2){
			int l;
			cin>>l;
			for(int i=1;i<=n;i++) if(mm[i][l]==1) mm[i][l]=-1;
		}
		else if(lll==3){
			int l,ll;
			cin>>l>>ll;
			mm[l][ll]=1;
		}
		else if(lll==4){
			int l;
			cin>>l; 
			for(int i=1;i<=n;i++) if(mm[i][l]==-1) mm[i][l]=1;
		}
	    int ans=0;
	    for(int i=1;i<=n;i++)
	    for(int j=1;j<=n;j++){
		    if(mm[i][j]==1) {
			    nn[j]++;
			    nnn[i]++;
		    }
	    }
	    for(int i=1;i<=n;i++){
		    if(nn[i]==0||nnn[i]==0) ans++;
	    }
	    if(ans>0) cout<<"NO"<<endl;
	    else cout<<"YES"<<endl;
	}
	return 0;
}
