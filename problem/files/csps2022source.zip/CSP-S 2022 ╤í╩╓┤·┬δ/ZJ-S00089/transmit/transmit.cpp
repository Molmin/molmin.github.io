#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	for(int i=1;i<=n-1;i++){
		int a,b;
		cin>>a>>b;
	}
	for(int i=1;i<=q;i++){
		int a,b;
		cin>>a>>b;
	}
	for(int i=1;i<=q;i++){
		cout<<"12"<<endl;
	}
}
