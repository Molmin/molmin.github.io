#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[200003],pd;
long long sum;
bool net[2002][2002];
bool gone[2002];
void dfs(int st,int step,int end){
	if(step==k-1){
		if(!net[st][end]){
			return ;
		}else{
			pd=1;
			return ;
		}
	}
	for(int i=1;i<=n;i++){
		if(net[st][end]==1){
			pd=1;
			return ;
		}
		if(net[st][i]==1&&!gone[i]){
			gone[i]=1;
			dfs(i,step+1,end);
			gone[i]=0;
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;i++){
		int lt1,lt2;
		scanf("%d%d",&lt1,&lt2);
		net[lt1][lt2]=1;
		net[lt2][lt1]=1;
	}
	while(q>0){
		q--;
		int s,t;
		pd=0;
		scanf("%d%d",&s,&t);
		gone[s]=1;
		dfs(s,0,t);
		gone[s]=0;
		sum=10000000000000000;
		if(pd==1){
			sum=v[s]+v[t];
		}else{
			long long ss=0;
			for(int i=1;i<=n;i++){
				pd=0;
				if(i==s||i==t){
					continue;
				}else{
					gone[s]=1;
					dfs(s,0,i);
					gone[s]=0;
					if(pd==1){
						pd=0;
						gone[i]=1;
						dfs(i,0,t);
						gone[i]=0;
						if(pd==1){
							ss=v[s]+v[i]+v[t];
							if(ss<sum)sum=ss;
						}
					}
				}
			}
		}
		printf("%lld\n",sum);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}