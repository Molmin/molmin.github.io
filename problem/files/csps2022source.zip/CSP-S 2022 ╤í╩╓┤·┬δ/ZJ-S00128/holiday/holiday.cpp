#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long ans;
long long jd[2505];
bool rd[2505][2505];
bool ifgo[2505],ig[2050];
int backhome(int x,int he){
	if(rd[x][1])return 1;
	if(he==k){
		if(rd[x][1]){
			return 1;
		}else{
			return 0;
		}
	}
	for(int i=2;i<=n;i++){
		if(ig[i]||!rd[i][x]){
			continue;
		}else{
			ig[i]=1;
			if(backhome(i,he+1)){
				return 1;
			}
		}
	}
	return 0;
} 
void dfs(int now,int s,int zc,long long fs){
	if(s==4){
		memset(ig,0,sizeof(ig));
		if(backhome(now,0)){
			if(fs>ans)ans=fs;
		}
		return ;
	}else{
		for(int i=1;i<=n;i++){
			if(!ifgo[i]&&rd[now][i]){
				ifgo[i]=1;
				dfs(i,s+1,k,fs+jd[i]);
				ifgo[i]=0;
			}
			if(rd[now][i]){
				if(zc>=1){
					dfs(i,s,zc-1,fs);
				}
			}
		}
	}
}
int main(){
	freopen("holoday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%lld",&jd[i]);
	}
	for(int i=1;i<=m;i++){
		int lt1,lt2;
		scanf("%d%d",&lt1,&lt2);
		rd[lt1][lt2]=1;
		rd[lt2][lt1]=1;
	}
	ifgo[1]=1;
	dfs(1,0,k,0);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}