#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long a[100003],b[100003];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
	}
	while(q>0){
		q--;
		int lo,ro,lt,rt;
		long long ans;
		scanf("%d%d%d%d",&lo,&ro,&lt,&rt);
		long long aa=-100000000000000000,a0a=-100000000000000000,i0a=100000000000000000,ia=100000000000000000,ab=-100000000000000000,ib=100000000000000000,ifa0=0,ifb0=0;
		for(int i=lo;i<=ro;i++){
			if(a[i]<0&&a[i]>a0a)a0a=a[i];
			if(a[i]>aa)aa=a[i];
			if(a[i]>0&&a[i]<i0a)i0a=a[i];
			if(a[i]<ia)ia=a[i];
			if(a[i]==0)ifa0=1;
		}
		for(int i=lt;i<=rt;i++){
			if(b[i]>ab)ab=b[i];
			if(b[i]<ib)ib=b[i];
			if(b[i]==0)ifb0=1;
		}
		if(ab>0){
			if(ib>0){
				ans=ib*aa;
			}else if(ib==0){
				if(aa<0){
					ans=aa*ab;
				}else{
					ans=0;
				}
			}else{
				if(ifa0){
					ans=0;
				}else{
					if(aa<0){
						ans=aa*ab;
					}else if(ia>0){
						ans=ia*ib;
					}else{
						ans=max(a0a*ab,i0a*ib);
					}
				}
			}
		}else if(ab==0){
			if(ia>0){
				ans=ia*ib;
			}else{
				ans=0;
			}
		}else{
			if(ia<0){
				ans=ab*ia;
			}else{
				ans=ia*ib;
			}
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}