#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int cd[2004][2004];
void pd(){
	/*
	printf("\n");
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			printf("%d ",cd[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	*/
	int gt[2004]={};
	int pass[2004]={};
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(cd[i][j]==1){
				if(gt[i]!=0){
					printf("NO\n");
					return ;
				}else{
					gt[i]=j;
				}
			}
		}
		if(i>1){
			if(gt[i-1]==0){
				printf("NO\n");
				return ;
			}
		}
	}
	if(gt[n]==0){
		printf("NO\n");
		return ;
	}
	printf("YES\n");
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	memset(cd,-1,sizeof(cd));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int lt1,lt2;
		scanf("%d%d",&lt1,&lt2);
		cd[lt1][lt2]=1;
	}
	scanf("%d",&q);
	while(q>0){
		q--;
		int t,u,v;
		scanf("%d",&t);
		if(t==1||t==3){
			scanf("%d%d",&u,&v);
			if(t==1){
				cd[u][v]=0;
			}else{
				cd[u][v]=1;
			}
		}else{
			scanf("%d",&u);
			if(t==2){
				for(int i=1;i<=n;i++){
					if(cd[i][u]==1){
						cd[i][u]=0;
					}
				}
			}else{
				for(int i=1;i<=n;i++){
					if(cd[i][u]==0){
						cd[i][u]=1;
					}
				}
			}
		}
		pd();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}