#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
int n,m,q;
bool flag;
int a[100005],b[100005];
void solve1() {
	ll mn=1e10,mx=-1e10;
	int l1,r1,l2,r2; 
	for(int i=1;i<=q;i++) {
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		mx=-1e10;
		for(int j=l1;j<=r1;j++) {
			mn=1e10;
			for(int k=l2;k<=r2;k++) {
				mn=min(mn,1ll*a[j]*b[k]);
			}
			mx=max(mn,mx);
		}
		printf("%lld\n",mx);
	}
}
void solve2() {
	ull mn=1e18,mx=0;
	int l1,r1,l2,r2; 
	for(int i=1;i<=q;i++) {
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		mx=0;
		for(int j=l1;j<=r1;j++) {
			mn=1e18;
			for(int k=l2;k<=r2;k++) {
				mn=min(mn,1ull*a[j]*b[k]);
			}
			mx=max(mn,mx);
		}
		printf("%ulld\n",mx);
	}
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	flag=true;
	for(int i=1;i<=n;i++) {
		scanf("%d",&a[i]);
		if(a[i]<0) flag=false;
	}
	for(int i=1;i<=m;i++) {
		scanf("%d",&b[i]);
		if(b[i]<0) flag=false;
	}
	if(n<5000) {
		if(flag==false) solve1();
		else solve2();
	}
	return 0;
}
