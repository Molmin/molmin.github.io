#include<bits/stdc++.h>
using namespace std;
bool f[1001][1001],vis[1001];
int d[10010];
int n,m,q;
struct ysy {
	int to,next;
}out[20020],in[20020];
int head1[10010],head2[10010],cnt1,cnt2;
void addout(int u,int v) {
	out[++cnt1].to=v;
	out[cnt1].next=head1[u];
	head1[u]=cnt1;
}
void addin(int u,int v) {
	in[++cnt2].to=v;
	in[cnt2].next=head2[u];
	head2[u]=cnt2;
}
bool dfs(int x,int F) {
	if(d[x]>1) return false;
	if(vis[x]) return true;
	vis[x]=true;
	int cnt=0;
	for(int i=head1[x];i;i=out[i].next) {
		int y=out[i].to;
		if(f[x][y]==true) {
			dfs(y,F);
		}
	}
	if(x==F) return false;
}
int read() {
	int s=0; char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c<='9'&&c>='0') s=(s<<1)+(s<<3)+c-'0',c=getchar();
	return s;
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(); m=read();
	for(int i=1;i<=m;i++) {
		int u,v; u=read(); v=read();
		addout(u,v); addin(v,u);
		f[u][v]=true;
		d[u]++;
	}
	q=read();
	int opt,u,v; 
	for(int i=1;i<=q;i++) {
		opt=read();
		if(opt==1) {
			u=read(); v=read();
			f[u][v]=false;
			d[u]--;
		}
		if(opt==2) {
			u=read();
			for(int i=head2[u];i;i=in[i].next) {
				v=in[i].to;
				f[v][u]=false;
				d[v]--;
			}
		}
		if(opt==3) {
			u=read(); v=read();
			f[u][v]=true;
			d[u]++;
		}
		if(opt==4) {
			u=read();
			for(int i=head2[u];i;i=in[i].next) {
				v=in[i].to;
				f[v][u]=true;
				d[v]++;
			}
		}
		bool flag=true;
		for(int i=1;i<=n;i++) {
			memset(vis,false,sizeof(vis));
			if(!dfs(i,i)) {
				flag=false; break;
			}
		}
		if(flag) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
