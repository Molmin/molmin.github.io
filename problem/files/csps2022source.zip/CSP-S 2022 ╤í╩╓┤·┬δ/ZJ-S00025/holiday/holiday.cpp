#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
int n,m,k;
ull ans[100],a[100],maxn;
bool vis[100];
struct ysy {
	int to,next;
}e[200];
int head[200],cnt;
void add(int u,int v) {
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
}
struct node {
	int to,next;
}e1[20020];
int head1[20020],cnt1;
void add1(int u,int v) {
	e1[++cnt1].to=v;
	e1[cnt1].next=head1[u];
	head1[u]=cnt1;
}
void dfs1(int x,int step,int F) {
	if(step==k+1) return;
	for(int i=head[x];i;i=e[i].next) {
		int y=e[i].to;
		if(vis[y]) continue;
		vis[y]=true;
		add1(F,y);
		dfs1(y,step+1,F);
	}
}
void dfs(int x,int step) {
	if(step==5) {
		if(x==1) {
			maxn=max(ans[x],maxn);
		}
		return;
	}
	for(int i=head1[x];i;i=e1[i].next) {
		int y=e1[i].to;
		if(vis[y] && (step+1!=5 || y!=1)) continue;
		vis[y]=true;
		ans[y]=ans[x]+a[y];
		dfs(y,step+1);
		ans[y]=0;
		vis[y]=false;
	}
}
int read() {
	int s=0; char c=getchar();
	while(c>'9'||c<'0') c=getchar();
	while(c<='9'&&c>='0') s=(s<<1)+(s<<3)+c-'0',c=getchar();
	return s;
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(); m=read(); k=read();
	if(n>12) return 0;
	for(int i=2;i<=n;i++) {
		scanf("%ulld",&a[i]);
	}
	for(int i=1;i<=m;i++) {
		int u,v; u=read(); v=read();
		add(u,v); add(v,u);
	}
	for(int i=1;i<=n;i++) {
		memset(vis,false,sizeof(vis));
		dfs1(i,0,i);
	}
	memset(vis,false,sizeof(vis));
	dfs(1,0);
	cout<<maxn;
	return 0;
}
