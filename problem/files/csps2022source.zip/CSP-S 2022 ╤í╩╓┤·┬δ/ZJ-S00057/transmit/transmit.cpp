#include<iostream>
#include<cstring>
using namespace std;
int n,t,k,x,y;
int a[200003],dis[10001][10001],f[10001][10001];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&t,&k);
	memset(dis,27,sizeof(dis));
	for(register int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(register int i=1;i<n;i++)
	{
		scanf("%d%d",&x,&y);
		f[x][y]=f[y][x]=0;
		dis[x][y]=dis[y][x]=a[x]+a[y];
	}
	for(register int g=1;g<=n;g++) for(register int i=1;i<n;i++) for(register int j=i+1;j<=n;j++) if(i!=g&&j!=g) f[j][i]=f[i][j]=min(f[i][g]+f[g][j]+1,f[i][j]);
	for(register int g=1;g<=n;g++)
	{
		for(register int i=1;i<n;i++)
		{
			if(f[i][g]>k) continue;
			for(register int j=i+1;j<=n;j++)
			{
				if(f[g][j]<=k)
				{
					dis[i][j]=min(dis[i][j],a[i]+a[g]+a[j]);
				}
			}
		}
	}
	while(t--)
	{
		cin>>x>>y;
		cout<<dis[x][y]<<endl;
	}
	return 0;
}
