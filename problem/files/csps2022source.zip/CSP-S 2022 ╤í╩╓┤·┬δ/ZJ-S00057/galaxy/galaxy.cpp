#include<iostream>
#include<cstring>
#include<queue>
using namespace std;
struct node
{
	int from,next,to,last;
	bool flag;
};
int n,m,t,x,y,num,cnt;
int chu[500003],head[500003],head1[500003],bol[500003];
node edge[500003];
void make(int u,int v)
{
	edge[++cnt].to=v;
	edge[cnt].from=u;
	edge[cnt].next=head[u];
	edge[cnt].last=head1[v];
	head[u]=cnt;
	head1[v]=cnt;
}
bool hui()
{
	memset(bol,0,sizeof(bol));
	queue <int> q;
	q.push(1);
	while(!q.empty())
	{
		int st=q.front();
		q.pop();
		for(int i=head[st];i;i=edge[i].next)
		{
			if(edge[i].flag) continue;
			int v=edge[i].to;
			if(bol[v]) return 1;
			else
			{
				q.push(v);
				bol[v]=1;
			}
		}
	}
	return 0;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		make(x,y);
		chu[x]++;
	}
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&num);
		if(num==1)
		{
			scanf("%d%d",&x,&y);
			for(int i=head[x];i;i=edge[i].next)
			{
				if(edge[i].to==y&&!edge[i].flag)
				{
					chu[x]--;
					edge[i].flag=1;
					break;
				}
			}
		}
		if(num==2)
		{
			scanf("%d",&y);
			for(int i=head1[y];i;i=edge[i].last)
			{
				if(!edge[i].flag)
				{
					edge[i].flag=1;
					chu[edge[i].from]--;
				}
			}
			printf("NO\n");
			goto end;
		}
		if(num==3)
		{
			scanf("%d%d",&x,&y);
			for(int i=head[x];i;i=edge[i].next)
			{
				if(edge[i].to==y&&edge[i].flag)
				{
					chu[x]++;
					edge[i].flag=0;
					break;
				}
			}
		}
		if(num==4)
		{
			scanf("%d",&y);
			for(int i=head1[y];i;i=edge[i].last)
			{
				if(edge[i].flag)
				{
					edge[i].flag=0;
					chu[edge[i].from]++;
				}
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(chu[i]!=1)
			{
				if(t==2) cout<<i<<' '<<chu[i]<<endl;
				printf("NO\n");
				goto end;
			}
		}
		if(!hui())
		{
			printf("NO\n");
			goto end;
		}
		printf("YES\n");
		end:;
	}
	return 0;
}
