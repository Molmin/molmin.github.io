#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int ans,num;
};
int n,m,k,x,y;
int f[2503][2503];
node p[2503];
bool cmp(node x,node y)
{
	return x.ans>y.ans;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(register int i=2;i<=n;i++)
	{
		cin>>p[i].ans;
		p[i].num=i;
	}
	sort(p+2,p+1+n,cmp);
	memset(f,27,sizeof(f));
	for(register int i=1;i<=m;i++)
	{
		cin>>x>>y;
		f[y][x]=f[x][y]=0;
	}
	for(register int g=1;g<=n;g++) for(register int i=1;i<n;i++) for(register int j=i+1;j<=n;j++) if(i!=g&&j!=g) f[j][i]=f[i][j]=min(f[i][g]+f[g][j]+1,f[i][j]);
	for(register int i=2;i<=n;i++)
	{
		if(f[1][p[i].num]>k) continue;
		for(register int j=1;j<=n;j++)
		{
			if(f[p[i].num][p[j].num]>k) continue;
			for(register int g=1;g<=n;g++)
			{
				if(f[p[j].num][p[g].num]>k) continue;
				for(register int h=2;h<=n;h++)
				{
					if(f[p[g].num][p[h].num]>k||f[p[h].num][1]>k) continue;
					if(i==j||i==g||i==h||j==g||j==h||g==h) continue;
					cout<<p[i].ans+p[j].ans+p[g].ans+p[h].ans;
					return 0;
				}
			}
		}
	}
	return 0;
}
