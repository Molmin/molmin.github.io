#include<iostream>
#include<algorithm>
using namespace std;
struct node
{
	int ans,y;
};
int n,m,k,l,r,l1,r1;
int a[100003],b[10003];
node f[10001][10001];
bool cmp(node x,node y)
{
	return x.ans<y.ans;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(register int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(register int i=1;i<=m;i++) scanf("%d",&b[i]);
	for(register int i=1;i<=n;i++) 
	{
		for(register int j=1;j<=m;j++)
		{
			f[i][j].ans=a[i]*b[j];
			f[i][j].y=j;
		}
		sort(f[i]+1,f[i]+1+m,cmp);
	}
	while(k--)
	{
		int maxx=-1e9;
		scanf("%d%d%d%d",&l,&r,&l1,&r1);
		for(register int i=l;i<=r;i++)
		{
			for(register int j=1;j<=m;j++)
			{
				if(f[i][j].y>=l1&&f[i][j].y<=r1)
				{
					maxx=max(maxx,f[i][j].ans);
					break;
				}
			}
		}
		printf("%d\n",maxx);
	}
	return 0;
}
