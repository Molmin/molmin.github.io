#include <bits/stdc++.h>

using namespace std;

const int Max=1005;
int a[Max][Max],f[Max][Max];
int n,m;


int check1()
{
	int ff[Max][Max];
	int i,j;
	memset(ff,0,sizeof(ff));
	
	/*for (i=1;i<=n;i++)
	{
		for (j=1;j<=n;j++)
		{
			if (f[i][j]==1)
			i=1;
		}
	}*/
	
	return 0;
}

int check2()
{
	
	return 0;
}

void check()
{
	if (check1()==1&&check2()==1) cout << "YES" << endl;
	else cout << "NO" << endl;
	return;
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	int i,j,q,u,v,t;
	
	memset(a,0,sizeof(a));
	memset(f,0,sizeof(f));
	
	cin >> n >> m;
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		a[u][v]=1;
		f[u][v]=1;
	}
	cin >> q;
	while (q--)
	{
		cin >> t;
		if (t==1)
		{
			cin >> u >> v;
			f[u][v]=-1;
		}
		if (t==2)
		{
			cin >> u;
			for (i=1;i<=n;i++)
			{
				if (a[i][u]==1) f[i][u]=-1;
			}
		}
		if (t==3)
		{
			cin >> u >> v;
			f[u][v]=1;
		}
		if (t==4)
		{
			cin >> u;
			for (i=1;i<=n;i++)
			{
				if (a[i][u]==1) f[i][u]=1;
			}
		}
		//check();
		cout << "NO" << endl;
	}
	
	
	
	return 0;
}
