#include <bits/stdc++.h>

using namespace std;

const int Max=100005;
int n,m;
long long a[Max],b[Max];
const int M=1000000000;

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	
	int i,j,q;
	cin >> n >> m >> q;
	for (i=1;i<=n;i++) scanf("%lld",&a[i]);
	for (i=1;i<=m;i++) scanf("%lld",&b[i]);
	
	while (q--)
	{
		int l1,l2,r1,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long maxxaz=-M,minnbz=M;
		long long minnaf=M,maxxbf=-M;
		long long maxxbz=-M,minnaz=M;
		long long minnbf=M,maxxaf=-M;
		//cout << a[l1] << " " << maxxf << " " << minnz << " " << minnf << endl;
		
		bool t1=true,t2=true,t3=true,t4=true,t5=true,t6=true; 
		//t1=a not have 0 t2=b not have 0 t3=a>0 t4=a<0 t5=b>0 t6=b<0
		for (i=l1;i<=r1;i++)
		{
			if (a[i]<0) t3=false;
			if (a[i]>0) t4=false;
			if (a[i]>=0) maxxaz=max(maxxaz,a[i]);
			if (a[i]<=0) minnaf=min(minnaf,a[i]);
			if (a[i]>=0) minnaz=min(minnaz,a[i]);
			if (a[i]<=0) maxxaf=max(maxxaf,a[i]);
		}
		for (i=l2;i<=r2;i++)
		{
			if (b[i]<0) t5=false;
			if (b[i]>0) t6=false;
			if (b[i]>=0) minnbz=min(minnbz,b[i]);
			if (b[i]<=0) maxxbf=max(maxxbf,b[i]);
			if (b[i]>=0) maxxbz=max(maxxbz,b[i]);
			if (b[i]<=0) minnbf=min(minnbf,b[i]);
		}
		if (t3&&t5) 
		{
			cout << max(maxxaz*minnbz,maxxbf*minnaf) << endl;
			continue;
		}
		if (t4&&t6)
		{
			cout << max(maxxaz*minnbz,maxxbf*minnaf) << endl;
			continue;
		}
		if (t6&&t3)
		{
			cout << minnaz*minnbf << endl;
			continue;
		}
		if (t5&&t4)
		{
			cout << maxxaf*maxxbz << endl;
			continue;
		}
		if (t6)
		{
			cout << minnaf*maxxbf << endl;
			continue;
		}
		if (t5)
		{
			cout << maxxaz*minnbz << endl;
			continue;
		}
		if (t4)
		{
			cout << maxxaf*maxxbz << endl;
			continue;
		}
		if (t3)
		{
			cout << minnaz*minnbf << endl;
			continue;
		}
		cout << max(maxxaf*maxxbz,minnaz*minnbf) << endl;
	}
	
	return 0;
}
