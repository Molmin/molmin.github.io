#include <bits/stdc++.h>

using namespace std;

const int MAX=2505;
int n,m,k;
int a[MAX][MAX];
long long s[MAX];
int f[MAX]; 
long long summax=0;

void dfs(int now,int num,int sumk,long long sumsum)
{
	int i,j;
	//cout << now << " " << num << " " << sumk << " " << sumsum << endl;
	if (num==5&&now==1) 
	{
		summax=max(summax,sumsum);
		return;
	}
	if (num==5) return;
	for (i=1;i<=n;i++)
	{
		if (a[now][i]==1&&sumk<k) 
		{
			dfs(i,num,sumk+1,sumsum);
		}
		if (a[now][i]==1&&f[i]==0) 
		{
			f[i]=1;
			dfs(i,num+1,0,sumsum+s[i]);
			f[i]=0;
		}
	} 
	return;
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	int i,j;
	memset(a,0,sizeof(a));
	memset(s,0,sizeof(s));
	memset(f,0,sizeof(f));
	
	cin >> n >> m >> k;
	
	for (i=2;i<=n;i++) cin >> s[i];
	for (i=1;i<=m;i++)
	{
		int x,y;
		cin >> x >> y;
		a[x][y]=a[y][x]=1;
	}
	
	dfs(1,0,0,0);
	
	cout << summax;
	
	return 0;
}
