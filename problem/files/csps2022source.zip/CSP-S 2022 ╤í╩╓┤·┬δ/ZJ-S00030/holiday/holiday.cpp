#include<bits/stdc++.h>
using namespace std;
int val[2505],dp[2505][10],n,m,k,a,b;
bool lj[2505][2505];
void doit(int from,int to,int zc,int t){
	if(!t)
		return;
	if(t==1&&zc==k+2){
		if(!lj[to][1])
			return;
		else{
			dp[to][1]=val[to];
			return;			
		}
	}
	if(zc==k+2) return;
	if(t==1){
		for(int i=1;i<=n;i++)
			if(lj[to][i])
				doit(to,i,zc+1,t);
		return;
	}
	dp[to][t]=max(dp[to][t],dp[from][t-1]+val[to]);
	for(int i=1;i<=n;i++)
		if(lj[to][i]){
			doit(to,i,zc+1,t);
			doit(to,i,zc,t-1);
		}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%d",&val[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&a,&b);
		lj[a][b]=lj[b][a]=true;
	}
	doit(1,1,0,5);
	printf("%d\n",dp[1][5]);
	return 0;
}
