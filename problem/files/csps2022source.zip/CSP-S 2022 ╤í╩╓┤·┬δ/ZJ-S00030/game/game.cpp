#include<bits/stdc++.h>
using namespace std;
#define N 3000005
long long n,m,q,a[N],b[N],c1[N],c2[N],c4[N],c5[N],d1[N],d2[N],l1,r1,l2,r2;
bool c3[N];
int minn(int x,int y){
	if(x<=0&&y<=0)
		return x>y?x:y;
	if(x<=0)
		return y;
	if(y<=0)
		return x;
	return x<y?x:y;
}
int maxn(int x,int y){
	if(x>=0&&y>=0)
		return x<y?x:y;
	if(x>=0)
		return y;
	if(y>=0)
		return x;
	return x>y?x:y;
}
void js1min(int x,int y,int z){
	if(x==y){
		c1[z]=a[x];	
		return;	
	}
	int mid=(x+y)/2;
	js1min(x,mid,2*z);
	js1min(mid+1,y,2*z+1);
	c1[z]=minn(c1[2*z],c1[2*z+1]);
}
void js1max(int x,int y,int z){
	if(x==y){
		c2[z]=a[x];	
		return;	
	}
	int mid=(x+y)/2;
	js1max(x,mid,2*z);
	js1max(mid+1,y,2*z+1);
	c2[z]=maxn(c2[2*z],c2[2*z+1]);
}
void js0min(int x,int y,int z){
	if(x==y){
		c4[z]=a[x];	
		return;	
	}
	int mid=(x+y)/2;
	js0min(x,mid,2*z);
	js0min(mid+1,y,2*z+1);
	c4[z]=min(c4[2*z],c4[2*z+1]);
}
void js0max(int x,int y,int z){
	if(x==y){
		c5[z]=a[x];	
		return;	
	}
	int mid=(x+y)/2;
	js0max(x,mid,2*z);
	js0max(mid+1,y,2*z+1);
	c5[z]=max(c5[2*z],c5[2*z+1]);
}
void js0(int x,int y,int z){
	if(x==y){
		if(!a[x])
			c3[z]=true;	
		return;	
	}
	int mid=(x+y)/2;
	js0(x,mid,2*z);
	js0(mid+1,y,2*z+1);
	c3[z]=c3[2*z]||c3[2*z+1];
}
void js2min(int x,int y,int z){
	if(x==y){
		d1[z]=b[x];	
		return;	
	}
	int mid=(x+y)/2;
	js2min(x,mid,2*z);
	js2min(mid+1,y,2*z+1);
	d1[z]=min(d1[2*z],d1[2*z+1]);
}
void js2max(int x,int y,int z){
	if(x==y){
		d2[z]=b[x];	
		return;	
	}
	int mid=(x+y)/2;
	js2max(x,mid,2*z);
	js2max(mid+1,y,2*z+1);
	d2[z]=max(d2[2*z],d2[2*z+1]);
}
int qz1min(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return c1[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz1min(x,y,x1,mid,2*z);
	if(mid<x)
		return qz1min(x,y,mid+1,y1,2*z+1);
	return minn(qz1min(x,mid,x1,mid,2*z),qz1min(mid+1,y,mid+1,y1,2*z+1));
}
int qz1max(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return c2[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz1max(x,y,x1,mid,2*z);
	if(mid<x)
		return qz1max(x,y,mid+1,y1,2*z+1);
	return maxn(qz1max(x,mid,x1,mid,2*z),qz1max(mid+1,y,mid+1,y1,2*z+1));
}
int qz0min(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return c4[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz0min(x,y,x1,mid,2*z);
	if(mid<x)
		return qz0min(x,y,mid+1,y1,2*z+1);
	return min(qz0min(x,mid,x1,mid,2*z),qz0min(mid+1,y,mid+1,y1,2*z+1));
}
int qz0max(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return c5[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz0max(x,y,x1,mid,2*z);
	if(mid<x)
		return qz0max(x,y,mid+1,y1,2*z+1);
	return max(qz0max(x,mid,x1,mid,2*z),qz0max(mid+1,y,mid+1,y1,2*z+1));
}
bool qz0(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return c3[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz0(x,y,x1,mid,2*z);
	if(mid<x)
		return qz0(x,y,mid+1,y1,2*z+1);
	return qz0(x,mid,x1,mid,2*z)||qz0(mid+1,y,mid+1,y1,2*z+1);
}
int qz2min(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return d1[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz2min(x,y,x1,mid,2*z);
	if(mid<x)
		return qz2min(x,y,mid+1,y1,2*z+1);
	return min(qz2min(x,mid,x1,mid,2*z),qz2min(mid+1,y,mid+1,y1,2*z+1));
}
int qz2max(int x,int y,int x1,int y1,int z){
	if(x1==x&&y1==y)
		return d2[z];
	int mid=(x1+y1)/2;
	if(mid>=y)
		return qz2max(x,y,x1,mid,2*z);
	if(mid<x)
		return qz2max(x,y,mid+1,y1,2*z+1);
	return max(qz2max(x,mid,x1,mid,2*z),qz2max(mid+1,y,mid+1,y1,2*z+1));
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	js1min(1,n,1);
	js1max(1,n,1);
	js0(1,n,1);
	js0min(1,n,1);
	js0max(1,n,1);
	js2min(1,m,1);
	js2max(1,m,1);
	for(int i=1;i<=q;i++){
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		long long a1=qz1min(l1,r1,1,n,1),b1=qz1max(l1,r1,1,n,1),c1=qz2min(l2,r2,1,m,1),d1=qz2max(l2,r2,1,m,1);
		if(c1>0)
			printf("%lld\n",c1*qz0max(l1,r1,1,n,1));
		else if(d1<0)
			printf("%lld\n",d1*qz0min(l1,r1,1,n,1));
		else if(qz0(l1,r1,1,n,1))
			printf("%lld\n",0);
		else if(a1<0)
			printf("%lld\n",a1*d1);
		else if(b1>0)
			printf("%lld\n",b1*c1);
		else
			printf("%lld\n",max(a1*c1,b1*d1));
	}
	return 0;
}