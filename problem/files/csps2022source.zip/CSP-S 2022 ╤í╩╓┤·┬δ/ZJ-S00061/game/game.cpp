#include <bits/stdc++.h>
typedef long long ll;
using namespace std;

int main()
{
    freopen("game","r",stdin);
    freopen("game.out","w",stdout);
    #include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int point[2505];
int an1[30],an2[3],an3[3],an4[3],an5[3],an6[3],an7[3],an8[3],an9[3],an10[3],an11[3],an12[3],an13[3],an14[3],an15[3],an16[3],an17[3],an18[3],an19[3],an20[3];

int main()
{
    int n , m , k ,a1,a2,a3,a4,a5;
    cin >> n >> m >> k;
    if(n==5){
        for(int q;q<n;q++)
        {
            cin >>  point[q] ;
        }
        
        cout << point[0]+point[1]+point[2]+point[3];
    }


}

    return 0;
}