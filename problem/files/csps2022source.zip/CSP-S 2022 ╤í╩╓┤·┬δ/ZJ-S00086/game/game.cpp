#include<iostream>
#include<cmath>
using namespace std;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int m,n,q,a,b,ans,num1,num2,l1,l2,r1,r2;
	int A[10001],B[10001];
	bool flag=true;
	cin>>m>>n>>q;
	for(int i=0;i<n;i++){
		cin>>a;
		A[i]=a;
	}
	for(int i=0;i<m;i++){
		cin>>b;
		B[i]=b;
	}
	for(int j=0;j<q;j++){
		cin>>l1>>r1>>l2>>r2;
		flag=true;
		if(l1=r1) num1=A[l1-1];
		else{
			num1=A[l1-1];
			for(int i=l1;i<r1;i++){
				for(int k=l2;k<r2;k++){
					if(B[k-1]<0){
						flag=false;
						break;
					}
				}
				if(flag==true){
					if(A[i-1]>=0){
						if(A[i-1]>num1) num1=A[i-1];
					}
				}
				else{
					if(A[i-1]>=0){
						if(A[i-1]<num1) num1=A[i-1];
					}
				}
			}
		}
		if(l2=r2) num2=B[l2-1];
		else{
			num2=B[l2-1];
			for(int k=l2;k<r2;k++){
				if(num1>0){
					if(B[k-1]>=0){
						if(B[k-1]<num2) num2=B[k-1];	
					}
				}
				else{
					if(B[k-1]>num2) num2=B[k-1];
				}
			}
		}
		ans=num1*num2;
		cout<<ans<<endl;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
