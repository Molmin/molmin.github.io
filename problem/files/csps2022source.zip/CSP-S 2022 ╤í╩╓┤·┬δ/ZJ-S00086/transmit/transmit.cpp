#include<iostream>
#include<cmath>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cout<<"buzhidao";
	fclose(stdin);fclose(stdout);
	return 0;
}
