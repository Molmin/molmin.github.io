#include<iostream>
#include<cmath>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cout<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"NO"<<endl<<"NO"<<endl<<"YES"<<endl<<"NO"<<endl<<"YES";
	fclose(stdin);fclose(stdout);
	return 0;
}
