#include<iostream>
#include<cmath>
using namespace std;
int s[2500],t[20000];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,k,a,b,c;
	cin>>n>>m>>k;
	for(int i=0;i<=n-2;i++){
		cin>>a;
		s[i]=a;
	}
	for(int i=0;i<=m-1;i++){
		cin>>b>>c;
		t[i]=char(a)+char(b);
	}
	cout<<s;
	fclose(stdin);fclose(stdout);
	return 0;
}
