#include<bits/stdc++.h>
using namespace std;
const long long Inf=2000000000;
int n,m,q;long long ans;
int L1,R1,L2,R2,k,ks,k2,ks2;
int log2s[100039]={0,0,1,1,2}; 
long long a[100039],b[100039];long long x,y,x2,y2,x3,y3;
long long xs[100039][18],ys[100039][18];
long long xs2[100039][18],ys2[100039][18],xs3[100039][18],ys3[100039][18];
long long Abs(long long a){return a<0?-a:a;}
long long min(long long a,long long b){return a>b?b:a;}
long long max(long long a,long long b){return a>b?a:b;}
long long maxQ(long long a,long long b){
	if(a>=0&&b>=0)
	return a<b?a:b;
	if(a>=0)return a;
	if(b>=0)return b;
	return -Inf;
}
long long minQ(long long a,long long b){
	if(a<=0&&b<=0)
	return a>b?a:b;
	if(b<=0)return b;
	if(a<=0)return a;
	return -Inf;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	register int i,j;
	for(i=4;i<=100000;i++)log2s[i]=log2s[i/2]+1;
	for(i=1;i<=n;i++)scanf("%lld",&a[i]),xs2[i][0]=ys2[i][0]=a[i],xs3[i][0]=ys3[i][0]=a[i];
	for(i=1;i<=m;i++)scanf("%lld",&b[i]),xs[i][0]=ys[i][0]=b[i];
	for(j=1;(1<<j)<=m;j++){
		for(i=1;i+(1<<j)-1<=m;i++){
			xs[i][j]=max(xs[i][j-1],xs[i+(1<<(j-1))][j-1]);
			ys[i][j]=min(ys[i][j-1],ys[i+(1<<(j-1))][j-1]);
		}
	}for(j=1;(1<<j)<=n;j++){
		for(i=1;i+(1<<j)-1<=n;i++){
			xs2[i][j]=max(xs2[i][j-1],xs2[i+(1<<(j-1))][j-1]);
			ys2[i][j]=min(ys2[i][j-1],ys2[i+(1<<(j-1))][j-1]);
			xs3[i][j]=maxQ(xs3[i][j-1],xs3[i+(1<<(j-1))][j-1]);
			ys3[i][j]=minQ(ys3[i][j-1],ys3[i+(1<<(j-1))][j-1]);
		}
	}
	while(q--){
		scanf("%d%d%d%d",&L1,&R1,&L2,&R2);
		k=log2s[R2-L2+1];
		ks=(1<<k);
		k2=log2s[R1-L1+1];
		ks2=(1<<k2);
		x=max(xs[L2][k],xs[R2-ks+1][k]);
		y=min(ys[L2][k],ys[R2-ks+1][k]);
		x3=max(xs2[L1][k2],xs2[R1-ks2+1][k2]);
		y3=min(ys2[L1][k2],ys2[R1-ks2+1][k2]);
		x2=maxQ(xs3[L1][k2],xs3[R1-ks2+1][k2]);
		y2=minQ(ys3[L1][k2],ys3[R1-ks2+1][k2]);
		ans=max(min(x3*x,x3*y),min(y3*x,y3*y));
		if(x2!=-Inf)ans=max(ans,min(x2*x,x2*y));
		if(y2!=-Inf)ans=max(ans,min(y2*x,y2*y));
		printf("%lld\n",ans);
	}
	return 0;
}
