#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,q;
int A[100005];
int B[100005];
int mi1=100005,mi2=100005,ma1=-100005,ma2=-100005,ts=-100005,tp=100005,yi=0,er=0;
int ke1[400005],ke2[400005],k5[400005],k6[400005];
int ke3[400005],ke4[400005];
void bu1(int l,int r,int k)
{
	if(l==r) {
		ke1[k]=A[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu1(l,mid,k*2);
	bu1(mid+1,r,k*2+1);
	ke1[k]=max(ke1[k*2],ke1[k*2+1]);
//	cout<<1111;
}
void bu2(int l,int r,int k)
{
	if(l==r) {
		ke2[k]=A[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu2(l,mid,k*2);
	bu2(mid+1,r,k*2+1);
	ke2[k]=min(ke2[k*2],ke2[k*2+1]);
}
void bu3(int l,int r,int k)
{
	if(l==r) {
		ke3[k]=B[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu3(l,mid,k*2);
	bu3(mid+1,r,k*2+1);
	ke3[k]=max(ke3[k*2],ke3[k*2+1]);
}
void bu4(int l,int r,int k)
{
	if(l==r) {
		ke4[k]=B[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu4(l,mid,k*2);
	bu4(mid+1,r,k*2+1);
	ke4[k]=min(ke4[k*2],ke4[k*2+1]);
}
void bu5(int l,int r,int k)
{
	if(l==r) {
		k5[k]=A[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu5(l,mid,k*2);
	bu5(mid+1,r,k*2+1);
//	int a=k5[k*2];
//	int b=k5[k*2+1];
//	if(a>b)
//	{
//		if(b>0){
//			k5[k]=b;
//		}
//		else{
//			if(a>0)
//			k5[k]=a;
//			else k5[k]=100005;
//		}
//	}
//	else{
//		if(a>0){
//			k5[k]=a;
//		}
//		else{
//			if(b>0)
//			k5[k]=b;
//			else k5[k]=100005;
//		}
//	}
	int x1=abs(k5[k*2]);
	int y1=abs(k5[k*2+1]);
	if(x1>=y1)
	{
		if(k5[k*2+1]>=0)
		k5[k]=k5[k*2+1];
		else if(k5[k*2]>=0)
		k5[k]=k5[k*2];
		else k5[k]=100005;
	}
	else{
		if(k5[k*2]>=0)
		k5[k]=k5[k*2];
		else if(k5[k*2+1]>=0)
		k5[k]=k5[k*2+1];
		else k5[k]=100005;
	}
}void bu6(int l,int r,int k)
{
	if(l==r) {
		k6[k]=A[l];
		return ;
	}
	int mid=(l+r)>>1;
	bu6(l,mid,k*2);
	bu6(mid+1,r,k*2+1);
	int x1=abs(k6[k*2]);
	int y1=abs(k6[k*2+1]);
	if(x1>=y1)
	{
		if(k6[k*2+1]<=0)
		k6[k]=k6[k*2+1];
		else if(k6[k*2]<=0)
		k6[k]=k6[k*2];
		else k6[k]=-100005;
	}
	else{
		if(k6[k*2]<=0)
		k6[k]=k6[k*2];
		else if(k6[k*2+1]<=0)
		k6[k]=k6[k*2+1];
		else k6[k]=-100005;
	}
//	int a=k6[k*2];
//	int b=k6[k*2+1];
//	if(a>b)
//	{
//		if(a<0){
//			k6[k]=a;
//		}
//		else{
//			if(b>0)
//			k6[k]=b;
//			else k6[k]=-100005;
//		}
//	}
//	else{
//		if(b<0){
//			k6[k]=b;
//		}
//		else{
//			if(a>0)
//			k6[k]=a;
//			else k6[k]=-100005;
//		}
//	}
}
void f1(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		ma1=max(ke1[k],ma1);
		if(ke1[k]<=0) ts=max(ke1[k],ts);
		return ;
	}
	int mid=(nl+nr)>>1;
	f1(l,r,mid+1,r,k*2+1);
	f1(l,r,l,mid,k*2);
}
void f2(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		mi1=min(ke2[k],mi1);
	if(ke2[k]>=0) tp=min(ke2[k],tp);
		return ;
	}
	int mid=(nl+nr)>>1;
	f2(l,r,mid+1,r,k*2+1);
	f2(l,r,l,mid,k*2);
}
void f3(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		ma2=max(ke3[k],ma2);
		return ;
	}
	int mid=(nl+nr)>>1;
	f3(l,r,mid+1,r,k*2+1);
	f3(l,r,l,mid,k*2);
}
void f4(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		mi2=min(ke4[k],mi2);
		return ;
	}
	int mid=(nl+nr)>>1;
	f4(l,r,mid+1,r,k*2+1);
	f4(l,r,l,mid,k*2);
}
void f5(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		tp=min(k5[k],tp);
		return ;
	}
	int mid=(nl+nr)>>1;
	f1(l,r,mid+1,r,k*2+1);
	f1(l,r,l,mid,k*2);
}
void f6(int l ,int r,int nl,int nr,int k)
{
	if(nr<l||nl>r) return ;
	if(nl>=l&&nr<=r)
	{
		ts=max(k6[k],ts);
		return ;
	}
	int mid=(nl+nr)>>1;
	f1(l,r,mid+1,r,k*2+1);
	f1(l,r,l,mid,k*2);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&A[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&B[i]);
	bu1(1,n,1);
	bu2(1,n,1);
	bu3(1,m,1);
	bu4(1,m,1);
	bu5(1,n,1);
	bu6(1,n,1);
	while(q--)
	{
		int l1,l2,r1,r2;
		mi1=100005,mi2=100005,ma1=-100005,ma2=-100005,ts=-100005,tp=100005;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
//		f1(l1,r1,1,n,1);
//		f2(l1,r1,1,n,1);
//		f3(l2,r2,1,m,1);
//		f4(l2,r2,1,m,1);
//		f5(l1,r1,1,n,1);
//		f6(l1,r1,1,n,1);
		for(int i=l2;i<=r2;i++)
		{
			if(B[i]==0) er=1;
			mi2=min(mi2,B[i]);
			ma2=max(ma2,B[i]);
		}
		for(int i=l1;i<=r1;i++)
		{
			if(A[i]==0) yi=1;
			if(A[i]<=0) ts=max(ts,A[i]);
			if(A[i]>=0) tp=min(tp,A[i]);
			mi1=min(mi1,A[i]);
			ma1=max(ma1,A[i]);
		}
//		cout<<ts<<" "<<tp<<"     ";
		if(mi2>0){
			if(ma1<0) 
			{
				cout<<1ll*ma2*ma1<<"\n";
			}
			else cout<<1ll*ma1*mi2<<"\n";
		} 
		else if(mi2<0)
		{
			if(ma1>0) 
			{
				if(mi1>=0)	
				{
					cout<<1ll*mi1*mi2<<"\n";
				}
				else{
					cout<<max(1ll*mi1*ma2,1ll*tp*mi2)<<"\n";
				}
			}
			else{
				if(ma2<0)
				{
					cout<<1ll*mi1*ma2<<"\n";
				}
				else{
					cout<<1ll*ma1*ma2<<"\n";
				}
			}
		}

	}
}

