#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,k;
ll w[2505];
vector<ll> tr[2555];
ll mox[2505],pla[2505];
ll ans=0;
ll dp[2505][105][5];//now w 
void findma(int x,int fa)
{
	for(auto i:tr[x])
	{
//		if(i==fa) continue ;
		if(mox[x]<w[i]) mox[x]=w[i],pla[x]=i;
		if(!mox[i]) findma(i,x);
	}
}
void dfs(int x,int t,int cnt,ll sum)
{
	if(cnt==4){
//		ans=max(ans,dp[x][t][cnt]);
		ans=max(ans,sum);
		return ;
	}
	for(auto i:tr[x])
	{
//		if(t<=k-1)
//		dfs(i,t++,cnt,sum);
//		if(t<k)
//		dp[x][t][cnt]=max(dp[i][t-1][cnt],dp[i][t-1][cnt-1]+w[x]);
		int s=w[i];
		w[i]=0;
		dfs(i,-1,cnt+1,sum+s);
	}
//	ll s=w[pla[x]];
//	w[pla[x]]=0;
//	findma(x,x);
//	if(t<=k-1)
//	dfs(pla[x],t++,cnt,sum);
//	dfs(pla[x],-1,cnt+1,sum+s);
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<n;i++)
	{
		scanf("%d",&w[i]);
	}
	int u,v;
	for(int i=1;i<=m;i++)
	{	
		scanf("%d%d",&u,&v);
		tr[u].push_back(v);
		tr[v].push_back(u);
	}
	findma(1,0);
	dfs(1,-1,0,0);
	cout<<ans;
}

