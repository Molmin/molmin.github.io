#include <bits/stdc++.h>
using namespace std;
const int MAX=500114;
int to[MAX*2],nxt[MAX*2];
int hd[MAX],dego[MAX],degi[MAX],tot=1;
bool bad[MAX];
//bool mark[MAX];
/*
edge[i]
i & 1 == 1,�·����
dego ����
degi ���
*/
int n,m,q,t,u,v;
void add(int u,int v) {
	tot++;
	to[tot]=v;
	nxt[tot]=hd[u];
	hd[u]=tot;
	tot++;
	to[tot]=u;
	nxt[tot]=hd[v];
	hd[v]=tot;
	dego[u]++;
	degi[v]++;
}
int cnt;
bool check() {
	return m==n and n==cnt;
//	if(m!=n) {
//		return false;
//	}
//	for(int i=1; i<=n; i++) {
//		if(dego[i]!=1) {
//			return false;
//		}
//	}
//	return true;
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1; i<=m; i++) {
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	for(int i=1; i<=n; i++) {
		if(dego[i]==1) {
			cnt++;
		}
	}
	scanf("%d",&q);
	while(q--) {
		scanf("%d",&t);
		if(t==1) {
			scanf("%d%d",&u,&v);
			for(int e=hd[u]; e; e=nxt[e]) {
				if(to[e]!=v) {
					continue;
				}
				if(!(e&1) and !bad[e/2]) {
					if(dego[u]==1) {
						cnt--;
					}
					bad[e/2]=true;
					m--;
					dego[u]--;
					degi[v]--;
					if(dego[u]==1) {
						cnt++;
					}
					break;
				}
			}

		} else if(t==2) {
			scanf("%d",&u);
			for(int e=hd[u]; e; e=nxt[e]) {
				if(e&1 and !bad[e/2]) {
					if(dego[to[e]]==1) {
						cnt--;
					}
					bad[e/2]=true;
					m--;
					dego[to[e]]--;
					degi[u]--;
					if(dego[to[e]]==1) {
						cnt++;
					}
				}
			}
		} else if(t==3) {
			scanf("%d%d",&u,&v);
			for(int e=hd[u]; e; e=nxt[e]) {
				if(to[e]!=v) {
					continue;
				}
				if(!(e&1) and bad[e/2]) {
					if(dego[u]==1) {
						cnt--;
					}
					bad[e/2]=false;
					m++;
					dego[u]++;
					degi[v]++;
					if(dego[u]==1) {
						cnt++;
					}
					break;
				}
			}
		} else if (t==4) {
			scanf("%d",&u);
			for(int e=hd[u]; e; e=nxt[e]) {
				if(e&1 and bad[e/2]) {
					if(dego[to[e]]==1) {
						cnt--;
					}
					bad[e/2]=false;
					m++;
					dego[to[e]]++;
					degi[u]++;
					if(dego[to[e]]==1) {
						cnt++;
					}
				}
			}
		}
		if(check()) {
			printf("YES\n");
		} else {
			printf("NO\n");
		}
//		cout<<"edges:"<<m<<endl;
	}
	return 0;
}
