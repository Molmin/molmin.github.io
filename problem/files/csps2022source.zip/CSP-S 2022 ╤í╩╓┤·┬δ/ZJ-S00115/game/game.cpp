#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll MINLL=0x8000000000000000;
const ll MAXLL=0x7FFFFFFFFFFFFFFF;
int arr_a[114514],arr_b[114514];
int ckmxb[514],ckmnb[514];
int n,m,q,l1,r1,l2,r2;
ll ans1,ans2;
int cks,ck,ckl,ckr,mxb,mnb;
// ck��: (ck-1)*cks+1,ck*cks,������
int main() {
	for(int i=0; i<514; i++) {
		ckmxb[i]=0x80000000;
		ckmnb[i]=0x7FFFFFFF;
	}
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1; i<=n; i++) {
		scanf("%d",arr_a+i);
	}
	cks=m;
	for(int i=1; i<=10; i++) {
		cks=(cks+m/cks)/2;
	}
//	cout<<"cks"<<cks<<endl;
	for(int i=1; i<=m; i++) {
		scanf("%d",arr_b+i);
		ck=(i-1)/cks+1;
		ckmxb[ck]=max(ckmxb[ck],arr_b[i]);
		ckmnb[ck]=min(ckmnb[ck],arr_b[i]);
	}
	for(int k=1; k<=q; k++) {
		ans1=MINLL;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ckl=(l2-1)/cks+2;
		ckr=(r2-1)/cks;
//		cout<<"["<<ckl<<","<<ckr<<"]\n";
		for(int i=l1; i<=r1; i++) {
			if(arr_a[i]==0) {
				ans1=max(ans1,0ll);
				break;
			}
			// if a[i] < 0, find max b
			// if a[i] > 0, find min b
			ans2=MAXLL;
			mxb=0x80000000;
			mnb=0x7FFFFFFF;
			if(ckl<=ckr) {
				for(int j=ckl; j<=ckr; j++) {
					mxb=max(mxb,ckmxb[j]);
					mnb=min(mnb,ckmnb[j]);
				}
				for(int j=l2; j<=(ckl-1)*cks; j++) {
					mxb=max(mxb,arr_b[j]);
					mnb=min(mnb,arr_b[j]);
				}
				for(int j=r2; j>=ckr*cks+1; j--) {
					mxb=max(mxb,arr_b[j]);
					mnb=min(mnb,arr_b[j]);
				}
			} else {
				for(int j=l2; j<=r2; j++) {
					mxb=max(mxb,arr_b[j]);
					mnb=min(mnb,arr_b[j]);
				}
			}
			ans2=min(1ll*arr_a[i]*mxb,ans2);
			ans2=min(1ll*arr_a[i]*mnb,ans2);
			ans1=max(ans1,ans2);
		}
		printf("%lld\n",ans1);
	}
	return 0;
}
