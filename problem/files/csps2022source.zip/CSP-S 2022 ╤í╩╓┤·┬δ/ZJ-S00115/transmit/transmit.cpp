#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int edge[2022][2022];
ll cost[2022][2022];
int val[2022];
int n,q,k;
int main() {
	memset(cost,0x3f,sizeof(cost));
	memset(edge,0x3f,sizeof(edge));
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1; i<=n; i++) {
		scanf("%d",val+i);
		cost[i][i]=val[i];
		edge[i][i]=0;
	}
	for(int i=1,u,v; i<n; i++) {
		scanf("%d%d",&u,&v);
		edge[u][v]=edge[v][u]=1;
		cost[u][v]=cost[v][u]=0ll+val[u]+val[v];
	}
	bool flag=true;
	while(flag) {
		flag=false;
		for(int m=1; m<=n; m++) {
			for(int i=1; i<=n; i++) {
				for(int j=1; j<=n; j++) {
					if(i!=j and i!=m and j!=m) {
						if (edge[i][j]>edge[i][m]+edge[j][m] and edge[i][m]+edge[j][m]<=k) {
							edge[i][j]=edge[i][m]+edge[j][m];
							cost[i][j]=min(cost[i][j],0ll+val[i]+val[j]);
							flag=true;
						}
					}
				}
			}
		}
	}
	for(int m=1; m<=n; m++) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				if(i!=j and j!=m and i!=m) {
					cost[i][j]=min(cost[i][j],0ll+cost[i][m]+cost[j][m]-val[m]);
				}
			}
		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<edge[i][j]<<" ";
//		}
//		cout<<endl;
//	}
	for(int i=1,a,b; i<=q; i++) {
		scanf("%d%d",&a,&b);
		printf("%lld\n",cost[a][b]);
	}
	return 0;
}
