#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;
typedef long long ll;
bool edge[2514][2514];
pair<ll,int> pts[25114];
int d[2514][2514];
int n,m,k;
ll ans=0;
//int steady;
//	struct Edge {
//		int to,nxt;
//	};
//	Edge edges[20114];
//	int head[2514],tot=1;
//	void add(int u,int v){
//		edges[++tot].to=v;
//		edges[tot].nxt=head[u];
//		head[u]=tot;
//		edges[++tot].to=u;
//		edges[tot].nxt=head[v];
//		head[v]=tot;
//	}
bool cmp(pair<ll,int> a,pair<ll,int> b) {
	return a>b;
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(d,0x3f,sizeof(d));
	scanf("%d%d%d",&n,&m,&k);
	k++;
	for(int i=1; i<=n; i++) {
		d[i][i]=0;
		if(i==1)continue;
		scanf("%lld",&pts[i].fi);
		pts[i].se=i;
	}
	sort(pts+1,pts+n+1,cmp);

//	for(int i=1; i<=n; i++) {
//		cout<<pts[i].fi<<" "<<pts[i].se<<endl;
//	}
	for(int i=1,u,v; i<=m; i++) {
		scanf("%d%d",&u,&v);
		d[u][v]=d[v][u]=edge[u][v]=edge[v][u]=1;
	}
	for(int ttt=1; ttt<=n; ttt++) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=n; j++) {
				d[i][j]=min(d[i][j],d[i][ttt]+d[j][ttt]);
			}
		}
	}
//	for(int i=1; i<=n; i++) {
//		for(int j=1; j<=n; j++) {
//			cout<<d[i][j]<<" ";
//		}
//		cout<<endl;
//	}
	for(int i=1; i<n; i++) {
		if(d[1][pts[i].se]>k) {
			continue;
		}
		for(int j=1; j<n; j++) {
			if(j==i or d[pts[i].se][pts[j].se]>k) {
				continue;
			}
			for(int p=1; p<n; p++) {
				if(p==i or p==j or d[pts[j].se][pts[p].se]>k) {
					continue;
				}
				for(int q=1; q<n; q++) {
					if(q==i or q==j or q==p or d[pts[p].se][pts[q].se]>k or d[pts[q].se][1]>k) {
						continue;
					}
//					cout<<pts[i].se<<" "<<pts[j].se<<" "<<pts[p].se<<" "<<pts[q].se<<endl;
					ans=max(ans,pts[i].fi+pts[j].fi+pts[p].fi+pts[q].fi);
					if(ans) {
						break;
					}
				}
				if(ans) {
					break;
				}
			}
			if(ans) {
				break;
			}
		}
		if(ans) {
			break;
		}
	}
	printf("%lld",ans);
	return 0;
}
