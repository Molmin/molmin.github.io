#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct edge{int t, e, f;};
const int sn = 500001;
int n, m, q, u, v, ii, t, e[sn];
bool vis[sn], tg[sn];
bool cmp(edge a, edge b)
{
	return a.t < b.t;
}
vector <edge> g[sn], _g[sn];
bool dfs(int p)
{
	if (tg[p] || vis[p])
	{
		tg[p] = 1;
		return 1;
	}
	vis[p] = 1;
	for (auto i : g[p])
		tg[p] |= dfs(i.t);
	return tg[p];
}
void check()
{
	for (int i = 1; i <= n; i++)
		if (e[i] != 1)
		{
			printf("NO\n");
			return;
		}
	for (int i = 1; i <= n; i++)
		if (!tg[i]) dfs(i);
	for (int i = 1; i <= n; i++)
		if (!tg[i])
		{
			printf("NO\n");
			return;
		}
	printf("YES\n");
	return;
}
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++)
	{
		scanf("%d%d", &u, &v);
		g[u].push_back((edge){v, 1, u}), e[u]++;
		_g[v].push_back((edge){u, g[u].size() - 1, v});
	}
	for (int i = 1; i <= n; i++)
		sort(g[i].begin(), g[i].end() - 1, cmp);
	scanf("%d", &q);
	for (int i = 1; i <= q; i++)             
	{
		scanf("%d%d", &t, &u);
		if (t % 2 == 1) scanf("%d", &v);
		if (t == 1 || t == 3)
		{
			int b = lower_bound(g[u].begin(), g[u].end() - 1, (edge){v, 0}, cmp) - g[u].begin();
			e[u] += (t == 3) - g[u][b].e;
			g[u][b].e = (t == 3);
		}
		else
		{
			for (auto i : _g[u])
			{
				e[i.t] += (t == 4) - g[i.t][i.e].e;
				g[i.t][i.e].e = (t == 4);
			}
		}
		check();
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2

*/