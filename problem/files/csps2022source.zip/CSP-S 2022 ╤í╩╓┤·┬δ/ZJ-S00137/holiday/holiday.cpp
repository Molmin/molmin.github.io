#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int sn = 2501;
struct point{int p; ll s;} u, sc[5][sn];
int n, m, k, x, y, tt[sn];
ll s[sn], ans;
bool vis[5][sn];
vector <int> g[sn];
bool cmp(point a, point b) 
{
	return a.s == b.s? a.p <= b.p : a.s >= b.s;
}
void dfs(int p, int d, ll ss)
{
	ss += s[p];
	if (d == 4 && tt[p] == 0) return;
	if (d == 4 && tt[p] == 1)
		ans = max(ans, ss);
	vis[0][p] = 1;
	for (auto i : g[p])
		if (!vis[0][i]) dfs(i, d + 1, ss);
	vis[0][p] = 0;
}
void bfs(int st, int l, int c)
{
	queue <point> q;
	memset(vis[l], 0, sizeof(vis[l]));
	q.push((point){st, 0});
	while (!q.empty())
	{
		u = q.front(), q.pop();
		sc[l][u.p].s = max(sc[l][u.p].s, c + s[u.p]);
		if (u.s > k) continue;
		for (auto i : g[u.p])
		{
			if (!vis[l][i])
			{
				vis[l][i] = 1;
				q.push((point){i, u.s + 1});
			}
		}
	}
	return;
}
int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 2; i <= n; i++)
		scanf("%lld", &s[i]);
	for (int i = 1; i <= m; i++)
	{
		scanf("%d%d", &x, &y);
		if (x > y) swap(x, y);
		if (x == 1) tt[y] = 1;
		g[x].push_back(y);
		g[y].push_back(x);
	}
	if (k != 0)
	{
		bfs(1, 0, 0);
		for (int i = 0; i < 4; i++)
		{
			for (int j = 1; j <= n; j++)
				sc[i][j].p = j;
			sort(sc[i] + 1, sc[i] + 1 + n, cmp);
			for (int j = 1; j <= n; j++)
				printf("%d %d\n", sc[i][j].p, sc[i][j].s);
			printf("\n");
			for (int j = 1; j <= n; j++)
				if (vis[i][sc[i][j].p]) bfs(j, i + 1, sc[i][j].s);
		}
		printf("%lld\n", sc[4][1].s);
	}
	else
	{
		dfs(1, 0, 0);
		printf("%lld\n", ans);
	}
	return 0;
}
/*
8 8 0
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/