#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int sn = 200001;
int n, q, k, x, y, t[sn];
ll s[sn], ans, dp[sn];
vector <int> g[sn];
bool dfs(int p, int f)
{
	if (p == y) 
	{
		t[p] = f;
		return q;
	}
	for (auto i : g[p])
		if (i != f && dfs(i, p))
		{
			t[p] = f;
			return 1;
		}
	return 0;
}
int main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	for (int i = 1; i <= n; i++)
		scanf("%lld", &s[i]);
	for (int i = 1; i < n; i++)
	{
		scanf("%d%d", &x, &y);
		g[x].push_back(y);
		g[y].push_back(x);
	}
	for (int i = 1; i <= q; i++)
	{
		memset(dp, 0x3f, sizeof(dp));
		scanf("%d%d", &x, &y);
		dfs(x, 0);
		dp[y] = s[y];
		for (int i = y; i; i = t[i])
		{
			for (int j = 1, l = t[i]; j <= k && l; j++, l = t[l])
			{
				//printf("dp[%d] = min(%d, %d + %d)\n", l, dp[l], dp[y], s[l]);
				dp[l] = min(dp[l], dp[i] + s[l]);
				//printf("dp[%d] = %d\n", l, dp[l]);
			}
		}
		printf("%lld\n", dp[x]);
	}
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

10 10 3
1 10 100 1000 10000 100000 1000000 10000000 100000000 1000000000
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7

10 10 3
1 10 100 1000 10000 100000 1000000 10000000 100000000 1000000000
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7

10 10 3
835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423 51944511 479806606
2 1
3 2
4 2
5 3
6 3
7 2
8 7
9 1
10 9
1 7
1 5
2 1
1 9
10 5
3 10
2 9
10 2
1 4
4 7


*/