#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int sn = 100001;
int n, m, k, ln, lx, rn, rx;
ll a[sn], b[sn];
int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; i++)
		scanf("%lld", a + i);
	for (int i = 1; i <= m; i++)
		scanf("%lld", b + i);
	for (int i = 1; i <= k; i++)
	{
		scanf("%d %d %d %d", &ln, &lx, &rn, &rx);
		ll mx = -1000000000000000000;
		for (int k = ln; k <= lx; k++)
		{
			//printf("k=%d\n", k);
			ll m = 1000000000000000000;
			for (int l = rn; l <= rx; l++)
			{
				//printf("l=%d\n", l);
				m = min(m, a[k] * b[l]);
				//printf("m=%lld\n", m);
			}
			mx = max(mx, m);
			//printf("mx=%lld\n", mx);
		}
		printf("%lld\n", mx);
	}
	return 0;
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

*/