#include <iostream>
#include <cstdio>
using namespace std;
long long n,m,q,x[100005],y[100005],c1[100005],c2[100005],flag;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&x[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&y[i]);
	for(int i=1;i<=q;i++)
	{
		int l,r,ll,rr;
		scanf("%d%d%d%d",&l,&r,&ll,&rr);
		flag=0;
		long long a[4],b[4];
		a[0]=-1e9-1,a[1]=1e9+1,a[2]=-1e9-1,a[4]=1e9+1,b[0]=-1e9-1,b[1]=1e9+1,b[2]=-1e9-1,b[3]=1e9+1;
		for(int j=l;j<=r;j++)
		{
			if(x[j]>0)	a[0]=max(a[0],x[j]),a[1]=min(a[1],x[j]);
			if(x[j]<0)	a[2]=max(a[2],x[j]),a[3]=min(a[3],x[j]);
			if(x[j]==0) flag=1;
		}
		for(int j=ll;j<=rr;j++)
		{
			if(y[j]>0)	b[0]=max(b[0],y[j]),b[1]=min(b[1],y[j]);
			if(y[j]<0)	b[2]=max(b[2],y[j]),b[3]=min(b[3],y[j]);
		}
		if(b[1]!=1e9+1&&b[3]!=1e9+1&&flag==1)
			printf("0\n");
		else
		{
			long long ans[4],ans1=-1e18-1;
			ans[1]=ans[2]=ans[3]=ans[0]=1e18+1;
			for(int j=0;j<4;j++)
			{
				for(int k=0;k<4;k++)
				{
					if(a[j]!=-1e9-1&&a[j]!=1e9+1&&b[k]!=-1e9-1&&b[k]!=1e9+1)
						ans[j]=min(ans[j],a[j]*b[k]);
					if(a[j]==1e9+1||a[j]==-1e9-1)
						ans[j]=-1e18-1;
				}
			}
			ans1=max(max(ans[1],ans[2]),max(ans[3],ans[0]));
			if(ans1==-1e18-1)
				ans1=0;
			printf("%lld\n",ans1);
		}	
	}
	return 0;
}
