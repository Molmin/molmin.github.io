#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int maxn=2505,maxk=105;
const int inf=0x3f3f3f3f;
long long n,m,k,c[maxn],u,v,ans;
int a[maxn][maxn],dis[maxn][maxn],vis[maxn];
void dfs(int step,int s,long long sum)
{
	if(step==4)
	{
		if(dis[s][1]>k+1)
			return ;
		ans=max(ans,sum);
		return ;
	}
	for(int i=2;i<=n;i++)
	{
		if(vis[i]==1)
			continue;
		if(dis[s][i]<=k+1)
		{
			vis[i]=1;
			dfs(step+1,i,sum+c[i]);
			vis[i]=0;
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&c[i]);
	memset(dis,inf,sizeof(dis));
	for(int i=1;i<=m;i++)
	{
		scanf("%lld%lld",&u,&v);
		a[u][v]=a[v][u]=1;
		dis[u][v]=dis[v][u]=1;
	}
	for(int i=1;i<=n;i++)
		dis[i][i]=0;
	for(int p=1;p<=n;p++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(i!=j&&j!=p&&i!=p)
					dis[i][j]=min(dis[i][j],dis[i][p]+dis[p][j]);
			}
		}
	}
	dfs(0,1,0);
	printf("%lld",ans);
	return 0;
}
