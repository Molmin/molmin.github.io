#include <bits/stdc++.h>
using namespace std;
const int N = 5e5+10;

struct Edge {
	int to, nxt;
	bool b; //connot pass by
} e[N];
int head[N], cnt;

void add(int x, int y) {
	e[++cnt].to = y;
	e[cnt].nxt = head[x];
	e[cnt].b = true;
	head[x] = cnt;
}

int n, m, q;
bool vis[N];

bool dfs(int x) {
	if (vis[x]) return true;
	vis[x] = true;
	for (int i = head[x]; i; i = e[i].nxt)
		if (e[i].b) return dfs(e[i].to);
	return false;
}

bool check() {
	for (int x = 1; x <= n; x++) {
		int sum = 0;
		for (int i = head[x]; i; i = e[i].nxt)
			if (e[i].b) sum++;
		if (sum != 1) return false;
	}
	for (int i = 1; i <= n; i++) {
		memset(vis, false, sizeof(vis));
		if (!dfs(i)) return false;
	}
	return true;
}

int main() { //40pts
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		int a, b;
		scanf("%d%d", &a, &b);
		add(a, b);
	}
	scanf("%d", &q);
	while (q--) {
		int t, u, v;
		scanf("%d%d", &t, &u);
		if (t == 1 || t == 3) {
			scanf("%d", &v);
			for (int i = head[u]; i; i = e[i].nxt)
				if (e[i].to == v) {
					e[i].b = !e[i].b;
					break;
				}
		}
		else if (t == 2) {
			for (int x = 1; x <= n; x++)
				for (int i = head[x]; i; i = e[i].nxt)
					if (e[i].to == u)
						e[i].b = false;
		}
		else if (t == 4) {
			for (int x = 1; x <= n; x++)
				for (int i = head[x]; i; i = e[i].nxt)
					if (e[i].to == u)
						e[i].b = true;
		}
		if (check()) puts("YES");
		else puts("NO");
	}
	return 0;
}