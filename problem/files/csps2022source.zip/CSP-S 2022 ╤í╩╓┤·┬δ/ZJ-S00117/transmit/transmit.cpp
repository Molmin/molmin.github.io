#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e5+10, M = 20;

struct Edge {
	int to, nxt;
} e[N << 1];
int head[N], cnt;

void add(int x, int y) {
	e[++cnt].to = y;
	e[cnt].nxt = head[x];
	head[x] = cnt;
}

int n, q, k, v[N], d[N], f[N];

void dfs(int x, int fa) {
	f[x] = fa;
	int t = x;
	for (int i = 1; i <= k; i++) {
		t = f[t];
		if (t == 0 && fa != 0) break;
		d[x] = min(d[x], d[t] + v[x]);
	}
	for (int i = head[x]; i; i = e[i].nxt)
		if (e[i].to != fa)
			dfs(e[i].to, x);
}

signed main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &q, &k);
	for (int i = 1; i <= n; i++) scanf("%lld", v + i);
	for (int i = 1; i < n; i++) {
		int a, b;
		scanf("%lld%lld", &a, &b);
		add(a, b);
		add(b, a);
	}
	while (q--) {
		int a, b;
		scanf("%lld%lld", &a, &b);
		for (int i = 1; i <= n; i++) f[i] = 0;
		for (int i = 1; i <= n; i++) d[i] = 1e18;
		d[0] = 0;
		dfs(a, 0);
		printf("%lld\n", d[b]);
	}
	return 0;
}