#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 1010;
const int Inf = 0x3f3f3f3f3f3f3f3f;

int n, m, q, a[N], b[N], c[N][N];

signed main() { //25pts
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &q);
	for (int i = 1; i <= n; i++) scanf("%lld", a + i);
	for (int i = 1; i <= m; i++) scanf("%lld", b + i);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			c[i][j] = a[i] * b[j];
//	for (int i = 1; i <= n; i++) {
//		for (int j = 1; j <= m; j++)
//			printf("%lld ", c[i][j]);
//		puts("");
//	}
	for (int i = 1; i <= q; i++) {
		int la, ra, lb, rb;
		scanf("%lld%lld%lld%lld", &la, &ra, &lb, &rb);
		int ans = -Inf, mxid;
		for (int i = la; i <= ra; i++) {
			int minn = Inf;
			for (int j = lb; j <= rb; j++)
				minn = min(minn, c[i][j]);
			if (minn > ans) {
				ans = minn;
				mxid = i;
			}
		}
		ans = Inf;
		for (int j = lb; j <= rb; j++)
			ans = min(ans, c[mxid][j]);
		printf("%lld\n", ans);
	}
	return 0;
}