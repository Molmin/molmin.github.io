#include <bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2505, M = 2e4+10;

struct Edge {
	int to, nxt;
} e[M];
int head[N], cnt;

void add(int x, int y) {
	e[++cnt].to = y;
	e[cnt].nxt = head[x];
	head[x] = cnt;
}

int n, m, k, p[N], ans, dis[N][5];
bool vis[N];

void dfs(int x, int pass, int sum, int sc) { //25pts
	if (pass > k) return;
	if (x == 1) {
		if (sum == 5 && pass == 0) ans = max(ans, sc);
		return;
	}
	for (int i = head[x]; i; i = e[i].nxt)
		if (!vis[e[i].to]) {
			vis[e[i].to] = true;
			dfs(e[i].to, 0, sum + 1, sc + p[e[i].to]);
			vis[e[i].to] = false;
			dfs(e[i].to, pass + 1, sum, sc);
		}
		else dfs(e[i].to, pass + 1, sum, sc);
}

void spfa() { //30pts
	queue<int> q, f;
	memset(vis, false, sizeof(vis));
	memset(dis, 0, sizeof(dis));
	q.push(1), f.push(0);
	vis[1] = true;
	while (!q.empty()) {
		int x = q.front(), fa = f.front();
		q.pop(), f.pop();
		vis[x] = false;
		for (int i = head[x]; i; i = e[i].nxt)
			if (e[i].to != fa) {
				int y = e[i].to;
				for (int j = 1; j <= 5; j++)
					if (dis[y][j] < dis[x][j - 1] + p[y]) {
						dis[y][j] = dis[x][j - 1] + p[y];
						if (!vis[y]) {
							vis[y] = true;
							q.push(y);
							f.push(x);
						}
					}
			}
	}
}

signed main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%lld%lld%lld", &n, &m, &k);
	for (int i = 2; i <= n; i++) scanf("%lld", p + i);
	for (int i = 1; i <= m; i++) {
		int a, b;
		scanf("%lld%lld", &a, &b);
		add(a, b);
		add(b, a);
	}
	if (n <= 10) { //25pts
		for (int i = head[1]; i; i = e[i].nxt) {
			vis[e[i].to] = true;
			dfs(e[i].to, 0, 1, p[e[i].to]);
			vis[e[i].to] = false;
			dfs(e[i].to, 1, 0, 0);
		}
		printf("%lld", ans);
	}
	else if (k == 0) { //30pts
		spfa();
		printf("%lld", dis[1][5]);
	}
	return 0;
}