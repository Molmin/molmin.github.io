#include<bits/stdc++.h>
using namespace std;typedef long long LL;
inline LL read(){
	LL ret=0,f=1;char ch=getchar();for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-f;for(;isdigit(ch);ch=getchar())ret=(ret<<1)+(ret<<3)+(ch&15);return ret*f;
}
#define maxn 2505
#define maxe 20005
LL dis[maxn][maxn],Max;
int tot,lnk[maxn],nxt[maxe],son[maxe];
int tot1,lnk1[maxn],nxt1[maxn*maxn],son1[maxn*maxn];
void add(LL x,LL y){
	nxt[++tot]=lnk[x],son[tot]=y,lnk[x]=tot;
}
void add1(LL x,LL y){
	nxt1[++tot1]=lnk1[x],son1[tot1]=y,lnk1[x]=tot1;
}
bool vis[maxe];LL n,m,all,a[maxn];bool flg[maxn][maxn];
inline void dfs(LL fa,LL x,LL now){
	if(now>all or vis[x])return;
	vis[x]=1;if(fa^x)add1(fa,x);
	for(LL j=lnk[x];j;j=nxt[j]){
		dfs(fa,son[j],now+1);
	}
}//n^2
bool V[maxn];
//LL Mx[maxn][3],id[maxn][3];
//struct AC{
//	int id,x;
//	bool operator <(const AC b)const{return x<b.x;}
//}hep[maxn][maxn];
//int len[maxn];
//void put(AC x,int c){
//	len[c]++;hep[c][len[c]]=x;int s=len[c];
//	while(s>1 and hep[c][s].x>hep[c][s>>1].x){
//		swap(hep[c][s],hep[c][s>>1]);s>>=1;
//	}
//}
//AC get(int c){
//	AC now=hep[c][1];hep[c][1]=hep[c][len[c]--];
//	int fa=1,s;
//	while((fa*2)<=len[c]){
//		if(fa*2 ==len[c] or hep[c][fa<<1].x>hep[c][fa<<1|1].x)s=fa<<1;else s=fa<<1|1;
//		if(hep[c][s].x>hep[c][fa].x)swap(hep[c][s],hep[c][fa]);else break;fa=s;
//	}return now;
//}
inline void DFS(LL now,LL k,LL A){
	if(vis[now])return ;
	if(k==4 ){
		 V[now]&&(Max=max(Max,A));return ;
	}
	for(int j=lnk1[now];j;j=nxt1[j]){
		vis[now]=1,DFS(son1[j],k+1,A+a[son1[j]]),vis[now]=0;
	}
	
}int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
 n=read(),m=read(),all=read()+1;for(int i=2;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++){
		LL x=read(),y=read();add(x,y),add(y,x);
	}
	for(int i=1;i<=n;i++)dfs(i,i,0),memset(vis,0,sizeof vis);
	for(int j=lnk1[1];j;j=nxt1[j])V[son1[j]]=1;
	DFS(1,0,0);
//for(int i=1;i<=n;i++){
//	if(V[i])
//		for(int j=lnk1[i];j;j=nxt1[j]){
//			put((AC){son[j],a[son[j]]},i);
//	}
//}
//for(int i=2;i<=n;i++){
//	if(!V[i])continue;
//	for(int j=2;j<=n;j++){
//		if(!V[j] or j==i)continue;
//			AC x=get(i),y=get(j),w1,w2,w3,w4,w5,w6;
//			if(x.id==j){w1=x;
//				x=get(i);
//			}if(y.id==i){
//				w2=y,y=get(j);
//			}
//			if(x.id != y.id){
//				Max=max(Max,a[i]+a[j]+x.x+y.x);continue;
//			}
//			else{
//				w3=x,x=get(i);
//				if(x.id==j){
//					w5=x,x=get(i);
//				}
//				Max=max(Max,a[i]+a[j]+y.x+x.x);
//				w4=y,y=get(j);
//				if(y.id==i){
//					w6=y,y=get(j);
//				}
//				Max=max(y.x+a[i]+a[j]+w3.x,Max);
//			}
//			if(w1.id)put(w1,i);
//			if(w3.id)put(w3,i);
//			if(w5.id)put(w5,i);
//			if(w2.id)put(w2,j);
//			if(w4.id)put(w4,j);
//			if(w6.id)put(w6,j);put(x,i);put(y,j);
//		}
//}
	printf("%lld",Max);
	return 0;
}
