#include<bits/stdc++.h>
using namespace std;typedef long long LL;
inline LL read(){
	LL ret=0,f=1;char ch=getchar();for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-f;for(;isdigit(ch);ch=getchar())ret=(ret<<1)+(ret<<3)+(ch&15);return ret*f;
}
#define maxn 2005
#define maxe maxn*maxn
LL dis[maxn],Max;
int tot,lnk[maxn],nxt[maxn<<2],son[maxn<<2];
int tot1,lnk1[maxn],nxt1[maxe],son1[maxe];
void add(LL x,LL y){
	nxt[++tot]=lnk[x],son[tot]=y,lnk[x]=tot;
}
void add1(LL x,LL y){
	nxt1[++tot1]=lnk1[x],son1[tot1]=y,lnk1[x]=tot1;
}
bool vis[maxe];LL n,Q,m,all,a[maxn];
inline void dfs(LL fa,LL x,LL now){
	if(now>all or vis[x])return;
	vis[x]=1;if(fa^x)add1(fa,x);
	for(LL j=lnk[x];j;j=nxt[j]){
		dfs(fa,son[j],now+1);
	}
}
struct AC{
	LL id,x;
	bool operator <(const AC b)const{return x<b.x;}
}hep[maxn];
LL len;
void put(AC x){
	len++;hep[len]=x;LL s=len;
	while(s>1 and hep[s].x<hep[s>>1].x){
		swap(hep[s],hep[s>>1]);s>>=1;
	}
}
AC get(){
	AC now=hep[1];hep[1]=hep[len--];
	LL fa=1,s;
	while((fa*2)<=len){
		if(fa*2 ==len or hep[fa<<1].x<hep[fa<<1|1].x)s=fa<<1;else s=fa<<1|1;
		if(hep[s].x<hep[fa].x)swap(hep[s],hep[fa]);else break;
		fa=s;
	}return now;
}
LL DIJ(LL s,LL t){
	memset(dis,63,sizeof dis);memset(vis,0,sizeof vis);len=0;put((AC){s,a[s]});dis[s]=a[s];
	for(;len;){
		loop:AC x=get();
		if(vis[x.id])goto loop;
		vis[x.id]=1;
		if(x.id==t)return dis[t];
		for(LL j=lnk1[x.id];j;j=nxt1[j])if(dis[x.id]+a[son1[j]]<dis[son1[j]])put((AC){son1[j],dis[son1[j]]=dis[x.id]+a[son1[j]]});
	}return dis[t];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
n=read(),Q=read(),all=read();
	for(LL i=1;i<=n;i++)a[i]=read();
	for(LL i=1;i<n;i++){
		LL x=read(),y=read();
		add(x,y),add(y,x);
	}
	for(LL i=1;i<=n;i++)dfs(i,i,0),memset(vis,0,sizeof vis);
	while(Q--){
		LL l=read(),r=read();
		printf("%lld\n",DIJ(l,r));
	}return 0;
}
