#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int ret=0,f=1;char ch=getchar();for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-f;for(;isdigit(ch);ch=getchar())ret=(ret<<1)+(ret<<3)+(ch&15);return ret*f;
}
#define maxn 1005
#define Maxn 500005
int ru[maxn],chu[Maxn],n,m;bool flg[maxn][maxn],yuan[maxn][maxn];
int cnt[maxn];
void init(){
	for(int i=1;i<=m;i++){
		int A=read(),B=read();
		yuan[B][A]=1;chu[A]++,ru[B]++;flg[B][A]=1;cnt[B]++;
	}
	for(int q=read();q--;){
		int op=read();
		if(op==1){
			int x=read(),y=read();
			flg[y][x]=0;chu[x]--;
		}if(op==2){int x=read();
		for(int i=1;i<=n;i++){
			if(flg[x][i]){
				chu[i]--,ru[x]--;flg[x][i]=0;
			}
		}
		
		}if(op==3){
			int x=read(),y=read();
			flg[y][x]=1;ru[y]++,chu[x]++;
		}if(op==4){
			int x=read();
			for(int i=1;i<=n;i++){
				if(yuan[x][i]){
					if(!flg[x][i]){
						flg[x][i]=1,ru[x]++,chu[i]++;
					}
				}
			}
		}bool f=0;
		for(int i=1;i<=n;i++)if((chu[i])^1){f=1;break;}
		puts(f?"NO":"YES");
	}
}
void init1(){
	for(int i=1;i<=m;i++){
		int A=read(),B=read();chu[A]++;
	}int c=0;for(int i=1;i<=n;i++)if(chu[i]==1)c++;
		for(int q=read();q--;){
		int op=read();
		if(op==1){
			int x=read(),y=read();
			chu[x]--;if(!chu[x])c--;if(chu[x]==1)c++; 
		
		}if(op==3){
			int x=read(),y=read();
			chu[x]++;if(chu[x]==2)c--;if(chu[x]==1)c++; 
		}
		puts(c^n?"NO":"YES");
	}
	
}
int main(){
	freopen("galaxy.in","r",stdin);freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	if(n<=1000)init();else init1();return 0;
}
