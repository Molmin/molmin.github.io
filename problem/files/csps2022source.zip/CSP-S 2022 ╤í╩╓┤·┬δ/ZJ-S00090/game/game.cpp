#include<bits/stdc++.h>
using namespace std;
typedef long long LL;
inline LL read(){
	LL ret=0,f=1;char ch=getchar();for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-f;for(;isdigit(ch);ch=getchar())ret=(ret<<1)+(ret<<3)+(ch&15);return ret*f;
}
#define maxn 1005
#define Maxn 20005
LL f[maxn][maxn<<1][12],n,m,a[Maxn],b[Maxn];
LL get(int i,int l,int r){
	int k=log2(r-l+1);
	return min(f[i][l][k],f[i][r-(1<<k)+1][k]);
}int q;
void init(){
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=m;i++)b[i]=read();
	memset(f,-63,sizeof f);
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)f[i][j][0]=a[i]*b[j];
	for(int i=1;i<=n;i++){
	for(int k=1;(1<<k)<=m;k++)
		for(int j=1;j<=m;j++){
			f[i][j][k]=min(f[i][j][k-1],f[i][j+(1<<(k-1))][k-1]);
		}
	}
	while(q--){
		int l=read(),r=read(),s=read(),t=read();
		LL Min=-5e18;
		for(int i=l;i<=r;i++){
			Min=max(get(i,s,t),Min);
		}
		printf("%lld\n",Min);
	}
	
	return;
}
LL f1[Maxn][20][2],f2[Maxn][20][2];//0 max 1 min
LL getmin(bool A,int l,int r){
	int k=log2(r-l+1);
	return A?min(f1[l][k][1],f1[r-(1<<k)+1][k][1]):min(f2[l][k][1],f2[r-(1<<k)+1][k][1]);
}LL getmax(bool A,int l,int r){
	int k=log2(r-l+1);
	return A?max(f1[l][k][0],f1[r-(1<<k)+1][k][0]):max(f2[l][k][0],f2[r-(1<<k)+1][k][0]);
}
void init1(){
	for(int i=1;i<=n;i++)f1[i][0][0]=f1[i][0][1]=a[i]=read();
	for(int i=1;i<=m;i++)f2[i][0][0]=f2[i][0][1]=b[i]=read();
	for(int k=1;(1<<k)<=n;k++)
		for(int j=1;j<=n;j++){
			f1[j][k][1]=min(f1[j][k-1][1],f1[j+(1<<(k-1))][k-1][1]);
			f1[j][k][0]=max(f1[j][k-1][0],f1[j+(1<<(k-1))][k-1][0]);
		}
	for(int k=1;(1<<k)<=m;k++)
		for(int j=1;j<=m;j++){
			f2[j][k][1]=min(f2[j][k-1][1],f2[j+(1<<(k-1))][k-1][1]);
			f2[j][k][0]=max(f2[j][k-1][0],f2[j+(1<<(k-1))][k-1][0]);
		}
	while(q--){LL ans;
		int l=read(),r=read(),s=read(),t=read();
		if(l==r){
			if(a[l]<0)ans=getmax(0,s,t);else ans=getmin(0,s,t);ans*=a[l];
		}else{
			if(b[s]<0)ans=getmax(1,l,r);else ans=getmin(1,l,r);ans*=b[s];
		}
		printf("%lld\n",ans);
	}
	
	
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read();q=read();
	if(n<=1000 and m<=1000)init();
	else init1();return 0;
}
