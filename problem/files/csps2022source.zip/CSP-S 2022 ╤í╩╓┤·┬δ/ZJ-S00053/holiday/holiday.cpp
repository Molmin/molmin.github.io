#include<bits/stdc++.h>
#define N 3005
#define M 30005
#define ll unsigned long long
using namespace std;
int n,m,K,o1,o2,fi[N],cnt,d[N][N],mx[N][5];
inline int read(){
	ll res=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res;
}
ll f[N][5][5],ans,a[N];
struct p{
	int ne,to;
}l[M];
struct data{
	int p,s;
};
inline void add(int x,int y){
	l[++cnt].ne=fi[x];
	l[cnt].to=y;
	fi[x]=cnt;
}
inline void bfs(int x){
	queue<data>q;
	for(int i=fi[x];i;i=l[i].ne)
	d[x][l[i].to]=0,q.push(data{l[i].to,0});
	while(!q.empty()){
		data u=q.front();q.pop();
		for(int i=fi[u.p];i;i=l[i].ne){
			int v=l[i].to;
			if(d[x][v]!=d[0][0])continue;
			d[x][v]=u.s+1;q.push(data{v,u.s+1});
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),K=read();memset(d,127,sizeof(d));
	for(int i=2;i<=n;++i)a[i]=read();
	for(int i=1;i<=m;++i)o1=read(),o2=read(),add(o1,o2),add(o2,o1);
	for(int i=1;i<=n;++i)bfs(i);
	for(int i=1;i<=n;++i)
	for(int j=1;j<=n;++j)
	if(i!=j&&d[i][j]<=K&&d[1][j]<=K){
		if(a[j]>=a[mx[i][1]])mx[i][3]=mx[i][2],mx[i][2]=mx[i][1],mx[i][1]=j;
		else if(a[j]>=a[mx[i][2]])mx[i][3]=mx[i][2],mx[i][2]=j;
		else if(a[j]>=a[mx[i][3]])mx[i][3]=j;
	}
	for(int i=2;i<=n;++i)
	for(int j=2;j<=n;++j)
	if(i!=j&&d[i][j]<=K){
		ll th=a[i]+a[j];int t1=1,t2=1;
		if(mx[i][t1]==j)++t1;if(mx[j][t2]==i)++t2;
		if(!mx[i][t1]||!mx[j][t2])continue;
		if(mx[i][t1]!=mx[j][t2]){ans=max(ans,a[mx[i][t1]]+a[mx[j][t2]]+th);continue;}
		o1=t1;
		++o1;if(mx[i][o1]==j)++o1;
		if(mx[i][o1])ans=max(ans,a[mx[i][o1]]+a[mx[j][t2]]+th);
		++t2;if(mx[j][t2]==i)++t2;
		if(mx[j][t2])ans=max(ans,a[mx[i][t1]]+a[mx[j][t2]]+th);
	}
	cout<<ans;
	return 0;
}