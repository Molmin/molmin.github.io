#include<bits/stdc++.h>
#define ll long long
#define N 100005
#define t tt[o][th]
#define ls tt[o][th<<1]
#define rs tt[o][th<<1|1]
using namespace std;
int n,m,Q;
ll a[2][N];
struct tree{
	ll mn,mx,mz,mf;
}tt[2][N<<2];
inline void build(int o,int th,int l,int r){
	if(l==r){
		t.mn=t.mx=a[o][l];
		if(a[o][l]<0)t.mf=a[o][l],t.mz=1e9;
		else t.mz=a[o][l],t.mf=-1e9;
		return;
	}
	int mid=l+r>>1;
	build(o,th<<1,l,mid),build(o,th<<1|1,mid+1,r);
	t.mn=min(ls.mn,rs.mn),t.mx=max(ls.mx,rs.mx);
	t.mz=min(ls.mz,rs.mz),t.mf=max(ls.mf,rs.mf);
}
inline int ask_mx(int o,int th,int l,int r,int tl,int tr){
	if(l>tr||r<tl)return -1e9;
	if(l>=tl&&r<=tr)return t.mx;
	int mid=l+r>>1;
	return max(ask_mx(o,th<<1,l,mid,tl,tr),ask_mx(o,th<<1|1,mid+1,r,tl,tr));
}
inline int ask_mn(int o,int th,int l,int r,int tl,int tr){
	if(l>tr||r<tl)return 1e9;
	if(l>=tl&&r<=tr)return t.mn;
	int mid=l+r>>1;
	return min(ask_mn(o,th<<1,l,mid,tl,tr),ask_mn(o,th<<1|1,mid+1,r,tl,tr));
}
inline int ask_mz(int o,int th,int l,int r,int tl,int tr){
	if(l>tr||r<tl)return 1e9;
	if(l>=tl&&r<=tr)return t.mz;
	int mid=l+r>>1;
	return min(ask_mz(o,th<<1,l,mid,tl,tr),ask_mz(o,th<<1|1,mid+1,r,tl,tr));
}
inline int ask_mf(int o,int th,int l,int r,int tl,int tr){
	if(l>tr||r<tl)return -1e9;
	if(l>=tl&&r<=tr)return t.mf;
	int mid=l+r>>1;
	return max(ask_mf(o,th<<1,l,mid,tl,tr),ask_mf(o,th<<1|1,mid+1,r,tl,tr));
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&Q);
	for(int i=1;i<=n;++i)scanf("%lld",&a[0][i]);
	for(int i=1;i<=m;++i)scanf("%lld",&a[1][i]);
	build(0,1,1,n),build(1,1,1,m);
	for(int i=1;i<=Q;++i){
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int jt1=3,jt2=3;
		ll mx1=ask_mx(0,1,1,n,l1,r1),mn1=ask_mn(0,1,1,n,l1,r1);
		ll mx2=ask_mx(1,1,1,m,l2,r2),mn2=ask_mn(1,1,1,m,l2,r2);
		if(mx1>=0&&mn1>=0)jt1=1;
		else if(mx1<=0&&mn1<=0)jt1=2;
		if(mx2>=0&&mn2>=0)jt2=1;
		else if(mx2<=0&&mn2<=0)jt2=2;
		if(jt1==1){
			if(jt2==1)printf("%lld\n",mx1*mn2);
			else printf("%lld\n",mn1*mn2);
			continue;
		}
		if(jt1==2){
			if(jt2==1)printf("%lld\n",mx1*mx2);
			else printf("%lld\n",mn1*mx2);
			continue;
		}
		if(jt2==1){printf("%lld\n",mx1*mn2);continue;}
		if(jt2==2){printf("%lld\n",mn1*mx2);continue;}
		if(l1==r1){
			if(a[0][l1]>0)printf("%lld\n",a[0][l1]*mn2);
			else printf("%lld\n",a[0][l1]*mx1);
			continue;
		}
		if(l2==r2){
			if(a[1][l2]>0)printf("%lld\n",mx1*a[1][l2]);
			else printf("%lld\n",mn1*a[1][l2]);
			continue;
		}
		ll z1=ask_mz(0,1,1,n,l1,r1),f1=ask_mf(0,1,1,n,l1,r1);
		ll z2=ask_mz(1,1,1,m,l2,r2),f2=ask_mf(1,1,1,m,l2,r2);
		ll t1=(z1*mn2<f1*mx2?f1:z1),t2=(z2*mx1>f2*mn2?f2:z2);
		printf("%lld\n",t1*t2);
	}
	return 0;
}