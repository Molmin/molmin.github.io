#include<bits/stdc++.h>
#define N 500005
using namespace std;
int n,m,Q,tm,fi[N],cnt,t[5005][5005],tx[N],ty[N],o1,o2;
inline int read(){
	int res=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
	return res;
}
struct p{
	int ne,to;
}l[N];
bool vis[N];
inline void add(int x,int y){
	l[++cnt].ne=fi[x];
	l[cnt].to=y;
	fi[x]=cnt;
}
inline bool check(){
	bool v[N];memset(v,0,sizeof(v));
	for(int i=1;i<=n;++i){
		int tot=0;
		for(int i=fi[i];i;i=l[i].ne){
			if(vis[i])continue;
			++tot,v[i]=1;
		}
		if(tot!=1)return 0;
	}
	int tot=0;
	for(int i=1;i<=n;++i)if(!v[i])return 0;
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read(),Q=read();
	for(int i=1;i<=m;++i)o1=read(),o2=read(),add(o1,o2),t[o1][o2]=cnt,
	tx[i]=o1,ty[i]=o2;
	while(Q--){
		int tmp,x,y;
		tmp=read(),x=read();
		if(tmp==1)y=read(),vis[t[x][y]]=1;
		if(tmp==2)for(int i=1;i<=m;++i)if(ty[o2]==x)vis[i]=1;
		if(tmp==3)y=read(),vis[t[x][y]]=0;
		if(tmp==4)for(int i=1;i<=m;++i)if(ty[o2]==x)vis[i]=0;
		if(check())printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}