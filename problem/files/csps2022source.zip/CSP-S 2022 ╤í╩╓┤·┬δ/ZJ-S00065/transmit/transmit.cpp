#include<bits/stdc++.h>
#define ll long long
#define N 200010
#define inf 0x3f3f3f3f3f3f3f3fLL
using namespace std;

int n, q, k;
int a[N], b[N], he[N], fa[N][20], de[N], cnt;
ll f[N], sum[N];
struct node {
	int to, ne;
}e[N*2];
void add(int x, int y) {
	e[++cnt]={y,he[x]}, he[x]=cnt;
}
void dfs(int x) {
	for(int i = 1; i < 19; i++) fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i = he[x]; i; i=e[i].ne) {
		int y=e[i].to;
		if(y==fa[x][0]) continue;
		de[y]=de[x]+1,sum[y]=sum[x]+a[y], fa[y][0]=x, dfs(y);
	}
}
int lca(int x, int y) {
	if(de[x]>de[y]) swap(x,y);
	for(int i = 19; i >= 0; i--) if(de[fa[y][i]]>=de[x]) y=fa[y][i];
	if(x==y) return x;
	for(int i = 19; i >= 0; i--) if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for(int i = 1; i < n; i++) {
		int x, y;
		scanf("%d%d",&x,&y);
		add(x,y),add(y,x);
	}
	sum[1]=a[1], de[1]=1, dfs(1);
	for(int i = 1; i <= q; i++) {
		int x, y, t, l1=0, len;
		scanf("%d%d",&x,&y);
		t=lca(x,y),len=de[x]+de[y]-2*de[t]+1;
		if(k==1) {
			printf("%lld\n",sum[x]+sum[y]-2*sum[t]+a[t]);
			continue;
		}
		for(int j = x; j!=t; j=fa[j][0]) b[++l1]=j;
		for(int j = y; j!=t; j=fa[j][0]) b[len--]=j;
		b[++l1]=t;
		len=de[x]+de[y]-2*de[t]+1;
		for(int j = 0; j <= len; j++) f[j]=inf;
		f[1]=a[b[1]];
		for(int j = 2; j <= len; j++) {
			f[j]=min(f[j],f[j-1]+a[b[j]]);
			if(k==2) {
				if(j>=3) f[j]=min(f[j],f[j-2]+a[b[j]]);
			}
			if(k==3) {
				if(j>=3) f[j]=min(f[j],f[j-2]+a[b[j]]);
				if(j>=4) f[j]=min(f[j],f[j-3]+a[b[j]]);
			}
		}
		printf("%lld\n",f[len]);
	}
	return 0;
}