#include<bits/stdc++.h>
#define ll long long
#define N 2510
#define M 10010
#define inf 0x3f3f3f3f
using namespace std;

int n, m, k;
ll a[N], ans;
int cnt,he[N],d[N];
bool f[N][N];
struct node {
	int to, ne;
}e[M*2];
void add(int x, int y) {
	e[++cnt]={y,he[x]};
	he[x]=cnt;
}
void sol(int x) {
	queue<int> q;
	memset(d,0x3f,sizeof(d));
	d[x]=-1;
	q.push(x);
	while(!q.empty()) {
		int t=q.front();q.pop();
		f[x][t]=f[t][x]=1;
		if(d[t]+1>k) continue;
		for(int i = he[t]; i; i=e[i].ne) {
			int y=e[i].to;
			if(d[y]==inf) d[y]=d[t]+1,q.push(y);
		}
	}
}
int g[N][2];
void chk(int x, int y) {
	if(a[y]>=a[g[x][0]]) g[x][1]=g[x][0],g[x][0]=y;
	else if(a[y]>a[g[x][1]]) g[x][1]=y;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 2; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1; i <= m; i++) {
		int x, y;
		scanf("%d%d",&x,&y);
		add(x,y),add(y,x);
	}
	for(int i = 1; i <= n; i++) sol(i);
	for(int i = 2; i <= n; i++)
		for(int j = 2; j <= n; j++)
			if(i!=j&&f[1][i]&&f[i][j]) {
				chk(i,j),chk(j,i);
			}
	for(int i = 2; i <= n; i++)
		for(int j = i+1; j <= n; j++)
			if(i!=j&&f[i][j]) {
				if(g[i][0]&&g[j][0]&&g[i][0]!=g[j][0]&&i!=g[j][0]&&j!=g[i][0]) ans=max(ans,a[i]+a[j]+a[g[i][0]]+a[g[j][0]]);
				else if(g[i][0]&&g[j][1]&&g[i][0]!=g[j][1]&&i!=g[j][1]&&j!=g[i][0])ans=max(ans,a[i]+a[j]+a[g[i][0]]+a[g[j][1]]);
				else if(g[i][1]&&g[j][0]&&g[i][1]!=g[j][0]&&i!=g[j][0]&&j!=g[i][1])ans=max(ans,a[i]+a[j]+a[g[i][1]]+a[g[j][0]]);
			}
	printf("%lld\n",ans);
	return 0;
}