#include<bits/stdc++.h>
#define ll long long
#define N 100010
#define inf 1000000001
using namespace std;

int n, m, q,len;
int a[N],b[N],s1[N][20],s2[N][20],h[N];
int mi[N<<2],mx[N<<2],lz[N<<2],hz[N<<2];
void pushup(int rt) {
	int lc=rt<<1,rc=rt<<1|1;
	mi[rt]=min(mi[lc],mi[rc]),mx[rt]=max(mx[lc],mx[rc]);
	lz[rt]=max(lz[lc],lz[rc]),hz[rt]=min(hz[lc],hz[rc]);
}
void build(int rt, int l, int r) {
	mi[rt]=inf,mx[rt]=-inf,lz[rt]=-inf,hz[rt]=inf;
	if(l==r) {
		mi[rt]=mx[rt]=a[l];
		if(a[l]<=0) lz[rt]=a[l];
		if(a[l]>=0) hz[rt]=a[l];
		return;
	}
	int mid=(l+r)>>1;
	build(rt<<1,l,mid);
	build(rt<<1|1,mid+1,r);
	pushup(rt);
}
int f1(int l, int r) {
	int len=r-l+1, t=h[len];
	return max(s1[l][t],s1[r-(1<<t)+1][t]);
}
int f2(int l, int r) {
	int len=r-l+1, t=h[len];
	return min(s2[l][t],s2[r-(1<<t)+1][t]);
}
int fmx(int rt, int l, int r, int x, int y) {
	if(x<=l&&r<=y) return mx[rt];
	int mid=(l+r)>>1,res=-inf;
	if(x<=mid) res=max(res,fmx(rt<<1,l,mid,x,y));
	if(y>mid) res=max(res,fmx(rt<<1|1,mid+1,r,x,y));
	return res;
}
int fmi(int rt, int l, int r, int x, int y) {
	if(x<=l&&r<=y) return mi[rt];
	int mid=(l+r)>>1,res=inf;
	if(x<=mid) res=min(res,fmi(rt<<1,l,mid,x,y));
	if(y>mid) res=min(res,fmi(rt<<1|1,mid+1,r,x,y));
	return res;
}
int flz(int rt, int l, int r, int x, int y) {
	if(x<=l&&r<=y) return lz[rt];
	int mid=(l+r)>>1,res=-inf;
	if(x<=mid) res=max(res,flz(rt<<1,l,mid,x,y));
	if(y>mid) res=max(res,flz(rt<<1|1,mid+1,r,x,y));
	return res;
}
int fhz(int rt, int l, int r, int x, int y) {
	if(x<=l&&r<=y) return hz[rt];
	int mid=(l+r)>>1,res=inf;
	if(x<=mid) res=min(res,fhz(rt<<1,l,mid,x,y));
	if(y>mid) res=min(res,fhz(rt<<1|1,mid+1,r,x,y));
	return res;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i = 1; i <= n; i++) scanf("%lld",&a[i]);
	for(int i = 1; i <= m; i++) scanf("%lld",&b[i]),s1[i][0]=s2[i][0]=b[i];
	build(1,1,n);
	len=0;
	while((1<<len)<m) len++;
	for(int i = 2; i <= m; i++) h[i]=h[i-1]+(i==(1<<(h[i-1]+1)));
	for(int i = 1; i <= len; i++)
		for(int j = 1; j+(1<<i)-1<=m; j++) {
			s1[j][i]=max(s1[j][i-1],s1[j+(1<<(i-1))][i-1]);
			s2[j][i]=min(s2[j][i-1],s2[j+(1<<(i-1))][i-1]);
		}
	for(int i = 1; i <= q; i++) {
		int l,r,L,R;
		scanf("%d%d%d%d",&l,&r,&L,&R);
		ll t1=f1(L,R),t2=f2(L,R),q1,q2;
		if(t1>=0&&t2>=0) {
			q1=fmx(1,1,n,l,r);
			printf("%lld\n",min(q1*t1,q1*t2));
		}
		else if(t1<=0&&t2<=0) {
			q1=fmi(1,1,n,l,r);
			printf("%lld\n",min(q1*t1,q1*t2));
		}
		else {
			q1=flz(1,1,n,l,r),q2=fhz(1,1,n,l,r);
			ll ans=max(min(q1*t1,q1*t2),min(q2*t1,q2*t2));
			printf("%lld\n",ans);
		}
	}
	return 0;
}