#include<bits/stdc++.h>
#define N 500010
#define M 500010
using namespace std;

int n, m, q;
struct node {
	int x, y;
}e[M];
vector<int> a[N];
int deg[N], ttt, sum;
bool flg[M];
int pd() {
	for(int i = 1; i <= n; i++) if(deg[i]!=1) return 0;
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= m; i++) scanf("%d%d",&e[i].x,&e[i].y),deg[e[i].x]++,a[e[i].y].push_back(i);
	scanf("%d",&q);
	for(int i = 1; i <= q; i++) {
		int t, u, v;
		scanf("%d%d",&t,&u);
		if(t==1) {
			scanf("%d",&v), deg[u]--, sum--;
			if(!deg[u]) ttt++;
			if(n<=1000){
				for(int j = 1; j <= m; j++)
					if(e[j].x==u&&e[j].y==v) {
						flg[j]=1;break;
					}
			}
		}
		else if(t==2) {
			for(int j = 0; j < a[u].size(); j++) {
				int t=a[u][j],y=e[t].x;
				if(!flg[t]) deg[y]--,flg[t]=1;
			}
		}
		else if(t==3) {
			if(!deg[u]) ttt--;
			scanf("%d",&v), deg[u]++, sum++;
			if(n<=1000){
				for(int j = 1; j <= m; j++)
					if(e[j].x==u&&e[j].y==v) {
						flg[j]=0;break;
					}
			}
		}
		else if(t==4) {
			for(int j = 0; j < a[u].size(); j++) {
				int t=a[u][j],y=e[t].x;
				if(flg[t]) deg[y]++,flg[t]=0;
			}
		}
		if(n<=1000) {
			if(pd()) printf("YES\n");
			else printf("NO\n");
		}
		else {
			if(!ttt&&sum==n) printf("YES\n");
			else printf("NO\n");
		}
	}
	return 0;
}