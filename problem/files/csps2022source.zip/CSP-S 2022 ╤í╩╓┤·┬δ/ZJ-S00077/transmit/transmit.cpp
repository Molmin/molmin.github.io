#include<iostream>
#include<cstdio>
using namespace std;
int n,Q,k;
long long v[10000],fl[2100][2100];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>Q>>k;
	for (int i=1;i<=n;++i){
		cin>>v[i];
	}
	for (int i=1;i<n;++i){
		int x,y;
		cin>>x>>y;
		fl[x][y]=fl[y][x]=1;
	}
	for (int i=1;i<=Q;++i){
		int x,y;
		cin>>x>>y;
		printf("%lld\n",v[x]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
