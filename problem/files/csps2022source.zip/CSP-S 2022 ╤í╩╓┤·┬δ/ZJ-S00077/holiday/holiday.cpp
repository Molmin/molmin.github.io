/*
1.��鿪longlong
*/

#include<iostream>
#include<cstdio>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;

struct node{
	int x1,x2;
	long long su;
}sva[6250010];	//�۰������� 
int n,m,k,len;
int ma[310][310],arred[110];	//1~8����int���� 
int mb[2510][2510];
long long maxn,ans1,ans2,value[2510];
vector <int> road[2510];

bool cmp(node x,node y){
	return x.su>y.su;
}

void dfs1(int x,int y,long long sum){
	//x����λ�� y����ڼ������� sum����֮��
	if (sum+maxn*(4-y)<ans1) return;
	if (y==4){
		if (ma[x][1]<=k){
			if (sum>ans1){
				ans1=sum;
			}
		}
		return;
	} 	//������ĸ����� 
	
	for (int i=2;i<=n;++i){
		if (!arred[i] && ma[x][i]<=k){
			arred[i]=1;
			dfs1(i,y+1,sum+value[i]);
			arred[i]=0;
		}
	}//ö��	ǰ������һ������ 
	
	return;
}

void dfs2(){
	for (int i=2;i<=n;++i){
		if (mb[1][i]){
			for (int j=2;j<=n;++j){
				if (i==j || !mb[i][j]) continue;
				sva[++len].x1=i;
				sva[len].x2=j;
				sva[len].su=value[i]+value[j];
			}
		}
	}	
	return ;
}

void dfs3(int l,int r){
	if (l>r) return;
	bool flag=0;
	for (int i=l+1;i<=r;++i){	//i��l 
		if (sva[i].x1==sva[l].x1 || sva[i].x1==sva[l].x2) continue;
		if (sva[i].x2==sva[l].x1 || sva[i].x2==sva[l].x2) continue;
		if (!mb[sva[i].x2][sva[l].x2]) continue;
		ans2=max(ans2,sva[i].su+sva[l].su);
		flag=1;
		dfs3(l+1,i-1);
		break;
	}
	if (!flag) {
		dfs3(l+1,r);
	}
	return ;
}

void dfs4(){
	for (int i=2;i<=n;++i){
		if (ma[1][i]<=k){
			for (int j=2;j<=n;++j){
				if (i==j || ma[i][j]>k) continue;
				sva[++len].x1=i;
				sva[len].x2=j;
				sva[len].su=value[i]+value[j];
//				cout<<sva[len].x1<<" "<<sva[len].x2<<" "<<sva[len].su<<endl; 
			}
		}
	}	
	return ;
}

void dfs5(int l,int r){
	if (l>r) return;
	bool flag=0;
	for (int i=l+1;i<=r;++i){	//i��l 
		if (sva[i].x1==sva[l].x1 || sva[i].x1==sva[l].x2) continue;
		if (sva[i].x2==sva[l].x1 || sva[i].x2==sva[l].x2) continue;
		if (ma[sva[i].x2][sva[l].x2]>k) continue;
		ans2=max(ans2,sva[i].su+sva[l].su);
		flag=1;
		dfs5(l+1,i-1);
		break;
	}
	if (!flag) {
		dfs5(l+1,r);
	}
	return ;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	if (n<=300){
		memset(ma,127/6,sizeof(ma));
	}
	for (int i=2;i<=n;++i){
		scanf("%lld",&value[i]);
		maxn=max(maxn,value[i]);
	}
	for (int i=1;i<=m;++i){
		int x,y;
		scanf("%d%d",&x,&y);
		road[x].push_back(y);
		road[y].push_back(x);
		if (n<=300){
			ma[x][y]=ma[y][x]=0;
		}
		mb[x][y]=mb[y][x]=1;
	}	//��ʼ��+���� 
	
	if (n<=20){
		for (int kk=1;kk<=n;++kk){
			for (int i=1;i<=n;++i) {
				if (ma[i][kk]<=k && i!=kk){
					for (int j=1;j<=n;++j){
						if (j==i || j==kk) continue;
						int temp=ma[i][kk]+ma[kk][j]+1;
						if (temp<ma[i][j]){
							ma[i][j]=temp;
						}
					}
				}
			}
		}	//��·�� ����ת��������¼��ma��

		dfs1(1,0,0);	//ģ��4����������������ֵ 
		
		printf("%lld",ans1);
	}	//����1~8�� 
	
	else if (k==0){
		dfs2();	//�ҵ�len��
		sort(sva+1,sva+1+len,cmp);
		dfs3(1,len);	//��� 
		printf("%lld",ans2);
	}	//����k==0����� 
	
	else {
		for (int kk=1;kk<=n;++kk){
			for (int i=1;i<=n;++i) {
				if (ma[i][kk]<=k && i!=kk){
					for (int j=1;j<=n;++j){
						if (j==i || j==kk) continue;
						int temp=ma[i][kk]+ma[kk][j]+1;
						if (temp<ma[i][j]){
							ma[i][j]=temp;
						}
					}
				}
			}
		}	//��·�� ����ת��������¼��ma��
		dfs4();	//�ҵ�len��
		sort(sva+1,sva+1+len,cmp);
		dfs5(1,len);	//��� 
		printf("%lld",ans2);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
