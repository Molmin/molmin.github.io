#include<iostream>
#include<cstdio>
using namespace std;
struct tree{
	int l,r,fu;	//1ֻ���� 2ֻ�и� 3 �����и� 
	int fl;	//�Ƿ���0 
	long long ma,mi,fma,zmi;
}p,ta[1000100],tb[1000100];
int n,m,q;
long long a[100100],b[100100],INF=0x7f7f7f7f7f7f7f7f;
void plant_a(int x,int l,int r){
	int mid=((l+r)>>1);
	ta[x].l=l;
	ta[x].r=r;
	if (l==r){
		ta[x].ma=ta[x].mi=a[l];
		ta[x].fma=-INF;
		ta[x].zmi=INF;
		if (a[l]>0) {ta[x].fu=1;ta[x].zmi=a[l];}
		else if (a[l]==0) {ta[x].fl=1;}
		else if (a[l]<0) {ta[x].fu=2;ta[x].fma=a[l];}
		return;
	}
	plant_a(x<<1,l,mid);
	plant_a(x<<1|1,mid+1,r);
	ta[x].ma=max(ta[x<<1].ma,ta[x<<1|1].ma);
	ta[x].mi=min(ta[x<<1].mi,ta[x<<1|1].mi);
	ta[x].fu=ta[x<<1].fu|ta[x<<1|1].fu;
	ta[x].fl=ta[x<<1].fl|ta[x<<1|1].fl;
	ta[x].fma=max(ta[x<<1].fma,ta[x<<1|1].fma);
	ta[x].zmi=min(ta[x<<1].zmi,ta[x<<1|1].zmi);
}
void plant_b(int x,int l,int r){
	int mid=((l+r)>>1);
	tb[x].l=l;
	tb[x].r=r;
	if (l==r){
		tb[x].ma=tb[x].mi=b[l];
		tb[x].fma=-INF;
		tb[x].zmi=INF;
		if (b[l]>0) {tb[x].fu=1;tb[x].zmi=b[l];}
		else if (b[l]==0) {tb[x].fl=1;}
		else if (b[l]<0) {tb[x].fu=2;tb[x].fma=b[l];}
		return;
	}
	plant_b(x<<1,l,mid);
	plant_b(x<<1|1,mid+1,r);
	tb[x].ma=max(tb[x<<1].ma,tb[x<<1|1].ma);
	tb[x].mi=min(tb[x<<1].mi,tb[x<<1|1].mi);
	tb[x].fu=tb[x<<1].fu|tb[x<<1|1].fu;
	tb[x].fl=tb[x<<1].fl|tb[x<<1|1].fl;
	tb[x].fma=max(tb[x<<1].fma,tb[x<<1|1].fma);
	tb[x].zmi=min(tb[x<<1].zmi,tb[x<<1|1].zmi);
}
tree add(tree x,tree y){
	tree temp;
	temp.fu=x.fu|y.fu;
	temp.fl=x.fl|y.fl;
	temp.ma=max(x.ma,y.ma);
	temp.mi=min(x.mi,y.mi);
	temp.zmi=min(x.zmi,y.zmi);
	temp.fma=max(x.fma,y.fma);
	return temp;
}
tree find_b(int x,int l,int r){
	if (tb[x].l>r || tb[x].r<l) return p;
	if (tb[x].l>=l && tb[x].r<=r) {
		return tb[x];
	}
	return add(find_b(x<<1,l,r),find_b(x<<1|1,l,r));
}
tree find_a(int x,int l,int r){
	if (ta[x].l>r || ta[x].r<l) return p;
	if (ta[x].l>=l && ta[x].r<=r) {
		return ta[x];
	}
	return add(find_a(x<<1,l,r),find_a(x<<1|1,l,r));
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	p.fma=p.ma=-INF;
	p.zmi=p.mi=INF;
	for (int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
	}
	plant_a(1,1,n);;
	for (int i=1;i<=m;++i){
		scanf("%lld",&b[i]);
	}
//	cout<<b[2]<<endl;
	plant_b(1,1,m);
	
	for (int i=1;i<=q;++i){
		int l1,l2,r1,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		tree tta=find_a(1,l1,r1),ttb=find_b(1,l2,r2);
//		if (i==256){
//			cout<<tta.fl<<" "<<tta.fu<<endl;
//			cout<<ttb.fl<<" "<<ttb.fu<<endl;	
//		}
//		else continue;
		if (ttb.fu==3){
			if (tta.fl) printf("0\n");
			else{
				long long x,y;
				x=tta.fma*ttb.ma;
//				cout<<"   "<<tta.fma<<endl;
				y=tta.zmi*ttb.mi;
//				cout<<"    "<<ttb.mi<<endl;
				if (tta.fu==1) printf("%lld\n",y);
				else if (tta.fu==2) printf("%lld\n",x);
				else if (x<y) printf("%lld\n",y);
				else printf("%lld\n",x);
			}
		}
		else if (ttb.fu==0){
			printf("0\n");
		}
		else if (ttb.fu==1){
//			cout<<tta.mi<<" "<<tta.ma<<endl;
//			cout<<ttb.mi<<" "<<ttb.ma<<endl;
			if (tta.fu==1 || tta.fu==3) printf("%lld\n",tta.ma*ttb.mi);
			else printf("%lld\n",tta.ma*ttb.ma);
		}
		else if (ttb.fu==2){
			if (tta.fu==2 || tta.fu==3) printf("%lld\n",tta.mi*ttb.ma);
			else printf("%lld\n",tta.mi*ttb.mi);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
