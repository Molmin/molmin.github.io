#include<bits/stdc++.h>
#define int long long
using namespace std;
struct edge{
	int to,next;
}e[400010];
int n,T,K,cnt,fa[200010][21],deep[200010],head[200010],a[200010],F[200010],dis[200010];
bool vis[200010];
inline void add(int u,int v){
	cnt++;
	e[cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
}
inline void dfs(int u,int from){
	fa[u][0]=from,deep[u]=deep[from]+1,F[u]=F[from]+a[u];
	for(int i=1;i<=20;i++)fa[u][i]=fa[fa[u][i-1]][i-1];
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].to;
		if(v==from)continue;
		dfs(v,u);
	}
}
inline int LCA(int x,int y){
	if(deep[x]<deep[y])swap(x,y);
	for(int i=20;~i;i--)
	if(deep[fa[x][i]]>=deep[y])x=fa[x][i];
	if(x==y)return x;
	for(int i=20;~i;i--)
	if(fa[x][i]!=fa[y][i])x=fa[x][i],y=fa[y][i];
	return fa[x][0];
}
priority_queue<pair<int,int> >Q;
inline int D(int x,int y){
	int p=LCA(x,y);
	return deep[x]+deep[y]-2*deep[p];
}
inline void Dij(int s){
	for(int i=1;i<=n;i++)dis[i]=1e18,vis[i]=0;
	dis[s]=a[s],Q.push({-dis[s],s});
	while(!Q.empty()){
		int u=Q.top().second;Q.pop();
		if(vis[u])continue;vis[u]=1;
		for(int v=1;v<=n;v++){
			if(u==v)continue;
			if(D(u,v)>K)continue;
			if(dis[u]+a[v]>=dis[v])continue;
			dis[v]=dis[u]+a[v];
			if(!vis[v])Q.push({-dis[v],v});
		}
	}
}
inline int solve(int x,int y){
	if(K==1){
		int p=LCA(x,y);
		return F[x]+F[y]-2*F[p]+a[p];
	}
	Dij(x);
	return dis[y]; 
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	std::ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>T>>K;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1,x,y;i<n;i++)cin>>x>>y,add(x,y),add(y,x);
	dfs(1,0);
	while(T--){
		int x,y;
		cin>>x>>y,cout<<solve(x,y)<<'\n';
	}
	return 0;
}
