#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,K,a[2510],res,f[2510][2510],F[2510][3],S[2510][3],dis[2510][2510];
bool vis[2510];
vector<int>e[2510];
queue<int>Q;
inline void add(int u,int v){
	e[u].push_back(v);
}
inline void bfs(int s){
	for(int i=1;i<=n;i++)vis[i]=0;
	Q.push(s),vis[s]=1,dis[s][s]=-1;
	while(!Q.empty()){
		int u=Q.front();Q.pop();
		for(int v:e[u]){
			if(vis[v])continue;
			dis[s][v]=dis[s][u]+1;
			vis[v]=1,Q.push(v);
		}
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	std::ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>K;
	for(int i=2;i<=n;i++)cin>>a[i];
	for(int i=1,x,y;i<=m;i++)cin>>x>>y,add(x,y),add(y,x);
	for(int i=1;i<=n;i++)bfs(i);
	for(int i=2;i<=n;i++)
	for(int j=2;j<=n;j++)
	if(i!=j&&dis[1][i]<=K&&dis[i][j]<=K)f[i][j]=a[i]+a[j];
	else f[i][j]=-1e18;
	for(int i=2;i<=n;i++){
		F[i][0]=F[i][1]=F[i][2]=-1e18;
		for(int j=2;j<=n;j++)
		if(i!=j){
			if(f[j][i]>F[i][0]){
				F[i][2]=F[i][1],S[i][2]=S[i][1];
				F[i][1]=F[i][0],S[i][1]=S[i][0];
				F[i][0]=f[j][i],S[i][0]=j;
			}
			else if(f[j][i]>F[i][1]){
				F[i][2]=F[i][1],S[i][2]=S[i][1];
				F[i][1]=f[j][i],S[i][1]=j;
			}
			else if(f[j][i]>F[i][2]){
				F[i][2]=f[j][i],S[i][2]=j;
			}
		}
	}
	for(int i=2;i<=n;i++)
	for(int j=2;j<=n;j++)
	if(i!=j&&dis[i][j]<=K){
		for(int k=0;k<3;k++)
		for(int l=0;l<3;l++){
			int A=S[i][k],B=i,C=j,D=S[j][l];
			if(A==B||A==C||A==D)continue;
			if(B==A||B==C||B==D)continue;
			if(C==A||C==B||C==D)continue;
			if(D==A||D==B||D==C)continue;
			res=max(res,F[i][k]+F[j][l]);
		}
	}
	cout<<res;
	return 0;
}
