#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,Q,a[100010];
struct SGT{
	struct node{
		int c,v,d;
	}tr[400010];
	inline void push_up(int p){
		tr[p].c=max(tr[p<<1].c,tr[p<<1|1].c);
		tr[p].v=min(tr[p<<1].v,tr[p<<1|1].v);
		tr[p].d=tr[p<<1].d|tr[p<<1|1].d;
	}
	inline void build(int p,int l,int r){
		if(l>=r){tr[p].c=tr[p].v=a[l];tr[p].d=(a[l]==0);return;}
		int mid=(l+r)>>1;
		build(p<<1,l,mid),build(p<<1|1,mid+1,r);
		push_up(p);
	}
	inline int query(int p,int l,int r,int L,int R,int opt){
		if(l>=L&&r<=R){
			if(opt)return tr[p].c;
			else return tr[p].v;
		}
		int mid=(l+r)>>1,res=opt?-1e9:1e9;
		if(L<=mid){
			if(opt)res=max(res,query(p<<1,l,mid,L,R,opt));
			else res=min(res,query(p<<1,l,mid,L,R,opt));
		}
		if(R>mid){
			if(opt)res=max(res,query(p<<1|1,mid+1,r,L,R,opt));
			else res=min(res,query(p<<1|1,mid+1,r,L,R,opt));
		}
		return res;
	}
	inline int Q(int p,int l,int r,int L,int R){
		if(l>=L&&r<=R)return tr[p].d;
		int mid=(l+r)>>1,res=0;
		if(L<=mid)res|=Q(p<<1,l,mid,L,R);
		if(R>mid)res|=Q(p<<1|1,mid+1,r,L,R);
		return res;
	}
}A,B;
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	std::ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>Q;
	for(int i=1;i<=n;i++)cin>>a[i];
	A.build(1,1,n);
	for(int i=1;i<=m;i++)cin>>a[i];
	B.build(1,1,m);
	while(Q--){
		int l,r,x,y;
		cin>>l>>r>>x>>y;
		int X[3];X[0]=A.query(1,1,n,l,r,0),X[1]=A.query(1,1,n,l,r,1),X[2]=A.Q(1,1,n,l,r);
		int Y[3];Y[0]=B.query(1,1,m,x,y,0),Y[1]=B.query(1,1,m,x,y,1),Y[2]=B.Q(1,1,m,x,y);
		if(X[1]<=0){
			if(Y[1]>0){
				if(X[2])cout<<0<<'\n';
				else cout<<X[1]*Y[1]<<'\n';
			}
			else cout<<X[0]*Y[1]<<'\n';
		}
		else{
			if(X[0]<=0){
				if(Y[1]<=0)cout<<X[0]*Y[1]<<'\n';
				else{
					if(Y[0]<=0){
						if(X[2])cout<<0<<'\n';
						else cout<<X[0]*Y[0]<<'\n';
					}
					else cout<<X[1]*Y[0]<<'\n';
				}
			}
			else{
				if(Y[1]<=0)cout<<X[0]*Y[0]<<'\n';
				else{
					if(Y[0]<=0)cout<<X[0]*Y[0]<<'\n';
					else cout<<X[1]*Y[0]<<'\n';
				}
			}
		}
	}
	return 0;
}
