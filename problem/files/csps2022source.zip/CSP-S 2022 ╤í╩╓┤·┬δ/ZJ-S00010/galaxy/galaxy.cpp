#include<bits/stdc++.h>
using namespace std;
int n,m,T,siz[1010],col[1010],in[1010],out[1010],I[1010],cnt,tot,top,S[1010],dfn[1010],low[1010];
bool used[1010][1010],f[1010];
vector<int>e[1010],g[1010];
queue<int>Q;
vector<int>E[1010];
inline void Tarjan(int u){
	dfn[u]=low[u]=++tot,S[++top]=u;
	for(int v:e[u]){
		if(used[u][v])continue;
		if(!dfn[v])Tarjan(v),low[u]=min(low[u],low[v]);
		else if(!col[v])low[u]=min(low[u],dfn[v]);
	}
	if(dfn[u]==low[u]){
		col[u]=++cnt,siz[cnt]=1;
		while(u!=S[top])col[S[top]]=cnt,siz[cnt]++,top--;
		top--;
	}
}
inline bool check(){
	for(int i=1;i<=n;i++)if(out[i]!=1)return 0;
	cnt=top=tot=0;
	for(int i=1;i<=n;i++)dfn[i]=low[i]=col[i]=siz[i]=I[i]=f[i]=0,E[i].clear();
	for(int i=1;i<=n;i++)if(!dfn[i])Tarjan(i);
	for(int i=1;i<=n;i++)
	for(int j:e[i])
	if(col[i]!=col[j]){
		if(used[i][j])continue;
		E[col[j]].push_back(col[i]),I[col[i]]++;
	}
	for(int i=1;i<=cnt;i++)if(!I[i])Q.push(i);
	while(!Q.empty()){
		int u=Q.front();Q.pop();
		if(siz[u]>1)f[u]=1;
		for(int v:E[u]){
			f[v]|=f[u];
			if(!--I[v])Q.push(v);
		}
	}
	for(int i=1;i<=cnt;i++)if(!f[i])return 0;
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	std::ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(int i=1,x,y;i<=m;i++)cin>>x>>y,e[x].push_back(y),g[y].push_back(x),out[x]++,in[y]++;
	cin>>T;
	while(T--){
		int opt,x,y;
		cin>>opt;
		if(opt==1)cin>>x>>y,used[x][y]=1,out[x]--,in[y]--;
		if(opt==2){cin>>x;for(int i:g[x])if(!used[i][x])used[i][x]=1,out[i]--,in[x]--;}
		if(opt==3)cin>>x>>y,used[x][y]=0,out[x]++,in[y]++;
		if(opt==4){cin>>x;for(int i:g[x])if(used[i][x])used[i][x]=0,out[i]++,in[x]++;}
		if(check())cout<<"YES\n";
		else cout<<"NO\n";
	}
	return 0;
}
