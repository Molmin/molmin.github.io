#include<bits/stdc++.h>
#define int long long 
#define For(i,a,b) for( register int i = ( a ) ; i <= ( b ) ; ++ i )
#define Rep(i,a,b) for( register int i = ( a ) ; i >= ( b ) ; -- i )
using namespace std ;
inline int read() {
	int s = 0 ; char ch = getchar() ; bool f = 0 ;
	for( ; !isdigit( ch ) ; ch = getchar() ) f ^= !( 45 ^ ch ) ;
	for( ; isdigit( ch ) ; ch = getchar() ) s = ( s << 3 ) + ( s << 1 ) + ( ch ^ 48 ) ;
	if( f ) return -s ; return s ;
}
int jdz( int x ) {
	if( x < 0 ) return -x ; 
	return x ;
}
int n , m , q , l1 , r1 , l2 , r2 ;
const int M = 100005 ;
int a[ M ] , b[ M ] ;
int INF = 1e18 + 1 ;
int qa1[ M ][ 25 ] , qa2[ M ][ 25 ] , qa3[ M ][ 25 ] , qa4[ M ][ 25 ] ;
int qb1[ M ][ 25 ] , qb2[ M ][ 25 ] ;
int log2( int x ) {
	return log( x )/log( 2 ) ;
}
void qry() {
	For( i , 1 , log2( n ) + 1 )
		For( j , 1 , n ) {
			if( j + ( 1 << i ) - 1 > n ) continue ;
			qa1[ j ][ i ] = max( qa1[ j ][ i - 1 ] , qa1[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
			qa2[ j ][ i ] = min( qa2[ j ][ i - 1 ] , qa2[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
			qa3[ j ][ i ] = min( qa3[ j ][ i - 1 ] , qa3[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
			qa4[ j ][ i ] = max( qa4[ j ][ i - 1 ] , qa4[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
		}
	For( i , 1 , log2( m ) + 1 )
		For( j , 1 , m ) {
			if( j + ( 1 << i ) - 1 > n ) continue ;
			qb1[ j ][ i ] = max( qb1[ j ][ i - 1 ] , qb1[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
			qb2[ j ][ i ] = min( qb2[ j ][ i - 1 ] , qb2[ j + ( 1 << ( i - 1 ) ) ][ i - 1 ] ) ;
		}
}
signed main() {
	freopen("game.in" , "r" , stdin ) ;
	freopen("game.out" , "w" , stdout ) ;
	n = read() ; 
	m = read() ;
	q = read() ;
	For( i , 1 , n ){
		a[ i ] = read() ;
		qa1[ i ][ 0 ] = a[ i ] ;
		qa2[ i ][ 0 ] = a[ i ] ;
		if( a[ i ] == 0 ) qa3[ i ][ 0 ] = 0 , qa4[ i ][ 0 ] = 0 ;
		else if( a[ i ] > 0 ) qa3[ i ][ 0 ] = a[ i ] , qa4[ i ][ 0 ] = -INF ;
		else  qa4[ i ][ 0 ] = a[ i ] , qa3[ i ][ 0 ] = INF;
	}
	For( i , 1 , m ){
		b[ i ] = read() ;
		qb1[ i ][ 0 ] = b[ i ] ;
		qb2[ i ][ 0 ] = b[ i ] ;
	}
	qry() ; 
	while( q-- ) {
		l1 = read() ;
		l2 = read() ;
		r1 = read() ;
		r2 = read() ;
		int mx1 = max( qa1[ l1 ][ log2( l2 - l1 ) ] , qa1[ l2 - ( 1 << log2( l2 - l1 ) ) + 1 ][ log2( l2 - l1 )]) ;
		int mx2 = min( qa2[ l1 ][ log2( l2 - l1 ) ] , qa2[ l2 - ( 1 << log2( l2 - l1 ) ) + 1 ][ log2( l2 - l1 )]) ;
		int my1 = max( qb1[ r1 ][ log2( r2 - r1 ) ] , qb1[ r2 - ( 1 << log2( r2 - r1 ) ) + 1 ][ log2( r2 - r1 )]) ;
		int my2 = min( qb2[ r1 ][ log2( r2 - r1 ) ] , qb2[ r2 - ( 1 << log2( r2 - r1 ) ) + 1 ][ log2( r2 - r1 )]) ;
		int k1 = min( qa3[ l1 ][ log2( l2 - l1 ) ] , qa3[ l2 - ( 1 << log2( l2 - l1 ) ) + 1 ][ log2( l2 - l1 )]) ;
		int k2 = max( qa4[ l1 ][ log2( l2 - l1 ) ] , qa4[ l2 - ( 1 << log2( l2 - l1 ) ) + 1 ][ log2( l2 - l1 )]) ;
		if( mx2 >= 0 && my2 >= 0 ) printf("%lld" , mx1 * my2 ) ;
		else if( mx2 >= 0 && my1 <= 0 ) printf("%lld" , mx2 * my2 ) ;
		else if( mx2 >= 0 && my1 >= 0 && my2 <= 0 ) printf("%lld" , mx2 * my2 ) ;
		else if( mx1 <= 0 && my2 >= 0 ) printf("%lld" , mx1 * my1 ) ;
		else if( mx1 <= 0 && my1 <= 0 ) printf("%lld" , mx2 * my1 ) ;
		else if( mx1 <= 0 && my1 >= 0 && my2 <= 0 ) printf("%lld" , mx1 * my1 ) ;
		else if( mx1 >= 0 && mx2 <= 0 && my2 >= 0 ) printf("%lld" , mx1 * my2 ) ;
		else if( mx1 >= 0 && mx2 <= 0 && my1 <= 0 ) printf("%lld" , mx2 * my1 ) ;
		else if( mx1 >= 0 && mx2 <= 0 && my1 >= 0 && my2 <= 0 ) printf("%lld" , max( k2 * my1 , k1 * my2 ) ) ;
		puts("") ;
	}
	return 0 ;
}