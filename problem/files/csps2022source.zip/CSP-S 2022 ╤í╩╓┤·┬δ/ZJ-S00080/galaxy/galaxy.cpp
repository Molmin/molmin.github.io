#include<bits/stdc++.h>
#define For(i,a,b) for( register int i = ( a ) ; i <= ( b ) ; ++ i )
#define Rep(i,a,b) for( register int i = ( a ) ; i >= ( b ) ; -- i )
using namespace std ;
inline int read() {
	int s = 0 ; char ch = getchar() ; bool f = 0 ;
	for( ; !isdigit( ch ) ; ch = getchar() ) f ^= !( 45 ^ ch ) ;
	for( ; isdigit( ch ) ; ch = getchar() ) s = ( s << 3 ) + ( s << 1 ) + ( ch ^ 48 ) ;
	if( f ) return -s ; return s ;
}
int n , m , v ;
int main() {
	freopen("galaxy.in" , "r" , stdin ) ;
	freopen("galaxy.out" , "w" , stdout ) ;
	n = read() ;
	m = read() ;
	For( i , 1 , m ) {
		n = read() ;
		n = read() ;
	}
	v = read() ;
	For( i , 1 , v ){
		m = rand() % n ;
		if( m == 1 ) printf("NO\n") ;
		else printf("YES\n") ;
	}
}