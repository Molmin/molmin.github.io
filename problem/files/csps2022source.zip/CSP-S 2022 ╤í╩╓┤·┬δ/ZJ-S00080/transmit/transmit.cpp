#include<bits/stdc++.h>
#define int long long 
#define For(i,a,b) for( register int i = ( a ) ; i <= ( b ) ; ++ i )
#define Rep(i,a,b) for( register int i = ( a ) ; i >= ( b ) ; -- i )
using namespace std ;
inline int read() {
	int s = 0 ; char ch = getchar() ; bool f = 0 ;
	for( ; !isdigit( ch ) ; ch = getchar() ) f ^= !( 45 ^ ch ) ;
	for( ; isdigit( ch ) ; ch = getchar() ) s = ( s << 3 ) + ( s << 1 ) + ( ch ^ 48 ) ;
	if( f ) return -s ; return s ;
}
int log2( int x ) {
	return log( x )/log( 2 ) ;
}
int n , q , k , a , b ;
int t[ 200005 ] ;
int head[ 200005 ] , tot ;
struct node{
	int to , nxt ;
} e[ 400005 ] ;
void add( int u , int v ) {
	e[ ++tot ].to = v ;
	e[ tot ].nxt = head[ u ] ;
	head[ u ] = tot ;
}
int fa[ 200005 ][ 25 ] , deep[ 200005 ] ;
void dfs( int x ) {
	for( int i = head[ x ] ; i ; i = e[ i ].nxt ) {
		int v = e[ i ].to ;
		if( v != fa[ x ][ 0 ] ) {
			fa[ v ][ 0 ] = x ;
			deep[ v ] = deep[ x ] + 1 ;
			dfs( v ) ;
		}
	}
}
void pry() {
	For( i , 1 , log2( n ) + 1 )
		For( j , 1 , n ) {
			if( deep[ j ] < ( 1 << i ) ) continue ;
			fa[ j ][ i ] = fa[ fa[ j ][ i - 1 ] ][ i - 1 ] ;
		} 
}
int p[ 200005 ] , l , o[ 200005 ] , l2 , f[ 200005 ] ;
int lca( int x , int y ) {
	if( deep[ x ] > deep[ y ] ) swap( x , y ) ;
	Rep( i , log2( n ) + 1 , 0 )
		if( deep[ y ] >= ( 1 << i ) && deep[ fa[ y ][ i ] ] >= deep[ x ] ) y = fa[ y ][ i ] ;
	if( x == y ) return x ;
	Rep( i , log2( n ) + 1 , 0 )
		if( fa[ x ][ i ] != 0 && fa[ y ][ i ] != 0 && fa[ x ][ i ] != fa[ y ][ i ] ) x = fa[ x ][ i ] , y = fa[ y ][ i ] ;
	return fa[ x ][ 0 ] ;
}
void getans( int u , int v ) {
	int ft = lca( u , v ) ;
	l = 0 ; l2 = 0 ;
	while( u != ft ) p[ ++l ] = u , u = fa[ u ][ 0 ] ;
	while( v != ft ) o[ ++l2 ] = v , v = fa[ v ][ 0 ] ;
	p[ ++l ] = ft ;
	Rep( i , l2 , 1 )
		p[ ++l ] = o[ i ] ;
	f[ 1 ] = t[ p[ 1 ] ] ;
	For( i , 2 , l ) {
		f[ i ] = f[ i - 1 ] + t[ p[ i ] ] ;
		Rep( j , i - 2 , max( i - k  , 1 * 1ll ) )
			f[ i ] = min( f[ i ] , f[ j ] + t[ p[ i ] ] ) ;
	}
	printf("%lld\n" , f[ l ] ) ;
}
signed main(){
	freopen("transmit.in" , "r" , stdin ) ;
	freopen("transmit.out" , "w" , stdout ) ;
	n = read() ; q = read() ; k = read() ;
	For( i , 1 , n )
		t[ i ] = read() ;
	For( i , 2 , n ){
		a = read() ;
		b = read() ;
		add( a , b ) ;
		add( b , a ) ;
	}
	deep[ 1 ] = 0 ;
	dfs( 1 ) ;
	pry() ;
	while( q-- ) {
		a = read() ; b = read() ;
		getans( a , b ) ;
	}
	return 0 ;
}