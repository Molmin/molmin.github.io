#include<bits/stdc++.h>
#define For(i,a,b) for( register int i = ( a ) ; i <= ( b ) ; ++ i )
#define Rep(i,a,b) for( register int i = ( a ) ; i >= ( b ) ; -- i )
using namespace std ;
inline int read() {
	int s = 0 ; char ch = getchar() ; bool f = 0 ;
	for( ; !isdigit( ch ) ; ch = getchar() ) f ^= !( 45 ^ ch ) ;
	for( ; isdigit( ch ) ; ch = getchar() ) s = ( s << 3 ) + ( s << 1 ) + ( ch ^ 48 ) ;
	if( f ) return -s ; return s ;
}
int n , m , k , a[ 2505 ] , u , v , ans = -0x3f3f3f3f , dis[ 505 ][ 505 ] ;
int head[ 2505 ] , tot ;
struct edge{
	int to , nxt ;
} e[ 1000005 ] ;
void add( int u , int v ) {
	e[ ++tot ].to = v ;
	e[ tot ].nxt = head[ u ] ;
	head[ u ] = tot ;
}
struct node{
	int num , sum , t[ 6 ] , l ;
} tmp , tx ;
queue < node > q ;
void dfs() {
	tmp.num = 1 ;tmp.sum = 0 ; tmp.l = 0 ;
	q.push( tmp ) ;
	while( !q.empty( ) ) {
		tmp = q.front() ;
		q.pop() ;
		if( tmp.l == 4 ) {
			if( dis[ tmp.num ][ 1 ] <= k ) ans = max( ans , tmp.sum ) ;
			continue ;
		}
		for( int i = head[ tmp.num ] ; i ; i = e[ i ].nxt ) {
			bool flag = 1 ;
			int v = e[ i ].to ;
			For( j , 1 , tmp.l )
				if( v == tmp.t[ j ] ) {
					flag = 0 ;
					break ;
				}
			if( !flag ) continue ;
			tx = tmp ;
			tx.l ++ ;
			tx.t[ tx.l ] = v ;
			tx.num = v ;
			tx.sum += a[ v ] ;
			q.push( tx ) ;
		}
	}
}
int main() {
	freopen("holiday.in" , "r" , stdin ) ;
	freopen("holiday.out" , "w" , stdout ) ;
	memset( dis , 0x3f , sizeof dis ) ;
	n = read() ;
	m = read() ;
	k = read() ;
	++k ;
	For( i , 2 , n )
		a[ i ] = read() ;
	For( i , 1 , m ){
		u = read() ;
		v = read() ;
		dis[ u ][ v ] = 1 ;
		dis[ v ][ u ] = 1 ;
	}
	For( k , 1 , n )
		For( i , 1 , n )
			For( j , i + 1 , n )
				dis[ i ][ j ] = min( dis[ i ][ j ] , dis[ i ][ k ] + dis[ k ][ j ] ) , dis[ j ][ i ] = dis[ i ][ j ] ;
	For( i , 1 , n )
		For( j , i + 1 , n ) 
			if( dis[ i ][ j ] <= k ) {
				add( i , j ) ;
				add( j , i ) ;
			}
	dfs() ;
	printf("%lld" , ans ) ;
	return 0 ;
}