#include <iostream>
using namespace std;
long long a[100010], b[100010];
int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n, m, q, ans1 = 0, ans2 = 0, ansum = 0;
	cin >> n >> m >> q;
	for(int i = 0; i < n; i++) cin >> a[i];
	for(int i = 0; i < m; i++) cin >> b[i];
	for(int i = 1; i <= q; i++)
	{
		int l, r, ll, rr;
		cin >> l >> r >> ll >> rr;
	}
	for(int i = 1; i <= q; i++)
	{
		ans1 = ans2 + 1;
		cout << ansum << endl;
		ansum += 4;
	}
	return 0;
}