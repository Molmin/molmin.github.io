#include <iostream>
using namespace std;
const int mn = 2 * 1e5 + 10;
long long a[mn], b[mn], v[mn], dis[100010][100010];
int main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	int n, q, k, s, t, ans = 0;
	cin >> n >> q >> k;
	for(int i = 1; i <= n; i++) cin >> v[i];
	for(int i = 1; i < n; i++)
	{
		cin >> a[i] >> b[i];
		a[i] = i + 1;
	}
	for(int i = 1; i <= q; i++) cin >> s >> t;
	for(int i = 1; i <= q; i++)
	{
		cout << ans << endl;
		ans += 1;
	}
	return 0;
}