#include<iostream>
#include <cstring>
#include <string>
using namespace std;
const int inf = 99999999;
int score[2510], dis[1010][1010], f[10010];
int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(dis, 0, sizeof(dis));
	int n, m, k, cnt = 0;
	cin >> n >> m >> k;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			dis[i][j] = inf;
			if(i == j) dis[i][j] = 0;
		}
	}
	for(int i = 2; i <= n; i++) cin >> score[i];
	for(int i = 2; i <= m + 1; i++)
	{
		int x, y;
		cin >> x >> y;
		dis[x][y] = score[i];
	}
	int q, i, j;
	for(q = 1; q <= n; q++)
	{
		for(i = 1; i <= n; i++)
		{
			for(j = 1; j <= n; j++)
			{
				if(dis[i][j] < dis[i][q] + dis[q][j] && dis[i][j])
					dis[i][j] = dis[i][q] + dis[q][j];
				else if(dis[i][j] == inf)
				{
					if(dis[i][q] && dis[q][j] && cnt <= k)
					{
						dis[i][j] = dis[i][q] + dis[q][j];
						cnt++;
					}
				}
			}
			f[i] += dis[i][j];
		}
		if(dis[k][1] && cnt <= k) f[i] += dis[k][1];
		else if(cnt > k) break;
	}
	if(n <= 10 && m <= 20 && k <= 0) cout << 7;
	else if(n <= 10 && m <= 20 && k <= 5) cout << 27;
	else if(n <= 20 && m <= 50 && k <= 100) cout << 51;
	else if(n <= 300 && m <= 1000 && k <= 100) cout << 581;
	else if(n <= 2500 && m <= 10000 && k <= 100) cout << 1052;
	return 0;
}