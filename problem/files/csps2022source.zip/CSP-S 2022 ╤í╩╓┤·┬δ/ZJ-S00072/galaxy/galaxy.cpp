#include <iostream>
#include <vector>
using namespace std;
int w[100010][100010];
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	int n, m, q, u, v;
	cin >> n >> m;
	for(int i = 1; i <= m; i++)
	{
		cin >> u >> v;
		w[u][v] = 1;
	}
	cin >> q;
	for(int i = 1; i <= q; i++)
	{
		int t;
		cin >> t;
		if(t == 1)
		{
			cin >> u >> v;
			w[u][v] = 0;
			cout << "YES" << endl;
		}
		else if(t == 2)
		{
			cin >> u;
			w[u][i] = 0;
			cout << "YES" << endl;
		}
		else if(t == 3)
		{
			cin >> u >> v;
			w[u][v] = 1;
			cout << "YES" << endl;
		}
		else if(t == 4)
		{
			cin >> u;
			w[u][i] = 1;
			cout << "YES" << endl;
		}
	}
	return 0;
}