#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long s=0;


int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&m);
	for(int i=1;i<=n;i++){
		int a;
		scanf("%d",&a);
		s+=a;
	}
	for(int i=1;i<=q;i++){
		cout<<s<<endl;
	}
	return 0;
}
