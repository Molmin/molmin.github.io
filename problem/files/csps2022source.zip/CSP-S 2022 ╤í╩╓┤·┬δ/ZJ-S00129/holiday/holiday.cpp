#include<bits/stdc++.h>


using namespace std;
int n,m,k;
unsigned long long ans=0;
int ma[2510][2510];
int va[2510];
bool check[2510];
void dfs(int mq,int cd,unsigned long long sum) {
	if(cd==0){
		ans=max(ans,sum);
		return;
	}
	for(int i=2; i<=n; i++) {
		if(!check[i]&&ma[mq][i]<=k) {
			if(cd==1&&ma[i][1]>k){
				continue;
			} 
			check[i]=1;
			dfs(i,cd-1,sum+va[i]);
			check[i]=0;
		}
	}
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(ma,2,sizeof(ma));
	memset(check,0,sizeof(check));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2; i<=n; i++) {
		scanf("%d",&va[i]);
	}
	for(int i=1; i<=m; i++) {
		int a,b;
		scanf("%d%d",&a,&b);
		ma[a][b]=0;
		ma[b][a]=0;
	}
	for(int k=1; k<=n; k++) {
		for(int j=1; j<=n; j++) {
			for(int i=j; i<=n; i++) {
				if(i==j) {
					ma[i][j]=0;
				} else {
					ma[i][j]=min(ma[i][j],ma[i][k]+ma[k][j]+1);
					ma[j][i]=min(ma[j][i],ma[i][j]);
				}
			}
		}
	}
	dfs(1,4,0ull);
	cout<<ans;
	return 0;
}

//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++){
//			cout<<i<<"->"<<j<<":"<<ma[i][j]<<endl;
//		}
//	}
