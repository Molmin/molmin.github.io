#include<bits/stdc++.h>

using namespace std;
int m,n,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>m>>n>>q;
	for(int i=1;i<=q;i++){
		cout<<"NO"<<endl;
	}
	return 0;
}
