#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
int n,m,q;
int A[maxn],B[maxn];
int l1,r1;
int l2,r2;
int Lmif,Lmaf,Lmiz,Lmaz;
int Qmif,Qmaf,Qmiz,Qmaz;
int jdz(int a) {
	if(a>0) {
		return a;
	} else {
		return -a;
	}
}
void init() {
	Lmif=2000000000;
	Lmaf=2000000000;
	Lmiz=2000000000;
	Lmaz=-2000000000;
	Qmif=2000000000;
	Qmaf=2000000000;
	Qmiz=2000000000;
	Qmaz=-2000000000;
}
void fdL_() {
	for(int i=l1; i<=r1; i++) {
		if(A[i]>=0){
			Lmaz=max(Lmaz,A[i]);
			Lmiz=min(Lmiz,A[i]);
		}else{
			Lmaf=min(Lmaf,A[i]);
			Lmif=-min(jdz(Lmif),jdz(A[i]));
			
		}
	}
//	cout<<Lmaz<<endl<<Lmiz<<endl<<Lmaf<<endl<<Lmif<<endl;
}
void fdQ_(){
	for(int i=l2; i<=r2; i++) {
		if(B[i]>=0){
			Qmaz=max(Qmaz,B[i]);
			Qmiz=min(Qmiz,B[i]);
		}else{
			Qmaf=min(Qmaf,B[i]);
			Qmif=-min(jdz(Qmif),jdz(B[i]));
		}
	}
	//cout<<Qmaz<<endl<<Qmiz<<endl<<Qmaf<<endl<<Qmif<<endl;
}
void solve(){
	unsigned long long ans=0;
	if(Qmif>0&&Lmif>0){
		ans=(unsigned long long)Lmaz*Qmiz;
		cout<<ans<<endl;
	//	cout<<11<<endl;
	}else if(Lmaz<0&&Qmaz<0){
		Lmaf=-Lmaf;
		Qmif=-Qmif;
		ans=(unsigned long long)Lmaf*Qmif;
		cout<<ans<<endl;
	//	cout<<22<<endl;
	}else if(Lmaz<0&&Qmif>0){
		Lmif=-Lmif;
		ans=(unsigned long long)Lmif*Qmaz;
		if(ans) cout<<'-';
		cout<<ans<<endl;
	//	cout<<33<<endl;
	}else if(Lmif>0&&Qmaz<0){
		Qmaf=-Qmaf;
		ans=(unsigned long long)Qmaf*Lmiz;
		if(ans) cout<<'-';
		cout<<ans<<endl;
	//	cout<<44<<endl;
	}else if(Lmif>0){
		Qmaf=-Qmaf;
		ans=(unsigned long long)Qmaf*Lmiz;
		if(ans) cout<<'-';
		cout<<ans<<endl;
	}else if(Lmaz<0){
		Lmif=-Lmif;
		ans=(unsigned long long)Lmif*Qmaz;
		if(ans) cout<<'-';
		cout<<ans<<endl;
	}else if(Qmif>0){
		ans=(unsigned long long)Lmaz*Qmiz;
		cout<<ans<<endl;
	}else if(Qmaz<0){
		Lmaf=-Lmaf;
		Qmif=-Qmif;
		ans=(unsigned long long)Lmaf*Qmif;
		cout<<ans<<endl;
	}else{
		Lmif=-Lmif;
		Qmaf=-Qmaf;
		ans=(unsigned long long)Lmif*Qmaz;
		if(ans<(unsigned long long)Lmiz*Qmaf){
			if(ans) cout<<'-';
			cout<<ans<<endl;
		}else{
			ans=(unsigned long long)Lmiz*Qmaf;
			if(ans) cout<<'-';
			cout<<ans<<endl;
		}
	}
}

int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1; i<=n; i++) {
		scanf("%d",&A[i]);
	}
	for(int i=1; i<=m; i++) {
		scanf("%d",&B[i]);
	}
	while(q--) {
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		init();
		fdL_();
		fdQ_();
		solve();
	}
	return 0;
}
