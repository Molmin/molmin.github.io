#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a[2505],x,y,z,ans;
long long tot,son[20005],fir[20005],nxt[20005];
bool v[20005];
void add (int x,int y) {
	son[++tot]=y;
	nxt[tot]=fir[x];
	fir[x]=tot;
}
void dfs (int x,int jd,long long len,int hc) {
	for (int i=fir[x];i;i=nxt[i]) {
		if (hc<k) dfs(son[i],jd,len,hc+1);
		if (!v[son[i]]&&jd<4&&son[i]!=1) {
			v[son[i]]=true;
			dfs(son[i],jd+1,len+a[son[i]],0);
			v[son[i]]=false;
		}
		if (son[i]==1&&jd==4) {
			ans=max(ans,len);
			return ;
		}
	}
}
inline long long read () {
	long long res=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
void put (long long x) {
	long long i=1;
	if (x==0) {
		putchar('0');
		return ;
	}
	if (x<0) putchar('-'),x=-x;
	while (i<=x) i*=10;i/=10;
	while (i) putchar(x/i^48),x%=i,i/=10;
}
int main () {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for (int i=2;i<=n;i++) a[i]=read();
	for (int i=1;i<=m;i++) {
		x=read(),y=read();
		add(x,y),add(y,x);
	}
	dfs(1,0,0,0);
	put(ans);
	return 0;
}