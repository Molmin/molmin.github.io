#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a[200005],x,y,c[200005],len,dp[200005];
bool v[200005];
long long tot,son[400005],fir[400005],nxt[400005];
void add (int x,int y) {
	son[++tot]=y;
	nxt[tot]=fir[x];
	fir[x]=tot;
}
void dfs (int x,int y,int k) {
	if (len!=0) return ;
	c[k]=x;
	if (x==y) {
		len=k;
		return ;
	}
	for (int i=fir[x];i;i=nxt[i]) {
		if (!v[son[i]]) {
			v[son[i]]=true;
			dfs(son[i],y,k+1);
			v[son[i]]=false;
			if (len!=0) return ;
		}
	}
}
inline long long read () {
	long long res=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
void put (long long x) {
	long long i=1;
	if (x==0) {
		putchar('0');
		return ;
	}
	if (x<0) putchar('-'),x=-x;
	while (i<=x) i*=10;i/=10;
	while (i) putchar(x/i^48),x%=i,i/=10;
}
int main () {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),m=read(),k=read();
	for (int i=1;i<=n;i++) a[i]=read();
	for (int i=1;i<n;i++) {
		x=read(),y=read();
		add(x,y),add(y,x);
	}
	for (int i=1;i<=m;i++) {
		x=read(),y=read();
		len=0;
		v[x]=true;
		dfs(x,y,1);
		v[x]=false;
		for (int j=1;j<=len;j++) dp[j]=1e18;
		dp[1]=a[x];
		for (long long j=2;j<=len;j++) {
			for (long long l=1;l<=min(j-1,k);l++) dp[j]=min(dp[j],dp[j-l]);
			dp[j]+=a[c[j]];
		}
		put(dp[len]);
		putchar('\n');
	}
	return 0;
}