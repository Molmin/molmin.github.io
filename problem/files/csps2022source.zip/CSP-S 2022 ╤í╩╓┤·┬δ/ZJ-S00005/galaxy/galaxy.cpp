#include<bits/stdc++.h>
using namespace std;
int n,m,k,x,y,du[1005],fj,op;
bool a[1005][1005],v[1005][1005];
inline int read () {
	int res=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
int main () {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();
	for (int i=1;i<=m;i++) {
		x=read(),y=read();
		a[x][y]=v[x][y]=true;
		du[x]++;
	}
	for (int i=1;i<=n;i++) {
		if (du[i]!=1) fj++;
	}
	k=read();
	for (int i=1;i<=k;i++) {
		op=read();
		if (op==1) {
			x=read(),y=read();
			v[x][y]=false;
			if (du[x]==2) fj--;
			if (du[x]==1) fj++;
			du[x]--;
		}
		if (op==2) {
			x=read();
			for (int j=1;j<=n;j++) {
				if (v[j][x]) {
					if (du[j]==2) fj--;
					if (du[j]==1) fj++;
					du[j]--,v[j][x]=false;
				}
			}
		}
		if (op==3) {
			x=read(),y=read();
			v[x][y]=true;
			if (du[x]==0) fj--;
			if (du[x]==1) fj++;
			du[x]++;
		}
		if (op==4) {
			x=read();
			for (int j=1;j<=n;j++) {
				if (a[j][x]&&!v[j][x]) {
					if (du[j]==0) fj--;
					if (du[j]==1) fj++;
					du[j]++,v[j][x]=true;
				}
			}
		}
		if (fj==0) putchar('Y'),putchar('E'),putchar('S'),putchar('\n');
		else putchar('N'),putchar('O'),putchar('\n');
	}
	return 0;
}