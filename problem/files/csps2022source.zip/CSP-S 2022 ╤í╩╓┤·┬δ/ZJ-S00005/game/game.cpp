#include<bits/stdc++.h>
using namespace std;
vector<long long>c[100005];
long long n,m,k,a[100005],b[100005],l1,r1,l2,r2,ans,lr[100005],len;
inline long long read () {
	long long res=0,f=1;char ch=getchar();
	while (ch<'0'||ch>'9') {if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0'&&ch<='9') res=(res<<3)+(res<<1)+(ch^48),ch=getchar();
	return res*f;
}
void put (long long x) {
	long long i=1;
	if (x==0) {
		putchar('0');
		return ;
	}
	if (x<0) putchar('-'),x=-x;
	while (i<=x) i*=10;i/=10;
	while (i) putchar(x/i^48),x%=i,i/=10;
}
int main () {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),k=read();
	for (int i=1;i<=n;i++) a[i]=read();
	for (int i=1;i<=m;i++) b[i]=read();
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=m;j++) c[i].push_back(a[i]*b[j]);
	}
	for (int i=1;i<=k;i++) {
		l1=read(),r1=read(),l2=read(),r2=read();
		if (l1==r1) {
			ans=-1e18;
			for (int j=l2;j<=r2;j++) ans=max(ans,c[l1][j-1]);
			put(ans),putchar('\n');
			continue;
		}
		if (l2==r2) {
			ans=-1e18;
			for (int j=l1;j<=r1;j++) ans=max(ans,c[j][l2-1]);
			put(ans),putchar('\n');
			continue;
		}
		ans=-1e18;
		for (int j=l1;j<=r1;j++) {
			len=1e18;
			for (int k=l2;k<=r2;k++) len=min(len,c[j][k-1]);
			ans=max(ans,len);
		}
		put(ans),putchar('\n');
	}
	return 0;
}