#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2005;
const int MAXM =4000005;
int n,Q,k,cnt,t[MAXN],len[2*MAXM],to[2*MAXM],nxt[2*MAXM],h[MAXN],f[MAXN][MAXN];
long long dis[MAXN],v[MAXN][MAXN];
bool vis[MAXN];
struct node
{
	int id;
	long long val;
	bool operator < (const node a) const
	{
		return a.val<val;
	}
};
void dij(int s)
{
	memset(dis,0x7f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[s]=0;
	priority_queue<node> q;
	node x;
	x.id=s,x.val=0;
	q.push(x);
	for(int i=1;i<=n;i++)
	{
		if(q.empty()) break;
		node u=q.top();
		q.pop();
		int v=u.id;
		vis[v]=1;
		for(int j=h[v];j;j=nxt[j])
		{
			int t=to[j],l=len[j];
			if(dis[t]>dis[v]+1ll*l) 
			{
				dis[t]=dis[v]+1ll*l;
				x.id=t,x.val=dis[t];
				q.push(x);
			}
		}
	}
}
void add(int u,int v,int l)
{
	to[++cnt]=v,len[cnt]=l,nxt[cnt]=h[u],h[u]=cnt;
}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-'){f=-f;}ch=getchar();}
	while(isdigit(ch)) x=(x<<3)+(x<<1)+ch-48,ch=getchar();
	return x*f;
}
inline void write(long long p)
{
	if(p>9) write(p/10);
	putchar((p%10)+'0');
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),Q=read(),k=read();
	for(int i=1;i<=n;i++)
	{
		t[i]=read();
	} 
	for(int i=1;i<=n-1;i++)
	{
		int u=read(),v=read();
		add(u,v,1),add(v,u,1);
 	}
 	
	for(int i=1;i<=n;i++)
	{
		dij(i);
		for(int j=1;j<=n;j++) f[i][j]=dis[j];
	}
	cnt=0;
	memset(h,0,sizeof(h));
	memset(to,0,sizeof(to));
	memset(nxt,0,sizeof(nxt));
	memset(len,0,sizeof(len)); 
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(f[i][j]<=k) add(i,j,t[j]),add(j,i,t[i]);
		}
	}
	for(int i=1;i<=n;i++)
	{
		dij(i);
		for(int j=1;j<=n;j++) v[i][j]=dis[j];
	}
	while(Q--)
	{
		int st=read(),ed=read();
		write(v[st][ed]+1ll*t[st]);
	}
	return 0;
}
