#include<bits/stdc++.h>
using namespace std;
const int MAXN = 100005;
int n,m,q,sta[MAXN][17][5],stb[MAXN][17][5],a[MAXN],b[MAXN];
int query_b(int l,int r,int k)
{
	int p=log2(r-l+1);
	if(k==1) return max(stb[l][p][1],stb[r-(1<<p)+1][p][1]);
	if(k==2) return min(stb[l][p][2],stb[r-(1<<p)+1][p][2]);
	if(k==3) return max(stb[l][p][3],stb[r-(1<<p)+1][p][3]);
	if(k==4) return min(stb[l][p][4],stb[r-(1<<p)+1][p][4]);
}

int query_a(int l,int r,int k)
{
	int p=log2(r-l+1);
	if(k==1) return max(sta[l][p][1],sta[r-(1<<p)+1][p][1]);
	if(k==2) return min(sta[l][p][2],sta[r-(1<<p)+1][p][2]);
	if(k==3) return max(sta[l][p][3],sta[r-(1<<p)+1][p][3]);
	if(k==4) return min(sta[l][p][4],sta[r-(1<<p)+1][p][4]);
}

inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){if(ch=='-'){f=-f;}ch=getchar();}
	while(isdigit(ch)) x=(x<<3)+(x<<1)+ch-48,ch=getchar();
	return x*f;
}
inline void write(long long p)
{
	if(p>9) write(p/10);
	putchar((p%10)+'0');
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) 
	{
		sta[i][0][1]=-1,sta[i][0][4]=1;
		sta[i][0][2]=1e9,sta[i][0][3]=-1e9;
		a[i]=read();
		if(a[i]>=0) sta[i][0][1]=sta[i][0][2]=a[i];
		if(a[i]<=0) sta[i][0][3]=sta[i][0][4]=a[i];
	}
	for(int i=1;i<=m;i++)
	{
		stb[i][0][1]=-1,stb[i][0][4]=1;
		stb[i][0][2]=1e9,stb[i][0][3]=-1e9;
		b[i]=read();
		if(b[i]>=0) stb[i][0][1]=stb[i][0][2]=b[i];
		if(b[i]<=0) stb[i][0][3]=stb[i][0][4]=b[i];
	}
	int ln=log2(n),lm=log2(m);
	for(int i=1;i<=ln;i++)
	{
		for(int j=1;j+(1<<i)-1<=n;j++)
		{
			sta[j][i][1]=max(sta[j][i-1][1],sta[j+(1<<(i-1))][i-1][1]);
			sta[j][i][2]=min(sta[j][i-1][2],sta[j+(1<<(i-1))][i-1][2]);
			sta[j][i][3]=max(sta[j][i-1][3],sta[j+(1<<(i-1))][i-1][3]);
			sta[j][i][4]=min(sta[j][i-1][4],sta[j+(1<<(i-1))][i-1][4]);
		}
	}
	for(int i=1;i<=lm;i++)
	{
		for(int j=1;j+(1<<i)-1<=m;j++)
		{
			stb[j][i][1]=max(stb[j][i-1][1],stb[j+(1<<(i-1))][i-1][1]);
			stb[j][i][2]=min(stb[j][i-1][2],stb[j+(1<<(i-1))][i-1][2]);
			stb[j][i][3]=max(stb[j][i-1][3],stb[j+(1<<(i-1))][i-1][3]);
			stb[j][i][4]=min(stb[j][i-1][4],stb[j+(1<<(i-1))][i-1][4]);
		}
	}
	while(q--)
	{
		int l1=read(),r1=read(),l2=read(),r2=read();
		long long total;
		int res_1=query_a(l1,r1,1),res_2=query_a(l1,r1,2);
		int res_3=query_a(l1,r1,3),res_4=query_a(l1,r1,4);
		
		int ans_1=query_b(l2,r2,1),ans_2=query_b(l2,r2,2);
		int ans_3=query_b(l2,r2,3),ans_4=query_b(l2,r2,4);
		
		if(ans_4==1) 
		{
			if(res_1==-1) total=1ll*res_3*ans_1;
			else total=1ll*res_1*ans_2;
		}
		else if(ans_1==-1)
		{
			if(res_4==1) total=1ll*res_2*ans_4;
			else total=1ll*res_4*ans_3;
		}
		else
		{
			if(res_4==1) total=1ll*res_2*ans_4;
			else if(res_1==-1) total=1ll*res_3*ans_1;
			else
			{
				total=max(1ll*res_2*ans_4,1ll*res_3*ans_1);
			}
		}
		if(total<0) 
		{
			putchar('-');
			total=-total;
		}
		write(total);
		puts("");
 	}
	return 0;
}
