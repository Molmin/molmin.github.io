#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN = 2505;
const int MAXM = 6250005;
int n,m,k,cnt,to[2*MAXM],nxt[2*MAXM],h[MAXN],dis[MAXN],f[MAXN][MAXN];
ll a[MAXN],total;
bool vis[MAXN],vis1[MAXN],vis2[MAXN];
struct node
{
	int id,val;
	bool operator < (const node a) const
	{
		return a.val<val;
	}
};
struct point
{
	int f,t;
	ll len;
};
struct nnn
{
	int ti,id;
};
bool cmp(point u,point v)
{
	return u.len>v.len;
}
void dij(int s)
{
	memset(dis,0x3f,sizeof(dis));
	memset(vis,0,sizeof(vis));
	dis[s]=0;
	priority_queue<node> q;
	node x;
	x.id=s,x.val=0;
	q.push(x);
	for(int i=1;i<=n;i++)
	{
		if(q.empty()) break;
		node u=q.top();
		q.pop();
		int v=u.id;
		vis[v]=1;
		for(int j=h[v];j;j=nxt[j])
		{
			int t=to[j];
			if(dis[t]>dis[v]+1) 
			{
				dis[t]=dis[v]+1;
				x.id=t,x.val=dis[t];
				q.push(x);
			}
		}
	}
}
void add(int u,int v)
{
	to[++cnt]=v,nxt[cnt]=h[u],h[u]=cnt;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=2;i<=n;i++) 
	{
		scanf("%lld",&a[i]);
	}
	
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d %d",&u,&v);
		add(u,v),add(v,u);
	}
	
	for(int i=1;i<=n;i++)
	{
		dij(i);
		for(int j=1;j<=n;j++)
		{
			f[i][j]=dis[j]-1;
		}
	}
	cnt=0;
	memset(h,0,sizeof(h));
	memset(to,0,sizeof(to));
	memset(nxt,0,sizeof(nxt));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j) continue;
			if(f[i][j]<=k) add(i,j);
		}
	}
	for(int i=h[1];i;i=nxt[i])
	{
		vis1[to[i]]=1;
	} 
	for(int i=2;i<=n;i++)
	{
		if(f[i][1]>k) continue;
		memset(vis2,0,sizeof(vis2));
		for(int k=h[i];k;k=nxt[k]) vis2[to[k]]=1;
		for(int j=2;j<=n;j++)
		{
			ll ans1=0,ans2=0;
			ll anss1=0,anss2=0;
			int res1=0,res2=0,ress1=0,ress2=0;
			if(i==j) continue;
			for(int k=h[j];k;k=nxt[k]) 
			{
				if(vis1[to[k]]==1) 
				{
					if(to[k]==i||to[k]==j) continue;
					if(ans1<a[to[k]]) ans1=a[to[k]],res1=to[k];
					else if(anss1<a[to[k]]) anss1=a[to[k]],ress1=to[k];
				}
				if(vis2[to[k]]==1) 
				{
					if(to[k]==i||to[k]==j) continue;
					if(ans2<a[to[k]]) ans2=a[to[k]],res2=to[k];
					else if(anss2<a[to[k]]) anss2=a[to[k]],ress2=to[k];
				}
			}
			if(res1==0||res2==0) continue;
			ll tmp;
			if(res1==res2)
			{
				if(ress2==0) 
				{
					if(ress1==0) continue;
					else tmp=ans2+anss1;
				}
				else
				{
					if(ress1==0) tmp=ans1+anss2;
					tmp=max(ans1+anss2,ans2+anss1);
				}
			} 
			else tmp=ans1+ans2;
			total=max(total,a[i]+a[j]+tmp);	
		}
	}
	printf("%lld\n",total);
	return 0;
}
