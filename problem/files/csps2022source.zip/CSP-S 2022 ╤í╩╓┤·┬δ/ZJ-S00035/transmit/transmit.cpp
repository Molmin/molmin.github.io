#include<bits/stdc++.h>
#define ll long long
#define ull unsigned ll
#define INF 0x3f3f3f3f
#define INFLL 0x3f3f3f3f3f3f3f3fll
using namespace std;
#define Ci const int
#define Cl const ll
#define Cul const ull
#define Cc const char
#define For(x,l,r) for(int x=(l);x<=(r);x++)
#define Rep(x,r,l) for(int x=(r);x>=(l);x--)
inline ll read(){ll x;cin>>x;return x;}
int n,k,q,a[200005],hd[200005],cnt;
struct E{
	int nxt,to;
}e[400005];
inline void add(Ci u,Ci v){
	e[++cnt]={hd[u],v};
	hd[u]=cnt;
}
namespace K2{
ll f[200005],res[200005];
int Fa[200005];
void dfs(Ci u,Ci fa){
	Fa[u]=fa;res[u]=INFLL;//cout<<u<<' '<<f[u]<<'\n';
	int faa=Fa[u];f[u]=INFLL;
	For(j,0,k-1){
		f[u]=min(f[faa]+a[u],f[u]);
		faa=Fa[faa];if(!faa)break;
	}
	for(int i=hd[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa)continue;
		dfs(v,u);
	}
}
}
ll ans[200005];
struct Que{
	int y,id;
};
vector<Que>que[200005];
namespace K3{
namespace GG{
	int hd[200005],cnt;ll F[205][205];
	struct E{
		int nxt,to;ll w;
	}e[400005];
	void init(){
		memset(F,0x3f,sizeof F);
	}
	inline void add(Ci u,Ci v,Ci w){
		F[u][v]=w;
	}
	void work(){
		for(int k=1;k<=n;k++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)F[i][j]=min(F[i][j],F[i][k]+F[k][j]);
//		for(int i=1;i<=n;i++)
//			for(int j=1;j<=n;j++)cout<<i<<' '<<j<<" "<<F[i][j]<<"\n";
	}
}
ll f[200005],res[200005];
int Fa[200005];
int dis[2505][2505],q[2505],L,R;
inline void bfs(Ci st){
	dis[st][st]=1;
	q[L=R=1]=st;
	while(L<=R){
		int u=q[L++];
		for(int i=hd[u];i;i=e[i].nxt){
			int v=e[i].to;
			if(dis[st][v])continue;
			dis[st][v]=dis[st][u]+1;
			q[++R]=v;
		}
	}
}
void dfs1(Ci u,Ci fa){
	Fa[u]=fa;
	for(int i=hd[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa)continue;
		dfs1(v,u);
	}
}
void dfs(Ci u,Ci fa){
	for(int i=hd[fa];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==u)continue;
	}
	for(int i=hd[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa)continue;
		dfs(v,u);
	}
}
}

namespace K1{
ll f[200005],res[200005];
int ft[200005][20],d[200005];
void dfs(Ci u,Ci fa){
	ft[u][0]=fa;f[u]=f[fa]+a[u];d[u]=d[fa]+1;
	for(int i=1;i<19;i++)ft[u][i]=ft[ft[u][i-1]][i-1];
	for(int i=hd[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa)continue;
		dfs(v,u);
	}
}
inline int LCA(int u,int v){
	if(d[u]<d[v])swap(u,v);
	for(int i=18;i>=0;i--)
		if(d[ft[u][i]]>=d[v])u=ft[u][i];
//	cout<<ft[3][1]<<' '<<u<<" "<<v<<"\n";
	if(u==v)return u;
	for(int i=18;i>=0;i--)
		if(ft[u][i]!=ft[v][i])u=ft[u][i],v=ft[v][i];
	return ft[u][0];
}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);
	n=read(),q=read(),k=read();
	For(i,1,n)a[i]=read();
	For(i,1,n-1){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	if(k==1){
		K1::dfs(1,0);
		For(i,1,q){
			int S=read(),T=read();
			int lca=K1::LCA(S,T);
//			cout<<lca<<"\n";
			cout<<K1::f[S]+K1::f[T]-K1::f[lca]-K1::f[K1::ft[lca][0]]<<'\n';
		}
		return 0;
	}
	For(i,1,q){
		int S=read(),T=read();
		if(S>T)swap(S,T);
		que[S].push_back({T,i});
	}
	if(k==2){
		For(i,1,n){
			if(!que[i].size())continue;
			K2::dfs(i,0);
			for(Que v:que[i])ans[v.id]=K2::f[v.y];
		}
		For(i,1,q)cout<<ans[i]<<"\n";
		return 0;
	}
	For(i,1,n)K3::bfs(i);
	K3::GG::init();
	For(i,1,n)
		For(j,1,n)
			if(K3::dis[i][j]<=4&&i!=j)K3::GG::add(i,j,a[j])/*,cout<<i<<' '<<j<<' '<<a[j]<<'\n'*/;
	K3::GG::work();
	For(i,1,n){
		for(Que v:que[i])ans[v.id]=K3::GG::F[i][v.y]+a[i];
	}
	For(i,1,q)cout<<ans[i]<<"\n";
	return 0;
}