#include<bits/stdc++.h>
#define ll long long
#define ull unsigned ll
#define INF 0x3f3f3f3f
#define INFLL 0x3f3f3f3f3f3f3f3fll
using namespace std;
#define Ci const int
#define Cl const ll
#define Cul const ull
#define Cc const char
#define For(x,l,r) for(int x=(l);x<=(r);x++)
#define Rep(x,r,l) for(int x=(r);x>=(l);x--)
inline ll read(){ll x;cin>>x;return x;}
int n,m,k,hd[2505],cnt;
ll a[2505];
bool Vis[2505];
struct E{
	int nxt,to;
}e[20005];
inline void add(Ci u,Ci v){
	e[++cnt]={hd[u],v};
	hd[u]=cnt;
}
int dis[2505][2505],q[2505],L,R;
inline void bfs(Ci st){
	dis[st][st]=1;
	q[L=R=1]=st;
	while(L<=R){
		int u=q[L++];
		for(int i=hd[u];i;i=e[i].nxt){
			int v=e[i].to;
			if(dis[st][v])continue;
			dis[st][v]=dis[st][u]+1;
			q[++R]=v;
		}
	}
}
vector<int>v[2505];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	n=read(),m=read(),k=read();
	For(i,2,n)a[i]=read()/*,cerr<<"!! "<<i<<' '<<a[i]<<'\n'*/;
	For(i,1,m){
		int x=read(),y=read();
		add(x,y);add(y,x);
	}
	For(i,1,n)bfs(i);
	For(i,1,n){
		For(j,1,n){
			if(i==j||dis[i][j]-2>k)continue;
//			cerr<<"?? "<<i<<' '<<j<<'\n';
			v[i].push_back(j);
		}
	}
	for(int i:v[1])Vis[i]=1;
	For(i,1,n){
		if(v[i].size()==1)continue;
		if(v[i].size()==0)continue;
		sort(v[i].begin(),v[i].end(),[](int x,int y){
			return Vis[x]>Vis[y]||(Vis[x]==Vis[y]&&a[x]>a[y]);
		});
	}
	ll ans=0;
	For(i,2,n)
		for(int j:v[i]){
			for(int I=0;I<min((int)v[i].size(),4);I++){
				if(!Vis[v[i][I]]||v[i][I]==j)continue;
				for(int J=0;J<min((int)v[j].size(),4);J++){
					if(!Vis[v[j][J]]||v[j][J]==i||v[j][J]==v[i][I])continue;
//					cerr<<v[i][I]<<' '<<i<<' '<<j<<' '<<v[j][J]<<" "<<a[i]+a[j]+a[v[i][I]]+a[v[j][J]]<<'\n';
					ans=max(ans,a[i]+a[j]+a[v[i][I]]+a[v[j][J]]);
				}
			}
		}
	cout<<ans<<'\n';
	return 0;
}