#include<bits/stdc++.h>
#define ll long long
#define ull unsigned ll
#define INF 0x3f3f3f3f
#define INFLL 0x3f3f3f3f3f3f3f3fll
using namespace std;
#define Ci const int
#define Cl const ll
#define Cul const ull
#define Cc const char
#define For(x,l,r) for(int x=(l);x<=(r);x++)
#define Rep(x,r,l) for(int x=(r);x>=(l);x--)
inline ll read(){ll x;cin>>x;return x;}
int n,m,q,a[500005],d[500005];
set<int>s[500005],del[500005];
int fl=0;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(0);
	n=read(),m=read();
	For(i,1,m){
		int x=read(),y=read();
		s[y].insert(x);++d[x];
	}
	For(i,1,n)fl+=(d[i]==1);
	for(int q=read();q;q--){
		int op=read(),x=read();
		if(op==1){
			int y=read();
			s[y].erase(x);
			if(d[x]==1)--fl;
			--d[x];
			if(d[x]==1)++fl;
			del[y].insert(x);
		}
		else if(op==2){
			for(int u:s[x]){
				if(d[u]==1)--fl;
				--d[u];
				if(d[u]==1)++fl;
				del[x].insert(u);
			}
			s[x].clear();
		}
		else if(op==3){
			int y=read();
			del[y].erase(x);
			s[y].insert(x);
			if(d[x]==1)--fl;
			++d[x];
			if(d[x]==1)++fl;
		}
		else if(op==4){
			for(int u:del[x]){
				if(d[u]==1)--fl;
				++d[u];
				if(d[u]==1)++fl;
				s[x].insert(u);
			}
			del[x].clear();
		}
		if(fl==n)puts("YES");
		else puts("NO");
	}
	return 0;
}