#include<bits/stdc++.h>
#define ll long long
#define ull unsigned ll
#define INF 0x3f3f3f3f
#define INFLL 0x3f3f3f3f3f3f3f3fll
using namespace std;
#define Ci const int
#define Cl const ll
#define Cul const ull
#define Cc const char
#define For(x,l,r) for(int x=(l);x<=(r);x++)
#define Rep(x,r,l) for(int x=(r);x>=(l);x--)
inline ll read(){ll x;cin>>x;return x;}
int n,m,q,a[100005],b[100005];
struct SGT{
	struct T{
		int ansa,ansb;
		int ansu,ansv;
		bool allf,allz;
		inline T operator+(const T&U)const{
			return{
				max(ansa,U.ansa),
				max(ansb,U.ansb),
				min(ansu,U.ansu),
				min(ansv,U.ansv),
				allf&&U.allf,
				allz&&U.allz
			};
		}
	}tr[400005];
	#define u (s<<1)
	#define v (s<<1|1)
	inline void push_up(Ci s){
		tr[s]=tr[u]+tr[v];
	}
	void build(Ci l,Ci r,Ci s){
		tr[s].ansa=tr[s].ansb=-INF;
		tr[s].ansu=tr[s].ansv=INF;
		tr[s].allf=tr[s].allz=0;
		if(l==r){
			if(a[l]>=0)tr[s].ansa=tr[s].ansu=a[l],tr[s].allz=1;
			else if(a[l]<=0)tr[s].ansb=tr[s].ansv=-a[l],tr[s].allf=1;
			return;
		}
		int mid=(l+r)>>1;
		build(l,mid,u);build(mid+1,r,v);
		push_up(s);
	}
	T query(Ci x,Ci y,Ci l,Ci r,Ci s){
		if(x<=l&&r<=y)return tr[s];
		int mid=(l+r)>>1;
		if(y<=mid)return query(x,y,l,mid,u);
		if(x>mid)return query(x,y,mid+1,r,v);
		return query(x,y,l,mid,u)+query(x,y,mid+1,r,v);
	}
	#undef u
	#undef v
}x,y;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	n=read(),m=read(),q=read();
	For(i,1,n)a[i]=read();
	x.build(1,n,1);
	For(i,1,m)a[i]=read();
	y.build(1,m,1);
	for(;q;q--){
		int l=read(),r=read(),L=read(),R=read();
		SGT::T A=x.query(l,r,1,n,1),B=y.query(L,R,1,m,1);
		if(B.allf){
			if(A.allz){
				cout<<-1ll*A.ansu*B.ansb<<"\n";
			}
			else cout<<1ll*A.ansb*B.ansv<<"\n";
		}
		else if(B.allz){
			if(A.allf){
				cout<<-1ll*A.ansv*B.ansa<<"\n";
			}
			else cout<<1ll*A.ansa*B.ansu<<"\n";
		}
		else{
			if(A.allf){
				cout<<-1ll*A.ansv*B.ansa<<"\n";
			}
			else if(A.allz){
				cout<<-1ll*A.ansu*B.ansb<<"\n";
			}
			else cout<<max(-1ll*A.ansu*B.ansb,-1ll*A.ansv*B.ansa)<<"\n";
		}
	}
	return 0;
}