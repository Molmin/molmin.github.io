#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define F(i,l,r) for(int i=(l);i<=(r);i++)
#define R(i,l,r) for(int i=(l);i>=(r);i--)
//#define int ll
const int N=1005;
int n,m,q,lg[100005],l1,r1,l2,r2;
ll a[100005],b[100005];
ll c[1005][1005],f[1005][1005][30];
ll A[N][30],B[N][30];
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%d%d%d",&n,&m,&q);
    lg[1]=0;F(i,2,n)lg[i]=lg[i/2]+1;
    F(i,1,n)scanf("%lld",&a[i]);
    F(i,1,m)scanf("%lld",&b[i]);
    if(n<=1000){
        F(i,1,n) F(j,1,m) c[i][j]=a[i]*b[j];
        F(l,1,n){
            F(i,1,m)f[l][i][0]=c[l][i];
            F(j,1,20) for(int i=1;i+(1<<j)-1<=m;i++) f[l][i][j]=min(f[l][i][j-1],f[l][i+(1<<(j-1))][j-1]);
        }
        while(q--){
            scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
            int s=lg[r2-l2+1];
            ll res=-1e18;
            F(l,l1,r1){
                ll mn=min(f[l][l2][s],f[l][r2-(1<<s)+1][s]);
                res=max(res,mn);
            }
            printf("%lld\n",res);
        }
    }
    else{
        F(i,1,n)A[i][0]=a[i];
	    F(i,1,m)B[i][0]=b[i];
        F(j,1,20) for(int i=1;i+(1<<j)-1<=n;i++) A[i][j]=max(A[i][j-1],A[i+(1<<(j-1))][j-1]);
        F(j,1,20) for(int i=1;i+(1<<j)-1<=m;i++) B[i][j]=min(B[i][j-1],B[i+(1<<(j-1))][j-1]);
        F(i,1,q){
        	scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
        	int s1=lg[r1-l1+1],s2=lg[r2-l2+1];
        	ll mx=max(A[l1][s1],A[r1-(1<<s1)+1][s1]),mn=min(B[l2][s2],B[r2-(1<<s2)+1][s2]);
        	printf("%lld\n",mx*mn);
	    }
    }
    return 0;
}