#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define F(i,l,r) for(int i=(l);i<=(r);i++)
#define R(i,l,r) for(int i=(l);i>=(r);i--)
//#define int ll
int n,m,q,dis[15][15];
bool flag,vis[15];
void dfs(int u){
    if(flag)return ;
    if(vis[u]){
        flag=1;
        return ;
    }
    vis[u]=1;
    F(i,1,n) if(dis[u][i]) dfs(i);
}
signed main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    scanf("%d%d",&n,&m);
    F(i,1,m){
        int u,v;
        scanf("%d%d",&u,&v);
        dis[u][v]=1;
    }
    scanf("%d",&q);
    while(q--){
        int t,u,v;
        scanf("%d%d",&t,&u);
        if(t==1){
            scanf("%d",&v);
            dis[u][v]=0;
        }
        if(t==2){
            F(i,1,n) if(dis[i][u]==1) dis[i][u]=2;
        }
        if(t==3){
            scanf("%d",&v);
            dis[u][v]=1;
        }
        if(t==4){
            F(i,1,n) if(dis[i][u]==2)dis[i][u]=1;
        }
        bool ans=1;
        F(i,1,n){
            int cnt=0;
            F(j,1,n)if(dis[i][j]==1)cnt++;
            if(cnt>1){
                ans=0;
                break;
            }
        }
        if(!ans){
            printf("NO\n");
            continue;
        }
        F(i,1,n){
            memset(vis,0,sizeof(vis));
            flag=0;
            dfs(i);
            ans|=flag;
            if(!ans)break;
        }
        if(!ans)printf("NO\n");
        else printf("YES\n");
    }
    return 0;
}