#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define ll long long
#define F(i,l,r) for(int i=(l);i<=(r);i++)
#define R(i,l,r) for(int i=(l);i>=(r);i--)
const int N=2505;
int n,m,p;
ll val[N],res;
bool vis[N];
vector<int>g[N];
void dfs(int u,int k,ll sum){
    if(k>4)return ; ++k;
    for(int i=0;i<(int)g[u].size();i++){
        int v=g[u][i];
        if(v==1&&k==5)res=max(res,sum);
        if(vis[v])continue;
        vis[v]=1;
        dfs(v,k,sum+val[v]);
        vis[v]=0;
    }
}
int dis[N][N];
signed main(){
    freopen("holiday.out","r",stdin);
    freopen("holiday.out","w",stdout);
	memset(dis,0x3f,sizeof(dis));
    scanf("%d%d%d",&n,&m,&p);
    F(i,2,n)scanf("%lld",&val[i]);
    if(p==0){
        F(i,1,m){
            int u,v;
            scanf("%d%d",&u,&v);
            g[u].pb(v),g[v].pb(u);
        }
        dfs(1,0,0);
        printf("%d\n",res);
        return 0;
    }
    p++;
    F(i,1,n)dis[i][i]=0;
    F(i,1,m){
    	int u,v;
    	scanf("%d%d",&u,&v);
    	dis[u][v]=dis[v][u]=1;
	}
	F(k,1,n) F(i,1,n) F(j,1,n) dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
	F(i,2,n){
		F(j,2,n){
			if(j==i)continue;
			F(k,2,n){
				if(k==i||k==j)continue;
				F(h,2,n){
					if(h==i||h==j||h==k)continue;
					if(dis[1][i]<=p&&dis[i][j]<=p&&dis[j][k]<=p&&dis[k][h]<=p&&dis[h][1]<=p){
						res=max(res,val[i]+val[j]+val[k]+val[h]);
					}
				}
			}
		}
	}
	printf("%lld\n",res);
    return 0;
}
/*55*/