#include<bits/stdc++.h>
using namespace std;
const int N = 2505;
const int M = 20005;
int h[N],e[M],ne[M],dist[N][N],n,m,kkk,idx;long long a[N];
void add(int x,int y){
	e[idx] = y,ne[idx] = h[x],h[x] = idx ++;
}
struct node{
	int x;
	int step;
};
void bfs(int start){
	dist[start][start] = 0;
	queue<node> que;
	que.push({start,0});
	while(!que.empty()){
		node now = que.front();que.pop();
		int ver = now.x;
		for(int i = h[ver];i != -1;i = ne[i]){
			if(dist[start][e[i]] == 0x3f3f3f3f)que.push({e[i],now.step+1});
			dist[start][e[i]] = min(dist[start][e[i]],dist[start][ver]+1);
		}
	}
}
void subtask1()//for n <= 20
{
	long long ans = 0;
	for(int i = 2;i <= n;i ++){
		if(dist[1][i] > kkk+1)continue;
		for(int j = 2;j <= n;j ++){
			if(i == j)continue;
			if(dist[i][j] > kkk+1)continue;
			for(int k = 2;k <= n;k ++){
				if(i == k || j == k)continue;
				if(dist[j][k] > kkk+1)continue;
				for(int t = 2;t <= n;t ++){
					if(i == t || j == t || k == t)continue;
					if(dist[k][t] > kkk+1 || dist[t][1] > kkk+1)continue;
					ans = max(ans,a[i]+a[j]+a[k]+a[t]);
				}
			}
		}
	}
	cout << ans << endl;exit(0);
}
long long ans = 0;
void subtask2(int step,int *aaa,long long sum){
	if(step == 5){
		if(dist[aaa[4]][1] == 1){
			ans = max(ans,sum);
		}
	}
	int x = aaa[step-1];
	for(int i = h[x];i != -1;i = ne[i]){
		int ok = 1;
		for(int j = 1;j < step;j ++)if(e[i] == aaa[j])ok = 0;
		if(!ok)continue;
		aaa[step] = e[i];
		subtask2(step+1,aaa,sum+a[e[i]]);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(h,-1,sizeof(h));
	cin >> n >> m >> kkk;
	for(int i = 2;i <= n;i ++)cin >> a[i];
	for(int i = 1;i <= m;i ++){
		int x,y;
		cin >> x >> y;
		add(x,y);
		add(y,x);
	}
	int AAA[6] = {0,1};
	if(kkk == 0)subtask2(2,AAA,0);
	memset(dist,0x3f,sizeof(dist));
	for(int i = 1;i <= n;i ++)bfs(i);
	subtask1();
	return 0;
}
