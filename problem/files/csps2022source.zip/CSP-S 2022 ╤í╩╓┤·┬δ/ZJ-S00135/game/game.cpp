#include<bits/stdc++.h>
using namespace std;
int n,m,q;
long long A[1005],B[1005];
long long C[1005][1005];
struct node{
	int l,r;
	long long minn;
};
struct Sigment_Tree{
	long long *A;
	node* tr = new node[1005*4]{};
	void pushup(int u){
		tr[u].minn = min(tr[u<<1].minn,tr[u<<1|1].minn);
	}
	void build(int u,int l,int r){
		if(l == r){
			tr[u] = {l,r,A[l]};
			return;
		}
		tr[u].l = l,tr[u].r = r;
		int mid = l + r >> 1;
		build(u<<1,l,mid);
		build(u<<1|1,mid+1,r);
		pushup(u);
	}
	long long query(int u,int l,int r){
		if(l <= tr[u].l && tr[u].r <= r){
			return tr[u].minn;
		}
		int mid = tr[u].l + tr[u].r >> 1;
		long long ans = 2e18;
		if(l <= mid)ans = min(ans,query(u<<1,l,r));
		if(r > mid)ans = min(ans,query(u<<1|1,l,r));
		return ans;
	}
}trees[1005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> n >> m >> q;
	for(int i = 1;i <= n;i ++)cin >> A[i];
	for(int i = 1;i <= m;i ++)cin >> B[i];
//	trees[0].A = A;
//	trees[0].build(1,1,n);
//	cout << trees[0].query(1,1,n) << endl;
	for(int i = 1;i <= n;i ++)
		for(int j = 1;j <= m;j ++)
			C[i][j] = A[i]*B[j];
//	for(int i = 1;i <= n;i ++){
//		for(int j = 1;j <= m;j ++)
//			cout << C[i][j] << " ";
//		cout << endl;
//	}
	for(int i = 1;i <= n;i ++){
		trees[i].A = C[i];
		trees[i].build(1,1,m);
	}
	while(q --){
		int l,r,l2,r2;
		cin >> l >> r >> l2 >> r2;
		long long ans = -2e18;
		for(int i = l;i <= r;i ++){
			ans = max(ans,trees[i].query(1,l2,r2));
		}
		cout << ans << endl;
	}
	return 0;
}/*

*/
