#include<bits/stdc++.h>
using namespace std;
int n,m,k;
const int N = 2e3+5;
int a[N],color[N],dist[2][N];
vector<int> edges[N];
long long ans = 2e18;
void C(int con,int x,int *d){
	for(auto i:edges[x]){
		if(i < x){
			color[i] += con;
			d[i] = d[x] + a[i];
			C(con,i,d);
		}
	}
}
int lca(int x,int y){
	for(int i = 1;i <= n;i ++){
		if(color[i] == x+y){
			return dist[i][0] + dist[i][1];
		}
	}
	return -1;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin >> n >> m >> k;
	for(int i = 1;i <= n;i ++){
		cin >> a[i];
	}
	for(int i = 1;i < n;i ++){
		int u,v;
		cin >> u >> v;
		edges[u].push_back(v);
		edges[v].push_back(u);
	}
	while(m --){
		int u,v;
		cin >> u >> v;
		C(u,u,dist[0]);C(v,v,dist[1]);
		cout << lca(u,v) << endl;
	}
	return 0;
}

