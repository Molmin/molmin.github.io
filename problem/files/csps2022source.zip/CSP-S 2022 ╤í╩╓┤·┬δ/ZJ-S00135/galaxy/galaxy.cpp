#include<bits/stdc++.h>
using namespace std;
const int N = 5e5+5;
set<int> f[N],g[N],clone[N];
int n,m,q,vis[N],be[N];
int bfs(int start){
	queue<int> que;
	que.push(start);
	vis[start] = 1;
	while(!que.empty()){
		int now = que.front();
		que.pop();
		int next = *f[now].begin();
		if(vis[next])return 1;
		que.push(next);vis[next] = 1;
	}
	return 0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin >> n >> m;
	for(int i = 1;i <= m;i ++){
		int u,v;
		cin >> u >> v;
		f[u].insert(v);//go to
		g[v].insert(u);		//go back
	}
	cin >> q;
	while(q --){
		int op;
		cin >> op;
		if(op == 1){
			int u,v;
			cin >> u >> v;
			f[u].erase(v);
			g[v].erase(u);
		}
		if(op == 2){
			int u;
			cin >> u;
			for(auto i:g[u]){
				f[i].erase(u);
			}
			g[u].clear();
		}
		if(op == 3){
			int u,v;
			cin >> u >> v;
			f[u].insert(v);
			g[v].insert(u);
		}
		if(op == 4){
			int u;
			cin >> u;
			g[u] = clone[u];
			for(auto i:g[u]){
				f[i].insert(u);
			}
		}
		int ok = 1;
		for(int i = 1;i <= n;i ++){
			if(f[i].size() != 1){
				ok = 0;
			}
		}
		if(ok == 0){
			cout << "NO" << endl;
			continue;
		}
		for(int i = 1;i <= n;i ++){
			memset(vis,0,sizeof(vis));
			ok &= bfs(i);
		}
		if(ok){
			cout << "YES" << endl;
		}else{
			cout << "NO" << endl;
		}
	}
	return 0;
}

