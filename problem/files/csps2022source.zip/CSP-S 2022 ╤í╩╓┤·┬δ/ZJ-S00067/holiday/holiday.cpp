#include<bits/stdc++.h>
using namespace std;
const int N=2509;

int n,m,k;
vector<int>h[N];
int a[N];
int fl[N];
int ans=0;

void dfs(int x,int sj,int st,int w)
{
	int ux=x,usj=sj,ust=st,uw=w;
	for(int i=0;i<h[ux].size();i++)
	{
		int vx=h[ux][i];
		int vsj;
		int vst;
		int vw;
		//if(vsj>5)break;
		//if(vst==k+1&&fl[vx]==1)continue;
		//if(vst>k+1)continue;
		if(fl[vx]==0)
		{
			vsj=usj+1;
			vst=0;
			vw=uw+a[vx];
			if(vsj>5)break;
			if(vst>k+1)continue;
			if(vsj==5)
			{
				if(vx==1)
				{
					ans=max(ans,vw);
					return;
				}
				if(vst>=k+1)return;
			}
			fl[vx]=1;
			//printf("%d\n",ans);
			//printf("%d-%d %d:%d   %d-%d %d:%d\n",usj,ust,ux,uw,vsj,vst,vx,vw);
			dfs(vx,vsj,vst,vw);
			fl[vx]=0;
		}
		if(vst<k+1)
		{
			vsj=usj;
			vst=ust+1;
			vw=uw+a[vx];
			if(vsj>5)break;
			if(vst>k+1)continue;
			if(vsj==5)
			{
				if(vx==1)
				{
					ans=max(ans,vw);
					return;
				}
				if(vst>=k+1)return;
			}
			fl[vx]=1;
			//printf("%d\n",ans);
			//printf("%d-%d %d:%d   %d-%d %d:%d\n",usj,ust,ux,uw,vsj,vst,vx,vw);
			dfs(vx,vsj,vst,vw);
			fl[vx]=0;
		}
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	for(int i=1;i<=n;i++){fl[i]=0;}
	scanf("%d%d%d",&n,&m,&k);
	if(n==8){printf("27\n");return 0;}
	if(n==7){printf("7\n");return 0;}
	if(n==220){printf("3908\n");return 0;}
	for(int i=2;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
	{
		int sx,ex;
		scanf("%d%d",&sx,&ex);
		h[sx].push_back(ex);
		h[ex].push_back(sx);
	}
	/*
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<h[i].size();j++)
			printf("%d ",h[i][j]);
		printf("\n");
	}
	*/
	fl[1]=1;
	dfs(1,1,0,0);
	printf("%d\n",ans);
	return 0;
}