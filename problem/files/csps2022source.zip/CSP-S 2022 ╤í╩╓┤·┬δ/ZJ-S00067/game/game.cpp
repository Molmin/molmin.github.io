#include<bits/stdc++.h>
using namespace std;
const long long N=100009;

long long n,m,q;
long long a[N],b[N];

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(long long i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(long long i=1;i<=m;i++)scanf("%lld",&b[i]);
	while(q--)
	{
		long long l1,r1,l2,r2;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		long long mx1=-1e18-1,mn1=1e18+1,ok11=0,ok10=0,mn1c=1e18+1,mx1c=-1e18-1;
		for(long long i=l1;i<=r1;i++)
		{
			if(a[i]>=0){ok11=1;mn1c=min(mn1c,a[i]);}
			if(a[i]<=0){ok10=1;mx1c=max(mx1c,a[i]);}
			mx1=max(mx1,a[i]);
			mn1=min(mn1,a[i]);
		}
		long long mx2=-1e18-1,mn2=1e18+1,ok21=0,ok20=0;
		for(long long i=l2;i<=r2;i++)
		{
			if(b[i]>=0){ok21=1;}
			if(b[i]<=0){ok20=1;}
			mx2=max(mx2,b[i]);
			mn2=min(mn2,b[i]);
		}
		//printf("%lld %lld %lld %lld %lld %lld   %lld %lld %lld %lld\n",mx1,mn1,ok11,ok10,mn1c,mx1c,mx2,mn2,ok21,ok20);
		long long tmp=0;
		if(ok11==1&&ok10==0&&ok21==1&&ok20==0)tmp=mx1*mn2;
		if(ok11==1&&ok10==0&&ok21==0&&ok20==1)tmp=mn1*mn2;
		if(ok11==1&&ok10==0&&ok21==1&&ok20==1)tmp=mn1*mn2;
		if(ok11==1&&ok10==1&&ok21==1&&ok20==0)tmp=mx1*mn2;
		if(ok11==1&&ok10==1&&ok21==0&&ok20==1)tmp=mn1*mx2;
		if(ok11==1&&ok10==1&&ok21==1&&ok20==1)tmp=max(mn1c*mn2,mx1c*mx2);
		if(ok11==0&&ok10==1&&ok21==1&&ok20==0)tmp=mx1*mx2;
		if(ok11==0&&ok10==1&&ok21==0&&ok20==1)tmp=mn1*mx2;
		if(ok11==0&&ok10==1&&ok21==1&&ok20==1)tmp=mx1*mx2;
		printf("%lld\n",tmp);
	}
	return 0;
}