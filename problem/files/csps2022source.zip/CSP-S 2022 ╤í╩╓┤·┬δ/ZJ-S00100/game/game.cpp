#include<iostream>
#include<cmath>
using namespace std;

int n,m,q;
int f[100005][20], fs[100005][20],fls[100005][20],fl[100005][20],fa[100005][20],fb[100005][20];

int mina(int a,int b){
    if(abs(a)<=abs(b)) return a;
    else return b;
}
int minb(int a,int b){
    if(abs(a)<abs(b)) return a;
    else return b;
}

int main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m>>q;
    for(int i=1; i<=n; i++){
        cin>>f[i][0];
        fs[i][0]=f[i][0];
        fa[i][0]=f[i][0];
        fb[i][0]=f[i][0];
    }
    for(int i=1; i<=m; i++){
        cin>>fl[i][0];
        fls[i][0]=fl[i][0];
       // fla[i][1]=abs(fl[i][1])
    }
    for(int j=1; (1<<j)<=n; j++){
        for(int i=1; i+(1<<j)-1<=n; i++){
            f[i][j]=max(f[i][j-1],f[i+(1<<(j-1))][j-1]);
            fs[i][j]=min(fs[i][j-1],fs[i+(1<<(j-1))][j-1]);
            fa[i][j]=mina(fa[i][j-1],fa[i+(1<<(j-1))][j-1]);
            fb[i][j]=minb(fb[i][j-1],fb[i+(1<<(j-1))][j-1]);
        }
    }
    for(int j=1; (1<<j)<=n; j++){
        for(int i=1 ;i+(1<<j)-1<=n; i++){
            fl[i][j]=max(fl[i][j-1],fl[i+(1<<(j-1))][j-1]);
            fls[i][j]=min(fls[i][j-1],fls[i+(1<<(j-1))][j-1]);
            //fla[i][j]=min(fla[i][j-1],fla[i+(1<<(j-1)][j-1])
        }
    }
    for(int i=1; i<=q; i++){
        int l1,r1,l2,r2;
        cin>>l1>>r1>>l2>>r2;
        int k1=log2(r1-l1+1),k2=log2(r2-l2+1);
        long long mx1=max(f[l1][k1],f[r1-(1<<k1)+1][k1]);
        long long mi1=min(fs[l1][k1],fs[r1-(1<<k1)+1][k1]);
        long long mx2=max(fl[l2][k2],fl[r2-(1<<k2)+1][k2]);
        long long mi2=min(fls[l2][k2],fls[r2-(1<<k2)+1][k2]);
        long long ma1=mina(fa[l1][k1],fa[r1-(1<<k1)+1][k1]);
        long long mb1=minb(fb[l1][k1],fb[r1-(1<<k1)+1][k1]);
        //int mx2=min(fl[l2][k2],fl[r2-(1<<k2)][k2]);
        //cout<<mx1<<' '<<mi1<<' '<<ma1<<' '<<mx2<<' '<<mi2<<' ';
        if(mx2<=0) cout<<(mi1*mx2);
        if(mi2>0)  cout<<(mx1*mi2);
        if(mx2>0&&mi2<=0){
            if(mb1!=ma1){
                if(ma1<=0) cout<<max(ma1*mx2,mb1*mi2);
                else cout<<max(ma1*mi2,mb1*mx2);
            }
            else{
                if(ma1<=0) cout<<ma1*mx2;
                else cout<<ma1*mi2;
            }
        }
        cout<<endl;
    }
}
