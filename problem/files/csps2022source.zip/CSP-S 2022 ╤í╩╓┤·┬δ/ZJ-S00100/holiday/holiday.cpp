#include<iostream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<cstring>
using namespace std;

int l[2505][105][5], sc[2505],go[2505],vis[2505],n,m,k,ans;
vector<int> e[2505];


int dfs(int x,int z,int tim){
    int a=-1e9;
    if(tim==4){
        if(go[x]) {
            return 0;
        }
        else return -1e9;
    }
    for(int i=0; i<e[x].size(); i++){
        int y=e[x][i];
        if(y!=1&&vis[y]==0){
            vis[y]=1;
            a=max(a,dfs(y,0,tim+1)+sc[y]);
            vis[y]=0;
        }
        if(z<k)
            a=max(a,dfs(y,z+1,tim));
    }
    return a;
}
void dfs_go(int x,int t){
    if(go[x]) return;
    go[x]=true;
    if(t==0) return;
    for(int i=0; i<e[x].size(); i++){
        int y=e[x][i];
        dfs_go(y,t-1);
    }
}

int main(){
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=2; i<=n; i++){
        cin>>sc[i];
    }
    for(int i=1; i<=m; i++){
        int a,b;
        cin>>a>>b;
        e[a].push_back(b);
        e[b].push_back(a);
    }
    dfs_go(1,k+1);
    for(int i=2; i<=n; i++){
        if(go[i]){
            vis[i]=1;
            ans=max(dfs(i,0,1)+sc[i],ans);
            vis[i]=0;
        }
    }
    cout<<ans;

    return 0;
}
