#include<bits/stdc++.h>
using namespace std;
int a[4000],n,k,m,u,v,w,vis[4005];
long long f[4005][4005],minn;
void dfs(int x,int y,long long s)
{
	if (x==y) 
	{
		minn=min(minn,s);
		return;
	}
	vis[x]=1;
	for (int i=1;i<=n;i++)
	if (f[x][i]<k&&vis[i]==0) dfs(i,y,s+a[i]);
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(f,0x3f3f3f,sizeof(f));
	for (int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
		f[i][i]=0;
	}
	for (int i=1;i<=n-1;i++) 
	{
		scanf("%d%d",&u,&v);
		f[u][v]=f[v][u]=1;
	}
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=n;j++)
	    for (int l=j+1;l<=n;l++)
	      f[j][l]=f[l][j]=min(f[j][l],f[j][i]+f[i][l]);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		memset(vis,0,sizeof(vis));
		minn=INT_MAX;
		dfs(u,v,a[u]);
		printf("%d\n",minn);
	}
	return 0;
}
