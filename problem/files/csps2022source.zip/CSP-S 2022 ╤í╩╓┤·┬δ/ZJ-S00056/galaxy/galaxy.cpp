#include<bits/stdc++.h>
using namespace std;
int n,q,m,u,v,out[500005],vis[500005],t,fx,c[500005];
vector<int> d[500005],d1[500005],f[500005],f1[500005];
bool dfs(int x)
{
	if (vis[x]==1) return true;
	vis[x]=1;
	for (int i=0;i<f[x].size();i++)
		if (dfs(f[x][i])) 
		{
			c[x]=1;
			return true;
		}
	return false;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++) 
	{
		scanf("%d%d",&u,&v);
		f[u].push_back(v);
		f1[u].push_back(1);
		out[u]++;
		d[v].push_back(u);
		d1[v].push_back(f[u].size()-1);
	}
	scanf("%d",&q);
	for (int i=1;i<=q;i++)
	{
		scanf("%d",&t);
		if (t==1) 
		{
			scanf("%d%d",&u,&v);
			for (int j=0;j<f[u].size();j++)
				if (f[u][j]==v) 
				{
					f1[u][j]=0;
					out[u]--;
					break; 
				}
		}
		if (t==2) 
		{
			scanf("%d",&u);
			for (int j=0;j<d[u].size();j++)
				if (f1[d[u][j]][d1[u][j]]==1)
					f1[d[u][j]][d1[u][j]]=0,out[d[u][j]]--;
		}
		if (t==3) 
		{
			scanf("%d%d",&u,&v);
			for (int j=0;j<f[u].size();j++)
				if (f[u][j]==v) 
				{
					f1[u][j]=1;
					out[u]++;
					break;
				} 
		}
		if (t==4) 
		{
			scanf("%d",&u);
			for (int j=0;j<d[u].size();j++)
				if (f1[d[u][j]][d1[u][j]]==0)
					f1[d[u][j]][d1[u][j]]=1,out[d[u][j]]++;
		}
		fx=1;
		for (int j=1;j<=n;j++)
			if (out[j]!=1) 
			{
				fx=0;
				break;
			}
		if (fx==1)
		{
			memset(c,0,sizeof(c));
			for (int j=1;j<=n;j++)
			{
				memset(vis,0,sizeof(vis));
				if (c[j]==0)
				if (!dfs(j)) 
				{
					fx=0;
					break;
				}
			}
		}
		if (fx==1) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
