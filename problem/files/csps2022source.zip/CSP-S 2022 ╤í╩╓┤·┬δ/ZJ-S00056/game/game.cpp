#include<bits/stdc++.h>
using namespace std;
int n,q,m,l1,r1,l2,r2;
long long minn,maxx,minj,a[100005],b[100005],maxa[100005][40],maxb[100005][40],mina[100005][40],minb[100005][40];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for (int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for (int i=0;1ll<<i<=n;i++)
	{
		int len=1<<i;
		for (int j=1;j+len-1<=n;j++)
		{
			if (i==0) 
			{
				maxa[j][i]=a[j];
				mina[j][i]=a[j];
			}
			else 
			{
				maxa[j][i]=max(maxa[j][i-1],maxa[j+len/2][i-1]);
				mina[j][i]=min(mina[j][i-1],mina[j+len/2][i-1]);
			}
		}
	}
	for (int i=1;i<=m;i++) scanf("%lld",&b[i]);
	for (int i=0;1<<i<=n;i++)
	{
		int len=1<<i;
		for (int j=1;j+len-1<=n;j++)
		{
			if (i==0) 
			{
				maxb[j][i]=b[j];
				minb[j][i]=b[j];
			}
			else 
			{
				maxb[j][i]=max(maxb[j][i-1],maxb[j+len/2][i-1]);
				minb[j][i]=min(minb[j][i-1],minb[j+len/2][i-1]);
			}
		}
	}
	for (int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if (l1==r1)
		{
			int logx=log2(r2-l2+1),len=1<<logx;
			if (a[l1]>0) printf("%lld\n",a[l1]*min(minb[l2][logx],minb[r2-len+1][logx]));
			if (a[l1]<0) printf("%lld\n",a[l1]*max(maxb[l2][logx],maxb[r2-len+1][logx]));
			if (a[l1]==0) printf("0\n");
		}
		else 	
		if (l2==r2)
		{
			int logx=log2(r1-l1+1),len=1<<logx;
			if (b[l2]<0) printf("%lld\n",b[l2]*min(mina[l1][logx],mina[r1-len+1][logx]));
			if (b[l2]>0) printf("%lld\n",b[l2]*max(maxa[l1][logx],maxa[r1-len+1][logx]));
			if (b[l2]==0) printf("0\n");
		}
		else 
		{
			maxx=-1e18;
			int logx=log2(r2-l2+1),len=1<<logx;
			for (int j=l1;j<=r1;j++)
			{
				if (a[j]>0) maxx=max(maxx,a[j]*min(minb[l2][logx],minb[r2-len+1][logx]));
				if (a[j]<0) maxx=max(maxx,a[j]*max(maxb[l2][logx],maxb[r2-len+1][logx]));
				if (a[j]==0) maxx=max(maxx,0ll);
			}
			printf("%lld\n",maxx);
		}
	}
	return 0;
}
