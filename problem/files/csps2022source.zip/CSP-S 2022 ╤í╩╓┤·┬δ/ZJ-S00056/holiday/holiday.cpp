#include<bits/stdc++.h>
using namespace std;
int n,k,m,u,v;
long long a[4000],f[2505][2505],maxx,vis[4000];
vector<int> d[4000];
void dfs(int x,int y,long long s)
{
	if (y==4)
	{
		if (f[x][1]<=k+1) maxx=max(maxx,s);
		return;
	}
	for (int i=0;i<d[x].size();i++)
		if (d[x][i]!=1&&vis[d[x][i]]==0)
		{
			vis[d[x][i]]=1;
			dfs(d[x][i],y+1,s+a[d[x][i]]);
			vis[d[x][i]]=0;
		}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	memset(f,0x3f3f3f3f,sizeof(f));
	for (int i=2;i<=n;i++) 
	{
		scanf("%lld",&a[i]);
		f[i][i]=0;
	}
	for (int i=1;i<=m;i++) 
	{
		scanf("%d%d",&u,&v);
		f[u][v]=f[v][u]=1;
	}
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			for (int l=j+1;l<=n;l++)
				f[j][l]=f[l][j]=min(f[j][l],f[j][i]+f[i][l]);
	for (int i=1;i<=n;i++)
	{
		for (int j=i+1;j<=n;j++)
		{
			if (f[i][j]<=k+1) 
			{
				d[i].push_back(j);
				d[j].push_back(i);
			}
		}
	}
	dfs(1,0,0);
	cout<<maxx;
	return 0;
}
