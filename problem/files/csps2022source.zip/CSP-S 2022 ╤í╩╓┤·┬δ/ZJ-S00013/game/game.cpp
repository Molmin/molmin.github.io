#include<bits/stdc++.h> 
using namespace std;
#define ll long long
int n,m,q;
const int MAXN=1e5+5;
ll a[MAXN],b[MAXN];
ll c[MAXN][MAXN];
ll tree[MAXN][4*MAXN];
ll tl,tr;

inline void build(int l,int r,int p,int hang){
	if( l==r ){
		tree[hang][p]=c[hang][l];
		return;
	}
	int mid=(l+r)>>1;
	build(l,mid,p*2,hang);
	build(mid+1,r,p*2+1,hang);
	tree[hang][p]=min(tree[hang][p*2],tree[hang][p*2+1]);
	return;
}

inline ll query(int l,int r,int p,int hang){
	if( tl<=l && r<=tr )
		return tree[hang][p];
	int mid=(l+r)>>1;
	ll ans=1e18;
	if( tl<=mid )
		ans=min(ans,query(l,mid,p*2,hang));
	if( tr>mid )
		ans=min(ans,query(mid+1,r,p*2+1,hang));
	return ans;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			c[i][j]=a[i]*b[j];
	for(int i=1;i<=n;i++)
		build(1,m,1,i);
	while( q-- ){
		int l1,r1,l2,r2;
		ll allans=-1e18;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if( l2==r2 ){
			swap(l1,l2);
			swap(r1,r2);
		}
		for(int i=l1;i<=r1;i++){
			tl=l2,tr=r2;
			allans=max(allans,query(1,m,1,i));
		}
		printf("%lld\n",allans);
	}
	return 0;
}
