#include<bits/stdc++.h> 
using namespace std;
#define ll long long
const ll MAXN=2505,INF=1e9;
bool flag[MAXN];
ll g[MAXN][MAXN],w[MAXN];
ll n,m,len,ans;

inline void dfs(ll root,ll now,ll depth){
	if( depth==5 ){
		if( g[root][1]<=len+1 )
			ans=max(ans,now);
		return;
	}
	for(int i=2;i<=n;i++){
		if( flag[i] )
			continue;
		if( g[root][i]<=len+1 ){
			flag[i]=1;
			dfs(i,now+w[i],depth+1);
			flag[i]=0;
		}
	}
	return;
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&len);
	for(int i=2;i<=n;i++)
		scanf("%lld",&w[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			g[i][j]=INF;
	for(int i=1;i<=m;i++){
		ll u,v;
		scanf("%lld%lld",&u,&v);
		g[u][v]=1,g[v][u]=1;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
	dfs(1,0,1);
	printf("%lld",ans);
	return 0;
}
