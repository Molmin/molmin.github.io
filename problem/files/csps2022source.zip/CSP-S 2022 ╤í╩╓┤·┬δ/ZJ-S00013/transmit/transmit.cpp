#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll MAXN=2e3+5,INF=1e18;
int n,Q,k;
ll g[MAXN][MAXN],w[MAXN];

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++)
		scanf("%lld",&w[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			g[i][j]=INF;
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		g[u][v]=w[v],g[v][u]=w[u];
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
	for(int i=1;i<=Q;i++){
		int s,t;
		scanf("%d%d",&s,&t);
		printf("%lld\n",g[s][t]+w[s]);
	}
	return 0;
}
