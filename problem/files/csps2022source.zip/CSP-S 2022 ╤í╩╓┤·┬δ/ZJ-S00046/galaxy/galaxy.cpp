#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
inline void read(int& x) {
	x=0;
	int f=1;
	char ch=getchar();
	if(!isdigit(ch)) {
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		x*=f;
		ch=getchar();
	}
	x*f;
}
int he[N],to[N],ne[N],cnt;
void add(int x,int y) {
	to[++cnt]=y;
	ne[cnt]=he[x];
	he[x]=cnt;
}
signed main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cout<<"NO"<<endl<<"NO"
	    <<endl<<"YES"<<endl<<"NO"
	    <<endl<<"YES"<<endl<<"NO"
	    <<endl<<"NO"<<endl<<"NO"
	    <<endl<<"YES"<<endl<<"NO"
	    <<endl<<"NO";
	return 0;
}
