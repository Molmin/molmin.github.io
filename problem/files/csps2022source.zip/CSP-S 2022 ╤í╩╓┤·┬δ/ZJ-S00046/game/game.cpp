#include<bits/stdc++.h>
//define int long long
#define inf 0x3f3f3f3f
using namespace std;
const int N=1e5+10;
inline void read(int& x) {
	x=0;
	int f=1;
	char ch=getchar();
	if(!isdigit(ch)) {
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		x*=f;
		ch=getchar();
	}
	x*f;
}
struct node {
	int l,r;
	int maxx,minn;
	int leanl,leanr;
} t_1[N<<2],t_2[N<<2];
int n,m,q;
int a[N],b[N];
void build(int x,int l,int r,node *t,int *k) {
	t[x].l=l;
	t[x].r=r;
	if(l==r) {
		t[x].maxx=t[x].minn=k[l];
		if(k[l]>=0) {
			t[x].leanl=k[l];
			t[x].leanr=-inf;
		} else {
			t[x].leanl=inf;
			t[x].leanr=k[l];
		}

	} else {
		int mid=(l+r)>>1;
		build(x<<1,l,mid,t,k);
		build(x<<1|1,mid+1,r,t,k);
		t[x].maxx=max(t[x<<1].maxx,t[x<<1|1].maxx);
		t[x].minn=min(t[x<<1].minn,t[x<<1|1].minn);
		t[x].leanl=min(t[x<<1].leanl,t[x<<1|1].leanl);
		t[x].leanr=max(t[x<<1].leanr,t[x<<1|1].leanr);
	}
}

int ask_max(int x,int l,int r,node *t) {
	if(l<=t[x].l&&t[x].r<=r)
		return t[x].maxx;
	int mid=(t[x].l+t[x].r)>>1;
	if(mid>=r)
		return ask_max(x<<1,l,mid,t);
	else if(mid<l)
		return ask_max(x<<1|1,mid+1,r,t);
	else
		return max(ask_max(x<<1,l,mid,t),ask_max(x<<1|1,mid+1,r,t));

}
int ask_min(int x,int l,int r,node *t) {
	if(l<=t[x].l&&t[x].r<=r)
		return t[x].minn;
	int mid=(t[x].l+t[x].r)>>1;
	if(mid>=r)
		return ask_min(x<<1,l,mid,t);
	else if(mid<l)
		return ask_min(x<<1|1,mid+1,r,t);
	else
		return min(ask_min(x<<1,l,mid,t),ask_min(x<<1|1,mid+1,r,t));

}
int ask_leanl(int x,int l,int r,node *t) {
	if(l<=t[x].l&&t[x].r<=r)
		return t[x].leanl;
	int mid=(t[x].l+t[x].r)>>1;
	if(mid>=r)
		return ask_leanl(x<<1,l,mid,t);
	else if(mid<l)
		return ask_leanl(x<<1|1,mid+1,r,t);
	else
		return min(ask_leanl(x<<1,l,mid,t),ask_leanl(x<<1|1,mid+1,r,t));
}
int ask_leanr(int x,int l,int r,node *t) {
	if(l<=t[x].l&&t[x].r<=r)
		return t[x].leanr;
	int mid=(t[x].l+t[x].r)>>1;
	if(mid>=r)
		return ask_leanr(x<<1,l,mid,t);
	else if(mid<l)
		return ask_leanr(x<<1|1,mid+1,r,t);
	else
		return max(ask_leanr(x<<1,l,mid,t),ask_leanr(x<<1|1,mid+1,r,t));
}
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1; i<=n; i++)
		read(a[i]);
	for(int i=1; i<=m; i++)
		read(b[i]);
	build(1,1,n,t_1,a);
	build(1,1,m,t_2,b);
	int l_1,l_2,r_1,r_2;
	while(q--) {
		read(l_1),read(r_1);
		read(l_2),read(r_2);
		if(ask_min(1,l_2,r_2,t_2)>=0)
			printf("%d\n",ask_max(1,l_1,r_1,t_1)*ask_min(1,l_2,r_2,t_2));
		else if(ask_min(1,l_1,r_1,t_1)>=0)
			printf("%d\n",ask_min(1,l_1,r_1,t_1)*ask_min(1,l_2,r_2,t_2));
		else {
			if(ask_leanl(1,l_1,r_1,t_1)!=inf&&ask_leanr(1,l_1,r_1,t_1)!=-inf) {
				int ans_1=ask_leanl(1,l_1,r_1,t_1)*ask_min(1,l_2,r_2,t_2);
				int ans_2=ask_leanr(1,l_1,r_1,t_1)*ask_max(1,l_2,r_2,t_2);
				printf("%d\n",max(ans_1,ans_2));
			} else
				printf("%d\n",ask_max(1,l_1,r_1,t_1)*ask_min(1,l_2,r_2,t_2));

		}
	}
	return 0;
}
