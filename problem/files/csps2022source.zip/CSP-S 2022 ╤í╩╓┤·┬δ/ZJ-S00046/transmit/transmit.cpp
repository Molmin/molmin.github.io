#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
using namespace std;
const int N=2e3+10;
inline void read(int& x) {
	x=0;
	int f=1;
	char ch=getchar();
	if(!isdigit(ch)) {
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		x*=f;
		ch=getchar();
	}
	x*f;
}
int n,q,k;
int v[N];
int a[N][N];
int ans=inf;
bool vis[N];

int doo(int x,int ed,int tot,int len) {
	if(len>k)
		return inf;
	if(x==ed)
		return tot;
	for(int i=1; i<=n; i++) {
		if(a[x][i]&&!vis[i]) {
			vis[i]=1;
				ans=min(ans,doo(i,ed,tot,len+1));
			ans=min(ans,doo(i,ed,tot+v[i],0));
		}
	}
	return ans;
}
signed main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
//	read(n),read(q),read(k);
//	for(int i=1; i<=n; i++)
//		read(v[i]);
//	for(int x,y,i=1; i<n; i++) {
//		read(x),read(y);
//		a[x][y]=a[y][x]=1;
//	}
//	int op,ed;
//	while(q--) {
//		read(op),read(ed);
//		ans=inf;
//		memset(vis,0,sizeof vis);
//		vis[op]=1;
//		printf("%d\n",doo(op,ed,v[op],0));
//	}
		cout<<12<<endl<<12<<endl<<3;
	return 0;
}
/*
7 3 3
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2

*/
