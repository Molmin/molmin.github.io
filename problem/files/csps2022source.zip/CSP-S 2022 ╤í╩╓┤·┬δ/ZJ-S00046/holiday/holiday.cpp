#include<bits/stdc++.h>
#define int long long
//#define inf 0x3f3f3f3f
using namespace std;
const int N=2e4+10;
inline void read(int& x) {
	x=0;
	int f=1;
	char ch=getchar();
	if(!isdigit(ch)) {
		if(ch=='-')
			f=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<1)+(x<<3)+(ch^48);
		x*=f;
		ch=getchar();
	}
	x*f;
}
int n,m,k;
int p[N];
bool vis[N];
int ans=-1;
int he[N],to[N],ne[N],cnt;
void add(int x,int y) {
	to[++cnt]=y;
	ne[cnt]=he[x];
	he[x]=cnt;
}
int doo(int x,int point,int num,int go) {
	// ����λ��    ����  ������   ת��
	if(go>k||num>4)
		return -1;
	if(num==4&&x==1) 
		return point;
	for(int i=he[x]; i; i=ne[i]) {
		int y=to[i];
		if(num==4&&y==1)
			return point;
		if(!vis[y]&&y!=1) {
			vis[y]=1;
			ans=max(ans,doo(y,point+p[y],num+1,0));
			vis[y]=0;
		}
		ans=max(ans,doo(y,point,num,go+1));
	}
	return ans;
}
signed main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for(int i=2; i<=n; i++)
		read(p[i]);
	for(int x,y,i=1; i<=m; i++) {
		read(x),read(y);
		add(x,y);
		add(y,x);
	}
	printf("%lld\n",doo(1,0,0,0));
	return 0;
}

