#include <bits/stdc++.h>
using namespace std;

long long n,m,k;
long long a[2505]={0};
long long b[2505][2505]={0};
long long c[2505]={0};
bool is[2505]={0};
long long ans=0;
void dfs(long long d,long long t,long long s)
{
	if(t==5)
	{
		if(d==1)
		{
			ans=max(ans,s);
		}
		return;
	}
	for(int i=1;i<=c[d];i++)
	{
		long long to=b[d][i];
		if(to==1||is[to]==0)
		{
			is[to]=1; 
			dfs(to,t+1,s+a[d]);
			is[to]=0;
		}
	}
	return;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		long long u,v;
		scanf("%lld %lld",&u,&v);
		b[u][++c[u]]=v;
		b[v][++c[v]]=u;
	}
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}
