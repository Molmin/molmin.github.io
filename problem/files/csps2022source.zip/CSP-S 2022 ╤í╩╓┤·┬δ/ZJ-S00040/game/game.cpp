#include <bits/stdc++.h>
using namespace std;

long long n,m,q;
long long l1,r1,l2,r2;
long long a[100005]={0};
long long b[100005]={0};
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
	}
	while(q--)
	{
		scanf("%lld %lld %lld %lld",&l1,&r1,&l2,&r2);
		if(n<=200&&m<=200)
		{
			long long a1=-1e18,a2=1e18;
			for(int i=l1;i<=r1;i++)
			{
				a2=1e18;
				for(int j=l2;j<=r2;j++)
				{
					a2=min(a2,a[i]*b[j]);
				}
				a1=max(a1,a2);
			}
			printf("%lld\n",a1);
		}
		else if(l1==r1)
		{
			long long ans=1e18;
			for(int i=l2;i<=r2;i++)
			{
				ans=min(ans,b[i]);
			}
			printf("%lld\n",a[l1]*ans);
		}
		else if(l2==r2)
		{
			long long ans=-1e18;
			for(int i=l1;i<=r1;i++)
			{
				ans=max(ans,a[i]);
			}
			printf("%lld\n",b[l2]*ans);
		}
	}
	return 0;
}
