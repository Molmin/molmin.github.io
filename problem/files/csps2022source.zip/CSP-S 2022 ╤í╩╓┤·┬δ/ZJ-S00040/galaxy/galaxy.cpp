#include <bits/stdc++.h>
using namespace std;

long long n,m,q;
long long t,u,v;
bool a[1005][1005]={0};
bool b[1005][1005]={0};
long long fr[1005]={0};
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%lld %lld",&u,&v);
		a[u][v]=1;
		b[u][v]=1;
		fr[u]++;
	}
	scanf("%lld",&q);
	while(q--)
	{
		scanf("%lld",&t);
		if(t==1)
		{
			scanf("%lld %lld",&u,&v);
			b[u][v]=0;
			fr[u]--;
		}
		else if(t==2)
		{
			scanf("%lld",&u);
			for(int i=1;i<=n;i++)
			{
				if(a[i][u]==1&&b[i][u]==1)
				{
					b[i][u]=0;
					fr[i]--;
				}
			}
		}
		else if(t==3)
		{
			scanf("%lld %lld",&u,&v);
			b[u][v]=1;
			fr[u]++;
		}
		else if(t==4)
		{
			scanf("%lld",&u);
			for(int i=1;i<=n;i++)
			{
				if(a[i][u]==1&&b[i][u]==0)
				{
					b[i][u]=1;
					fr[i]++;
				}
			}
		}
		bool qwq=1;
		for(int i=1;i<=n;i++)
		{
			if(fr[i]!=1)
			{
				qwq=0;
			}
		}
		if(qwq==1)
		{
			printf("YES\n");
		}
		else
		{
			printf("NO\n");
		}
	}
	return 0;
}
