#include <bits/stdc++.h>
using namespace std;

long long n,q,k;
long long a,b;
long long s,t;
long long v[200005]={0};
long long zx[200005]={0};
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld %lld %lld",&n,&q,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&v[i]);
	}
	for(int i=1;i<=n-1;i++)
	{
		scanf("%lld",&a,&b);
		zx[b]=a;
	}
	while(q--)
	{
		scanf("%lld",&s,&t);
		printf("%lld\n",v[s]+v[t]);
	}
	return 0;
}
