#include <bits/stdc++.h>
using namespace std;
const int maxn = 100005;
long long a[maxn],b[maxn];
int n,m,q,l1,l2,r1,r2;
bool f;
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	long long maxa = -1e18;
	long long minb = 1e18;
	for (int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]);
		if (a[i] <= 0) f = false;
		maxa = max(maxa, a[i]);
	}
	for (int i = 1; i <= m; i++) {
		scanf("%lld", &b[i]);
		if (b[i] <= 0) f = false;
		minb = min(minb, b[i]);
	}
/*	if(f) {
		while(q--) {
			scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
			
		}
	}*/
	while(q--) {
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		long long zmin = 1e18,fmax = -1e18,z = -1e18,f = 1e18;
		long long zmin2 = 1e18,fmax2 = -1e18,z2 = -1e18,f2 = 1e18;
		for (int i = l1; i <= r1; i++) {
			z = max(z, a[i]);
			if(a[i] >= 0) zmin = min(a[i], zmin);
			if(a[i] <= 0) fmax = max(a[i], fmax);
			f = min(a[i], f);
		} 
		for (int i = l2; i <= r2; i++) {
			z2 = max(z2, b[i]);
			if(b[i] >= 0) zmin2 = min(b[i], zmin2);
			if(b[i] <= 0) fmax2 = max(b[i], fmax2);
			f2 = min(b[i], f2);
		} 
		if (z2 < 0) {
			printf("%lld\n", f * fmax2);
			continue;
		} else if (z2 >= 0 && f2 <= 0) {
			if (z < 0) {
				printf("%lld\n", z2 * fmax);
			} else if (z >= 0 && f <= 0) {
				printf("%lld\n", max(fmax * z2, zmin * f2));
			} else if(f > 0) {
				printf("%lld\n", zmin * f2);
			}
		} else {
			printf("%lld\n", zmin2 * z);
		} 
	}
	return 0;
}

