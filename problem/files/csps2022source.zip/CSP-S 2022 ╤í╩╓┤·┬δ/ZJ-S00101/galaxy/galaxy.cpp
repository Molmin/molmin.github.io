#include <bits/stdc++.h>
using namespace std;
int n,m,q,t,x,y;
const int maxn = 500005;
int to[maxn],pre[maxn],cnt1[maxn],cnt2[maxn],u,v;
int a[maxn];
int main() {	
	freopen("T2.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		scanf("%d%d", &i, &v);
		to[u]++;
		pre[i]++;
	}
	for (int i = 1; i <= maxn; i++) {
		cnt1[i] = to[i];
		cnt2[i] = pre[i];
	}
	scanf("%d", &q);
	while(q--) {
		bool f = true;
		scanf("%d", &t);
		if(t == 1) {
			scanf("%d%d", &x, &y);
			pre[y]--;
			to[x]--;
			for (int i = 1; i <= n; i++) {
				if(to[i] != 1) {
					f = false;
					cout << "NO" << endl;
					break;
				}
			}
			if(f) {
				cout << "YES" << endl;
			}
		} else if (t == 2){ 
			scanf("%d", &x);
			pre[x] = 0;
			for (int i = 1; i <= n; i++) {
				if(to[i] == x) to[i]--;
			}
			for (int i = 1; i <= n; i++) {
				if(to[i] != 1) {
					f = false;
					cout << "NO" << endl;
					break;
				}
			}
			if(f) {
				cout << "YES" << endl;
			}
		} else if (t == 3) {
			scanf("%d%d", &x, &y);
			to[x]++;
			pre[y]++;
			for (int i = 1; i <= n; i++) {
				if(to[i] != 1) {
					f = false;
					cout << "NO" << endl;
					break;
				}
			}
			if(f) {
				cout << "YES" << endl;
			}
		} else {
			scanf("%d", &x);
			pre[x] = cnt2[x];
			for (int i = 1; i <= n; i++) {
				if(to[i] == x) to[i]++;
			}
			for (int i = 1; i <= n; i++) {
				if(to[i] != 1) {
					f = false;
					cout << "NO" << endl;
					break;
				}
			}
			if(f) {
				cout << "YES" << endl;
			}
		}
	}
	return 0; 
}
