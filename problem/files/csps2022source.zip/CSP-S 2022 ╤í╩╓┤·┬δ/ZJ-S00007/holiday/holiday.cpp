#include<bits/stdc++.h>
using namespace std;
struct A{
	int z,d;
}p[2505];
int n,m,k,f[2505],a[2505][2505],c[3005],b[2505][2505],d[2505],s;
vector<int>q[3005],q1[3005];
void bfs(int x){
	int l=1,r=1;
	p[l].z=-1;p[l].d=x;
	while(l<=r){
		int u=p[l].d,v=p[l].z+1;
		for (int i=0;i<c[u];i++)
			if(q[u][i]!=x&&a[x][q[u][i]]==-1){
				p[++r].z=a[x][q[u][i]]=v;
				p[r].d=q[u][i];
			}
		l++;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=2;i<=n;i++)scanf("%d",&f[i]);
	int x,y;
	for (int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		c[x]++,c[y]++;
		q[y].push_back(x);
		q[x].push_back(y);
	}
	memset(a,-1,sizeof(a));
	for (int i=1;i<=n;i++)bfs(i);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			if(a[i][j]<=k&&a[i][j]>=0)b[i][j]=1,q1[i].push_back(j),d[i]++;
	for (int i=0;i<d[1];i++)
		for (int j=i+1;j<d[1];j++){
			int u=q1[1][i],v=q1[1][j];
			for (int l=0;l<d[u];l++)
				for (int r=0;r<d[v];r++){
					x=q1[u][l],y=q1[v][r];
					if(x!=y&&b[x][y]&&u!=x&&u!=y&&v!=x&&v!=y)s=max(s,f[u]+f[v]+f[x]+f[y]);
				}
		}
	printf("%d",s);
}
