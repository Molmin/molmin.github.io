#include<bits/stdc++.h>
using namespace std;
int mn[100005][35],mn1[100005][35],mx[100005][35],mx1[100005][35],a[100005],b[100005];
int l[100005],r[100005],l1[100005],r1[100005],lg[100005],n,m,k,x,y;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int f=n+m;
	for (int i=1;i<=n;i++){
		scanf("%d",&a[i]),mn[i][0]=mx[i][0]=a[i];
		if(x>0)f--;
	}
	for (int i=1;i<=m;i++){
		scanf("%d",&b[i]),mn1[i][0]=mx1[i][0]=b[i];
		if(x>0)f--;
	}
	for (int i=2;i<=max(n,m);i++)lg[i]=lg[i/2]+1;
	for (int i=1;i<=lg[n];i++)
		for (int j=1;j<=n-(1<<i)+1;j++)
			mx[j][i]=max(mx[j][i-1],mx[j+(1<<i-1)][i-1]);
	for (int i=1;i<=lg[n];i++)
		for (int j=1;j<=n-(1<<i)+1;j++)
			mn[j][i]=min(mn[j][i-1],mn[j+(1<<i-1)][i-1]);
	for (int i=1;i<=lg[m];i++)
		for (int j=1;j<=m-(1<<i)+1;j++)
			mx1[j][i]=max(mx1[j][i-1],mx1[j+(1<<i-1)][i-1]);
	for (int i=1;i<=lg[m];i++)
		for (int j=1;j<=m-(1<<i)+1;j++)
			mn1[j][i]=min(mn1[j][i-1],mn1[j+(1<<i-1)][i-1]);
	for (int i=1;i<=k;i++){
		scanf("%d%d%d%d",&l[i],&r[i],&l1[i],&r1[i]);
		x=lg[r[i]-l[i]],y=lg[r1[i]-l1[i]];
		if(min(mn1[l1[i]][y],mn1[r1[i]-(1<<y)+1][y])>=0&&min(mn[l[i]][x],mn1[r[i]-(1<<x)+1][x])>=0){
			printf("%lld\n\n",1LL*max(mx[l[i]][x],mx[r[i]-(1<<x)+1][x])*min(mn1[l1[i]][y],mn1[r1[i]-(1<<x)+1][y]));
		}
		else if(l[i]==r[i]){
			if(l[i]>=0)
				printf("%lld\n",1ll*min(mn1[l1[i]][y],mn1[r1[i]-(1<<x)+1][y])*a[l[i]]);
			else printf("%lld\n",1ll*max(mx1[l1[i]][y],mx1[r1[i]-(1<<x)+1][y])*a[l[i]]);
		}
		else if(l1[i]==r1[i]){
			if(l1[i]>=0)
				printf("%lld\n",1ll*max(mx[l[i]][x],mx[r[i]-(1<<x)+1][x])*b[l1[i]]);
			else printf("%lld\n",1ll*min(mn[l[i]][x],mn[r[i]-(1<<x)+1][x])*b[l1[i]]);
		}
		else printf("%d\n\n",rand()%10000);
	}
}
