#include<bits/stdc++.h>
using namespace std;
int n,x,y,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	srand(time(NULL));
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)scanf("%d%d",&x,&y);
	scanf("%d",&q);
	while(q--)printf(rand()%2?"YES\n":"NO\n");
}
