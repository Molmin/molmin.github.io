#include<bits/stdc++.h>
using namespace std;
const int sb=2e5+5;
struct A{
	int d;
	long long z;
}p[sb];
int n,m,k,b[sb],c[sb],c1[sb],a[sb];
long long f[sb];
vector<int>q[sb],q1[sb];
void bfs(int x){
	int l=1,r=1;
	p[l].d=x;
	while(l<=r){
		if(p[l].z==k)break;
		int u=p[l].d,v=p[l].z+1;
		for (int i=0;i<c[u];i++)
			if(q[u][i]!=x&&a[q[u][i]]==0){
				p[++r].z=a[q[u][i]]=v;
				p[r].d=q[u][i];
			}
		l++;
	}
}
void bfs1(int x){
	int l=1,r=1;
	p[l].d=x;p[l].z=b[x];f[x]=0;
	while(l<=r){
		int u=p[l].d;
		for (int i=0;i<c1[u];i++){
			int v=q1[u][i];
			long long w=p[l].z+b[v];
			if(w<f[v])p[++r].z=f[v]=w,p[r].d=v;
		}
		l++;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for (int i=1;i<=n;i++)scanf("%d",&b[i]);
	int x,y;
	for (int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		c[x]++,c[y]++;
		q[y].push_back(x);
		q[x].push_back(y);
	}
	for (int i=1;i<=n;i++){
		memset(a,0,sizeof(a));
		bfs(i);
		for (int j=1;j<=n;j++)
			if(a[j])q1[i].push_back(j),c1[i]++;
	}
	for (int i=1;i<=m;i++){
		for (int j=1;j<=n;j++)f[j]=1e18;
		scanf("%d%d",&x,&y);
		bfs1(x);
		printf("%lld\n",f[y]);
	}
}
