#include<iostream>
#include<algorithm>
using namespace std;
int read(){
	char c=getchar();
	int x=0,f=1;
	if(c=='-'){
		f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
}
void write(int x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+'0');
}
bool cmd(int x,int y){
	return x>y;
}
const int N=2*1e3+505,inf=0x3f3f3f3f;
int n,m,k,num;
long long ans,maxn=-inf;
int w[N],w1[N],q[N];
bool vis[N],g[N];
int e[N][N];
void ford(){
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int p=1;p<=n;p++){
				if(e[i][j]+e[j][p]>=k){
					continue;
				}
				if(e[i][j]!=inf&&e[j][p]!=inf){
					//cout<<i<<" "<<j<<" "<<p<<endl;
					e[i][p]=min(e[i][j]+e[j][p]+1,e[i][p]);
				}
			}
		}
	}
}
void f(int x){
	if(num==3&&ans+w1[2]<maxn){
		return ;
	}
	if(num==2&&ans+w1[2]+w1[3]<maxn){
		return ;
	}
	if(num==1&&ans+w1[2]+w1[3]+w1[4]<maxn){
		return ;
	}
	if(num==4){
		if(e[q[x]][1]!=inf){
		    maxn=max(maxn,ans);
		}
		return ;
	}
	for(int i=2;i<=n;i++){
		if(g[i]){
			continue;
		}
		if(e[q[x]][q[i]]!=inf){
			ans+=w1[i];
			g[i]=true;
			num++;
			//cout<<num<<" "<<w1[i]<<endl;
			f(i);
			ans-=w1[i];
			g[i]=false;
			num--;
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			e[i][j]=inf;
		}
	}
	for(int i=2;i<=n;i++){
		w1[i]=w[i]=read();
	}
	sort(w1+2,w1+n+1,cmd);
	for(int i=2;i<=n;i++){
		for(int j=2;j<=n;j++){
			if(w1[i]==w[j]&&vis[j]==false){
				vis[j]=true;
				q[i]=j;
				break;
			}
		}
	}
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		e[x][y]=0;
		e[y][x]=0;
	}
	ford();
	ford();
	q[1]=1;
	f(1);
	write(maxn);
	return 0;
}
