#include<iostream>
using namespace std;
int read(){
	char c=getchar();
	int x=0,f=1;
	if(c=='-'){
		f=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x*f;
}
void write(int x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		write(x/10);
	}
	putchar(x%10+'0');
}
const int N=1e4+5,inf=0x3f3f3f3f;
bool vis1[N],vis2[N];
int n,m,q;
int a[N],b[N],p[N][N];
int check1(int x,int y,int x1,int y1){
	int ans=-inf;
	int l1,r1;
	int p1;
	for(int i=x;i<=y;i++){
		int k=inf;
		for(int j=x1;j<=y1;j++){
			if(k>p[i][j]){
				l1=i,r1=j;
				k=p[i][j];
			}
		}
		if(ans<k){
			//cout<<ans<<endl;
			p1=l1;
			ans=k;
		}
	}
	return p1;
}
int check2(int x,int y,int x1,int y1){
	int ans=inf;
	int l1,r1;
	int q1;
	for(int i=x1;i<=y1;i++){
		int k=-inf;
		for(int j=x;j<=y;j++){
			if(k<p[j][i]){
				l1=i,r1=j;
				k=p[i][j];
			}
		}
		if(ans>k){
			q1=r1;
			ans=k;
		}
	}
	return q1;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=m;i++){
		b[i]=read();
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			p[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;i++){
		int l1=read(),r1=read(),l2=read(),r2=read();
		int x=check1(l1,r1,l2,r2);
		//cout<<endl;
		int y=check2(l1,r1,l2,r2);
		//cout<<x<<" "<<y<<endl;
		//cout<<endl;
		cout<<p[x][y]<<endl;
	}
	return 0;
}
