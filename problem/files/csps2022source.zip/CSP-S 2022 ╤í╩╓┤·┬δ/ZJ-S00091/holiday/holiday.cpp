#include<bits/stdc++.h>
#include<ext/pb_ds/assoc_container.hpp>
#include<ext/pb_ds/tree_policy.hpp>
#define endl '\n'
#define QAQ(n, m) for (ll i = n; i <= m; ++i)
#define QWQ(n, m) for (ll j = n; j <= m; ++j)
#define For(i, n, m) for (ll i = n; i <= m; ++i)
#define uQAQ(n, m) for (ll i = n; i >= m; --i)
#define uQWQ(n, m) for (ll j = n; j >= m; --j)
#define uFor(i, n, m) for (ll i = n; i >= m; --i)
#define mkp make_pair
#define pb push_back
#define Open(x) freopen (#x".in", "r", stdin), freopen (#x".out", "w", stdout)
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
struct Node
{
	ll Val, A, B;
	inline bool operator< (const Node& B)const { return Val > B.Val; }
};
struct Edge { ll v, Nxt; }ed[7000010];
ll Head[3010], Ecnt;
ll n, m, x, y, k, a[3010], vis[2501], Ans;
bool G[2501][2501];
vector<ll> E[2501];
__gnu_pbds::tree<Node, __gnu_pbds::null_type>S;

inline void AddE (ll u, ll v) { ed[++Ecnt] = { v, Head[u] }, Head[u] = Ecnt; }

int main ()
{
	Open (holiday), cin.tie (nullptr), ios::sync_with_stdio (false);
	cin >> n >> m >> k; QAQ (2, n) cin >> a[i];
    QAQ (1, m) cin >> x >> y, E[x].pb (y), E[y].pb (x);
    QAQ (1, n)
    {
        static queue<pair<ll, ll>> Q;
        vis[i] = i; Q.push (mkp (-1, i));
        while (!Q.empty ())
        {
            static ll Dis, Now; tie (Dis, Now) = Q.front (), Q.pop ();
            for (ll v : E[Now]) if (vis[v] != i && Dis + 1 <= k)
                vis[v] = i, Q.push (mkp (Dis + 1, v)), AddE (i, v), G[i][v] = true;
        }
    }
    // QAQ (1, n) QWQ (1, n) cerr << G[i][j] << " \n"[j == n];
	for (ll i = Head[1]; i; i = ed[i].Nxt)
	{
		ll A = ed[i].v;
		for (ll j = Head[A]; j; j = ed[j].Nxt)
		{
			ll B = ed[j].v;
			for (Node Oppo : S)
			{
				if (Oppo.A != A && Oppo.A != B && Oppo.B != A && Oppo.B != B && G[B][Oppo.B])
				{
					Ans = max (Ans, a[A] + a[B] + Oppo.Val);
					break;
				}
				if (Oppo.Val + a[A] + a[B] <= Ans) break;
			}
			S.insert ({ a[A] + a[B], A, B });
		}
	}
	cout << Ans << endl;
	// cerr << clock () << endl;
}