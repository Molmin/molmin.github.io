#include<bits/stdc++.h>
#define endl '\n'
#define QAQ(n, m) for (ll i = n; i <= m; ++i)
#define QWQ(n, m) for (ll j = n; j <= m; ++j)
#define For(i, n, m) for (ll i = n; i <= m; ++i)
#define uQAQ(n, m) for (ll i = n; i >= m; --i)
#define uQWQ(n, m) for (ll j = n; j >= m; --j)
#define uFor(i, n, m) for (ll i = n; i >= m; --i)
#define Open(x) freopen (#x".in", "r", stdin), freopen (#x".out", "w", stdout)
#define mkp make_pair
#define pb push_back
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
ll n, Q, k, a[200010], Dep[200010];
vector<ll> E[200010];
namespace Task1
{
	ll ST[200010][20], ST1[200010][20];
	inline void DFS (ll Now = 1, ll fa = 0)
	{
		ST[Now][0] = fa, ST1[Now][0] = a[Now];
		QAQ (1, 19) 
			ST[Now][i] = ST[ST[Now][i - 1]][i - 1],
			ST1[Now][i] = ST1[Now][i - 1] + ST1[ST[Now][i - 1]][i - 1];
		for (ll v : E[Now]) if (v != fa) Dep[v] = Dep[Now] + 1, DFS (v, Now);
	}
	inline void Solve ()
	{
		Dep[1] = 1, DFS ();
		while (Q--)
		{
			static ll x, y; cin >> x >> y;
			if (Dep[x] < Dep[y]) swap (x, y);
			ll Ans = 0;
			uQAQ (19, 0) if (Dep[ST[x][i]] >= Dep[y])
				Ans += ST1[x][i], x = ST[x][i];
			if (x == y) Ans += a[y];
			else
			{
				uQAQ (19, 0) if (x != y && ST[x][i] != ST[y][i])
					Ans += ST1[x][i] + ST1[y][i], x = ST[x][i], y = ST[y][i];
				if (x == y) Ans += a[y];
				else Ans += a[x] + a[y] + a[ST[x][0]];
			}
			cout << Ans << endl;
		}
	}	
};
ll f[200010], Fa[200010];
ll Pre[200010], Suf[200010];

inline void DFS (ll Now = 1, ll fa = 0)
{
	Fa[Now] = fa, Dep[Now] = Dep[fa] + 1;
	for (ll v : E[Now]) if (v != fa) DFS (v, Now);
}

int main ()
{
	Open (transmit), cin.tie (nullptr), ios::sync_with_stdio (false);
	cin >> n >> Q >> k; QAQ (1, n) cin >> a[i];
	QAQ (2, n)
	{
		static ll x, y; cin >> x >> y;
		E[x].pb (y), E[y].pb (x);
	}
	if (k == 1) Task1::Solve (), exit (0);
	DFS ();
	while (Q--)
	{
		static ll x, y; cin >> x >> y;
		if (Dep[x] < Dep[y]) swap (x, y);
		Pre[0] = 0, Suf[0] = 0;
		while (Dep[x] > Dep[y]) Pre[++Pre[0]] = x, x = Fa[x];
		while (x != y) Pre[++Pre[0]] = x, Suf[++Suf[0]] = y, x = Fa[x], y = Fa[y];
		Pre[++Pre[0]] = x;
		while (Suf[0]) Pre[++Pre[0]] = Suf[Suf[0]], --Suf[0];
		f[Pre[1]] = a[Pre[1]];
// 251245604 368308854 912572995  835701672  51944511  479806606
// 251245604 619554458 1163818599 1086947276 671498969 1151305575
		if (k == 2)
		{
			if (Pre[0] >= 2)
			{
				f[Pre[2]] = a[Pre[2]] + f[Pre[1]];
				QAQ (3, Pre[0]) f[Pre[i]] = a[Pre[i]] + min (f[Pre[i - 1]], f[Pre[i - 2]]);
			}
		}
		if (k >= 3) 
		{
			if (Pre[0] >= 2) f[Pre[2]] = a[Pre[2]] + f[Pre[1]];
			if (Pre[0] >= 3)
			{
				f[Pre[3]] = a[Pre[3]] + min (f[Pre[1]], f[Pre[2]]);
				QAQ (4, Pre[0])
					f[Pre[i]] = a[Pre[i]] + min ( f[Pre[i - 1]] , min ( f[Pre[i - 2]], f[Pre[i - 3]] ));
			}
		}
		cout << f[Pre[Pre[0]]] << endl;
	}
}