#include<bits/stdc++.h>
#define endl '\n'
#define QAQ(n, m) for (ll i = n; i <= m; ++i)
#define QWQ(n, m) for (ll j = n; j <= m; ++j)
#define For(i, n, m) for (ll i = n; i <= m; ++i)
#define uQAQ(n, m) for (ll i = n; i >= m; --i)
#define uQWQ(n, m) for (ll j = n; j >= m; --j)
#define uFor(i, n, m) for (ll i = n; i >= m; --i)
using namespace std;
typedef long long ll;
typedef long double ld;
typedef unsigned long long ull;
const ll Maximum = 1e18 + 1;
struct Node 
{
	ll PosMax, PosMin, NegMax, NegMin; bool Zero;
	inline Node operator + (Node B) 
	{
		Node Res;
		Res.PosMax = max (PosMax, B.PosMax);
		Res.PosMin = min (PosMin, B.PosMin);
		Res.NegMax = max (NegMax, B.NegMax);
		Res.NegMin = min (NegMin, B.NegMin);
		Res.Zero = Zero | B.Zero;
		return Res;
	}
} TrA[400010], TrB[400010];
ll n, m, Q, Qx, Qy, a[100010], b[100010];
#define ls (Pos << 1)
#define rs (Pos << 1 | 1)
inline void BuildA (ll l = 1, ll r = n, ll Pos = 1)
{
	if (l == r)
	{
		TrA[Pos] = { 0, Maximum, -Maximum, 0, false };
		if (a[l] == 0) TrA[Pos].Zero = true;
		else if (a[l] > 0) TrA[Pos].PosMax = TrA[Pos].PosMin = a[l];
		else TrA[Pos].NegMax = TrA[Pos].NegMin = a[l];
		return;
	}
	ll mid = (l + r) >> 1;
	BuildA (l, mid, ls), BuildA (mid + 1, r, rs);
	TrA[Pos] = TrA[ls] + TrA[rs];
}
inline void BuildB (ll l = 1, ll r = n, ll Pos = 1)
{
	if (l == r)
	{
		TrB[Pos] = { 0, Maximum, -Maximum, 0, false };
		if (b[l] == 0) TrB[Pos].Zero = true;
		else if (b[l] > 0) TrB[Pos].PosMax = TrB[Pos].PosMin = b[l];
		else TrB[Pos].NegMax = TrB[Pos].NegMin = b[l];
		return;
	}
	ll mid = (l + r) >> 1;
	BuildB (l, mid, ls), BuildB (mid + 1, r, rs);
	TrB[Pos] = TrB[ls] + TrB[rs];
}
inline Node QueryA (ll l = 1, ll r = n, ll Pos = 1)
{
	if (Qy < l || r < Qx) return (Node){ 0, Maximum, -Maximum, 0, false };
	if (Qx <= l && r <= Qy) return TrA[Pos];
	ll mid = (l + r) >> 1;
	return QueryA (l, mid, ls) + QueryA (mid + 1, r, rs);
}
inline Node QueryB (ll l = 1, ll r = n, ll Pos = 1)
{
	if (Qy < l || r < Qx) return (Node){ 0, Maximum, -Maximum, 0, false };
	if (Qx <= l && r <= Qy) return TrB[Pos];
	ll mid = (l + r) >> 1;
	return QueryB (l, mid, ls) + QueryB (mid + 1, r, rs);
}

int main ()
{
	freopen ("game.in", "r", stdin), freopen ("game.out", "w", stdout);
	cin.tie (nullptr), ios::sync_with_stdio (false);
	cin >> n >> m >> Q; QAQ (1, n) cin >> a[i]; QAQ (1, m) cin >> b[i];
	BuildA (), BuildB ();
	// bool Tmp = false;
	while (Q--)
	{
		// ll PosMax, PosMin, NegMax, NegMin; bool Zero;
		// Tmp = true;
		static Node A, B; 
		cin >> Qx >> Qy; A = QueryA ();
		// Tmp = Tmp && Qx == 133 && Qy == 189;
		cin >> Qx >> Qy; B = QueryB ();
		// Tmp = Tmp && Qx == 154 && Qy == 407;
		// B 有正 & 有负
		if (B.PosMax && B.NegMin)
		{
			// A 有 0 （此时 B 会反选 A，因此最大值为 0）
			if (A.Zero) cout << "0\n";
			else
			{
				// if (Tmp) cerr << "Correct Place 1!\n";
				// A 无 0
				if (A.PosMax && A.NegMin)
					cout << max (A.PosMin * B.NegMin, A.NegMax * B.PosMax) << endl;
				else if (A.PosMax)
					cout << A.PosMin * B.NegMin << endl;
				else
					cout << A.NegMax * B.PosMax << endl;
			}
		}
		// B 有正, 无负
		else if (B.PosMax)
		{
			// 此时 A 要获得最大值
			// 若 A 选择的数 > 0，B 没有负数，结果 >= 0
			// B 优先选 0。没 0 就选最小值
			// 这样 A 只要选最大值就好
			// 若 A 选择的数 = 0，结果 = 0
			// 若 A 选择的数 < 0，结果 < 0，那么 B 会选最大值
			// A 选负数中的最大值
			if (A.PosMax)
				cout << (B.Zero ? 0 : B.PosMin * A.PosMax) << endl;
			else if (A.Zero)
				cout << "0\n";
			else 
				cout << A.NegMax * B.PosMax << endl;
		}
		else if (B.NegMin)
		{
			if (A.NegMin)
				cout << (B.Zero ? 0 : B.NegMax * A.NegMin) << endl;
			else if (A.Zero)
				cout << "0\n";
			else 
				cout << A.PosMin * B.NegMin << endl;
		}
		else cout << "0\n";
		// if (Tmp)
		// {
		// 	cerr << "A: { " << A.PosMax << ", " << A.PosMin << ", " << A.NegMax << ", " << A.NegMin << ", " << A.Zero << " } ";
		// 	cerr << "B: { " << B.PosMax << ", " << B.PosMin << ", " << B.NegMax << ", " << B.NegMin << ", " << B.Zero << " }\n";
		// 	cerr << A.PosMin * B.PosMin << endl;
		// }
	}
}