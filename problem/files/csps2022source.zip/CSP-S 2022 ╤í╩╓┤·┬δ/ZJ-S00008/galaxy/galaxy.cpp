#include<bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define per(i,j,k) for(int i=j;i>=k;i--)
typedef pair<int,int> pii;
// #define int long long
// #define mod 1000000007
int read()
{
	int x=0;int w=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')w=-1;c=getchar();}
	while(isdigit(c)){x=x*10+(c-'0');c=getchar();}
	return x*w;
}
void read(int &x){x=read();}
void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10)write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){write(x);putchar(c);}
int n,m;
map <int,int> g[500005];
int outdeg[500005];
int isin[1005],dfn[1005],low[1005],tot,cir[1005];
void dfs(int u)
{
	isin[u]=1;
	dfn[u]=++tot;
	for(auto &[v,ban]:g[u])if(!ban)
	{
		if(dfn[v])
		{
			if(isin[v])
				low[u]=min(low[u],low[v]);
		}
		else
		{
			dfs(v);
			low[u]=min(low[u],low[v]);
		}
	}
	if(low[u]<dfn[u])cir[u]=1;
	isin[u]=0;
}
signed main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	rep(i,1,m)
	{
		int u=read(),v=read();
		outdeg[u]++;
		g[u][v]=1;
	}
	int q=read();
	if(n>1000)
	{
		rep(i,1,q)
			puts("NO");
		return 0;
	}
	while(q--)
	{
		int t=read();
		if(t==1)
		{
			int u=read(),v=read();
			if(g[u][v]==1)
			{
				g[u][v]=0;
				outdeg[u]--;
			}
		}
		if(t==2)
		{
			int u=read();
			rep(i,1,n)
				if(g[i].find(u)!=g[i].end())
					if(g[i][u]==1)
					{
						g[i][u]=0;
						outdeg[i]--;
					}
		}
		if(t==3)
		{
			int u=read(),v=read();
			if(g[u][v]==0)
			{
				g[u][v]=1;
				outdeg[u]++;
			}
		}
		if(t==4)
		{
			int u=read();
			rep(i,1,n)
				if(g[i].find(u)!=g[i].end())
					if(g[i][u]==0)
					{
						g[i][u]=1;
						outdeg[i]++;
					}
		}
		memset(isin,0,sizeof(isin));
		memset(dfn,0,sizeof(dfn));
		memset(low,0,sizeof(low));
		tot=0;
		dfs(1);
		int flag=1;
		rep(i,1,n)if(!cir[i])flag=0;
		rep(i,1,n)if(outdeg[i]!=1)flag=0;
		if(flag)puts("YES");
		else puts("NO");
	}
}