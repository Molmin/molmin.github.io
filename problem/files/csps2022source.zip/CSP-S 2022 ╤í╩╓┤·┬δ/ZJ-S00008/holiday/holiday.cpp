#include<bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define per(i,j,k) for(int i=j;i>=k;i--)
typedef pair<int,int> pii;
#define int long long
// #define mod 1000000007
int read()
{
	int x=0;int w=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')w=-1;c=getchar();}
	while(isdigit(c)){x=x*10+(c-'0');c=getchar();}
	return x*w;
}
void read(int &x){x=read();}
void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10)write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){write(x);putchar(c);}
int n,m,k,w[2505],dis0[2505],f[2505][3],pre[2505][3];
vector <int> g[2505];
int vis[2505],dis[2505];
struct node{int u,dis;};
bool operator < (node a,node b){return a.dis>b.dis;}
void dijkstra(int u,int dis[])
{
	memset(vis,0,sizeof(vis));
	memset(dis,0x3f,sizeof(vis));
	priority_queue <node> q;
	q.push({u,0});dis[u]=0;
	while(!q.empty())
	{
		u=q.top().u;q.pop();
		if(vis[u])continue;
		for(int v:g[u])
			if(dis[u]+1<dis[v])
			{
				dis[v]=dis[u]+1;
				q.push({v,dis[v]});
			}
	}
}
signed main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	rep(i,2,n)read(w[i]);
	rep(i,1,m){
		int u=read(),v=read();
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dijkstra(1,dis0);
	// rep(i,1,n)write(dis0[i]," \n"[i==n]);
	int ans=0;
	rep(i,2,n)
	{
		dijkstra(i,dis);
		// write(i,'\n');
		// rep(j,1,n)write(dis[j]," \n"[j==n]);
		rep(j,2,n)if(j!=i&&dis[j]<=k+1&&dis0[j]<=k+1)
		{
			if(w[i]+w[j]>=f[i][0])
			{
				f[i][2]=f[i][1];
				pre[i][2]=pre[i][1];
				f[i][1]=f[i][0];
				pre[i][1]=pre[i][0];
				f[i][0]=w[i]+w[j];
				pre[i][0]=j;
			}
			else if(w[i]+w[j]>=f[i][1])
			{
				f[i][2]=f[i][1];
				pre[i][2]=pre[i][1];
				f[i][1]=w[i]+w[j];
				pre[i][1]=j;
			}
			else if(w[i]+w[j]>=f[i][2])
			{
				f[i][2]=w[i]+w[j];
				pre[i][2]=j;
			}
		}
		// rep(j,1,n)write(f[j][0]," \n"[j==n]);
		// rep(j,1,n)write(pre[j][0]," \n"[j==n]);
		// rep(j,1,n)write(f[j][1]," \n"[j==n]);
		// rep(j,1,n)write(pre[j][1]," \n"[j==n]);

		rep(j,2,i-1)if(j!=i&&dis[j]<=k+1)
		{
			rep(w,0,2)rep(l,0,2)
				if( i!=pre[j][l]&&
					j!=pre[i][w]&&
					pre[i][w]!=pre[j][l])
						ans=max(ans,f[i][w]+f[j][l]);
		}
	}
	write(ans,'\n');
}