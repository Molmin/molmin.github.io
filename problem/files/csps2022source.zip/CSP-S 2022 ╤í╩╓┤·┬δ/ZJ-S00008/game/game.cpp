#include<bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define per(i,j,k) for(int i=j;i>=k;i--)
typedef pair<int,int> pii;
#define int long long
// #define mod 1000000007
int read()
{
	int x=0;int w=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')w=-1;c=getchar();}
	while(isdigit(c)){x=x*10+(c-'0');c=getchar();}
	return x*w;
}
void read(int &x){x=read();}
void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10)write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){write(x);putchar(c);}
int n,m,q;
struct node
{
	int posmax,posmin,negmin,negmax,zero;
	node()
	{
		posmax=0;
		posmin=0x3f3f3f3f3f3f3f3f;
		negmax=-0x3f3f3f3f3f3f3f3f;
		negmin=0;
		zero=0;
	}
};
node operator + (node a,node b)
{
	node ans;
	ans.posmax=max(a.posmax,b.posmax);
	ans.posmin=min(a.posmin,b.posmin);
	ans.negmin=min(a.negmin,b.negmin);
	ans.negmax=max(a.negmax,b.negmax);
	ans.zero=a.zero|b.zero;
	return ans;
}

struct Seg1
{
	#define ls (pos<<1)
	#define rs (pos<<1|1)
	#define mid ((l+r)>>1)
	node x[100005<<2];
	void build(int pos=1,int l=1,int r=n)
	{
		if(l==r)return;
		build(ls,l,mid);
		build(rs,mid+1,r);
		x[pos]=x[ls]+x[rs];
	}
	void update(int k,int v,int pos=1,int l=1,int r=n)
	{
		if(l==r)
		{
			if(v==0)x[pos].zero=1;
			if(v>0)
				x[pos].posmax=max(x[pos].posmax,v),
				x[pos].posmin=min(x[pos].posmin,v);
			if(v<0)
				x[pos].negmin=min(x[pos].negmin,v),
				x[pos].negmax=max(x[pos].negmax,v);
			return;
		}
		if(k<=mid)update(k,v,ls,l,mid);
		else update(k,v,rs,mid+1,r);
		x[pos]=x[ls]+x[rs];
	}
	node query(int lx,int rx,int pos=1,int l=1,int r=n)
	{
		if(lx<=l&&r<=rx)return x[pos];
		if(lx<=mid&&rx>mid)return query(lx,rx,ls,l,mid)+query(lx,rx,rs,mid+1,r);
		if(lx<=mid)return query(lx,rx,ls,l,mid);
		return query(lx,rx,rs,mid+1,r);
	}
    #undef pos
    #undef ls
    #undef rs
}seg1;

struct Seg2
{
	#define ls (pos<<1)
	#define rs (pos<<1|1)
	#define mid ((l+r)>>1)
	node x[100005<<2];
	void build(int pos=1,int l=1,int r=m)
	{
		if(l==r)return;
		build(ls,l,mid);
		build(rs,mid+1,r);
		x[pos]=x[ls]+x[rs];
	}
	void update(int k,int v,int pos=1,int l=1,int r=m)
	{
		if(l==r)
		{
			if(v==0)x[pos].zero=1;
			if(v>0)
				x[pos].posmax=max(x[pos].posmax,v),
				x[pos].posmin=min(x[pos].posmin,v);
			if(v<0)
				x[pos].negmin=min(x[pos].negmin,v),
				x[pos].negmax=max(x[pos].negmax,v);
			return;
		}
		if(k<=mid)update(k,v,ls,l,mid);
		else update(k,v,rs,mid+1,r);
		x[pos]=x[ls]+x[rs];
	}
	node query(int lx,int rx,int pos=1,int l=1,int r=m)
	{
		if(lx<=l&&r<=rx)return x[pos];
		if(lx<=mid&&rx>mid)return query(lx,rx,ls,l,mid)+query(lx,rx,rs,mid+1,r);
		if(lx<=mid)return query(lx,rx,ls,l,mid);
		return query(lx,rx,rs,mid+1,r);
	}
    #undef pos
    #undef ls
    #undef rs
}seg2;
signed main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
    seg1.build();
    seg2.build();
    rep(i,1,n)seg1.update(i,read());
    rep(i,1,m)seg2.update(i,read());
    while(q--)
    {
        int l1,r1,l2,r2;
		read(l1),read(r1),read(l2),read(r2);
        node a=seg1.query(l1,r1);
        node b=seg2.query(l2,r2);
        vector <int> x,y;
        if(a.posmax)
            x.push_back(a.posmax),
            x.push_back(a.posmin);
        if(a.negmin)
            x.push_back(a.negmin),
            x.push_back(a.negmax);
        if(a.zero)
            x.push_back(0);

        if(b.posmax)
            y.push_back(b.posmax),
            y.push_back(b.posmin);
        if(b.negmin)
            y.push_back(b.negmin),
            y.push_back(b.negmax);
        if(b.zero)
            y.push_back(0);
        int ans=-0x3f3f3f3f3f3f3f3f;
        for(int i:x)
        {
            int tmp=0x3f3f3f3f3f3f3f3f;
            for(int j:y)
                tmp=min(tmp,i*j);
            ans=max(ans,tmp);
        }
        write(ans,'\n');
    }
}

#include<bits/stdc++.h>
// using namespace std;
// #define rep(i,j,k) for(int i=j;i<=k;i++)
// #define per(i,j,k) for(int i=j;i>=k;i--)
// typedef pair<int,int> pii;
// #define int long long
// // #define mod 1000000007
// int read()
// {
// 	int x=0;int w=1;char c=getchar();
// 	while(!isdigit(c)){if(c=='-')w=-1;c=getchar();}
// 	while(isdigit(c)){x=x*10+(c-'0');c=getchar();}
// 	return x*w;
// }
// void read(int &x){x=read();}
// void write(int x)
// {
// 	if(x<0){putchar('-');x=-x;}
// 	if(x>=10)write(x/10);
// 	putchar(x%10+'0');
// }
// void write(int x,char c){write(x);putchar(c);}
// int n,m,q;
// int a[100005],b[100005];



// namespace sub1
// {
// struct node
// {
// 	int posmax,posmin,negmin,negmax,zero;
// 	node()
// 	{
// 		posmax=0;
// 		posmin=0x3f3f3f3f3f3f3f3f;
// 		negmax=-0x3f3f3f3f3f3f3f3f;
// 		negmin=0;
// 		zero=0;
// 	}
// };
// node operator + (node a,node b)
// {
// 	node ans;
// 	ans.posmax=max(a.posmax,b.posmax);
// 	ans.posmin=min(a.posmin,b.posmin);
// 	ans.negmin=min(a.negmin,b.negmin);
// 	ans.negmax=max(a.negmax,b.negmax);
// 	ans.zero=a.zero|b.zero;
// 	return ans;
// }
// struct Seg
// {
// 	#define ls (pos<<1)
// 	#define rs (pos<<1|1)
// 	#define mid ((l+r)>>1)
// 	node x[1005<<2];
// 	void build(int pos=1,int l=1,int r=m)
// 	{
// 		if(l==r)return;
// 		build(ls,l,mid);
// 		build(rs,mid+1,r);
// 		x[pos]=x[ls]+x[rs];
// 	}
// 	void update(int k,int v,int pos=1,int l=1,int r=m)
// 	{
// 		if(l==r)
// 		{
// 			if(v==0)x[pos].zero=1;
// 			if(v>0)
// 				x[pos].posmax=max(x[pos].posmax,v),
// 				x[pos].posmin=min(x[pos].posmin,v);
// 			if(v<0)
// 				x[pos].negmin=min(x[pos].negmin,v),
// 				x[pos].negmax=max(x[pos].negmax,v);
// 			return;
// 		}
// 		if(k<=mid)update(k,v,ls,l,mid);
// 		else update(k,v,rs,mid+1,r);
// 		x[pos]=x[ls]+x[rs];
// 	}
// 	node query(int lx,int rx,int pos=1,int l=1,int r=m)
// 	{
// 		if(lx<=l&&r<=rx)return x[pos];
// 		if(lx<=mid&&rx>mid)return query(lx,rx,ls,l,mid)+query(lx,rx,rs,mid+1,r);
// 		if(lx<=mid)return query(lx,rx,ls,l,mid);
// 		return query(lx,rx,rs,mid+1,r);
// 	}
// }seg;
// void main()
// {
// 	seg.build();
// 	rep(i,1,m)seg.update(i,b[i]);
// 	while(q--)
// 	{
// 		int l1,r1,l2,r2;
// 		read(l1),read(r1),read(l2),read(r2);
// 		int ans=-0x3f3f3f3f3f3f3f3f;
// 		node p=seg.query(l2,r2);
// 		rep(i,l1,r1)
// 		{
// 			int tmp=-0x3f3f3f3f3f3f3f3f;
// 			if(a[i]>0)
// 			{
// 				if(p.negmin!=0)tmp=p.negmin*a[i];
// 				else if(p.zero)tmp=0;
// 				else tmp=a[i]*p.posmin;
// 			}
// 			if(a[i]<0)
// 			{
// 				if(p.posmax!=0)tmp=a[i]*p.posmax;
// 				else if(p.zero)tmp=0;
// 				else tmp=a[i]*p.negmax;
// 			}
// 			if(a[i]==0)
// 				tmp=0;
// 			ans=max(ans,tmp);
// 		}
// 		write(ans,'\n');
// 	}
// 	exit(0);
// }

// }
// signed main()
// {
// 	freopen("game.in","r",stdin);
// 	freopen("game.out","w",stdout);
// 	read(n),read(m),read(q);
// 	rep(i,1,n)read(a[i]);
// 	rep(i,1,m)read(b[i]);
// 	if(n<=1000&&m<=1000)sub1::main();
// }