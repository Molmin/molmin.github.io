#include<bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define per(i,j,k) for(int i=j;i>=k;i--)
typedef pair<int,int> pii;
#define int long long
// #define mod 1000000007
int read()
{
	int x=0;int w=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')w=-1;c=getchar();}
	while(isdigit(c)){x=x*10+(c-'0');c=getchar();}
	return x*w;
}
void read(int &x){x=read();}
void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x>=10)write(x/10);
	putchar(x%10+'0');
}
void write(int x,char c){write(x);putchar(c);}
int n,q,k,w[200005];
vector <int> g[200005];
int anc[200005][21],dep[200005];
void dfsl(int u,int fa)
{
	anc[u][0]=fa;
	dep[u]=dep[fa]+1;
	for(int v:g[u])if(v!=fa)
		dfsl(v,u);
}
int lca(int u,int v)
{
	if(dep[u]<dep[v])swap(u,v);
	per(i,20,0)if(dep[anc[u][i]]>=dep[v])
		u=anc[u][i];
	if(u==v)return u;
	per(i,20,0)if(anc[u][i]!=anc[v][i])
		u=anc[u][i],v=anc[v][i];
	return anc[u][0];
}
int ancestor(int u,int k)
{
	int d=dep[u]-k;
	per(i,20,0)if(dep[anc[u][i]]>=d)
		u=anc[u][i];
	return u;
}

namespace sub1
{
	int f[2005][2005];
	void dfs(int u,int fa)
	{
		int pos=u;
		f[u][0]=0;
		rep(i,1,k)f[u][i]=w[u];
		rep(i,1,k)
		{
			pos=anc[pos][0];
			rep(j,1,n)
				if(j-k>=0)
					f[u][j]=min(f[u][j],f[pos][j-k]+w[u]);
		}
		for(int v:g[u])if(v!=fa)
			dfs(v,u);
	}
	void main()
	{
		memset(f,0x3f,sizeof(f));
		dfs(1,0);
		// rep(i,1,n)
		// 	rep(j,1,n)
		// 		write(f[i][j]," \n"[j==n]);
		while(q--)
		{
			int u=read(),v=read();
			if(dep[u]<dep[v])swap(u,v);
			int l=lca(u,v);
			int l1=dep[u]-dep[l],l2=dep[v]-dep[l];
			int ans=f[u][l1]+f[v][l2]+w[l];
			int pos;
			vector <int> a,b;
			pos=ancestor(u,max(l1-k,0ll));
			while(pos!=l)
				a.push_back(pos),pos=pos[anc][0];
			pos=ancestor(v,max(l2-k,0ll));
			while(pos!=l)
				b.push_back(pos),pos=pos[anc][0];
			for(int i:a)
				for(int j:b)
					if(dep[i]+dep[j]-2*dep[l]<=k)
						ans=min(ans,f[u][dep[u]-dep[i]]+w[i]+
									f[v][dep[v]-dep[j]]+w[j]);
			write(ans,'\n');
		}
		exit(0);
	}
}

signed main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	read(n),read(q),read(k);
	rep(i,1,n)read(w[i]);
	rep(i,1,n-1)
	{
		int u=read(),v=read();
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfsl(1,0);
	rep(j,1,20)
		rep(i,1,n)
			anc[i][j]=anc[anc[i][j-1]][j-1];
	if(n<=2000&&q<=2000)sub1::main();
}
/*
考场游寄

现在6:20 没啥事能干了 写写游记

T1花了20min想到只要保留最大值和次大值就好了
然后写一半发现挂了 调半天发现要保留前三大的值
写完T1是 3:40 100+0+0+0
简单读了下T2 T4题面，去厕所寻找灵感。
拉完回来是 3:50

然后开始写T4  写到5:00 过了样例1 没过样例2
手玩了下样例 发现思路完全萎了 T4保单

时间还有90min 有点小急
于是写了T2 n^2 还有60min 100+60+0+0
T3 nqlog 还有30min 100+60+40+0

然后发现T2写的很傻 用n^2的改了改
nlogn 样例全过 还有10min 100+100+40+0

16:20 开始游记
*/