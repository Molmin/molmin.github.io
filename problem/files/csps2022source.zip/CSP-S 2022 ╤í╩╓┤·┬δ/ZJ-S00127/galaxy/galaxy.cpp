#include<bits/stdc++.h>
using namespace std;
const int N=1e6+6;
int n,m,q;
struct edge{
	int to,nex;
}e[N];
int head[N],cnt=0;
void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].nex=head[u];
	head[u]=cnt;
	return ;
}

namespace mfpf{
	void _main_(){
		while(q--)
			cout<<"NO"<<endl;
	}
}
namespace zc{
	
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	cin>>q;
	if(q>1005){
		mfpf::_main_();
	}
	else{
		mfpf::_main_();
	}
}
