#include<bits/stdc++.h>
using namespace std;

const int N=2e4+5;

struct edge {
	int to,nex;
} e[N];

int n,m,k;
int dis[N][N];
long long val[N];
long long ans=0;
int head[N],cnt=0;

void add(int u,int v) {
	e[++cnt].to=v;
	e[cnt].nex=head[u];
	head[u]=cnt;
	return;
}


namespace  baoli {
	bool check(int u,int fa,int t1) {
		if(t1<0) {
			if(u==1) {
				return 1;
			}
		}
		for(int i=head[u]; i; i=e[i].nex) {
			int v=e[i].to;
			if(v==fa)continue;
			bool tmp=check(v,u,t1-1);
			if(tmp==1)return 1;
		}
		return 0;
	}
	void dfs(int u,int fa,int cnt,int t,long long sum) {

		if(t>k) {
			return;
		}
		if(cnt==4) {
			if(check(u,fa,k+1)) {
				if(sum>ans)ans=sum;
			}
			return;
		}
		for(int i=head[u]; i; i=e[i].nex) {
			int v=e[i].to;
			if(v==fa)continue;
			dfs(v,u,cnt,t+1,sum);
			dfs(v,u,cnt+1,0,sum+val[v]);
		}
	}
	int _main_() {
		dfs(1,0,0,k,0);
		cout<<ans<<endl;
		return 0;
	}
}
//namespace aaaaa {
//
//}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
//	freopen("holiday3.in","r",stdin);
//	freopen("holiday1.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2; i<=n; i++)cin>>val[i];
	for(int i=1; i<=m; i++) {
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
		dis[u][v]=1;
		dis[v][u]=1;
	}
	if(n<20) {
		baoli:: _main_();
	} else {
		baoli:: _main_();
	}
	return 0;
}
