#include<bits/stdc++.h>
using namespace std;

#define ll long long
const int N=4e5+5;

struct edge{
	int to,nex;
}e[N];

int head[N],cnt=0;
ll n,q,k,val[N];
ll s,t,ans=1e9;
void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].nex=head[u];
	head[u]=cnt;
	return ;
}

namespace baoli{
	void dfs(int u,int fa,ll a,ll sum){
		if(u==t){
			if(sum<ans){
//				cout<<u<<' '<<sum<<endl;
				ans=sum;
				return;
			}
		}
		for(int i=head[u];i;i=e[i].nex){
			int v=e[i].to;
			if(v==fa)continue;
			if(a<k){
//				cout<<"1#"<<u<<' '<<v<<' '<<sum<<endl;
				dfs(v,u,a+1,sum);
			}
//			cout<<"2#"<<u<<' '<<v<<' '<<sum+val[u]<<endl;
			dfs(v,u,0,sum+val[u]);
		}
	}
	void solve(){
		cin>>s>>t;
//		cout<<val[t]<<'#'<<endl;;
		dfs(s,0,0,val[s]);
		
		cout<<ans+val[t]<<endl;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
//	freopen("transmit.in","r",stdin);
//	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		cin>>val[i];
	}
	for(int i=1;i<n;i++){
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	while(q--){
		ans=1e9;
		baoli::solve();
	}
	return 0;
}
