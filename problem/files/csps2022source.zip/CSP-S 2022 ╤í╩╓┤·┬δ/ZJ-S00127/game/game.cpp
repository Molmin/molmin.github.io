#include<bits/stdc++.h>
using namespace std;

const long long inf=2e8;
const int N=1e5+500;

int n,m,q;
int l1,r1,l2,r2;
int a[N],b[N];
long long min1[N],max2[N];

namespace baoli {
	void _main_() {
		long long maxn=-inf,minn=inf;
		int maxx,miny;
		for(int i=l1; i<=r1; i++) {
			if(min1[i]>maxn) {
				maxn=min1[i];
				maxx=i;
			}
		}
		for(int j=l2; j<=r2; j++) {
			int t=a[maxx]*b[j];
			if(t<minn) {
				minn=t;
				miny=j;
			}
		}
		cout<<a[maxx]*b[miny]<<endl;
	}

}
namespace ts2_1 {
	void _main_() {
		int minn=inf,miny;
		for(int j=l2; j<=r2; j++) {
			int t=a[l1]*b[j];
			if(t<minn) {
				minn=t;
				miny=j;
			}
		}
		cout<<a[l1]*b[miny]<<endl;
	}
}
namespace ts2_2 {
	void _main_() {
		int maxn=-inf,maxx;
		for(int i=l1; i<=r1; i++) {
			int t=a[i]*b[l2];
			if(t>maxx) {
				maxn=t;
				maxx=i;
			}
		}
		cout<<a[maxx]*b[l2]<<endl;
	}
}
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
//	freopen("game2.in","r",stdin);
//	freopen("game1.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1; i<=n; i++)cin>>a[i];
	for(int i=1; i<=m; i++)cin>>b[i];
	while(q--) {
		for(int i=1; i<=n; i++)min1[i]=inf;
		cin>>l1>>r1>>l2>>r2;
		if(l1==r1) ts2_1::_main_();
		else if(l2==r2)ts2_2::_main_();
		else {
			for(int i=l1; i<=r1; i++) {
				for(int j=l2; j<=r2; j++) {
					long long t=a[i]*b[j];
					min1[i]=min(t,min1[i]);
				}
			}
			baoli::_main_();
		}
//		for(int i=l1;i<=r1;i++)cout<<min1[i]<<' ';
//		cout<<endl;
		
	}
	return 0;
}
