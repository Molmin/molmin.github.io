#include<bits/stdc++.h>
#define ls(k) (k<<1)
#define rs(k) (k<<1|1)
using namespace std;
const int MAXN = 5e5+5;
bool Small;
struct Edge
{
	int u,v;
	bool operator < (const Edge &x)const
	{
		return u==x.u?v<x.v:u<x.u;
	}
}e[MAXN];
struct node
{
	int x,y,sx,sy,fx,fy,hx,hy,tu,ca;
	bool a;
}st[MAXN<<2];
vector <int> t[MAXN<<2],g[MAXN];
int to[MAXN],f[MAXN],siz[MAXN],top,h[MAXN],be[MAXN],en[MAXN],n,m,q;
int catk;
bool atk;
bool Sunny;
void upd(int p,int le,int ri,int k,int l,int r)
{
	if(le>ri) return ;
	
//	if(l==1&&r==q) cout<<e[p].u<<" "<<e[p].v<<" "<<le<<" "<<ri<<endl;

	if(le<=l&&r<=ri)
	{
		t[k].push_back(p);
		return ;
	}
	int mid=l+r>>1;
	if(le<=mid) upd(p,le,ri,ls(k),l,mid);
	if(ri>mid) upd(p,le,ri,rs(k),mid+1,r);
}
int find(int x){return x==f[x]?x:find(f[x]);}
void Add(int id)
{
	int u=e[id].u,v=e[id].v,x=find(u),y=find(v);
	st[++top]=node{u,v,siz[x],siz[y],f[x],f[y],h[x],h[y],to[u],catk,atk};
	if(to[u]) atk=0;
	else
	{
		to[u]=v;
		
//		if(2==id) cout<<"find1:"<<u<<" "<<v<<" "<<h[u]<<" "<<siz[2]<<endl;
		
		u=find(u),v=find(v);
		if(siz[u]<siz[v]) swap(u,v);
		
//		if(2==id) cout<<"find2:"<<u<<" "<<v<<" "<<h[u]<<" "<<siz[2]<<endl;
		
		if(u==v) catk+=siz[u],h[u]=1;
		else siz[u]+=siz[v],f[v]=u,catk+=siz[v]*(h[u]==1&&h[v]==0);
		
//		if(2==id) cout<<"find3:"<<catk<<endl;
	}
}
void Del()
{
	int u=st[top].x,v=st[top].y;
	to[u]=st[top].tu;
	u=find(u);v=find(v);
	siz[u]=st[top].sx;siz[v]=st[top].sy;
	h[u]=st[top].hx;h[v]=st[top].hy;
	f[u]=st[top].fx;f[v]=st[top].fy;
	catk=st[top].ca,atk=st[top].a;
	--top;
}
void dfs(int k,int l,int r)
{
	for(int i=0;i<t[k].size();++i) Add(t[k][i]);
	
//	cout<<"k:"<<k<<" "<<t[1].size()<<endl;
//	if(l==1&&r==q) cout<<"siz:"<<catk<<" "<<siz[find(1)]<<" "<<find(1)<<endl;
//	if(l==1&&r==q) cout<<"topp:"<<top<<" "<<t[k].size()<<" "<<find(1)<<" "<<siz[find(1)]<<endl;
	
	if(l==r)
	{
		
//		cout<<"top,catk:"<<l<<" "<<top<<" "<<catk<<" "<<atk<<endl;
		catk=0;
		for(int i=1;i<=n;++i) if(h[find(i)]==1) ++catk;
		if(top==n&&catk==n&&atk) printf("YES\n");
		else printf("NO\n");
	}
	else
	{
		int mid=l+r>>1;
		dfs(ls(k),l,mid);
		dfs(rs(k),mid+1,r);
	}
//	if(l==1&&r==2) cout<<"Del1:"<<h[2]<<" "<<top<<" "<<st[top-1].hy<<" "<<st[top-1].y<<endl;
	for(int i=t[k].size()-1;i>=0;--i) Del();
//	if(l==1&&r==2) cout<<"Del2:"<<h[2]<<" "<<top<<" "<<h[2]<<endl;
}
int main()
{
//	cout<<1.0*(&Sunny-&Small)/1024/1024<<"MB"<<endl;
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1,u,v;i<=m;++i)
	{
		scanf("%d %d",&u,&v);
		e[i]=Edge{u,v};
		be[i]=1;
	}
	sort(e+1,e+1+m);
	for(int i=1;i<=m;++i) g[e[i].v].push_back(i);
	scanf("%d",&q);
	for(int i=1;i<=q;++i)
	{
		int ty,u,v;
		scanf("%d",&ty);
		if(ty==1)
		{
			scanf("%d %d",&u,&v);
			int id=lower_bound(e+1,e+1+m,Edge{u,v})-e;
			if(en[id]==0)
			{
				en[id]=i;
				upd(id,be[id],i-1,1,1,q);
			}
		}
		if(ty==2)
		{
			scanf("%d",&u);
			
//			cout<<"ty:"<<ty<<" "<<u<<endl;
//			cout<<u<<endl;
			
			for(int j=0;j<g[u].size();++j)
				if(en[g[u][j]]==0)
				{
					en[g[u][j]]=i;
					upd(g[u][j],be[g[u][j]],i-1,1,1,q);
//					cout<<"g:"<<e[g[u][j]].u<<" "<<e[g[u][j]].v<<endl;
				}
		}
		if(ty==3)
		{
			scanf("%d %d",&u,&v);
			int id=lower_bound(e+1,e+1+m,Edge{u,v})-e;
			en[id]=0;be[id]=i;
		}
		if(ty==4)
		{
			scanf("%d",&u);
			for(int j=0;j<g[u].size();++j)
				if(en[g[u][j]]!=0) be[g[u][j]]=i,en[g[u][j]]=0;
		}
	}
	for(int i=1;i<=m;++i) if(en[i]==0) upd(i,be[i],q,1,1,q);
	for(int i=1;i<=n;++i) f[i]=i,siz[i]=1,h[i]=0;
	top=catk=0;atk=1;
	
	
	
	dfs(1,1,q);
	return 0;
}
