#include<bits/stdc++.h>
#define ls(k) (k<<1)
#define rs(k) (k<<1|1)
#define ll long long
using namespace std;
const int MAXN = 1e5+5;
const ll INF = 1e18;
bool Small;
int n,m,q;
ll A[MAXN],B[MAXN];
struct node
{
	ll fx,fi,zx,zi;
	node operator + (const node &x)const
	{
		node t;
		t.fx=min(fx,x.fx);t.fi=max(fi,x.fi);
		t.zx=max(zx,x.zx);t.zi=min(zi,x.zi);
		return t;
	}
};
struct Tree
{
	node t[MAXN<<2];
	void build(int k,int l,int r,ll *a)
	{
		if(l==r)
		{
			t[k].zi=t[k].fx=INF;t[k].fi=t[k].zx=-INF;
			if(a[l]==0) t[k].zx=t[k].zi=t[k].fx=t[k].fi=0;
			else if(a[l]>0) t[k].zx=t[k].zi=a[l];
			else t[k].fx=t[k].fi=a[l];
			return ;
		}
		int mid=l+r>>1;
		build(ls(k),l,mid,a);
		build(rs(k),mid+1,r,a);
		t[k]=t[ls(k)]+t[rs(k)];
	}
	node query(int le,int ri,int k,int l,int r)
	{
		if(le<=l&&r<=ri) return t[k];
		int mid=l+r>>1;
		if(ri<=mid) return query(le,ri,ls(k),l,mid);
		else if(le>mid) return query(le,ri,rs(k),mid+1,r);
		else return query(le,ri,ls(k),l,mid)+query(le,ri,rs(k),mid+1,r);
	}
}at,bt;
bool Sunny;
int main()
{
//	cout<<1.0*(&Sunny-&Small)/1024/1024<<"MB"<<endl;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	scanf("%d %d %d",&n,&m,&q);
	for(int i=1;i<=n;++i) scanf("%lld",&A[i]);
	for(int i=1;i<=m;++i) scanf("%lld",&B[i]);
	at.build(1,1,n,A);bt.build(1,1,m,B);
	while(q--)
	{
		int l1,r1,l2,r2;
		scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
		node a=at.query(l1,r1,1,1,n),b=bt.query(l2,r2,1,1,m);
		ll tmp=-INF;
		if(a.zx!=-INF)
		{
			if(b.fx!=INF) tmp=max(tmp,a.zx*b.fx);
			else tmp=max(tmp,a.zx*b.zi);
		}
		if(a.fx!=INF)
		{
			if(b.zx!=-INF) tmp=max(tmp,a.fx*b.zx);
			else tmp=max(tmp,a.fx*b.fi);
		}
		if(a.zi!=INF)
		{
			if(b.fx!=INF) tmp=max(tmp,a.zi*b.fx);
			else tmp=max(tmp,a.zi*b.zi);
		}
		if(a.fi!=-INF)
		{
			if(b.zx!=-INF) tmp=max(tmp,a.fi*b.zx);
			else tmp=max(tmp,a.fi*b.fi);
		}
		printf("%lld\n",tmp);
	}
	return 0;
}