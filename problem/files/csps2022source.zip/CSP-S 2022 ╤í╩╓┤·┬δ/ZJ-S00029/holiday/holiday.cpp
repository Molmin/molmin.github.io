#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN = 2505;
bool Small;
int n,m,k,dis[MAXN],id[MAXN][3];
ll V[MAXN],L[MAXN][3],Ans;
vector <int> e[MAXN];
bool vis[MAXN],g[MAXN][MAXN];
bool Sunny;
void bfs(int p)
{
	queue <int> q;
	q.push(p);
	while(!q.empty())
	{
		int cur=q.front();
		q.pop();
		for(int i=0;i<e[cur].size();++i)
		{
			int to=e[cur][i];
			if(dis[cur]<=k&&!vis[to])
			{
				g[p][to]=1;
				dis[to]=dis[cur]+1;
				vis[to]=1;
				q.push(to);
			}
		}
	}
}
int main()
{
//	cout<<1.0*(&Sunny-&Small)/1024/1024<<endl;
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=2;i<=n;++i) scanf("%d",&V[i]);
	for(int i=1,u,v;i<=m;++i)
	{
		scanf("%d %d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=1;i<=n;++i)
	{
		memset(vis,0,sizeof vis);
		memset(dis,0,sizeof dis);
		bfs(i);
	}
	
//	for(int i=1;i<=n;++i,cout<<endl)
//		for(int j=1;j<=n;++j) cout<<g[i][j]<<" ";
	
	for(int i=2;i<=n;++i)
		for(int j=2;j<=n;++j)
		{
			if(i==j||!g[1][i]||!g[i][j]) continue;
			if(V[i]>L[j][0]) L[j][0]=V[i],id[j][0]=i;
			if(L[j][0]>L[j][1]) swap(L[j][0],L[j][1]),swap(id[j][0],id[j][1]);
			if(L[j][1]>L[j][2]) swap(L[j][1],L[j][2]),swap(id[j][1],id[j][2]);
		}
	for(int i=2;i<=n;++i)
	{
		for(int j=2;j<=n;++j)
		{
			if(i==j||!g[i][j]) continue;
			ll tmp=V[i]+V[j];
			int use,u2;
			if(j!=id[i][2]) tmp+=L[i][2],use=id[i][2];
			else tmp+=L[i][1],use=id[i][1];
			if(id[j][2]!=i&&id[j][2]!=use) tmp+=L[j][2],u2=id[j][2];
			else if(id[j][1]!=i&&id[j][1]!=use) tmp+=L[j][1],u2=id[j][1];
			else tmp+=L[j][0],u2=id[j][0];
			
			if(use==0||u2==0) continue;
			
//			if(i==3&&j==8) cout<<"yes"<<endl;
			
//			if(tmp==27) cout<<use<<" "<<i<<" "<<j<<" "<<u2<<endl;
			
			Ans=max(Ans,tmp);
		}
	}
	printf("%lld",Ans);
	return 0;
}