// CSP-S 2022 T3 galaxy
#include <bits/stdc++.h>
using namespace std;
const int N = 500010, M = 500010;
int n, m, q;
namespace gf {
	struct edge {
		int nxt, to;
	} a[M];
	int h[N], c;
	void init () {
		c = 0;
		memset (h, 0, sizeof (h));
	}
	void add (int u, int v) {
		a[++c].nxt = h[u];
		a[c].to = v;
		h[u] = c;
	}
}
namespace fg {
	struct edge {
		int nxt, to;
	} a[M];
	int h[N], c;
	void init () {
		c = 0;
		memset (h, 0, sizeof (h));
	}
	void add (int u, int v) {
		a[++c].nxt = h[u];
		a[c].to = v;
		h[u] = c;
	}
}
map < pair <int, int>, bool > sh;
bool vis[N];
pair <int, int> dfs (int u) {
//	cerr << u << '\n';
	if (vis[u]) {
		return make_pair (0, 0);
	}
	vis[u] = true;
	int a = 0, b = 0, c = 0;
	for (int i = gf::h[u]; i != 0; i = gf::a[i].nxt) {
		int v = gf::a[i].to;
		if (sh[make_pair (u, v)]) {
			continue;
		}
		a++;
		pair <int, int> ans = dfs (v);
		b += ans.first;
		c += ans.second + 1;
	}
	for (int i = fg::h[u]; i != 0; i = fg::a[i].nxt) {
		int v = fg::a[i].to;
		if (sh[make_pair (v, u)]) {
			continue;
		}
		if (vis[v]) {
			continue;
		}
		pair <int, int> ans = dfs (v);
		b += ans.first;
		c += ans.second;
	}
	b++;
//	if (u == 1 && q == 300 - 21) {
//		cerr << a << ' ';
//	}
//	cerr << a << ' ' << b << ' ' << c << '\n';
	if (a >= 2) {
		return make_pair (1145141919, 810);
	} else if (a == 1 || b != 0 || c != 0) {
		return make_pair (b, c);
	} else {
		return make_pair (1, 0);
	}
}
int main () {
	freopen ("galaxy.in", "r", stdin);
	freopen ("galaxy.out", "w", stdout);
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		gf::add (u, v);
		fg::add (v, u);
	}
	scanf ("%d", &q);
	while (q--) {
		int op, u, v;
		scanf ("%d%d" , &op, &u);
		if (op % 2 == 1) {
			scanf ("%d", &v);
		}
		if (op == 1) {
			sh[make_pair (u, v)] = true;
		}
		if (op == 2) {
			for (int i = fg::h[u]; i != 0; i = fg::a[i].nxt) {
				int v = fg::a[i].to;
				sh[make_pair (v, u)] = true;
			} 
		}
		if (op == 3) {
			sh[make_pair (u, v)] = false;
		}
		if (op == 4) {
			for (int i = fg::h[u]; i != 0; i = fg::a[i].nxt) {
				int v = fg::a[i].to;
				sh[make_pair (v, u)] = false;
			} 
		}
		bool flag = true;
		fill (vis + 1, vis + n + 1, false);
		for (int i = 1; i <= n; i++) {
			if (!vis[i]) {
				pair <int, int> ans = dfs (i);
//				cerr << ans.first << ' ' << ans.second << '\n';
				if (ans.first == 1145141919) {
					puts ("NO");
					flag = false;
					break;
				}
				if (ans.first == ans.second) {
					puts ("YES");
					flag = false;
					break;
				}
			}
		}
		if (flag) {
			puts ("NO");
		}
//		cerr << "------------\n";
	}
	return 0;
}
