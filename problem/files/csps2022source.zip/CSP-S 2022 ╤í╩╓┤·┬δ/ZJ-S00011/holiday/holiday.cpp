// CSP-S 2022 T1 holiday
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2510, M = 4000010, inf = 0x7f7f7f7f;
const ll infll = 0x7f7f7f7f7f7f7f7fll / 2;
namespace gf {
	struct edge {
		int nxt, to;
	} a[M];
	int h[N], c;
	void init () {
		c = 0;
		memset (h, 0, sizeof (h));
	}
	void add (int u, int v) {
		a[++c].nxt = h[u];
		a[c].to = v;
		h[u] = c;
	}
}
int n, m, k;
ll a[N], c1[N][3], c2[N][3], ans;
bool b[N][N];
namespace dij {
	int d[N];
	bool vis[N];
	priority_queue < pair <int, int>, vector < pair <int, int> >, greater < pair <int, int> > > h;
	void main (int s) {
		fill (d + 1, d + n + 1, inf);
		fill (vis + 1, vis + n + 1, false);
		d[s] = 0;
		h.push (make_pair (d[s], s));
		while (!h.empty ()) {
			if (d[h.top ().second] != h.top ().first) {
				h.pop ();
				continue;
			}
			int u = h.top ().second;
			h.pop ();
			vis[u] = true;
			for (int i = gf::h[u]; i != 0; i = gf::a[i].nxt) {
				int v = gf::a[i].to;
				if (d[u] + 1 < d[v]) {
					d[v] = d[u] + 1;
					h.push (make_pair (d[v], v));
				}
			}
		}
	}
}
int main () {
	freopen ("holiday.in", "r", stdin);
	freopen ("holiday.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &k);
	k++;
	for (int i = 2; i <= n; i++) {
		scanf ("%lld", &a[i]);
	}
	for (int i = 1; i <= m; i++) {
		int u, v;
		scanf ("%d%d", &u, &v);
		gf::add (u, v);
		gf::add (v, u);
	}
	for (int i = 1; i <= n; i++) {
		dij::main (i);
		for (int j = 1; j <= n; j++) {
			if (dij::d[j] <= k) {
				b[i][j] = true;
			}
		}
	}
	gf::init ();
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (i != j && (b[i][j] || b[j][i])) {
				gf::add (i, j);
				gf::add (j, i);
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		c2[i][0] = c2[i][1] = c2[i][2] = -infll;
	}
	ans = -infll;
	for (int i = gf::h[1]; i != 0; i = gf::a[i].nxt) {
		int u = gf::a[i].to;
		for (int j = gf::h[u]; j != 0; j = gf::a[j].nxt) {
			int v = gf::a[j].to;
			if (u == v) {
				continue;
			}
			ll w = a[u] + a[v];
			for (int k = 0; k <= 2; k++) {
				if (w >= c2[v][k]) {
					for (int kk = k; kk < 2; kk++) {
						c2[v][kk + 1] = c2[v][kk];
						c1[v][kk + 1] = c1[v][kk];
					}
					c2[v][k] = w;
					c1[v][k] = u;
					break;
				}
			}
		}
	}
	for (int u = 2; u <= n; u++) {
		for (int i = gf::h[u]; i != 0; i = gf::a[i].nxt) {
			int v = gf::a[i].to;
			if (v == 1) {
				continue;
			}
			ll w1 = c2[u][0], w2 = c2[v][0];
			int u1 = c1[u][0], u2 = c1[v][0];
			if (c1[u][0] == v) {
				w1 = c2[u][1];
				u1 = c1[u][1];
			}
			if (c1[v][0] == u) {
				w2 = c2[v][1];
				u2 = c1[v][1];
			}
			if (u1 == 0 || u2 == 0) {
				continue;
			} else if (u1 != u2) {
				ans = max (ans, w1 + w2);
			}
		}
	}
	printf ("%lld", ans);
	return 0;
}
