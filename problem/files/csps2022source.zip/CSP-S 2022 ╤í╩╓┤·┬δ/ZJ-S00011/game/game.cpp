// CSP-S 2022 T2 game
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 100010;
const ll inf = 0x7f7f7f7f;
int n, m, q, l1, r1, l2, r2;
ll a[N], b[N];
namespace segtree1 {
	ll mx[N << 2], mn[N << 2];
	void build (int x, int l, int r) {
		if (l == r) {
			mx[x] = mn[x] = b[l];
			return ;
		}
		int mid = (l + r) >> 1;
		build (x << 1, l, mid);
		build (x << 1 | 1, mid + 1, r);
		mx[x] = max (mx[x << 1], mx[x << 1 | 1]);
		mn[x] = min (mn[x << 1], mn[x << 1 | 1]);
	}
	ll query1 (int x, int l, int r, int ql, int qr) {
		if (ql <= l && r <= qr) {
			return mx[x];
		}
		int mid = (l + r) >> 1;
		ll ans = -inf;
		if (ql <= mid) {
			ans = max (ans, query1 (x << 1, l, mid, ql, qr));
		}
		if (qr > mid) {
			ans = max (ans, query1 (x << 1 | 1, mid + 1, r, ql, qr));
		}
		return ans;
	}
	ll query2 (int x, int l, int r, int ql, int qr) {
		if (ql <= l && r <= qr) {
			return mn[x];
		}
		int mid = (l + r) >> 1;
		ll ans = inf;
		if (ql <= mid) {
			ans = min (ans, query2 (x << 1, l, mid, ql, qr));
		}
		if (qr > mid) {
			ans = min (ans, query2 (x << 1 | 1, mid + 1, r, ql, qr));
		}
		return ans;
	}
}
typedef pair < bool, pair <ll, ll> > data;
namespace segtree2 {
	data emptydata = make_pair (false, make_pair (0ll, 0ll));
	data pos[N << 2], neg[N << 2];
	data merge (data a, data b) {
		if (a.first && !b.first) {
			return make_pair (true, a.second);
		} else if (b.first && !a.first) {
			return make_pair (true, b.second);
		} else if (!a.first && !b.first) {
			return emptydata;
		} else {
			return make_pair (true, make_pair (max (a.second.first, b.second.first), min (a.second.second, b.second.second)));
		}
	}
	void build (int x, int l, int r) {
		if (l == r) {
			if (a[l] < 0) {
				pos[x] = emptydata;
				neg[x] = make_pair (true, make_pair (a[l], a[l]));
			} else {
				neg[x] = emptydata;
				pos[x] = make_pair (true, make_pair (a[l], a[l]));
			}
			return ;
		}
		int mid = (l + r) >> 1;
		build (x << 1, l, mid);
		build (x << 1 | 1 , mid + 1, r);
		pos[x] = merge (pos[x << 1], pos[x << 1 | 1]);
		neg[x] = merge (neg[x << 1], neg[x << 1 | 1]);
	}
	data query1 (int x, int l, int r, int ql, int qr) {
		if (ql <= l && r <= qr) {
			return pos[x];
		}
		int mid = (l + r) >> 1;
		data ans = emptydata;
		if (ql <= mid) {
			ans = merge (ans, query1 (x << 1, l, mid, ql, qr));
		}
		if (qr > mid) {
			ans = merge (ans, query1 (x << 1 | 1, mid + 1, r, ql, qr));
		}
		return ans;
	}
	data query2 (int x, int l, int r, int ql, int qr) {
		if (ql <= l && r <= qr) {
			return neg[x];
		}
		int mid = (l + r) >> 1;
		data ans = emptydata;
		if (ql <= mid) {
			ans = merge (ans, query2 (x << 1, l, mid, ql, qr));
		}
		if (qr > mid) {
			ans = merge (ans, query2 (x << 1 | 1, mid + 1, r, ql, qr));
		}
		return ans;
	}
}
int main () {
	freopen ("game.in", "r", stdin);
	freopen ("game.out", "w", stdout);
	scanf ("%d%d%d", &n, &m, &q);
	for (int i = 1; i <= n; i++) {
		scanf ("%lld", &a[i]);
	}
	for (int i = 1; i <= m; i++) {
		scanf ("%lld", &b[i]);
	}
	segtree1::build (1, 1, m);
	segtree2::build (1, 1, n);
	while (q--) {
		scanf ("%d%d%d%d", &l1, &r1, &l2, &r2);
		data v1 = segtree2::query1 (1, 1, n, l1, r1);
		data v2 = segtree2::query2 (1, 1, n, l1, r1);
		ll t1 = segtree1::query2 (1, 1, m, l2, r2);
		ll t2 = segtree1::query1 (1, 1, m, l2, r2);
		if (!v1.first) {
			printf ("%lld\n", max (v2.second.first * t2, v2.second.second * t2));
		} else if (!v2.first) {
			printf ("%lld\n", max (v1.second.first * t1, v1.second.second * t1));
		} else {
			printf ("%lld\n", max (max (v1.second.first * t1, v1.second.second * t1), max (v2.second.first * t2, v2.second.second * t2)));
		}
	}
	return 0;
}
