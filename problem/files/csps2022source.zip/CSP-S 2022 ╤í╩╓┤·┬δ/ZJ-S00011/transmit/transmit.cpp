// CSP-S 2022 T4 transmit
#include <bits/stdc++.h>
using namespace std;
int main () {
	freopen ("transmit.in", "r", stdin);
	freopen ("transmit.out", "w", stdout);
	return 0;
}
