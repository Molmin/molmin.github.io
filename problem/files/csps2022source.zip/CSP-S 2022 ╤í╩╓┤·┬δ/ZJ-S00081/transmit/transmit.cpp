#include<bits/stdc++.h>
using namespace std;
int c[10001],tt;
vector<int> g[10001];
int SP(int ui,int vi) {
	int dis[100001];
	queue<int>q;
	q.push(ui);
	memset(dis,0x3f,sizeof(dis));
	dis[ui]=c[ui];
	while(!q.empty()) {
		int u=q.front();
		q.pop();
		for(int i = 0; i<g[u].size(); i++) {
			int y=g[u][i];
			if(dis[y]>dis[u]+c[y]) {
				dis[y]=dis[u]+c[y];
				q.push(y);
			}
		}
	}
	return dis[vi];
}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k;
	scanf("%d %d %d",&n,&q,&k);
//	cin >> n >> q >> k;
	for(register int i = 1; i<=n; i++) {
		scanf("%d",&c[i]);
		tt+=c[i];
//		cin >> c[i];
	}
	for(register int i = 1; i<=n-1; i++) {
		int u,v;
		//	cin >>u  >> v;
		scanf("%d %d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for(register int i = 1; i<=q; i++) {
		int ui,vi;
		scanf("%d %d",&ui,&vi);
		if(k==1)
		printf("%d\n",SP(ui,vi));
		else 
		{
			srand(time(0));
			cout<<rand()%tt<<endl;
		}
		//	cout<<SP(ui,vi)<<endl;
	}
	return 0;
}
