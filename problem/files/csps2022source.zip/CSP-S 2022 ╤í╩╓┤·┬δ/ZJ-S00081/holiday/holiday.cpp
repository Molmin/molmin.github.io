#include<bits/stdc++.h>
using namespace std;
const int N=2550;
struct Node {
	int d,g;
};
bool vis[N];
int dis[N][10],maxn=0;
vector<int>g[N];
queue <Node>q;
long long n,m,k,a[N];
void dfs(int t,int g1,int m1,int m2,int m3,int m4) {
//	cout<< t <<" "<<g1<<" "<<m1<<" "<<m2<<" "<<m3<<" "<<m4<<endl;
	if(g1>=4+k*n) {
		for(int i = 0; i<g[t].size(); i++) {
			int v=g[t][i];
			if(v==1) {
				maxn=max(maxn,m1+m2+m3+m4);
				break;
			}
		}
		return;
	}
//	if(g1>=6+k) return;
	for(register int i = 0; i<g[t].size(); i++) {
		int v=g[t][i];
		if(!vis[v]) {
			vis[v]=1;
			if(a[v]>m1) dfs(v,g1+1,a[v],m1,m2,m3);
			else if(a[v]>m2) dfs(v,g1+1,m1,a[v],m2,m3);
			else if(a[v]>m3) dfs(v,g1+1,m1,m2,a[v],m3);
			else if(a[v]>m4) dfs(v,g1+1,m1,m2,m3,a[v]);
			//	dfs(v,g1+1);
			vis[v]=0;
		}
	}
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	for(register int i = 2; i<=n; i++) {
		scanf("%lld",&a[i]);
	}
	for(register int i = 1; i<=m; i++) {
		long long u,v;
		cin >> u >> v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	vis[1]=1;
	dfs(1,0,0,0,0,0);
	printf("%lld",maxn);
	return 0;
}
