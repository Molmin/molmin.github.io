#include<bits/stdc++.h>
using namespace std;
int n,m,q,f1[10001][30],f2[10001][30],w1[10001][30],w2[10001][30],q1[100001];
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> n>>m>>q;
	for(register int i = 1; i<=n; i++) {
		cin >> f1[i][0];
		if(f1[i][0]==0)
			q1[i]=q1[i-1]+1;
		else q1[i]=q1[i-1];
		f2[i][0]=f1[i][0];
	}
	for(register int i = 1; i<=m; i++) {
		cin >> w1[i][0];
		w2[i][0]=w1[i][0];
	}
//	for(int i = 1;i<=n;i++)
	for(register int j = 1; (1<<j)<=n; j++) {
		for(register int i = 1; i<=n; i++) {
			f1[i][j]=min(f1[i][j-1],f1[i+(1<<j-1)][j-1]);
			f2[i][j]=max(f2[i][j-1],f2[i+(1<<j-1)][j-1]);
		}
	}
	for(register int j = 1; (1<<j)<=m; j++) {
		for(register int i = 1; i<=m; i++) {
			w1[i][j]=min(w1[i][j-1],w1[i+(1<<j-1)][j-1]);
			w2[i][j]=max(w2[i][j-1],w2[i+(1<<j-1)][j-1]);
		}
	}
	for(register int i = 1; i<=q; i++) {
		int l1,r1,l2,r2;
		cin >> l1 >> r1>>l2>>r2;
		int n1,m1,n2,m2;
		if(l1==r1) {
			n1=f1[l1][0];
			m1=f1[l1][0];
		} else {
			int k=log2(r1-l1);
			n1=min(f1[l1][k],f1[r1-(1<<k)+1][k]);
			m1=max(f2[l1][k],f2[r1-(1<<k)+1][k]);
		}
		if(l2==r2) {
			n2=w1[l1][0];
			m2=w1[l1][0];
		} else {
			int k=log2(r2-l2);
			n2=min(w1[l2][k],w1[r2-(1<<k)+1][k]);
			m2=max(w2[l2][k],w2[r2-(1<<k)+1][k]);
		}/*
		if(m1<=0)
		{
			if(m2<=0) cout<<n1*m2<<endl;
			else
			{
				if(q1[r1]-q1[l1]>0) cout<<0<<endl;
				else cout<<m1*m2<<endl;
			}
		}
		else
		{
			if(n2>=0) cout<<m1*n2<<endl;
			else
			{
				cout<<0;
			}
		}*/
		if(n1==m1) {
			if(n1==0) {
				puts("0");
				continue;
			}
			if(n1>0) {
				cout<<n1*n2<<'\n';
			}
			if(n1<0) cout<<n1*m2<<'\n';
			continue;
		}
		if(m2==n2) {
			if(n2==0) {
				puts("0");
				continue;
			}
			if(n2>0) {
				cout<<m1*n2<<'\n';
			}
			if(n2<0) cout<<n1*m2<<'\n';
			continue;
		}
		if(m1<=0) {
			if(m2<=0) cout<<n1*m2<<endl;
			else {
				if(q1[r1]-q1[l1]>0) cout<<0<<endl;
				else cout<<m1*m2<<endl;
			}
		} else {
			if(n2>=0) cout<<m1*n2<<endl;
			else {
				cout<<n2*m2<<endl;
			}
		}
	}
	return 0;
}
