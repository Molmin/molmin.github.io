#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin >> n >> m;
	for(register int i = 1; i<=n; i++) {
		int u,v;
		cin >> u >> v;
	}
	int q;
	cin >> q;
	for(register int i = 1; i<=q; i++) {
		int op;
		cin >> op;
		if(op==1) {
			int u,v;
			cin >> u >> v;
		}
		if(op==2) {
			int u;
			cin >> u;
		}
		if(op==3) {
			int u,v;
			cin >> u >> v;
		}
		if(op==4) {
			int u;
			cin >> u;
		}
		srand(time(NULL));
		if(rand()%2) puts("YES");
		else puts("NO");
	}
	return 0;
}
