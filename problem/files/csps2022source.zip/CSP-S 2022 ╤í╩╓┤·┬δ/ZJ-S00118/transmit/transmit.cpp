#include<bits/stdc++.h>
using namespace std;
#define rint register int
#define ll long long
#define lv inline void
ll n,q,k,ans;
ll a[200005];
int b[205][205];
vector<int> e[200005];
ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||'9'<ch){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch&15);
		ch=getchar();
	}
	return x*f;
}
lv inPut(){
	memset(b,0x7f,sizeof(b));
	n=read(),q=read(),k=read();
	for(int i=1; i<=n; i++) a[i]=read();
	for(int i=1; i<n; i++){
		int u=read(),v=read();
		if(k==1){
			e[u].push_back(v);
			e[v].push_back(u);
		}else b[u][v]=b[v][u]=1;
	}
}
lv rwork(){
	for(int t=1; t<=n; t++)
		for(int i=1; i<=n; i++){
			if(k==i||b[i][t]>=k) continue;
			for(int j=1; j<=n; j++){
				if(j==i||j==k) continue;
				b[i][j]=min(b[i][j],b[i][t]+b[t][j]);
			}
		}
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			if(b[i][j]<=k)
				e[i].push_back(j);
}
bool vis[200005];
int doit(int x,int fa,int l,ll res){
	if(x==l) ans=min(ans,res);
	for(int i=0; i<e[x].size(); i++){
		int to=e[x][i];
		if(fa==to||vis[to]) continue;
		vis[to]=1;
		doit(to,x,l,res+a[to]);
		vis[to]=0;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	inPut();
	if(k!=1) rwork();
	for(int i=1; i<=q; i++){
		int s=read(),l=read();
		ans=1e18;
		vis[s]=1;
		doit(s,0,l,0);
		vis[s]=0;
		ans+=a[s];
		printf("%lld\n",ans);
	}
}