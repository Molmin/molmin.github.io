#include<bits/stdc++.h>
using namespace std;
#define rint register int
#define ll long long
#define lv inline void
int q;
ll a[100005],b[100005];
ll res[100005];
ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||'9'<ch){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch&15);
		ch=getchar();
	}
	return x*f;
}
lv inPut(){
	int n=read(),m=read();
	q=read();
	for(rint i=1; i<=n; i++) a[i]=read();
	for(rint i=1; i<=m; i++) b[i]=read();
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	inPut();
	for(rint i=1; i<=q; i++){
		memset(res,0x7f,sizeof(res));
		int l1=read(),r1=read(),l2=read(),r2=read();
		for(rint i=l1; i<=r1; i++)
			for(rint j=l2; j<=r2; j++)
				res[i]=min(res[i],a[i]*b[j]);
		ll ans=-1e18;
		for(rint i=l1; i<=r1; i++)
			ans=max(ans,res[i]);
		printf("%lld\n",ans);
	}
}