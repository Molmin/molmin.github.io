#include<bits/stdc++.h>
using namespace std;
#define rint register int
#define ll long long
#define lv inline void
int n,m,t;
int a[2505];
int b[2505][2505];
vector<int> e[2505];
ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||'9'<ch){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch&15);
		ch=getchar();
	}
	return x*f;
}
lv inPut(){
	memset(b,0x3f,sizeof(b));
	n=read(),m=read(),t=read();
	for(rint i=2; i<=n; i++) a[i]=read();
	for(rint i=1; i<=m; i++){
		int u=read(),v=read();
		b[u][v]=b[v][u]=1;
	}
}
lv rwork(){
	for(rint k=1; k<=n; k++)
		for(rint i=1; i<=n; i++){
			if(i==k||b[i][k]>=k+1) continue;
			for(rint j=1; j<=n; j++){
				if(i==j||k==j) continue;
				b[i][j]=min(b[i][j],b[i][k]+b[k][j]);
			}
		}
	for(rint i=1; i<=n; i++)
		for(rint j=1; j<=n; j++)
			if(b[i][j]<=t+1) e[i].push_back(j);
}
int ans;
int vis[2505];
lv doit(int x,int res,int k){
	if(k==4){
		if(b[x][1]<=t+1) ans=max(ans,res);
		return;
	}
	for(rint i=0; i<e[x].size(); i++){
		int to=e[x][i];
		if(vis[to]) continue;
		vis[to]=1;
		doit(to,res+a[to],k+1);
		vis[to]=0;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	inPut();
	rwork();
	vis[1]=1;
	doit(1,0,0);
	printf("%d",ans);
}