#include<bits/stdc++.h>
using namespace std;
#define rint register int
#define ll long long
#define lv inline void
struct data{
	int to;
	bool use;
};
int n,m,q;
int out[500005],o0,o1,od;
vector<data> e[500005];
ll read(){
	ll x=0,f=1;
	char ch=getchar();
	while(ch<'0'||'9'<ch){
		if(ch=='-') f=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch&15);
		ch=getchar();
	}
	return x*f;
}
bool cmp(data x,data y){
	return x.to<y.to;
}
lv inPut(){
	n=read(),m=read();
	for(rint i=1; i<=m; ++i){
		int u=read(),v=read();
		e[u].push_back({v,1});
		out[u]++;
	}
	for(rint i=1; i<=n; i++)
		sort(e[i].begin(),e[i].end(),cmp);
	for(rint i=1; i<=n; i++)
		if(!out[i]) o0++;
		else if(out[i]==1) o1++;
		else od++;
	q=read();
}
lv les(int x){
	out[x]--;
	if(out[x]==1) o1++,od--;
	else if(!out[x]) o1--,o0++;
}
lv broke(int x,int y){
	for(int i=0; i<e[x].size(); i++){
		int to=e[x][i].to;
		if(to==y){
			if(e[x][i].use) les(x);
			e[x][i].use=0;
			break;
		}
	}
}
lv dele(int x){
	for(rint i=1; i<=n; i++)
		for(rint j=0; j<e[i].size(); j++){
			int to=e[i][j].to;
			if(to==x){
				if(e[i][j].use) les(i);
				e[i][j].use=0;
			}else if(to>x) break;
		}
}
lv more(int x){
	out[x]++;
	if(out[x]==1) o0--,o1++;
	else if(out[x]==2) o1--,od++;
}
lv fix(int x,int y){
	for(int i=0; i<e[x].size(); i++){
		int to=e[x][i].to;
		if(to==y){
			if(!e[x][i].use) more(x);
			e[x][i].use=1;
			break;
		}
	}
}
lv repl(int x){
	for(rint i=1; i<=n; i++)
		for(rint j=0; j<e[i].size(); j++){
			int to=e[i][j].to;
			if(to==x){
				if(!e[i][j].use) more(i);
				e[i][j].use=1;
				break;
			}else if(to>x) break;
		}
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	inPut();
	if(o0){
		for(int i=1; i<=q; i++)
			printf("NO\n");
		return 0;
	}
	for(rint i=1; i<=q; i++){
		int ope=read();
		if(ope==1){
			int a=read(),b=read();
			broke(a,b);
		}else if(ope==2){
			int a=read();
			dele(a);
		}else if(ope==3){
			int a=read(),b=read();
			fix(a,b);
		}else if(ope==4){
			int a=read();
			repl(a);
		}
		if(o1!=n) printf("NO\n");
		else printf("YES\n");
	}
}