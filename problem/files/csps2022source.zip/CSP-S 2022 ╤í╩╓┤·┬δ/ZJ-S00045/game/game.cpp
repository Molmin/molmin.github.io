#include<bits/stdc++.h>
typedef long long LL;
using namespace std;
int n, m, q;
LL a[100001], b[100001];
int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	for(int i=1;i<=n;i++)
		scanf("%lld", &a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld", &b[i]);
	while(q--)
	{
		int al, ar, bl, br;
		scanf("%d%d%d%d", &al, &ar, &bl, &br);
		long long Max=0x8080808080808080;
		for(int i=al;i<=ar;i++)
		{
			long long Min=0x7f7f7f7f7f7f7f7f;
			for(int j=bl;j<=br;j++)
				Min=min(Min, a[i]*b[j]);
			Max=max(Max, Min);
		}
		printf("%lld\n", Max);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
