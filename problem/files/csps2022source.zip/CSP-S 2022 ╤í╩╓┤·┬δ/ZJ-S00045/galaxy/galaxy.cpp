#include<bits/stdc++.h>
template<typename type>
void read(type &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!('0'<=ch && ch<='9'))
		ch=getchar();
	while('0'<=ch && ch<='9')
	{
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=f;
}
typedef long long LL;
using namespace std;
int n, m, q;
struct data
{
	int to;
	bool Exist;
};
vector<data> ing[500001];
vector<data> outg[500001];
bool Used[500001];
bool L()
{
	memset(Used, false, sizeof(Used));
	queue<int> q;
	q.push(1);
	int cnt=0;
	while(!q.empty())
	{
		int t=q.front();q.pop();
		for(int i=0;i<outg[t].size();i++)
		{
			int to=outg[t][i].to;
			if(Used[to]) continue;
			Used[to]=true;
			q.push(to);
			cnt++;
		}
	}
	if(cnt==n)
		return true;
	else
		return false;
}
bool Check(int in[], int out[])
{
	memset(Used, false, sizeof(Used));
	stack<int> st;
	for(int i=1;i<=n;i++)
	{
		if(!in[i])
		{
			st.push(i);
			Used[i]=true;
		}
		if(out[i]!=1)
			return false;
	}
	queue<int> az;
	int cnt=0;
	while(!st.empty())
	{
		int t=st.top();st.pop();
		cnt++;
		for(int i=0;i<outg[t].size();i++)
		{
			if(!outg[t][i].Exist || Used[i]) continue;
			int to=outg[t][i].to;
			Used[to]=true;
			az.push(to);
			in[to]--;
			if(!in[to])
				st.push(to);
		}
	}
	while(!az.empty())
	{
		in[az.front()]++;
		az.pop();
	}
	if(cnt!=n)
		return true;
	else
		return false;
}
int in[500001], out[500001];
int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	read(n), read(m);
	for(int i=1;i<=m;i++)
	{
		int u, v;
		read(u), read(v);
		out[u]++, in[v]++;
		outg[u].push_back({v, true});
		ing[v].push_back({u, true});
	}
	read(q);
	while(q--)
	{
		int type;
		read(type);
		if(type==1)
		{
			int u, v;
			read(u), read(v);
			for(int i=0;i<outg[u].size();i++)
			{
				int to=outg[u][i].to;
				if(to==v)
				{
					outg[u][i].Exist=false;
					out[u]--;
					break;
				}
			}
			for(int i=0;i<ing[v].size();i++)
			{
				int to=ing[v][i].to;
				if(to==u)
				{
					ing[v][i].Exist=false;
					in[v]--;
					break;
				}
			}
		}
		if(type==2)
		{
			int u;
			read(u);
			for(int i=0;i<ing[u].size();i++)
			{
				int to=ing[u][i].to;
				if(!ing[u][i].Exist) continue;
				ing[u][i].Exist=false, in[u]--;
				for(int j=0;j<outg[to].size();j++)
				{
					int too=outg[to][j].to;
					if(too==u)
					{
						outg[to][j].Exist=false, out[to]--;
						break;
					}
				}
			}
		}
		if(type==3)
		{
			int u, v;
			read(u), read(v);
			for(int i=0;i<outg[u].size();i++)
			{
				int to=outg[u][i].to;
				if(to==v)
				{
					outg[u][i].Exist=true;
					out[u]++;
					break;
				}
			}
			for(int i=0;i<ing[v].size();i++)
			{
				int to=ing[v][i].to;
				if(to==u)
				{
					ing[v][i].Exist=true;
					in[v]++;
					break;
				}
			}
		}
		if(type==4)
		{
			int u;
			read(u);
			for(int i=0;i<ing[u].size();i++)
			{
				int to=ing[u][i].to;
				if(ing[u][i].Exist) continue;
				ing[u][i].Exist=true, in[u]++;
				for(int j=0;j<outg[to].size();j++)
				{
					int too=outg[to][j].to;
					if(too==u)
					{
						outg[to][j].Exist=true, out[to]++;
						break;
					}
				}
			}
		}
		if(Check(in, out) && L())
			printf("YES\n");
		else
			printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/
