#include<bits/stdc++.h>
template<typename type>
void read(type &x)
{
	x=0;
	int f=1;
	char ch=getchar();
	while(!('0'<=ch && ch<='9'))
		ch=getchar();
	while('0'<=ch && ch<='9')
	{
		x=(x<<1)+(x<<3)+ch-'0';
		ch=getchar();
	}
	x*=f;
}
typedef long long LL;
using namespace std;
int n, m, K;
LL dis[2501][2501];
LL Val[2501];
bool Used[2501];
LL ans;
void dfs(int x, LL sum, int cnt)
{
	if(cnt==4)
	{
		if(dis[x][1]>K)
			return ;
		ans=max(ans, sum);
	}
	bool flag=true;
	for(int i=2;i<=n;i++)
	{
		if(i==x || Used[i] || dis[x][i]>K) continue;
		flag=false;
		Used[i]=true;
		dfs(i, sum+Val[i], cnt+1);
		Used[i]=false;
	}
}
int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(dis, 0x3f, sizeof(dis));
	read(n), read(m), read(K);
//	printf("%d", n);
	for(int i=2;i<=n;i++)
		read(Val[i]);
	for(int i=1;i<=m;i++)
	{
		int x, y;
		read(x), read(y);
		dis[x][y]=dis[y][x]=1;
	}
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
		{
			if(k==i) continue;
			for(int j=1;j<=n;j++)
			{
				if(i==j || k==j) continue;
				dis[i][j]=min(dis[i][j], dis[i][k]+dis[k][j]);
			}
		}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			dis[i][j]--;
	dfs(1, 0, 0);
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/