//rp++
#include<bits/stdc++.h>
using namespace std;

int n,m,u,v,q;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	cin>>n>>m;
	
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	while(m--)
		cin>>u>>v;
	
	cin>>q;
	while(q--)
	{
		cin>>n;
		
		if(n==1||n==3)
			cin>>u>>v;
		
		else if(n==2||n==4)
			cin>>u;
		
		cout<<"NO"<<endl;
	}
}
