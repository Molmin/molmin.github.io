#include<bits/stdc++.h>
#define ll long long
#define N 2505
#define M 10005
using namespace std;

struct Edge
{
	int to,nxt;
}e[M];

int head[N],cnt;
int n,m,k;
ll a[N],sum,b[N],ans;

bool g[N][N],vis[N];

inline void add(const int& u,const int& v)
{
	e[++cnt].to=v;
	e[cnt].nxt=head[u];
	head[u]=cnt;
}

void DFS(const int& root,const int& u,const int& dep)
{
	if(dep>k+1)
		return;
	
	g[root][u]=g[u][root]=true;
	
	for(int i=head[u];i;i=e[i].nxt)
		if(!g[root][e[i].to])
			DFS(root,e[i].to,dep+1);
}

bool DFS_ans(const int& u,const int& step,const ll& value)
{
	if(step==5)
		return u==1;
	
	if(u==1&&step!=0)
		return false;
	
	bool flag=false;
	for(int i=1;i<=n;i++)
		if(g[u][i]&&(!vis[i]))
		{
			vis[i]=true;
			if(DFS_ans(i,step+1,value+a[i]))
				ans=max(ans,value+a[i]),flag=true;
			vis[i]=false;
		}
	
	return flag;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++)
		cin>>a[i];
	
	int x,y;
	for(int i=1;i<=m;i++)
		cin>>x>>y,add(x,y),add(y,x);
	
	for(int i=1;i<=n;i++)
		DFS(i,i,0);
	
	DFS_ans(1,0,0);
	cout<<ans<<endl;
}
