#include<bits/stdc++.h>
#define ll long long
#define N 100005
using namespace std;

struct Node
{
	ll maxn,minn,l,r,z_zero,f_zero;
}ta[N<<2],tb[N<<2];

int n,m,q;
ll a[N],b[N];

void build(const int& x,const int& l,const int& r,const ll * a,Node* t)
{
	t[x].l=l;
	t[x].r=r;
	
	if(l==r)
	{
		t[x].maxn=a[l];
		t[x].minn=a[l];
		if(a[l]>0)
		{
			t[x].z_zero=a[l];
			t[x].f_zero=-1e10;
		}
		
		if(a[l]<0)
		{
			t[x].z_zero=1e10;
			t[x].f_zero=a[l];
		}
		
		return;
	}
	
	int mid=l+r>>1;
	build(x<<1,l,mid,a,t);
	build(x<<1|1,mid+1,r,a,t);
	
	t[x].maxn=max(t[x<<1].maxn,t[x<<1|1].maxn);
	t[x].minn=min(t[x<<1].minn,t[x<<1|1].minn);
	t[x].z_zero=min(t[x<<1].z_zero,t[x<<1|1].z_zero);
	t[x].f_zero=max(t[x<<1].f_zero,t[x<<1|1].f_zero);
}

ll query_min(const int& x,const int& l,const int& r,const ll * a,const Node* t)
{
	if(t[x].l>r||t[x].r<l)
		return 1e10;
	
	if(t[x].l>=l&&t[x].r<=r)
		return t[x].minn;
	
	return min(query_min(x<<1,l,r,a,t),query_min(x<<1|1,l,r,a,t));
}

ll query_f_zero(const int& x,const int& l,const int& r,const ll * a,const Node* t)
{
	if(t[x].l>r||t[x].r<l)
		return -1e10;
	
	if(t[x].l>=l&&t[x].r<=r)
		return t[x].f_zero;
	
	return max(query_f_zero(x<<1,l,r,a,t),query_f_zero(x<<1|1,l,r,a,t));
}

ll query_max(const int& x,const int& l,const int& r,const ll * a,const Node* t)
{
	if(t[x].l>r||t[x].r<l)
		return -1e10;
	
	if(t[x].l>=l&&t[x].r<=r)
		return t[x].maxn;
	
	return max(query_max(x<<1,l,r,a,t),query_max(x<<1|1,l,r,a,t));
}

ll query_z_zero(const int& x,const int& l,const int& r,const ll * a,const Node* t)
{
	if(t[x].l>r||t[x].r<l)
		return 1e10;
	
	if(t[x].l>=l&&t[x].r<=r)
		return t[x].z_zero;
	
	return min(query_z_zero(x<<1,l,r,a,t),query_z_zero(x<<1|1,l,r,a,t));
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=m;i++)
		cin>>b[i];
	
	build(1,1,n,a,ta);
	build(1,1,m,b,tb);
	
	int l1,l2,r1,r2;
	ll amin,amax,bmin,bmax,a_z_zero,a_f_zero,b_z_zero,b_f_zero;
	
	while(q--)
	{
		cin>>l1>>r1>>l2>>r2;
		
		amin=query_min(1,l1,r1,a,ta),amax=query_max(1,l1,r1,a,ta);
		bmin=query_min(1,l2,r2,b,tb),bmax=query_max(1,l2,r2,b,tb);
		
		if(amax<=0&&bmax>=0)
			cout<<amax*bmax<<endl;
		
		else if(amax<=0&&bmax<=0)
			cout<<amin*bmax<<endl;
		
		else if(bmin>=0)
			cout<<amax*bmin<<endl;
		
		else if(amin<=0&&bmax<=0)
			cout<<amin*bmax<<endl;
		
		else if(amin<=0)
		{
			a_z_zero=query_z_zero(1,l1,r1,a,ta);
			a_f_zero=query_f_zero(1,l1,r1,a,ta);
			//b_z_zero=query_z_zero(1,l2,r2,b,tb);
			//b_f_zero=query_f_zero(1,l2,r2,b,tb);

			cout<<max(a_f_zero*bmax,a_z_zero*bmin)<<endl;
		}
			
		else
			cout<<amin*bmin<<endl;
	}
}
