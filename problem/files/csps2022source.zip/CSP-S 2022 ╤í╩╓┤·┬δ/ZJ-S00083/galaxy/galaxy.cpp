#include<bits/stdc++.h>
using namespace std;
int n,m,i,x,u,v,fl,fl1,T,f[1010][1010],e[1010],h[1010],l[1010];
bool pd(int x){
	int fl1;
	if(l[x])return false;
	l[x]=1;
	for(int i=1;i<=n;i++)
		if(f[x][i]&&e[i]&&(!h[x]&&!h[i])){
			fl1=pd(i);
			if(!fl1)return false;
		}
	l[x]=0;
	return true;
}
void dfs(int x){
	if(fl||!fl1)return;
	if(h[x]){
		fl=1;
		for(int i=1;i<=n;i++)
			if(!h[i]){
				memset(l,0,sizeof(l));
				if(!pd(i)){fl1=0;break;}
			}
		return;
	}
	h[x]=1;
	for(int i=1;i<=n;i++)
		if(f[x][i]&&e[i])dfs(i);
	h[x]=0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)scanf("%d%d",&u,&v),f[u][v]=1,e[v]=1;
	cin>>T;
	while(T--){
		scanf("%d",&x);fl=0;fl1=1;
		if(x==1)scanf("%d%d",&u,&v),f[u][v]=0;
		else if(x==2)scanf("%d",&u),e[u]=0;
		else if(x==3)scanf("%d%d",&u,&v),f[u][v]=1;
		else scanf("%d",&u),e[u]=1;
		dfs(1);
		if(fl&&fl1)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
