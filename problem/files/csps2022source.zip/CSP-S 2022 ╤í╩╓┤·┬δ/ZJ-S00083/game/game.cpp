#include<bits/stdc++.h>
using namespace std;
long long n,m,k,i,j,l,r,x,y,mi,aa,bb,t,w,a[100010],b[100010],c[100010],d[100010];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(i=1;i<=m;i++)scanf("%lld",&b[i]);
	for(i=1;i<=k;i++){
		cin>>l>>r>>x>>y;t=w=aa=bb=0;
		for(j=l;j<=r;j++)c[++t]=a[j];
		for(j=x;j<=y;j++)d[++w]=b[j];
		sort(c+1,c+1+t);sort(d+1,d+1+w);
		if(c[t]>0&&d[1]>0)aa=c[t];
		else if(c[t]>0&&d[1]<0){
			if(c[1]<0&&d[w]<0)aa=c[1];
			else{
				mi=2e9;
				if(abs(d[1])>abs(d[w])){
					for(j=1;j<=t;j++)
						if(mi>abs(c[j]))mi=abs(c[j]),aa=c[j];
				}
				else{
					for(j=1;j<=t;j++)
						if(mi>=abs(c[j]))mi=abs(c[j]),aa=c[j];
				}
			}
		}
		else if(c[t]<0&&d[w]<0)aa=c[1];
		else{
			mi=2e9;
			if(abs(d[1])>abs(d[w])){
				for(j=1;j<=t;j++)
					if(mi>abs(c[j]))mi=abs(c[j]),aa=c[j];
			}
			else{
				for(j=1;j<=t;j++)
					if(mi>=abs(c[j]))mi=abs(c[j]),aa=c[j];
			}
		}
		if(aa>0)bb=d[1];
		else if(aa<0)bb=d[w];
		else bb=d[1];
		printf("%lld\n",aa*bb);
	}
	return 0;
}
