#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,k,i,u,v,t,ma,a[200010],head[20010],f[20010],e[20010];
struct no{int v,next;}b[20010];
void add(int u,int v){b[++t].v=v;b[t].next=head[u];head[u]=t;}
bool pd(int x,int l){
	int fl;
	if(l<=k){
		if(x==1)return true;
		for(int i=head[x];i;i=b[i].next)
			if(!e[b[i].v]){
				e[b[i].v]=1;fl=pd(b[i].v,l+1);e[b[i].v]=0;
				if(fl)return true;
			}
	}
	return false;
}
void dfs(int x,int s,int t,int l){
	if(t==4){
		if(pd(x,-1)){
			ma=max(ma,s);
		}
		return;
	}
	for(int i=head[x];i;i=b[i].next){
		if(!f[b[i].v])f[b[i].v]=1,dfs(b[i].v,s+a[b[i].v],t+1,0),f[b[i].v]=0;
		if(l+1<=k)dfs(b[i].v,s,t,l+1);
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(i=2;i<=n;i++)scanf("%lld",&a[i]);
	for(i=1;i<=m;i++)scanf("%lld%lld",&u,&v),add(u,v),add(v,u);
	f[1]=1;dfs(1,0,0,-1);printf("%lld",ma);
	return 0;
} 
