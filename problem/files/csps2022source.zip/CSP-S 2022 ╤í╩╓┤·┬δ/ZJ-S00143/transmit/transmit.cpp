#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
int siz[N],tp[N],dfn[N],a[N],c[N],h[N];
int ecnt,fa[N],son[N],dp[N],cnt,b[N],kk[N],f[N];
int n,k,T,i,x,y;
struct edge{
	int to,nex;
}e[N*2];
void add(int x,int y){
	e[++ecnt]=(edge){y,h[x]};
	h[x]=ecnt;
}
void dfs(int x){
	siz[x]=1;
	for(int i=h[x];i;i=e[i].nex){
		int to=e[i].to;
		if(fa[x]==to)continue;
		fa[to]=x;
		dfs(to);
		siz[x]+=siz[to];
		if(siz[to]>siz[son[x]])
			son[x]=to;
	}
}
void dfss(int x,int top){
	tp[x]=top;dp[x]=dp[fa[x]]+1;
	dfn[x]=++cnt;a[cnt]=x;
	if(son[x])dfss(son[x],top);
	for(int i=h[x];i;i=e[i].nex){
		int to=e[i].to;
		if(fa[x]==to)continue;
		if(son[x]==to)continue;
		dfss(to,to);
	}
}
int LCA(int x,int y){
	int t=0,w=0;
	while(tp[x]!=tp[y]){
//		cout<<dp[x]<<' '<<dp[y]<<'\n';
		if(dp[tp[x]]<dp[tp[y]]){
			for(int i=dfn[y];i>=dfn[tp[y]];i--)
				b[++w]=c[a[i]];
			y=fa[tp[y]];
		}
		else{
			for(int i=dfn[x];i>=dfn[tp[x]];i--)
				kk[++t]=c[a[i]];
			x=fa[tp[x]];
		}
	}
	if(dp[x]<dp[y]){
		for(int i=dfn[y];i>=dfn[x];i--)
			b[++w]=c[a[i]];
	}
	else{
		for(int i=dfn[x];i>=dfn[y];i--)
			kk[++t]=c[a[i]];
	}
	for(int i=w;i>=1;i--)
		kk[++t]=b[i];
//	for(int i=1;i<=t;i++)cout<<kk[i]<<' ';
//	cout<<"\n\n\n";
	for(int i=1;i<=k;i++)f[i]=kk[1]+kk[i];
	f[1]-=kk[1];
	for(int i=k+1;i<=t;i++){
		f[i]=LLONG_MAX;
		for(int j=i-k;j<i;j++)
			f[i]=min(f[i],f[j]+kk[i]);
	}
//	for(int i=1;i<=t;i++)cout<<f[i]<<' ';
//	cout<<"\n\n\n";
	return f[t];
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>T>>k;
	for(i=1;i<=n;i++)cin>>c[i];
	for(i=1;i<n;i++)cin>>x>>y,add(x,y),add(y,x);
	dfs(1);dfss(1,1);
	while(T--){
		cin>>x>>y;
		cout<<LCA(x,y)<<'\n';
	}
	return 0;
}
//10 1 3
//835701672 912572995 368308854 156367225 251245604 788978650 385396264 960190423
//51944511 479806606
//2 1
//3 2
//4 2
//5 3
//6 3
//7 2
//8 7
//9 1
//10 9
//5 10

//208311736
