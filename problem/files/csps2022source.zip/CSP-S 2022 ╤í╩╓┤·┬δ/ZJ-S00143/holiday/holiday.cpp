#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2500+5;
const int M=1e4+5;
int n,m,k,ecnt,h[N],f[N][N],dis[N][N],ans,i,j,kk,l,x,y,a[N]; 
struct edge{
	int to,nex;
}e[M*8+N*3];
void add(int x,int y){
	e[++ecnt]=(edge){y,h[x]};
	h[x]=ecnt;
}
//struct node{
//	int ans,ma,dis,third;
//	bool operator < (const node & a)const{
//		if(a.ans+a.ma>ans+ma)return 1;
//		if(a.ans+a.ma==ma+ans&&a.dis<dis)return 1;
//		return 0;
//	}
//};
//priority_queue<node> q;
//void Dij(int x){
//	memset(vis,0,sizeof(vis));
//	memset(dis,125,sizeof(dis));
//	ma[x]=INT_MAX;dis[x]=-1;
//	q.push((node){0,INT_MAX,-1,x});
//	while(!q.empty()){
//		x=q.top().third;
////		cout<<q.top().ma<<' '<<q.top().dis<<'\n';
////		cout<<x<<'\n';
//		q.pop();
//		if(vis[x])continue;
//		vis[x]=1;
//		for(int i=h[x];i;i=e[i].nex){
//			int to=e[i].to;
////			cout<<to<<' '<<x<<'\n';
//			if((to-x)%n!=0){
//				if(dis[x]==k)continue;
//				if(ma[to]==ma[0])ma[to]=a[to];
//				if((dis[x]+1<=k&&ans[x]+ma[x]>ans[to]+ma[to])||(dis[x]+1<dis[to]&&ans[x]+ma[x]==ans[to]+ma[to])){
//					if(x!=1)ma[to]=ma[x];
//					ans[to]=ans[x];
//					dis[to]=dis[x]+1;
//					if(vis[to])continue;
//					q.push((node){ans[to],ma[to],dis[to],to});
//				}
//			}
//			else{
//				if(ma[x]>ma[to]){
//					if(x!=1)ans[to]+=ma[x];
//					else ans[to]=ma[x];
//					ma[to]=ma[x];
//					dis[to]=-1;
//					if(vis[to])continue;
//					q.push((node){ans[to],ma[to],dis[to],to});
//				}
//			}
//		}
//	}
//}
int ma,sum,vis[N];
void dfs(int x,int dp){
	vis[x]=1;
//	cout<<x<<' '<<dp<<' '<<sum<<'\n';
	if(dp>4){
		int i;
		for(i=h[x];i;i=e[i].nex){
			int to=e[i].to;
			if(to==1)break;
		}
		if(i)ma=max(ma,sum);
		return;
	}
	for(int i=h[x];i;i=e[i].nex){
		int to=e[i].to;
		if(vis[to])continue;
		sum+=a[to];
		dfs(to,dp+1);
		sum-=a[to];
	}
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	int i;
	memset(f,125,sizeof(f));
	for(i=2;i<=n;i++)cin>>a[i],f[i][i]=0;f[1][1]=0;
	for(i=1;i<=m;i++)
		cin>>x>>y,f[x][y]=f[y][x]=1,add(x,y),add(y,x);
	if(k==0){
		dfs(1,1);
		cout<<ma;
		return 0;
	}
	for(kk=1;kk<=n;kk++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if(f[i][kk]!=f[0][0]&&f[kk][j]!=f[0][0])
					f[i][j]=min(f[i][j],f[i][kk]+f[kk][j]);
//	cout<<f[5][8]<<'\n';
	for(i=1;i<=n;i++){
		if(f[1][i]<=k+1)
			for(j=1;j<=n;j++)
				if(i!=j&&f[i][j]<=k+1)
					for(kk=1;kk<=n;kk++)
						if(j!=kk&&i!=kk&&f[j][kk]<=k+1)
							for(l=1;l<=n;l++)
								if(l!=kk&&i!=l&&j!=l&&f[kk][l]<=k+1&&f[l][1]<=k+1){
									ans=max(ans,a[i]+a[j]+a[kk]+a[l]);
//									if(a[i]+a[j]+a[kk]+a[l]==30){
//										cout<<i<<' '<<j<<' '<<kk<<' '<<l<<'\n';
//									}
								}
	}
	cout<<ans;
	return 0;
}
//belief2022
