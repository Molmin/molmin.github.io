#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+5;
int n,m,ma[N][25],mi[N][25],T,a[N],l1,l2,b[N],r1,r2,ma1[N][25],mi1[N][25],ze1[N][25],ze2[N][25];
struct node{
	int mx,mn;
};
node ask(int l,int r){
	int s1=log2(r-l+1);
//	cout<<"asdads"<<min(mi[l][s1],mi[r-(1<<s1)+1][s1])<<'\n';
	return (node){max(ma[l][s1],ma[r-(1<<s1)+1][s1]),min(mi[l][s1],mi[r-(1<<s1)+1][s1])};
}
node ask1(int l,int r){
	int s1=log2(r-l+1);
	return (node){max(ma1[l][s1],ma1[r-(1<<s1)+1][s1]),min(mi1[l][s1],mi1[r-(1<<s1)+1][s1])};
}
node ask2(int l,int r){
	int s1=log2(r-l+1);
	return (node){min(ze1[l][s1],ze1[r-(1<<s1)+1][s1]),max(ze2[l][s1],ze2[r-(1<<s1)+1][s1])};
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m>>T;
	int i,len,s1,j;
	for(i=1;i<=n;i++){
		cin>>a[i],ma[i][0]=mi[i][0]=a[i];
		if(a[i]>=0)ze1[i][0]=a[i],ze2[i][0]=INT_MIN;
		else ze2[i][0]=a[i],ze1[i][0]=INT_MAX;
	}
	for(i=1;i<=m;i++){
		cin>>b[i],ma1[i][0]=mi1[i][0]=b[i];
	}
	for(i=1;(1<<i)<=n;i++){
		len=1<<i;s1=1<<(i-1);
		for(j=1;j<=n-len+1;j++)
			ma[j][i]=max(ma[j][i-1],ma[j+s1][i-1]),
			mi[j][i]=min(mi[j][i-1],mi[j+s1][i-1]);
	}
	for(i=1;(1<<i)<=m;i++){
		len=1<<i;s1=1<<(i-1);
		for(j=1;j<=m-len+1;j++)
			ma1[j][i]=max(ma1[j][i-1],ma1[j+s1][i-1]),
			mi1[j][i]=min(mi1[j][i-1],mi1[j+s1][i-1]);
	}
	for(i=1;(1<<i)<=n;i++){
		len=1<<i;s1=1<<(i-1);
		for(j=1;j<=n-len+1;j++)
			ze2[j][i]=max(ze2[j][i-1],ze2[j+s1][i-1]),
			ze1[j][i]=min(ze1[j][i-1],ze1[j+s1][i-1]);
	}
	while(T--){
		cin>>l1>>r1>>l2>>r2;
		node s1,s2;
		s1=ask(l1,r1);
		s2=ask1(l2,r2);
//		cout<<s1.mn<<' '<<s1.mx<<'\n';
//		cout<<s2.mn<<' '<<s2.mx<<'\n';
		if(s1.mx>=0&&s2.mn>=0)
			cout<<s1.mx*s2.mn<<'\n';
		else if(s1.mx>=0){
			if(s1.mn>=0)cout<<s1.mn*s2.mn<<'\n';
			else{
				if(s2.mx>=0){
					node s3;
					s3=ask2(l1,r1);
					cout<<max(s3.mx*s2.mn,s3.mn*s2.mx)<<'\n';
				}
				else cout<<s1.mn*s2.mx<<'\n';
			}
		}
		if(s1.mx<0&&s2.mx<0)
			cout<<s1.mn*s2.mx<<'\n';
		else if(s1.mx<0){//s2.mx>=0
			cout<<s1.mx*s2.mx<<'\n';
		}
	}
	return 0;
}
//belief2022
