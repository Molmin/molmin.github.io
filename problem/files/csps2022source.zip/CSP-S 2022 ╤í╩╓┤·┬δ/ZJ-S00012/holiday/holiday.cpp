#include <stdio.h>
#include <string.h>
#define MAXN 2510
#define MAXM 10010
#define LL long long

int n,m,k;
LL s[MAXN],ans;
int visited[MAXN],p[MAXN][MAXN];

LL max(LL a,LL b){
	return a>b?a:b;
}

void dfs(int cur,int dep,LL sc){
	if(dep==4){
		if(p[cur][1]>k+1)return;
		ans=max(ans,sc);
	}
	for(int i=2;i<=n;i++){
		if(i!=cur&&!visited[i]&&p[cur][i]<=k+1){
			visited[i]=1;
			dfs(i,dep+1,sc+s[i]);
			visited[i]=0;
		}
	}
}

void floyd(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				if(i!=j&&j!=k&&i!=k)
					if(p[i][k]+p[k][j]<p[i][j])
						p[i][j]=p[i][k]+p[k][j];
}

int main(){
	FILE *fin,*fout;
	fin=fopen("holiday.in","r");
	fout=fopen("holiday.out","w");
	fscanf(fin,"%d%d%d",&n,&m,&k);
	s[1]=0;
	for(int i=2;i<=n;i++){
		fscanf(fin,"%lld",&s[i]);
	}
	int x,y;
	memset(p,0x3f,sizeof(p));
	for(int i=1;i<=m;i++){
		fscanf(fin,"%d%d",&x,&y);
		p[x][y]=p[y][x]=1;
	}
	floyd();
	memset(visited,0,sizeof(visited));
	ans=0;
	dfs(1,0,0);
	fprintf(fout,"%lld\n",ans);
	fclose(fin);
	fclose(fout);
	return 0;
}