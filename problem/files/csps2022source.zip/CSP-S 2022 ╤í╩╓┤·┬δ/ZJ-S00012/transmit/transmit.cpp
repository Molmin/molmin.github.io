#include <stdio.h>
#include <string.h>
#define MAXN 200010
#define ll long long

int n,Q,k;
ll v[MAXN];

struct Edge{
	int to,next;
}edge[MAXN];
int h[MAXN],cnt;

void add_e(int from,int to){
	edge[cnt].to=to;
	edge[cnt].next=h[from];
	h[from]=cnt;
	cnt++;
}

int road[MAXN],visited[MAXN];
int dfs(int cur,int y,int dep){
	road[dep]=cur;
	if(cur==y){
		return dep;
	}
	int tmp;
	for(int i=h[cur];i!=-1;i=edge[i].next){
		if(!visited[edge[i].to]){
			visited[edge[i].to]=1;
			tmp=dfs(edge[i].to,y,dep+1);
			visited[edge[i].to]=0;
			if(tmp!=-1)return tmp;
		}
	}
	return -1;
}

int q[MAXN];
ll dp[MAXN];

int main(){
	FILE *fin,*fout;
	fin=fopen("transmit.in","r");
	fout=fopen("transmit.out","w");
	fscanf(fin,"%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++){
		fscanf(fin,"%lld",&v[i]);
	}
	int x,y;
	memset(h,-1,sizeof(h));
	for(int i=1;i<n;i++){
		fscanf(fin,"%d%d",&x,&y);
		add_e(x,y);add_e(y,x);
	}
	int last,hd,ta;
	ll ans;
	for(int T=0;T<Q;T++){
		fscanf(fin,"%d%d",&x,&y);
		memset(visited,0,sizeof(visited));
		visited[x]=1;
		last=dfs(x,y,0);
		hd=ta=1;
		dp[0]=v[road[0]];q[1]=0;
		for(int i=1;i<=last;i++){
			while(hd<=ta&&q[hd]<i-k)hd++;
			dp[i]=dp[q[hd]]+v[road[i]];
			while(hd<=ta&&dp[i]<=dp[q[ta]])ta--;
			q[++ta]=i;
		}
		fprintf(fout,"%lld\n",dp[last]);
	}
	fclose(fin);
	fclose(fout);
	return 0;
}