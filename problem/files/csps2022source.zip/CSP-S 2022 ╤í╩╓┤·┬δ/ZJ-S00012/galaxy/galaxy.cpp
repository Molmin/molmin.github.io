#include <stdio.h>
#include <string.h>
#define MAXN 500010
#define MAXM 500010
#define INF 0x3f3f3f3f
#define ll long long

int n,m;
struct Edge{
	int to,next,len;
}edge[MAXM];
int h[MAXN],cnt,st_cnt[MAXN];

void add_e(int from,int to,int len){
	edge[cnt].to=to;
	edge[cnt].len=len;
	edge[cnt].next=h[from];
	h[from]=cnt;
	cnt++;
}

int can(int x,int y){
	for(int i=h[x];i!=-1;i=edge[i].next){
		if(edge[i].to==y){
			return edge[i].len==1;
		}
	}
	return 0;
}

int main(){
	FILE *fin,*fout;
	fin=fopen("galaxy.in","r");
	fout=fopen("galaxy.out","w");
	fscanf(fin,"%d%d",&n,&m);
	int x,y,q,cmd;cnt=0;
	memset(h,-1,sizeof(h));
	memset(st_cnt,0,sizeof(st_cnt));
	for(int i=0;i<m;i++){
		fscanf(fin,"%d%d",&x,&y);
		add_e(x,y,1);st_cnt[x]++;
	}
	fscanf(fin,"%d",&q);
	for(int t=0;t<q;t++){
		fscanf(fin,"%d",&cmd);
		switch(cmd){
			case 1:
				fscanf(fin,"%d%d",&x,&y);
				for(int i=h[x];i!=-1;i=edge[i].next){
					if(edge[i].to==y){
						edge[i].len=INF;
						st_cnt[x]--;
						break;
					}
				}
				break;
			case 2:
				fscanf(fin,"%d",&x);
				for(int s=1;s<=n;s++){
					for(int i=h[s];i!=-1;i=edge[i].next){
						if(edge[i].to==x&&edge[i].len!=INF){
							edge[i].len=INF;
							st_cnt[s]--;
							break;
						}
					}
				}
				break;
			case 3:
				fscanf(fin,"%d%d",&x,&y);
				for(int i=h[x];i!=-1;i=edge[i].next){
					if(edge[i].to==y){
						edge[i].len=1;
						st_cnt[x]++;
						break;
					}
				}
				break;
			case 4:
				fscanf(fin,"%d",&x);
				for(int s=1;s<=n;s++){
					for(int i=h[s];i!=-1;i=edge[i].next){
						if(edge[i].to==x&&edge[i].len!=1){
							edge[i].len=1;
							st_cnt[s]++;
							break;
						}
					}
				}
				break;
		}
		int flag=0;
		for(int i=1;i<=n;i++){
			if(st_cnt[i]!=1){
				flag=1;
			}
		}
		if(flag){
			fprintf(fout,"NO\n");continue;
		}
		fprintf(fout,"YES\n");
	}
	fclose(fin);
	fclose(fout);
	return 0;
}