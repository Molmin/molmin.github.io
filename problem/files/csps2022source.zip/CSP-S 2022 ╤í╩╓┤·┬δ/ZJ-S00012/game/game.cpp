#include <stdio.h>
#define MAXN 100010
#define ll long long
#define INF 0x3f3f3f3f

int n,m,q;
ll a[MAXN],b[MAXN],maxa,mina,maxb,minb;
ll aseg[MAXN<<2][2],bseg[MAXN<<2][2];

ll max(ll a,ll b){return a>b?a:b;}
ll min(ll a,ll b){return a<b?a:b;}

void apushup(int rt){
	aseg[rt][0]=min(aseg[rt<<1][0],aseg[rt<<1|1][0]);
	aseg[rt][1]=max(aseg[rt<<1][1],aseg[rt<<1|1][1]);
}

void bpushup(int rt){
	bseg[rt][0]=min(bseg[rt<<1][0],bseg[rt<<1|1][0]);
	bseg[rt][1]=max(bseg[rt<<1][1],bseg[rt<<1|1][1]);
}

void abuild(int rt,int l,int r){
	if(l>=r){
		aseg[rt][0]=aseg[rt][1]=a[l];
		return;
	}
	int m=(l+r)>>1;
	abuild(rt<<1,l,m);
	abuild(rt<<1|1,m+1,r);
	apushup(rt);
}

void bbuild(int rt,int l,int r){
	if(l>=r){
		bseg[rt][0]=bseg[rt][1]=b[l];
		return;
	}
	int m=(l+r)>>1;
	bbuild(rt<<1,l,m);
	bbuild(rt<<1|1,m+1,r);
	bpushup(rt);
}

ll amin_query(int rt,int l,int r,int ql,int qr){
	if(l>qr||r<ql)return INF;
	if(l>=ql&&r<=qr)return aseg[rt][0];
	int m=(l+r)>>1;
	return min(amin_query(rt<<1,l,m,ql,qr),amin_query(rt<<1|1,m+1,r,ql,qr));
}

ll amax_query(int rt,int l,int r,int ql,int qr){
	if(l>qr||r<ql)return -INF;
	if(l>=ql&&r<=qr)return aseg[rt][1];
	int m=(l+r)>>1;
	return max(amax_query(rt<<1,l,m,ql,qr),amax_query(rt<<1|1,m+1,r,ql,qr));
}

ll bmin_query(int rt,int l,int r,int ql,int qr){
	if(l>qr||r<ql)return INF;
	if(l>=ql&&r<=qr)return bseg[rt][0];
	int m=(l+r)>>1;
	return min(bmin_query(rt<<1,l,m,ql,qr),bmin_query(rt<<1|1,m+1,r,ql,qr));
}

ll bmax_query(int rt,int l,int r,int ql,int qr){
	if(l>qr||r<ql)return -INF;
	if(l>=ql&&r<=qr)return bseg[rt][1];
	int m=(l+r)>>1;
	return max(bmax_query(rt<<1,l,m,ql,qr),bmax_query(rt<<1|1,m+1,r,ql,qr));
}

int main(){
	FILE *fin,*fout;
	fin=fopen("game.in","r");
	fout=fopen("game.out","w");
	fscanf(fin,"%d%d%d",&n,&m,&q);
	int flag=1;
	for(int i=1;i<=n;i++){
		fscanf(fin,"%lld",&a[i]);
		if(a[i]<0)flag=0;
	}
	abuild(1,1,n);
	for(int i=1;i<=m;i++){
		fscanf(fin,"%lld",&b[i]);
		if(b[i]<0)flag=0;
	}
	bbuild(1,1,m);
	int l1,r1,l2,r2;ll ans;
	for(int t=0;t<q;t++){
		fscanf(fin,"%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1){
			if(a[l1]>0)ans=a[l1]*bmin_query(1,1,m,l2,r2);
			else ans=a[l1]*bmax_query(1,1,m,l2,r2);
		}
		else if(l2==r2){
			if(b[l2]>0)ans=b[l2]*amax_query(1,1,n,l1,r1);
			else ans=b[l2]*amin_query(1,1,n,l1,r1);
		}
		else if(flag){
			ans=amax_query(1,1,n,l1,r1)*bmin_query(1,1,m,l2,r2);
		}
		else{
			int maxa=amax_query(1,1,n,l1,r1),mina=amin_query(1,1,n,l1,r1),maxb=bmax_query(1,1,m,l2,r2),minb=bmin_query(1,1,m,l2,r2);
			if(minb>=0){
				ans=maxa*minb;
			}
			else if(maxa<=0){
				ans=maxa*minb;
			}
			else{
				ans=0;
			}
		}
		fprintf(fout,"%lld\n",ans);
	}
	fclose(fin);
	fclose(fout);
	return 0;
}