#include<bits/stdc++.h>
using namespace std;
const int N=2521,M=21;
int n,m,k,l[N][N],num[N];
long long v[N],answer=0ll;
int tw[N][N];
inline int dog(int a,int b){ return v[a]<v[b]; }
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n>>m>>k; k++;
	for(int i=2;i<=n;i++) cin>>v[i];
	for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) l[i][j]=2e9+7;
	for(int i=1;i<=m;i++){
		int x,y; cin>>x>>y;
		l[x][y]=l[y][x]=1;
	}
	if(n<=20){
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(i!=j)
			for(int w=1;w<=n;w++) if(i!=w&&j!=w){
				if(l[i][w]==2e9+7||l[j][w]==2e9+7) continue;
				else l[i][j]=min(l[i][j],l[i][w]+l[j][w]);
			}
		for(int i=2;i<=n;i++) if(l[1][i]<=k)
			for(int j=2;j<=n;j++) if(i!=j&&l[i][j]<=k)
				for(int p=2;p<=n;p++) if(i!=p&&j!=p&&l[j][p]<=k)
					for(int q=2;q<=n;q++) if(i!=q&&j!=q&&p!=q&&l[p][q]<=k)
						if(l[q][1]<=k) answer=max(answer,v[i]+v[j]+v[p]+v[q]);
		cout<<answer<<'\n';
	}else if(n<=300){
		for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) if(i!=j)
			for(int w=1;w<=n;w++) if(i!=w&&j!=w){
				if(l[i][w]==2e9+7||l[j][w]==2e9+7) continue;
				else l[i][j]=min(l[i][j],l[i][w]+l[j][w]);
			}
		for(int i=2;i<=n;i++) for(int j=2;j<=n;j++) 
			if(i!=j&&l[i][j]<=k&&l[j][1]<=k) tw[i][++num[i]]=j;
		for(int i=2;i<=n;i++) sort(tw[i]+1,tw[i]+num[i]+1,dog);
		for(int i=2;i<=n;i++) if(l[1][i]<=k)
			for(int j=2;j<=n;j++) if(i!=j&&l[i][j]<=k)
				for(int p=2;p<=n;p++) if(i!=p&&j!=p&&l[j][p]<=k)
					for(int q=num[p];q>=0;q--){
						int qq=tw[p][q];
						long long aa=v[i]+v[j]+v[p]+v[qq];
						if(qq!=i&&qq!=j){
							answer=max(answer,aa);
							break;
						}
					}
		cout<<answer<<'\n';
	}
	return 0;
}
