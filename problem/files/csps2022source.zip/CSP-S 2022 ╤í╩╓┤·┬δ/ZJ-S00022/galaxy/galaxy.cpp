#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,q,t;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	while(m--) cin>>x>>y;
	cin>>q;
	while(q--){
		cin>>t;
		if(t%2) cin>>x>>y;
		else cin>>x;
		cout<<"NO\n";
	}
	return 0;
}
