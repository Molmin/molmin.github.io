#include<bits/stdc++.h>
using namespace std;
const int N=1e5+21;
struct five{
	int xl,nl,xr,nr; bool zo;
	inline void fine(int aa,int bb,int cc,int dd,bool ee){
		xl=aa; nl=bb; xr=cc; nr=dd; zo=ee;
	}
};
int n,m,q,a[N],b[N];
five tree_a[4*N],tree_b[4*N];
inline five update(five aa,five bb){
	five ret;
	ret.fine(max(aa.xl ,bb.xl ),min(aa.nl ,bb.nl ),
		min(aa.xr ,bb.xr ),max(aa.nr ,bb.nr ),aa.zo |bb.zo );
	return ret;
}
void build_a(int l,int r,int rt){
	if(l==r){
		if(a[l]==0) tree_a[rt].fine(-1,2e9,1,-2e9,1); 
		else if(a[l]>0) tree_a[rt].fine(a[l],a[l],1,-2e9,0);
		else tree_a[rt].fine(-1,2e9,a[l],a[l],0);  
		return;
	}
	int mid=(l+r)>>1;
	build_a(l,mid,rt*2); build_a(mid+1,r,rt*2+1);
	tree_a[rt]=update(tree_a[rt*2],tree_a[rt*2+1]);
}
void build_b(int l,int r,int rt){
	if(l==r){
		if(b[l]==0) tree_b[rt].fine(-1,2e9,1,-2e9,1); 
		else if(b[l]>0) tree_b[rt].fine(b[l],b[l],1,-2e9,0);
		else tree_b[rt].fine(-1,2e9,b[l],b[l],0); 
		return; 
	}
	int mid=(l+r)>>1;
	build_b(l,mid,rt*2); build_b(mid+1,r,rt*2+1);
	tree_b[rt]=update(tree_b[rt*2],tree_b[rt*2+1]);
}
five query_a(int l,int r,int rt,int L,int R){
	if(L<=l&&r<=R) return tree_a[rt];
	int mid=(l+r)>>1;
	if(R<=mid) return query_a(l,mid,rt*2,L,R);
	else if(L>mid) return query_a(mid+1,r,rt*2+1,L,R);
	else{
		five ll=query_a(l,mid,rt*2,L,R); 
		five rr=query_a(mid+1,r,rt*2+1,L,R);
		return update(ll,rr);
	}
}
five query_b(int l,int r,int rt,int L,int R){
	if(L<=l&&r<=R) return tree_b[rt];
	int mid=(l+r)>>1;
	if(R<=mid) return query_b(l,mid,rt*2,L,R);
	else if(L>mid) return query_b(mid+1,r,rt*2+1,L,R);
	else{
		five ll=query_b(l,mid,rt*2,L,R); 
		five rr=query_b(mid+1,r,rt*2+1,L,R);
		return update(ll,rr);
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	build_a(1,n,1);
	build_b(1,m,1);
	while(q--){
		int aa,bb,cc,dd;
		cin>>aa>>bb>>cc>>dd;
		five L=query_a(1,n,1,aa,bb),Q=query_b(1,m,1,cc,dd);
		if(Q.xl ==-1){
			if(L.xr ==1){
				if(L.zo ) cout<<"0\n";
				else cout<<L.nl *1ll*Q.xr <<'\n';
			}else{
				if(Q.zo ) cout<<"0\n";
				else cout<<L.xr *1ll*Q.nr <<'\n';
			}
		}else if(Q.xr ==1){
			if(L.xl ==-1){
				if(L.zo ) cout<<"0\n";
				else cout<<L.nr *1ll*Q.xl <<'\n';
			}else{
				if(Q.zo ) cout<<"0\n";
				else cout<<L.xl *1ll*Q.nl <<'\n';
			}
		}else{
			if(L.zo ) cout<<"0\n";
			else cout<<max(L.nl *1ll*Q.xr ,L.nr *1ll*Q.xl )<<'\n';
		}
	}
	return 0;
}
