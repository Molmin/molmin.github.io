#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(k);++i)
#define ForD(i,j,k) for(int i=(j);i>=(k);--i)
#define ll long long
#define inf 0x5f5f5f5f
using namespace std;
ll n,m,q;
ll deg[500005];
vector<ll> E[500005];
vector<ll>fE[500005];
vector<ll>rE[500005];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	For(i,1,m){
		ll u,v;
		cin>>u>>v;
		deg[u]++;
		E[v].push_back(u);
	}
	cin>>q;
	For(i,1,q){
		ll opt;
		cin>>opt;
		if(opt==1){
			ll u,v;
			cin>>u>>v;
			fE[v].push_back(u);
			deg[u]--;
		}else if(opt==2){
			ll u;
			cin>>u;
			ll z=E[u].size();
			For(j,0,z-1){deg[E[u][j]]--;fE[u].push_back(E[u][j]);}
			z=fE[u].size();
			For(j,0,z-1){deg[fE[u][j]]++;rE[u].push_back(fE[u][j]);}
			//fE[u].clear();
			z=rE[u].size();
			For(j,0,z-1){deg[rE[u][j]]--;fE[u].push_back(rE[u][j]);}
			//rE[u].clear();
		}else if(opt==3){
			ll u,v;
			cin>>u>>v;
			rE[v].push_back(u);
			deg[u]++;
		}else if(opt==4){
			ll u;
			cin>>u;
			ll z=fE[u].size();
			For(j,0,z-1){deg[fE[u][j]]++;
			rE[u].push_back(fE[u][j]);}
			//fE[u].clear();
			z=rE[u].size();
			For(j,0,z-1){
			deg[rE[u][j]]--;fE[u].push_back(rE[u][j]);}
			//rE[u].clear();
		}
		ll pan=1;
		For(j,1,n){
			cout<<deg[j]<<" ";
			if(deg[j]!=1){
				cout<<"NO"<<endl;
				pan=0;
				break;
			}
		}
		if(pan) cout<<"YES"<<endl;
	}
	return 0;
}