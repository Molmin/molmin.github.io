#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(k);++i)
#define ForD(i,j,k) for(int i=(j);i>=(k);--i)
#define ll long long
#define inf 0x5f5f5f5f5f5f5f5f
using namespace std;
ll n,m,q;
namespace Tree{
	ll a[1005],b[1005];
	ll num[1005][1005];
	ll tree[1005][10005];
	void build(ll nu,ll node,ll l,ll r){
		if(l==r) tree[nu][node]=num[nu][l];
		else{
			ll mid=(l+r)>>1;
			build(nu,node<<1,l,mid);
			build(nu,node<<1|1,mid+1,r);
			tree[nu][node]=min(tree[nu][node<<1],
							tree[nu][node<<1|1]);
		}
		return;
	}
	ll quary(ll nu,ll node,ll l,ll r,ll ql,ll qr){
		if(r<ql||l>qr) return inf;
		ll ret;
		if(l>=ql&&r<=qr){
			ret=tree[nu][node];
		}
		else{
			ll mid=(l+r)>>1;
			ret =min(quary(nu,node<<1,l,mid,ql,qr),
					quary(nu,node<<1|1,mid+1,r,ql,qr));
		}
		return ret;
	}
	void solve(){
		For(i,1,n) cin>>a[i];
		For(i,1,m) cin>>b[i];
		For(i,1,n) For(j,1,m){
			num[i][j]=a[i]*b[j];
		}
		For(i,1,n){
			build(i,1,1,m);
		}
		For(i,1,q){
			ll l1,r1,l2,r2;
			cin>>l1>>r1>>l2>>r2;
			ll ans=-inf;
			For(j,l1,r1){
				ans=max(ans,quary(j,1,1,m,l2,r2));
			}
			cout<<ans<<endl;
		}
	}
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	if(n<=1000&&m<=1000) Tree::solve();
	return 0;
}