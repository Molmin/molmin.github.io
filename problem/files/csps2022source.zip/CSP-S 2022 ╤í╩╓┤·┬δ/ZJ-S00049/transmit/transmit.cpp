#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(k);++i)
#define ForD(i,j,k) for(int i=(j);i>=(k);--i)
#define ll long long
#define inf 0x5f5f5f5f
using namespace std;
ll n,q,k;
ll a[200005],c[200005],fa[200005];
vector<ll> E[200005];
void dfs(ll node){
	ll z=E[node].size();
	c[node]=c[fa[node]]+1;
	For(i,0,z-1){
		if(E[node][i]!=fa[node]){
			fa[E[node][i]]=node;
			dfs(E[node][i]);
		}
	}
	return;
}
namespace one{
	ll lca(ll u,ll v){
		ll ans=0;
		if(c[u]<c[v])u^=v^=u^=v;
		ll cha=c[u]-c[v];
		For(i,1,cha){
			ans+=a[u];
			u=fa[u];
		}
		while(u!=v){
			ans+=a[u];ans+=a[v];
			u=fa[u],v=fa[v];
		}
		ans+=a[u];
		return ans;
	}
	void solve(){
		For(i,1,q){
			ll u,v;
			cin>>u>>v;
			cout<<lca(u,v)<<endl;
		}
		return ;
	}
}
namespace BF{
	ll dp[200005];
	struct T{
		ll pos,w;
	}que[200005];
	ll num[200005],cnt=0;
	void lca(ll u,ll v){
		cnt=0;memset(num,0,sizeof(num));
		stack<ll> st;
		if(c[u]<c[v])u^=v^=u^=v;
		ll cha=c[u]-c[v];
		For(i,1,cha){
			num[++cnt]=u;
			u=fa[u];
		}
		while(u!=v){
			num[++cnt]=u;
			st.push(v);
			u=fa[u],v=fa[v];
		}
		num[++cnt]=u;
		while(!st.empty()){
			num[++cnt]=st.top();st.pop();
		}
		return ;
	}
	void solve(){
		For(i,1,q){
			ll u,v;
			cin>>u>>v;
			lca(u,v);
			dp[1]=num[1];
			ll l=1,r=1;
			T niu;niu.pos=1,niu.w=num[1];
			que[r]=niu;
			For(j,2,cnt){
				while(que[l].pos<j-k)l++;
				dp[j]=que[l].w+num[j];
				T niu;niu.pos=j;niu.w=que[l].w+num[j];
				T nul;nul.pos=0;nul.w=0;
				while(que[r].w>dp[j]&&l<=r)que[r--]=nul;
				que[++r]=niu;
			}
			cout<<dp[cnt]<<endl;
		}
		return ;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	For(i,1,n) cin>>a[i];
	For(i,1,n-1){
		ll u,v;
		cin>>u>>v;
		E[u].push_back(v);
		E[v].push_back(u);
	}
	dfs(1);
	if(k==1)one::solve();
	if(n<=1000&&q<=1000)BF::solve();
	return 0;
}