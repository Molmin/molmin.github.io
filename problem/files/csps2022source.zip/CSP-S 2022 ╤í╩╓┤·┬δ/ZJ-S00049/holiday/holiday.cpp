#include<bits/stdc++.h>
#define For(i,j,k) for(int i=(j);i<=(k);++i)
#define ForD(i,j,k) for(int i=(j);i>=(k);--i)
#define ll long long
using namespace std;
ll n,m,k;
ll a[2505];
vector<ll> E[2505];
namespace zero{
	ll vis[2505];
	ll dfs(ll t,ll node){
		if(node==1&&t==4) return 0;
		if(vis[node])return -1;
		ll ans=-1;
		if(t>4) return -1;
		vis[node]=1;
		ll z=E[node].size();
		For(i,0,z-1){
			ll aba=dfs(t+1,E[node][i]);
			if(aba!=-1)
				ans=max(ans,aba);
		}
		if(ans==-1)return -1;
		return ans+a[node];
	}
	void solve(){
		cout<<dfs(0,1)<<endl;
		return;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	a[1]=0;
	For(i,1,n){
		cin>>a[i];
	}
	For(i,1,m){
		ll u,v;
		cin>>u>>v;
		E[u].push_back(v);
		E[v].push_back(u);
	}
	if(k==0){
		zero::solve();
	}
	return 0;
}