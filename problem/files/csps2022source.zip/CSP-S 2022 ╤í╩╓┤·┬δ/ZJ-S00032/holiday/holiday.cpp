#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2505;
vector<int> va[N],v[N];
int n,m,k,a[N],ans,f[N][5];
bool b[N];
void dfs(int i,int d,int f,int r) {
	if(d<=k+1) {
		if(i!=f) {
			v[i].push_back(f);
			v[f].push_back(i);
		}
		for(auto c:va[i]) {
			if(c!=r)
				dfs(c,d+1,f,i);
		}
	}
}
void dfs2(int i,int d,int x) {
	if(d==5) {
		for(auto c:v[i]) {
			if(c==1)ans=max(ans,x);
		}
		return;
	}
	for(auto c:v[i]) {
		if(!b[c]) {
			b[c]=1;
			dfs2(c,d+1,x+a[c]);
			b[c]=0;
		}
	}
}
signed main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2; i<=n; ++i) {
		scanf("%lld",a+i);
	}
	for(int i=1; i<=m; ++i) {
		int a,b;
		scanf("%lld%lld",&a,&b);
		va[a].push_back(b);
		va[b].push_back(a);
	}
	for(int i=1; i<=n; ++i) {
		dfs(i,0,i,-1);
	}
	dfs2(1,1,0);
	cout<<ans;
	return 0;
}
