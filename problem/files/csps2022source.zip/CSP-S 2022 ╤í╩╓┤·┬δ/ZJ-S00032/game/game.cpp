#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+4;
int n,m,a[N],b[N],q,l1,l2,r1,r2,ans;
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1; i<=n; ++i) {
		scanf("%lld",a+i);
	}
	for(int i=1; i<=m; ++i) {
		scanf("%lld",b+i);
	}
	for(int i=1; i<=q; ++i) {
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		ans=-1e18-2;
		for(int i=l1; i<=r1; ++i) {
			int minn=1e18;
			for(int j=l2; j<=r2; ++j) {
				minn=min(a[i]*b[j],minn);
			}
			ans=max(ans,minn);
		}
		printf("%lld\n",ans);
	}
}
