#include<bits/stdc++.h>
using namespace std;
const int N=5e5+4;
int t,n,m,q;
struct ss{
	int x;
	bool b;
};
vector<ss> v[N];
bool vis[N];
bool check(int i){
	if(vis[i]=1)return true;
	int cnt=0,x;
	for(auto c:v[i]){
		if(!c.b)cnt++,x=c.x;
	}
	if(cnt!=1)return false;
	auto t=v[x];
	vis[t.x]=1;
	return check(t.x);
}
signed main(){
	mt19937 gen(time(0));
	srand(time(0));
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		int a,b;
		scanf("%d%d",&a,&b);
		v[a].push_back(b);
	}
	scanf("%d",&q);
	for(int i=1;i<=q;++i){
		memset(vis,0,sizeof vis);
		if((rand()&gen()*rand())%2)puts("YES");
		else puts("NO");
	}
}
