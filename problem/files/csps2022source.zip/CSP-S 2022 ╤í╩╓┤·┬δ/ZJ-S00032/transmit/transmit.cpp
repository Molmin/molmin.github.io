#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
vector<int> v[N];
struct ss{
	int i,ans;
	bool operator<(const struct ss b)const{
		return ans>b.ans;
	}
};
bool b[N];
int a[N],n,q,k;
int bfs(int from,int end){
	priority_queue<ss> q;
	q.push({from,a[from]});
	while(!q.empty()){
		auto t=q.top();
		b[t.i]=1;
		cout<<t.i<<endl;
		q.pop();
		if(t.i==end)return t.ans;
		for(auto c:v[t.i]){
			if(!b[c])q.push({c,t.ans+a[t.i]});
		}
	}
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&k);
	for(int i=1;i<=n;++i){
		scanf("%lld",a+i);
	}
	for(int i=1;i<n;++i){
		int a,b;
		scanf("%lld%lld",&a,&b);
		v[a].push_back(b);
		v[b].push_back(a);
	}
	for(int i=1;i<=q;++i){
		int a,b;
		scanf("%lld%lld",&a,&b);
		printf("%lld\n",bfs(a,b));
	}
}
