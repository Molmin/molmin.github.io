#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll INF=1e9;
ll a[3005];
int b[3005];
int g[2505][2505];
ll ans=0;
ll x=0;
int n,m,k;
void dfs(int s)
{
	int o=0;
	ll mx=0;
	for(int i=2;i<=n;i++)
	{
		if(a[i]>mx&&b[i]==0&&g[s][i]<=k)
		{
			mx=a[i];
			o=i;
		}
	}
	b[o]=1;
	x++;
	ans+=a[o];
	if(x==4)
	{
		return;
	}
	dfs(o);
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	a[1]=0;
	for(int i=0;i<=2500;i++)
	{
		for(int j=0;j<=2500;j++)
		{
			g[i][j]=INF;
		}
		g[i][i]=0;
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		g[x][y]=g[y][x]=0;
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				g[i][j]=min(g[i][j],g[i][k]+g[k][j]+1);
			}
		}
	}
	memset(b,0,sizeof(b));
	dfs(1);
	printf("%lld\n",ans);
	return 0;
}
