#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int INF=1e9;
const int N=5e5+10;
int n,m,q,t,uu,vv;
struct node
{
	int u,v;
	bool b;
}a[N];
int g[2005][2005];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<=2002;i++)
	{
		for(int j=0;j<=2002;j++)
		{
			g[i][j]=INF;
		}
		g[i][i]=0;
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&a[i].u,&a[i].v);
		a[i].b=true;
		g[a[i].u][a[i].v]=min(0,g[a[i].u][a[i].v]);
	}
	scanf("%d",&q);
	for(int z=1;z<=q;z++)
	{
		scanf("%d",&t);
		if(t==1)
		{
			scanf("%d%d",&uu,&vv);
			for(int i=1;i<=m;i++)
			{
				if(a[i].u==uu&&a[i].v==vv&&a[i].b==true)
				{
					a[i].b=false;
					g[uu][vv]=INF;
					break;
				}
			}
		}
		else if(t==2)
		{
			scanf("%d",&uu);
			for(int i=1;i<=m;i++)
			{
				if(a[i].v==uu&&a[i].b==true)
				{
					for(int j=1;j<=m;j++)
					{
						g[a[j].u][uu]=INF;
					}
					a[i].b=false;
				}
			}
		}
		else if(t==3)
		{
			scanf("%d%d",&uu,&vv);
			for(int i=1;i<=m;i++)
			{
				if(a[i].u==uu&&a[i].v==vv&&a[i].b==false)
				{
					g[uu][vv]=0;
					a[i].b=true;
					break;
				}
			}
		}
		else if(t==4)
		{
			scanf("%d",&uu);
			for(int i=1;i<=m;i++)
			{
				if(a[i].v==uu&&a[i].b==false)
				{
					for(int j=1;j<=m;j++)
					{
						if(uu==a[j].v)
						{
							g[a[j].u][uu]=min(g[a[j].u][uu],0);
						}
					}
					a[i].b=true;
				}
			}
		}
		for(int k=1;k<=n;k++)
		{
			for(int i=1;i<=n;i++)
			{
				for(int j=1;j<=n;j++)
				{
					g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
				}
			}
		}
		bool f1=false,f2=true;
		for(int i=1;i<=m;i++)
		{
			for(int j=1;j<=m;j++)
			{
				if(i!=j&&g[a[i].u][a[i].v]==0&&g[a[i].v][a[i].u]==0)
				{
					f1=true;
				}
				if(i!=j&&a[i].u==a[j].u&&a[i].b==true&&a[j].b==true)
				{
					f2=false;
					break;
				}
			}
			if(f2==false)
			{
				break;
			}
		}
		if(f1==true&&f2==true)
		{
			printf("YES\n");
		}
		else
		{
			printf("NO\n");
		}
	}
	return 0;
}
