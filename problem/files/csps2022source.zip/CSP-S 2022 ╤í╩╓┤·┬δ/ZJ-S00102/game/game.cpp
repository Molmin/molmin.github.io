#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
const ll INF=2e18;
ll a[N],b[N],mx2[N],mn2[N];
int n,m,q;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
	}
	for(int z=1;z<=q;z++)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int l=0,q=0;
		ll mnn=INF,mxx=-INF;
		int i,j;
		for(i=l1;i<=r1;i++)
		{
			ll mn=INF;
			mx2[i]=-INF;
			for(j=l2;j<=r2;j++)
			{
				if(a[i]*b[j]<mn)
				{
					mn=a[i]*b[j];
				}
				mx2[i]=max(mx2[i],a[i]*b[j]);
			}
			if(mn>mxx)
			{
				mxx=mn;
				l=i;
			}
			else if(mn==mxx)
			{
				if(mx2[i]>mx2[l])
				{
					l=i;
				}
			}
		}
		for(j=l2;j<=r2;j++)
		{
			ll mx=-INF;
			mn2[j]=INF;
			for(int i=l1;i<=r1;i++)
			{
				if(a[i]*b[j]>mx)
				{
					mx=a[i]*b[j];
				}
				mn2[j]=min(mn2[j],a[i]*b[j]);
			}
			if(mx<mnn)
			{
				mnn=mx;
				q=j;
			}
			else if(mx==mnn)
			{
				if(mn2[j]<mn2[q])
				{
					q=j;
				}
			}
		}
		printf("%lld\n",a[l]*b[q]);
	}
	return 0;
}
