#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=2e5+10;
const int INF=1e9;
struct node
{
	ll s;
	int b;
}a[N];
bool cmp(node a,node b)
{
	return a.s<b.s;
}
int g[2005][2005];
int n,q,k;
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i].s);
		a[i].b=i;
	}
	sort(a+1,a+n+1,cmp);
	for(int i=0;i<=2002;i++)
	{
		for(int j=0;j<=2002;j++)
		{
			g[i][j]=INF;
		}
		g[i][i]=0;
	}
	for(int i=1;i<=n-1;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		if(x==y)
		{
			g[x][y]=0;
		}
		else
		{
			if(g[x][y]==INF)
			{
				g[x][y]=1;
			}
			else
			{
				g[x][y]++;
			}
			if(g[y][x]==INF)
			{
				g[y][x]=1;
			}
			else
			{
				g[y][x]++;
			}
		}
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
			}
		}
	}
	for(int i=1;i<=q;i++)
	{
		ll ans=0;
		int x,y;
		scanf("%d%d",&x,&y);
		ans=a[x].s+a[y].s;
		if(g[x][y]>k)
		{
			int xx=x;
			for(int i=1;i<=n;i++)
			{
				if(i!=x&&i!=y)
				{
					ans+=a[i].s;
				}
				int yy=xx;
				xx=a[i].b;
				if(g[yy][xx]<=k&&g[xx][y]<=k)
				{
					break;
				}
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
