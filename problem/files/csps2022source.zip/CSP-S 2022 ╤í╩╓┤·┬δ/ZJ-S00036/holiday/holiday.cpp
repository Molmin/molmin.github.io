#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll fastread()
{
	ll sym = 1, res = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') sym = -sym;
		ch = getchar();
	}

	while(ch >= '0' && ch <= '9')
	{
		res = (res << 1) + (res << 3) + (ch ^ '0');
		ch = getchar();
	}

	return sym * res;
}

void fastwrite(ll x)
{
	ll cnt = 0;
	char str[63];
	if(x < 0) putchar('-'), x = -x;
	while(x)
	{
		str[cnt ++] = (x % 10) + '0';
		x /= 10;
	}

	for(ll i = cnt - 1; i >= 0; -- i)	putchar(str[i]);

	puts("");
}

ll cnt, head[250005];

struct Edge {
	ll to, nxt, dis;
} edge[2000005];

void add(ll u, ll v, ll w)
{
	++ cnt;
	edge[cnt].to = v;
	edge[cnt].nxt = head[u];
	edge[cnt].dis = w;
	head[u] = cnt;
}

ll N, M, K;
ll score[250005];
ll dis[2505][2505];

struct Node {
	ll num, dis;
};

bool operator <(Node a, Node b)
{
	return a.dis < b.dis;
}

void dijkstra(ll source)
{
	priority_queue<Node> q;	
	q.push((Node) {source, 0});
	dis[source][source] = 0;
	while(!q.empty())
	{
		Node ele = q.top();
		q.pop();
		ll u = ele.num;
		for(ll i = head[u]; i; i = edge[i].nxt)
		{
			ll v = edge[i].to;
			if(dis[source][v] > dis[source][u] + edge[i].dis)
			{
				dis[source][v] = dis[source][u] + edge[i].dis;
				q.push((Node) {v, dis[source][v]});
			}
		}
	}
}

ll vismax[20005], pos[20005];

signed main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	N = fastread(), M = fastread(), K = fastread();
	for(ll i = 2; i <= N; ++ i)
		score[i] = fastread();
		
	for(ll i = 1; i <= M; ++ i)
	{
		ll u, v;
		u = fastread(), v = fastread();
		add(u, v, 1);
		add(v, u, 1);
	}
	
	memset(dis, 0x3f, sizeof(dis));
	for(ll i = 1; i <= N; ++ i)
		dijkstra(i);
		
//	if(K == 0)
//	{
//		ll maxn = -1;
//		for(ll a1 = 2; a1 <= N; a1 ++)
//		{
//			if(dis[1][a1] - 1 > K) continue;
//			for(ll a2 = 2; a2 <= N; a2 ++)
//			{
//				if(a1 == a2 || dis[a1][a2] - 1 > K) continue;
//				for(ll a3 = 2; a3 <= N; a3 ++)
//				{
//					if(a1 == a3 || a2 == a3 || dis[a2][a3] - 1 > K) continue;
//					for(ll a4 = 2; a4 <= N; a4 ++)
//					{
//						if(a1 == a4 || a2 == a4 || a3 == a4 || dis[a3][a4] - 1 > K) continue;
//						if(dis[a4][1] - 1 <= K)
//							maxn = max(maxn, score[a1] + score[a2] + score[a3] + score[a4]);
//					}
//				}
//			}
//		}
//		
//		cout << maxn << endl;
//	}
//	else
//	{
		ll maxn = -1;
		for(ll a1 = 2; a1 <= N; a1 ++)
		{
			if(dis[1][a1] - 1 > K) continue;
			for(ll a2 = 2; a2 <= N; a2 ++)
			{
				if(a1 == a2 || dis[a1][a2] - 1 > K) continue;
				for(ll a3 = 2; a3 <= N; a3 ++)
				{
					if(a1 == a3 || a2 == a3 || dis[a2][a3] - 1 > K) continue;
					for(ll a4 = 2; a4 <= N; a4 ++)
					{
						if(a1 == a4 || a2 == a4 || a3 == a4 || dis[a3][a4] - 1 > K) continue;
						if(dis[a4][1] - 1 <= K)
							maxn = max(maxn, score[a1] + score[a2] + score[a3] + score[a4]);
					}
				}
			}
		}
		
		cout << maxn << endl;
//	}

	return 0;
}

