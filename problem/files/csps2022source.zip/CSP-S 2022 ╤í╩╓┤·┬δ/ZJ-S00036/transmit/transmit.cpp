#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll fastread()
{
	ll sym = 1, res = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') sym = -sym;
		ch = getchar();
	}

	while(ch >= '0' && ch <= '9')
	{
		res = (res << 1) + (res << 3) + (ch ^ '0');
		ch = getchar();
	}

	return sym * res;
}

void fastwrite(ll x)
{
	int cnt = 0;
	char str[63];
	if(x < 0) putchar('-'), x = -x;
	while(x)
	{
		str[cnt ++] = (x % 10) + '0';
		x /= 10;
	}

	for(int i = cnt - 1; i >= 0; -- i)	putchar(str[i]);

	puts("");
}

int N, Q, K;

ll val[200005];
ll cnt, head[250005];

struct Edge {
	ll to, nxt;
} edge[2000005];

void add(ll u, ll v)
{
	++ cnt;
	edge[cnt].to = v;
	edge[cnt].nxt = head[u];
//	edge[cnt].dis = w;
	head[u] = cnt;
}

struct Node {
	int num, dis;
};

int bfs(int from, int to)
{
	queue<Node> q;
	bool visited[10005];
	memset(visited, 0, sizeof(visited));
	q.push((Node) {from, 0});
	visited[from] = true;
	while(!q.empty())
	{
		Node ele = q.front();
		q.pop();
		int u = ele.num;
		for(int i = head[u]; i; i = edge[i].nxt)
		{
			int v = edge[i].to;
			if(!visited[v])
			{
				q.push((Node) {v, ele.dis + val[v]});
				visited[v] = true;
			}
			
			if(v == to)
			{
				return ele.dis + val[v];
			}
		}
	}
	
	return -1;
}

signed main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	cin >> N >> Q >> K;
	for(int i = 1; i <= N; ++ i)
		cin >> val[i];
	
	for(int i = 1; i < N; ++ i)
	{
		int a, b;
		cin >> a >> b;
		add(a, b);
		add(b, a);
	}
	
	for(int i = 1; i <= Q; ++ i)
	{
		int s, t;
		cin >> s >> t;
		cout << bfs(s, t) << endl;
	}
	return 0;
}

