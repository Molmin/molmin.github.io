#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll fastread()
{
	ll sym = 1, res = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') sym = -sym;
		ch = getchar();
	}

	while(ch >= '0' && ch <= '9')
	{
		res = (res << 1) + (res << 3) + (ch ^ '0');
		ch = getchar();
	}

	return sym * res;
}

void fastwrite(ll x)
{
	int cnt = 0;
	char str[63];
	if(x < 0) putchar('-'), x = -x;
	while(x)
	{
		str[cnt ++] = (x % 10) + '0';
		x /= 10;
	}

	for(int i = cnt - 1; i >= 0; -- i)	putchar(str[i]);

	puts("");
}

int N, M, Q;
int hlbl[1000005];

signed main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> N >> M;
	for(int i = 1; i <= M; ++ i)
	{
		int u, v;
		cin >> u >> v;
	} 
	
	cin >> Q;
	while(Q --)
	{
		int t, u, v;
		cin >> t;
		if(t == 1 || t == 3) cin >> u >> v;
		if(t == 2 || t == 4) 
		{
			cin >> u;
		}
		
		puts("NO");
	}
	return 0;
}

