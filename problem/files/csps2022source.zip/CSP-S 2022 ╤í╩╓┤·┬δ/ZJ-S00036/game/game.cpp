#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

ll fastread()
{
	ll sym = 1, res = 0;
	char ch = getchar();
	while(ch < '0' || ch > '9')
	{
		if(ch == '-') sym = -sym;
		ch = getchar();
	}

	while(ch >= '0' && ch <= '9')
	{
		res = (res << 1) + (res << 3) + (ch ^ '0');
		ch = getchar();
	}

	return sym * res;
}

void fastwrite(ll x)
{
	int cnt = 0;
	char str[63];
	if(x < 0) putchar('-'), x = -x;
	while(x)
	{
		str[cnt ++] = (x % 10) + '0';
		x /= 10;
	}

	for(int i = cnt - 1; i >= 0; -- i)	putchar(str[i]);
	puts("");
}

int N, M, Q;
int A[100005], B[100005];
int log2table[100005];
int mxA[100005][20], mnB[100005][20];
int mnA[100005][20], mxB[100005][20];

ll qpow(ll a, ll n)
{
	if(n == 0) return 1;
	if(n == 1) return a;
	ll tmp = qpow(a, n >> 1);
	if(n & 1) return tmp * tmp * a;
	else 	  return tmp * tmp;
}

ll getmaxA(ll l, ll r)
{
	ll len = r - l + 1;
	return max(mxA[l][log2table[len]], mxA[r - qpow(2, log2table[len]) + 1][log2table[len]]);
}

ll getminB(ll l, ll r)
{
	ll len = r - l + 1;
	return min(mnB[l][log2table[len]], mnB[r - qpow(2, log2table[len]) + 1][log2table[len]]);
}

ll getminA(ll l, ll r)
{
	ll len = r - l + 1;
	return min(mnA[l][log2table[len]], mnA[r - qpow(2, log2table[len]) + 1][log2table[len]]);
}

ll getmaxB(ll l, ll r)
{
	ll len = r - l + 1;
	return max(mxB[l][log2table[len]], mxB[r - qpow(2, log2table[len]) + 1][log2table[len]]);
}

bool nopos = true;

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	cin >> N >> M >> Q;
	for(int i = 1; i <= N; ++ i)
	{
		cin >> A[i];
		if(A[i] < 0)
			nopos = false;
	}
		
	for(int i = 1; i <= M; ++ i)
	{
		cin >> B[i];
		if(B[i] < 0)
			nopos = false;
	}
	
	log2table[2] = 1;
	for(int i = 3; i <= max(N, M); ++ i)
		log2table[i] = log2table[i / 2] + 1;
	
	for(int i = 1; i <= N; ++ i)
		mxA[i][0] = A[i];
	
	for(int i = 1; i <= M; ++ i)
		mnB[i][0] = B[i];
	
	for(int i = 1; i <= N; ++ i)
		mnA[i][0] = A[i];
	
	for(int i = 1; i <= M; ++ i)
		mxB[i][0] = B[i];
	
	for(int j = 1; j <= log2table[N]; ++ j)
		for(int i = 1; i <= N - qpow(2, j) + 1; ++ i)
			mxA[i][j] = max(mxA[i][j - 1], mxA[i + qpow(2, j - 1)][j - 1]);
	
	for(int j = 1; j <= log2table[M]; ++ j)
		for(int i = 1; i <= M - qpow(2, j) + 1; ++ i)
			mnB[i][j] = min(mnB[i][j - 1], mnB[i + qpow(2, j - 1)][j - 1]);
			
	for(int j = 1; j <= log2table[N]; ++ j)
		for(int i = 1; i <= N - qpow(2, j) + 1; ++ i)
			mnA[i][j] = min(mnA[i][j - 1], mnA[i + qpow(2, j - 1)][j - 1]);
	
	for(int j = 1; j <= log2table[M]; ++ j)
		for(int i = 1; i <= M - qpow(2, j) + 1; ++ i)
			mxB[i][j] = max(mxB[i][j - 1], mxB[i + qpow(2, j - 1)][j - 1]);
			
	if(nopos)
	{
		while(Q --)
		{
			int l1, r1, l2, r2;
			cin >> l1 >> r1 >> l2 >> r2;
			cout << getmaxA(l1, r1) * getminB(l2, r2) << endl;
		}
	}
	else
	{
		while(Q --)
		{
			int l1, r1, l2, r2;
			cin >> l1 >> r1 >> l2 >> r2;
			if(l1 == r1)
			{
				if(getmaxA(l1, r1) >= 0) cout << getmaxA(l1, r1) * getminB(l2, r2) << endl;
				else 					 cout << getmaxA(l1, r1) * getmaxB(l2, r2) << endl;
			}
			if(l2 == r2)
			{
				if(getmaxB(l2, r2) >= 0) cout << getmaxA(l1, r1) * getmaxB(l2, r2) << endl;
				else 					 cout << getminA(l1, r1) * getmaxB(l2, r2) << endl;
			}
		}
	}
	return 0;
}

