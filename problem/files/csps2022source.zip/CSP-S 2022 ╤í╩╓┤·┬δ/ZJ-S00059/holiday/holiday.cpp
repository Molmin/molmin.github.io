#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline int read(){
	int x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+c-48;
	return f*x;
}
inline void write(int x){
	if(x<0) x=~(x-1),putchar('-');
	if(x>9) write(x/10);
	putchar(x%10+48);return ;
}
vector <ll> g[2505];
vector <ll> v[2505];
bool b[2505][2505];
ll n,m,k,x,y,w,ans=-1000,a[2505],c[2505][2505],from;
void Dfs(ll kk,ll now){
	if(kk>k+2) return ;
	if(kk>1 && from!=now && now!=1){
		if(!b[from][now]) v[from].push_back(now),b[from][now]=1;
		if(!b[now][from]) v[now].push_back(from),b[now][from]=1;
	}
	int len=g[now].size();
	for(int i=0;i<len;i++) Dfs(kk+1,g[now][i]);
}
ll Dfs2(ll u,ll v){
	ll len1=g[u].size(),len2=g[v].size(),ans=-1000;
	for(int i=0;i<len1;i++)
	 if(g[u][i]!=v && g[u][i]!=1)
	  for(int j=0;j<len2;j++)
	   if(g[v][j]!=1 && g[v][j]!=u && g[v][j]!=g[u][i])
	    ans=max(ans,a[g[u][i]]+a[g[v][j]]+a[u]+a[v]);
	return ans;
}
ll val(ll x,ll y,ll z,ll w) { return a[x]+a[y]+a[z]+a[w]; }
bool dif(int x,int y,int z,int w){
	if(x==y || x==z || x==w || y==z || y==w || z==w) return false;
	else return true;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=2;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++)
	 x=read(),y=read(),g[x].push_back(y),g[y].push_back(x),
	 b[x][y]=b[y][x]=1,v[y].push_back(x),v[x].push_back(y);
	if(k==0){
		int len=g[1].size();
		for(int i=0;i<len-1;i++)
		 for(int j=i+1;j<len;j++)
		  w=Dfs2(g[1][i],g[1][j]),ans=max(ans,w);
		write(ans);
		return 0;
	}
	for(from=1;from<=n;from++) Dfs(1,from);
	/*
	for(int i=1;i<=n;i++){
		for(int j=0;j<v[i].size();j++) 
		 cout<<v[i][j]<<' ';
		cout<<endl;
	}*/
	int len=v[1].size();
	for(int i=0;i<len-1;i++){
		x=v[1][i];
		for(int j=i+1;j<len;j++){
			y=v[1][j];
			int len1=v[x].size(),len2=v[y].size();
			for(int k=0;k<len1;k++)
			 for(int l=0;l<len2;l++)
			  if(dif(x,y,v[x][k],v[y][l]) && b[v[x][k]][v[y][l]])
			   ans=max(ans,val(x,y,v[x][k],v[y][l]));
		}
	}write(ans);
	return 0;
}
