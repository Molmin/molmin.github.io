#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline int read(){
	int x=0,f=1;char c=getchar();
	for(;!isdigit(c);c=getchar()) if(c=='-') f=-1;
	for(;isdigit(c);c=getchar()) x=(x<<3)+(x<<1)+c-48;
	return f*x;
}
inline void write(int x){
	if(x<0) x=~(x-1),putchar('-');
	if(x>9) write(x/10);
	putchar(x%10+48);return ;
}
bool b[500005],f[500005];
ll n,m,t,x,y,sum[500005];
struct cvb1 { int to,num; };
struct cvb2 { int from,num; };
queue <int> q;
vector <cvb1> g[500005];
vector <cvb2> v[500005]; 
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		x=read();y=read();sum[y]++;b[i]=1;
		g[x].push_back((cvb1){y,i});
		v[y].push_back((cvb2){x,i});
	}
	t=read();
	for(int w=0;w<t;w++){
		int ch;
		cin>>ch;
		switch(ch) {
			case 1:{
				cin>>x>>y;sum[x]--;
				int len=g[x].size();
				for(int i=0;i<len;i++){
					cvb1 now=g[x][i];
					if(now.to==y) {b[now.num]=0;break;}
				}
				break;
			}
			case 2:{
				cin>>x;
				int len=v[x].size();
				for(int i=0;i<len;i++){
					cvb2 now=v[x][i];
					if(b[now.num]) sum[now.from]--,b[now.num]=0;
				}
				break;
			}
			case 3:{
				cin>>x>>y;sum[x]++;
				int len=g[x].size();
				for(int i=0;i<len;i++){
					cvb1 now=g[x][i];
					if(now.to==y) {b[now.num]=1;break;}
				}
				break;
			}
			default:{
				cin>>x;
				int len=v[x].size();
				for(int i=0;i<len;i++){
					cvb2 now=v[x][i];
					if(!b[now.num]) sum[now.from]++,b[now.num]=1;
				}
				break;
			}
		}
		bool ff=0;
		for(int i=1;i<=n;i++) if(sum[i]>1) {cout<<"NO"<<endl;ff=1;break;}
		if(ff) continue;
		for(int i=1;i<=n;i++){
			memset(f,0,sizeof(f));
			q.push(i);
			bool fff=1;
			while(!q.empty() && fff){
				int now=q.front();q.pop();
				int len=g[now].size();
				for(int j=0;j<len;j++){
					cvb1 now1=g[now][j];
					if(!b[now1.num]) continue;
					if(f[now1.to]) {fff=0;break;}
					f[now1.to]=1;q.push(now1.to);
				}
			}
			if(fff) {cout<<"NO"<<endl;ff=1;break;}
		}
		if(!ff) cout<<"YES"<<endl;
	}
	return 0;
}
