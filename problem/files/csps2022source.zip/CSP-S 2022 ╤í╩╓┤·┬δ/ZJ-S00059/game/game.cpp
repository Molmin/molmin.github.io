#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=1;
	char c=getchar();
	for(;c<'0'||c>'9';c=getchar()) if(c=='-') f=-1;
	for(;c>='0'&&c<='9';c=getchar()) x=(x<<3)+(x<<1)+c-48;
	return f*x;
}
inline void write(long long x){
	if(x<0) x=~(x-1),putchar('-');
	if(x>9) write(x/10);
	putchar(x%10+48);return ;
}
bool f=1;
long long n,m,t,a[100005],b[100005],l,x,r,y;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();t=read();
	for(int i=1;i<=n;i++) {
		x=read();a[i]=x;
		if(a[i]<=0) f=0;
	}
	for(int i=1;i<=m;i++) {
		x=read();b[i]=x;
		if(b[i]<=0) f=0;
	}
	if(!f) for(int i=1;i<=t;i++){
		l=read();r=read();x=read();y=read();
		if(l==r) {
			long long minn=INT_MAX;
			for(int j=x;j<=y;j++) minn=min(minn,b[j]);
			cout<<a[l]*minn<<endl;
		}
		else if(x==y) {
			long long maxn=INT_MIN;
			for(int j=l;j<=r;j++) maxn=max(maxn,a[j]*b[x]);
			cout<<maxn<<endl;
		}
		else {
//			cout<<"NNN\n";
			long long ans=INT_MIN;
			for(int j=l;j<=r;j++){
				long long minn=INT_MAX;
				for(int k=x;k<=y;k++) minn=min(minn,a[j]*b[k]);
				ans=max(ans,minn);//cout<<minn<<' ';
			}//cout<<endl;
			cout<<ans<<endl;
		}
	}
	else for(int i=1;i<=t;i++){
		l=read();r=read();x=read();y=read();
		long long minn=INT_MAX;
		for(int j=x;j<=y;j++) minn=min(minn,b[j]);
		long long maxn=INT_MIN;
		for(int j=l;j<=r;j++) maxn=max(maxn,a[j]*minn);
		cout<<maxn<<endl;
	}
	return 0;
}
