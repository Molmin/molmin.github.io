//û����Ļ��ƺ��Ǳ���+�س����⣿
//$k=3$ ��ʱ����Ҫ����һ������·�������

//T4 Ӧ�ò�����ô�򵥰�������ʱû�뵽 Hack��ѡ����� 

#include<bits/stdc++.h>
#define Cn const
#define CI Cn int&
#define N 200000
#define K 3
#define LN 17
#define LL long long
#define INF (LL)1e18
#define add(x,y) (e[++ee].nxt=lnk[x],e[lnk[x]=ee].to=y)
using namespace std;
namespace FastIO
{
	#define FS 100000
	#define Tp template<typename Ty>
	#define tc() (FA==FB&&(FB=(FA=FI)+fread(FI,1,FS,stdin),FA==FB)?EOF:*FA++)
	#define pc(c) (FC==FE&&(clear(),0),*FC++=c)
	#define clear() (fwrite(FO,1,FC-FO,stdout),FC=FO)
	int OT;char oc,FI[FS],FO[FS],OS[30],*FA=FI,*FB=FI,*FC=FO,*FE=FO+FS;
	Tp void read(Ty& x) {x=0;while(!isdigit(oc=tc()));while(x=(x<<3)+(x<<1)+(oc&15),isdigit(oc=tc()));}
	Tp void writeln(Ty x) {while(OS[++OT]=x%10+48,x/=10);while(OT) pc(OS[OT--]);pc('\n');}
}using namespace FastIO;
int n,k,a[N+5],ee,lnk[N+5];struct edge {int to,nxt;}e[2*N+5];
struct Mat
{
	int n,m;LL a[K][K];LL* operator [] (int x) {return a[x];}Cn LL* operator [] (int x) Cn {return a[x];}
	void Init(int x,int y) {n=x,m=y;for(int i=0;i<n;++i) for(int j=0;j<m;++j) a[i][j]=INF;}
	friend void operator *= (Mat& A,Mat B) {Mat t;t.Init(A.n,B.m);for(int i=0;i<t.n;++i) for(int j=0;j<t.m;++j) for(int k=0;k<B.n;++k) t[i][j]=min(t[i][j],A[i][k]+B[k][j]);A=t;}
}g[N+5][LN+1];
int w[N+5],D[N+5],f[N+5][LN+1];void Init(int x)
{
	int i,j;for(i=1;i<=LN&&(f[x][i]=f[f[x][i-1]][i-1]);++i) (g[x][i]=g[x][i-1])*=g[f[x][i-1]][i-1];
	for(w[x]=1e9,i=lnk[x];i;i=e[i].nxt) w[x]=min(w[x],a[e[i].to]);
	int y;for(i=lnk[x];i;i=e[i].nxt) if((y=e[i].to)^f[x][0]) {for(g[y][0].Init(k,k),j=0;j<k;++j) g[y][0][j][0]=a[x],j<k-1&&(g[y][0][j][j+1]=0);k==3&&(g[y][0][1][1]=w[x]),D[y]=D[f[y][0]=x]+1,Init(y);}
}
LL Q(int x,int y)
{
	D[x]<D[y]&&(swap(x,y),0);int i,j;Mat Sx,Sy;Sx.Init(1,k),Sy.Init(1,k),Sx[0][0]=a[x],Sy[0][0]=a[y];
	for(i=0;D[x]^D[y];++i) (D[x]^D[y])>>i&1&&(Sx*=g[x][i],x=f[x][i]);if(x==y) return Sx[0][0];
	for(i=0;i<=LN&&f[x][i]^f[y][i];++i);for(--i;~i;--i) f[x][i]^f[y][i]&&(Sx*=g[x][i],Sy*=g[y][i],x=f[x][i],y=f[y][i]);
	LL t=INF;for(i=0;i<k;++i) for(j=0;j<k;++j) t=min(t,Sx[0][i]+Sy[0][j]);t+=a[f[x][0]];
	k==3&&(t=min(t,Sx[0][1]+Sy[0][1]+w[f[x][0]]));
	for(i=0;i<k;++i) for(j=0;i+j+2<=k;++j) t=min(t,Sx[0][i]+Sy[0][j]);return t;
}
int main()
{
	freopen("transmit.in","r",stdin),freopen("transmit.out","w",stdout);
	int Qt,i,x,y;for(read(n),read(Qt),read(k),i=1;i<=n;++i) read(a[i]);
	for(i=1;i^n;++i) read(x),read(y),add(x,y),add(y,x);Init(1);
	while(Qt--) read(x),read(y),writeln(Q(x,y));return clear(),0;
}
