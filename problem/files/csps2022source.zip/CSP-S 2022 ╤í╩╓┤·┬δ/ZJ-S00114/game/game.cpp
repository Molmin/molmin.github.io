#include <bits/stdc++.h>
#define gc getchar()
using namespace std;
inline int read()
{
	int x = 0,f = 1;
	char c = gc;
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = gc;
	}
	while (isdigit(c))
	{
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = gc;
	}
	return x * f;
}
const int N = 1e5 + 5;
int n,m,q,a[N],b[N];
int main()
{
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> n >> m >> q;
	for (int i = 1; i <= n; i++) cin >> a[i];
	for (int i = 1; i <= m; i++) cin >> b[i];
	while (q--)
	{
		int l1 = read(),r1 = read(),l2 = read(),r2 = read();
		bool fl1 = 0,fl2 = 0;
		if (l1 == r1)
		{
			long long ans = 1ll << 63;
			for (int i = l2; i <= r2; i++) ans = min(ans,1ll * a[l1] * b[i]);
			cout << ans << endl;
			continue;
		}
		if (l2 == r2)
		{
			long long ans = -1e18 - 1;
			for (int i = l1; i <= r1; i++) ans = max(ans,1ll * a[i] * b[l2]);
			cout << ans << endl;
			continue;
		}
		for (int i = l1; i <= r1; i++) if (a[i] <= 0){fl1 = 1;break;}
		for (int i = l2; i <= r2; i++) if (b[i] <= 0){fl2 = 1;break;}
		if (fl2 == 0) 
		{
			int maxn = 0,minn = 1e9;
			for (int i = l1; i <= r1; i++) maxn = max(maxn,a[i]);
			for (int i = l2; i <= r2; i++) minn = min(minn,b[i]);
			cout << 1ll * maxn * minn << endl;
			continue;
		}
		else if (fl1 == 0)
		{
			int maxn = 0,minn = 0;
			long long ans = -1e18 - 5;
			bool ffl = 0;
			for (int i = l2; i <= r2; i++) if (b[i] <= 0) ffl = 1,minn = min(minn,b[i]);
			if (ffl)
			{
				maxn = a[l1];
				for (int i = l1 + 1; i <= r1; i++) maxn = min(maxn,a[i]);
				ans = 1ll * maxn * minn;
			}
			else
			{
				for (int i = l1; i <= r1; i++) maxn = max(maxn,a[i]);
				for (int i = l2; i <= r2; i++) ans = min(ans,1ll * maxn * b[i]);
			}
			cout << ans << endl;
		}
		else
		{
			int mi = b[l2],minn = 1;
			long long ans = -1e18 - 5;
			bool ffl = 0;
			for (int i = l2; i <= r2; i++)
			{
				if (b[i] <= 0) mi = min(mi,b[i]);
				else minn = max(minn,b[i]),ffl = 1;
			}
			if (ffl != 1) for (int i = l2; i <= r2; i++) mi = max(mi,b[i]);
			for (int i = l1; i <= r1; i++)
			{
				if (a[i] < 0){
					if (ffl) ans = max(ans,1ll * a[i] * minn);
					else ans = max(ans,1ll * a[i] * mi);
				}
				if (a[i] > 0) ans = max(ans,1ll * a[i] * mi);
			}
			cout << ans << endl;
		}
	}
	return 0;
}