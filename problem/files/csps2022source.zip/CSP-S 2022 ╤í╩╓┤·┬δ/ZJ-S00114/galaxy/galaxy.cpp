#include <bits/stdc++.h>
#define gc getchar()
using namespace std;
inline int read()
{
	int x = 0,f = 1;
	char c = gc;
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = gc;
	}
	while (isdigit(c))
	{
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = gc;
	}
	return x * f;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	return 0;
}
