#include <bits/stdc++.h>
#define gc getchar()
#define pb push_back
using namespace std;
const int N = 2505;
inline int read()
{
	int x = 0,f = 1;
	char c = gc;
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = gc;
	}
	while (isdigit(c))
	{
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = gc;
	}
	return x * f;
}
inline long long readl()
{
	long long x = 0,f = 1;
	char c = gc;
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = gc;
	}
	while (isdigit(c))
	{
		x = (x << 1) + (x << 3) + (c ^ 48);
		c = gc;
	}
	return x * f;
}
int n,m,k;
long long a[N],maxn;
bool vis[N];
vector<int> ma[N];
inline void dfs(int now,long long point,int stop)
{
	
	if (stop == 5 && now == 1){
		maxn = max(maxn,point);
		return;
	}if (stop > 4) return;
	for (int i = 0; i < (int)ma[now].size(); i++){
		dfs(ma[now][i],point + a[now],stop + 1);
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n = read(),m = read(),k = read();
	for (int i = 2; i <= n; i++) a[i] = readl();
	for (int i = 1; i <= m; i++)
	{
		int u = read(),v = read();
		ma[u].pb(v);ma[v].pb(u);
	}
	dfs(1,0,0);
	cout << maxn << endl;
	return 0;
}