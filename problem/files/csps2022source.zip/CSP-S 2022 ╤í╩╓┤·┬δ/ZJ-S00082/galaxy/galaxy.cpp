#include <bits/stdc++.h>
using namespace std;

int Outs[500024],Es[500024],n,m,p,NotOnes;

vector<int> Tos[500024];
vector<bool> AllreadyEnabled[500024];
int Is[500024];

bool cmp(int a,int b)
{
	return a<b;
}

int main()
{
	
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	int F,T;
	int x,y,z;
	
	scanf("%d %d",&n,&m);
	
	for(int i=0;i<m;i++)
	{
		scanf("%d %d",&F,&T);
		Outs[F]++;
		Es[F]++;
		Is[T]++;
		Tos[T].push_back(F);
		AllreadyEnabled[T].push_back(true);
	}
	
	
	for(int i=1;i<=n;i++)
	{
		if(Es[i]!=1)
		{
			NotOnes++;
		}
	}
	
	scanf("%d",&p);
	
	for(int i=0;i<p;i++)
	{
		scanf("%d %d",&x,&y);
		
		if(x==1||x==3)
		{
			scanf("%d",&z);
			if(Outs[y]==1)
			{
				NotOnes++;
			}
		}
		
		if(x==1)
		{
			Outs[y]--;
			for(int i=0;i<Is[z];i++)
			{
				if(Tos[z][i]==y)
				{
					AllreadyEnabled[z][i]=false;
				}
			}
		}
		else if(x==3)
		{
			Outs[y]++;
			for(int i=0;i<Is[z];i++)
			{
				if(Tos[z][i]==y)
				{
					AllreadyEnabled[z][i]=true;
				}
			}
		}
		if(x==2)
		{
			for(int i=0;i<Is[y];i++)
			{
				if(!AllreadyEnabled[y][i]) continue;
				AllreadyEnabled[y][i]=false;
				if(Outs[Tos[y][i]]==1)
				{
					NotOnes++;
				}
				Outs[Tos[y][i]]--;
				if(Outs[Tos[y][i]]==1)
				{
					NotOnes--;
				}
			}
		}
		
		if(x==4)
		{
			for(int i=0;i<Is[y];i++)
			{
				if(AllreadyEnabled[y][i]) continue;
				AllreadyEnabled[y][i]=true;
				if(Outs[Tos[y][i]]==1)
				{
					NotOnes++;
				}
				Outs[Tos[y][i]]++;
				if(Outs[Tos[y][i]]==1)
				{
					NotOnes--;
				}
			}
		}
		
		if(x==1||x==3)
		{
			if(Outs[y]==1)
			{
				NotOnes--;
			}
		}
		
		if(NotOnes==0)
		{
			printf("YES\n");
		}
		else
		{
			printf("NO\n");
		}
		
//		printf("[main/debug nos=%d]\n",NotOnes);
	}
	return 0;
}