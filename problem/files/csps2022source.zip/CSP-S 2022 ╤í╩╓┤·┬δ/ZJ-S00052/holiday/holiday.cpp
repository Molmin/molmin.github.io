#include<bits/stdc++.h>
using namespace std;
struct node{
	int id,step; 
};
struct node2{
	long long v;
	int a,b,c;
	bool ok; 
}dp1[2505],dp2[2502];
int n,m,k,zc[2505][2505];
long long fs[2505];
vector<int> e[2505];
queue<node> que;
void solve(int x){
	node t;
	t.id=x; t.step=0;
	que.push(t);
	while(!que.empty()){
		t=que.front();
		que.pop();
		if(zc[x][t.id]<t.step)continue;
		else zc[x][t.id]=t.step;
		for(int i=0;i<e[t.id].size();i++){
			node ti;
			ti.id=e[t.id][i];
			ti.step=t.step+1;
			que.push(ti);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(zc,127,sizeof(zc));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&fs[i]);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=1;i<=n;i++)
		solve(i);
	for(int i=2;i<=n;i++)
		if(zc[1][i]-1<=k){
			dp1[i].v=fs[i];
			dp1[i].a=i;
			dp1[i].ok=1;
		}
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)
		if(zc[j][i]-1<=k){
			if(dp2[j].v<dp1[i].v+fs[j]&&dp1[i].ok){
				if(dp1[i].a==j)continue;
				dp2[j]=dp1[i];
				dp2[j].v+=fs[j];
				dp2[j].b=j;
				dp2[j].a=dp1[i].a;
				dp2[i].ok=1;
			}
		}
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)
		if(zc[j][i]-1<=k&&dp2[i].a!=j&&dp2[i].b!=j&&i!=j&&dp2[i].ok){
			if(dp1[j].v<dp2[i].v+fs[j]){
				if(dp2[i].a==j)continue;
				if(dp2[i].b==j)continue;
				dp1[j]=dp2[i];
				dp1[j].v+=fs[j];
				dp1[j].c=j;
				dp1[i].ok=1;
			}
		}
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)
		if(zc[j][i]-1<=k&&dp1[i].a!=j&&dp1[i].b!=j&&dp1[i].c!=j&&i!=j&&dp1[i].ok){
			if(dp2[j].v<dp1[i].v+fs[j]){
				if(dp1[i].a==j)continue;
				if(dp1[i].b==j)continue;
				if(dp1[i].c==j)continue;
				dp2[j]=dp1[i];
				dp2[j].v+=fs[j];
				dp2[i].ok=1;
			}
		}
	long long ans=-1;
	for(int i=2;i<=n;i++)
	if(zc[1][i]-1<=k&&dp2[i].ok)
		ans=max(ans,dp2[i].v);
	printf("%lld",ans);
	return 0;
}                     