#include<bits/stdc++.h>
using namespace std;
int n,m,q,cza,czb,cfa,cfb,c0a,c0b,a[100005],b[100005],za[100005],zb[100005],fa[100005],fb[100005],zeroa[100005],zerob[100005];
int maxtreeza[400005],mintreeza[400005];
int maxtreezb[400005],mintreezb[400005];
int maxtreefa[400005],mintreefa[400005];
int maxtreefb[400005],mintreefb[400005];
bool tree0a[400005],tree0b[400005],bo[10];
long long ans[10];
void buildmax(int p,int l,int r,int k){
	if(l>r)return;
	if(l==r){
		if(k==1)maxtreeza[p]=za[l];
		if(k==2)maxtreefa[p]=fa[l];
		if(k==3)maxtreezb[p]=zb[l];
		if(k==4)maxtreefb[p]=fb[l];
		return;
	}
	int mid=(l+r)/2;
	buildmax(p+p,l,mid,k);
	buildmax(p+p+1,mid+1,r,k);
	switch(k)
		if(k==1)maxtreeza[p]=max(maxtreeza[p+p],maxtreeza[p+p+1]);
		if(k==2)maxtreefa[p]=max(maxtreefa[p+p],maxtreefa[p+p+1]);
		if(k==3)maxtreezb[p]=max(maxtreezb[p+p],maxtreezb[p+p+1]);
		if(k==4)maxtreefb[p]=max(maxtreefb[p+p],maxtreefb[p+p+1]);
}
void buildmin(int p,int l,int r,int k){
	if(l>r)return;
	if(l==r){
		if(k==1)mintreeza[p]=za[l];
		if(k==2)mintreefa[p]=fa[l];
		if(k==3)mintreezb[p]=zb[l];
		if(k==4)mintreefb[p]=fb[l];
		return;
	}
	int mid=(l+r)/2;
	buildmin(p+p,l,mid,k);
	buildmin(p+p+1,mid+1,r,k);
	switch(k)
		if(k==1)mintreeza[p]=min(mintreeza[p+p],mintreeza[p+p+1]);
		if(k==2)mintreefa[p]=min(mintreefa[p+p],mintreefa[p+p+1]);
		if(k==3)mintreezb[p]=min(mintreezb[p+p],mintreezb[p+p+1]);
		if(k==4)mintreefb[p]=min(mintreefb[p+p],mintreefb[p+p+1]);
}
void builda(int p,int l,int r){
	if(l>r)return;
	if(l==r){
		tree0a[p]=zeroa[l];
		return;
	}
	int mid=(l+r)/2;
	builda(p+p,l,mid);
	builda(p+p+1,mid+1,r);
	tree0a[p]=tree0a[p+p]|tree0a[p+p+1];
}
void buildb(int p,int l,int r){
	if(l>r)return;
	if(l==r){
		tree0b[p]=zerob[l];
		return;
	}
	int mid=(l+r)/2;
	buildb(p+p,l,mid);
	buildb(p+p+1,mid+1,r);
	tree0b[p]=tree0b[p+p]|tree0b[p+p+1];
}
int findmax(int p,int x,int y,int kx,int ky,int k){
	if(x>y)return 0;
	if(x==kx&&y==ky){
		if(k==1)return maxtreeza[p];
		if(k==2)return maxtreefa[p];
		if(k==3)return maxtreezb[p];
		if(k==4)return maxtreefb[p];
	}
	int mid=(x+y)/2;
	if(ky<=mid)return findmax(p+p,x,mid,kx,ky,k);
	else if(kx>mid)return findmax(p+p+1,mid+1,y,kx,ky,k);
	else return max(findmax(p+p,x,mid,kx,mid,k),findmax(p+p+1,mid+1,y,mid+1,ky,k));
}
int findmin(int p,int x,int y,int kx,int ky,int k){
	if(x>y)return 0;
	if(x==kx&&y==ky){
		if(k==1)return mintreeza[p];
		if(k==2)return mintreefa[p];
		if(k==3)return mintreezb[p];
		if(k==4)return mintreefb[p];
	}
	int mid=(x+y)/2;
	if(ky<=mid)return findmin(p+p,x,mid,kx,ky,k);
	else if(kx>mid)return findmin(p+p+1,mid+1,y,kx,ky,k);
	else return min(findmin(p+p,x,mid,kx,mid,k),findmin(p+p+1,mid+1,y,mid+1,ky,k));
}
bool find0a(int p,int x,int y,int kx,int ky){
	if(x>y)return 0;
	if(x==kx&&y==ky)return tree0a[p];
	int mid=(x+y)/2;
	if(ky<=mid)return find0a(p+p,x,mid,kx,ky);
	else if(kx>mid)return find0a(p+p+1,mid+1,y,kx,ky);
	else return find0a(p+p,x,mid,kx,mid)||find0a(p+p+1,mid+1,y,mid+1,ky);
}
bool find0b(int p,int x,int y,int kx,int ky){
	if(x>y)return 0;
	if(x==kx&&y==ky)return tree0b[p];
	int mid=(x+y)/2;
	if(ky<=mid)return find0b(p+p,x,mid,kx,ky);
	else if(kx>mid)return find0b(p+p+1,mid+1,y,kx,ky);
	else return find0b(p+p,x,mid,kx,mid)||find0b(p+p+1,mid+1,y,mid+1,ky);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		int x;
		scanf("%d",&a[i]);
		if(a[i]>0)za[++cza]=a[i];
		if(a[i]==0)zeroa[i]=1;
		if(a[i]<0)fa[++cfa]=a[i];
	}
	for(int i=1;i<=m;i++){
		int x;
		scanf("%d",&b[i]);
		if(b[i]>0)zb[++czb]=b[i];
		if(b[i]==0)zerob[i]=1;
		if(b[i]<0)fb[++cfb]=b[i];
	}	
	
	if(cfa>0||cfb>0){
		for(int i=1;i<=q;i++){
			int l1,r1,l2,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			long long ans1,ans2;
			ans1=-1e18;ans2=1e18;
			for(int i=l1;i<=r1;i++)
				for(int j=l2;j<=r2;j++){
					long long ax=a[i],bx=b[j];
					ans1=max(ans1,ax*bx);
					ans2=min(ans2,ax*bx);
				}
			printf("%lld\n",ans1+ans2);
		}
	}else{
		buildmax(1,1,cza,1); if(cza==0)bo[1]=bo[5]=1;
		buildmax(1,1,cfa,2); if(cfa==0)bo[2]=bo[6]=1;
		buildmax(1,1,czb,3); if(czb==0)bo[3]=bo[7]=1;
		buildmax(1,1,cfb,4); if(cfb==0)bo[4]=bo[8]=1;
		buildmin(1,1,cza,1);
		buildmin(1,1,cfa,2);
		buildmin(1,1,czb,3);
		buildmin(1,1,cfb,4);
		builda(1,1,n);
		buildb(1,1,m);
		for(int i=1;i<=q;i++){
			int l1,r1,l2,r2;
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			long long ans1,ans2;
			ans[1]=findmax(1,1,cza,l1,r1,1);
			ans[2]=findmax(1,1,cfa,l1,r1,2);
			ans[3]=findmax(1,1,czb,l2,r2,3);
			ans[4]=findmax(1,1,cfb,l2,r2,4);
			ans[5]=findmin(1,1,cza,l1,r1,1);
			ans[6]=findmin(1,1,cfa,l1,r1,2);
			ans[7]=findmin(1,1,czb,l2,r2,3);
			ans[8]=findmin(1,1,cfb,l2,r2,4);
			bool flag0=find0a(1,1,n,l1,r1)|find0b(1,1,m,l2,r2);
			if(flag0)ans1=ans2=0;
			else ans1=-1e18,ans2=1e18;
			for(int i=1;i<=8;i++)
				for(int j=1;j<=8;j++)
					if(!bo[i]&&!bo[j]){	
						ans1=max(ans1,ans[i]*ans[j]);
						ans2=min(ans2,ans[i]*ans[j]);
					}
			printf("%lld\n",ans1+ans2);
		}
	}
	
	return 0;
}