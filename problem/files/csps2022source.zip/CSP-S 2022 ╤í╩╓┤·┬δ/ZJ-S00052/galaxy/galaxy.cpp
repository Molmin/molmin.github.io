#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int e[10005][10005];
bool vis[10005]={};
queue<int> que;
bool cheak(int x){
	int cnt=0;
	for(int i=1;i<=n;i++)
		if(e[x][i]==1)cnt++;
	if(cnt!=1)return 0;
	memset(vis,0,sizeof(vis));
	que.push(x);
	while(!que.empty()){
		int ti=que.front();
		que.pop();
		if(vis[ti])return 1;
		vis[ti]=1;
		for(int i=1;i<=n;i++)
			if(e[ti][i]==1)que.push(i);
	}
	return 0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		e[u][v]=1;
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		int t,u,v;
		scanf("%d",&t);
		if(t==1){
			scanf("%d%d",&u,&v);
			e[u][v]=-1;
		}
		if(t==2){
			scanf("%d",&u);
			for(int j=1;j<=n;j++)
				if(e[j][u]!=0)e[j][u]=-1;
		}
		if(t==3){
			scanf("%d%d",&u,&v);
			e[u][v]=1;
		}
		if(t==4){
			scanf("%d",&u);
			for(int j=1;j<=n;j++)
				if(e[j][u]==-1)e[j][u]=1;
		}
		bool flag=true;
		for(int j=1;j<=n;j++)
			if(!cheak(j)){
				printf("NO\n");
				flag=0;
				break;
			}
		if(flag)printf("YES\n");
	}
}