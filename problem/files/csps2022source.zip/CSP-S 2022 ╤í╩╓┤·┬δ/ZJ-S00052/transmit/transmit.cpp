#include<bits/stdc++.h>
using namespace std;
int n,q,k;
long long v[200005];
bool vis[200005];
vector<int> e[200005];
long long search(int now,int sum,int t,int k){
	if(vis[now])return 1e18;
	vis[now]=1;
	if(now==t)return sum;
	long long ret=1e18;
	for(int i=0;i<e[now].size();i++){
		ret=min(ret,search(e[now][i],sum+v[now]*k,t,1-k));
	}
	return ret;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<=n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for(int i=1;i<=q;i++){
		int s,t;
		scanf("%d%d",&s,&t);
		memset(vis,0,sizeof(vis));
		printf("%lld\n",min(search(s,0,t,0),search(s,0,t,1)));
	}
	return 0;
}                     