#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5 + 5;
int n, q, k, u, v, w[N], dep[N], fa[N][20]; ll sum[N], dp[N][20][2][2]; basic_string <int> adj[N];
int read() {
	int s = 0; char ch = getchar();
	while (! isdigit(ch)) ch = getchar();
	while (isdigit(ch)) s = s * 10 + ch - '0', ch = getchar();
	return s;
}
void write(ll x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
void dfs1(int u, int f) {
	dep[u] = dep[f] + 1, fa[u][0] = f, sum[u] = sum[f] + w[u];
	for (int i=1; 1<<i<dep[u]; i++)
		fa[u][i] = fa[fa[u][i-1]][i-1];
	for (int v : adj[u]) if (v ^ f)
		dfs1(v, u);
}
void dfs2(int u, int f) {
	dep[u] = dep[f] + 1, fa[u][0] = f, dp[u][0][1][0] = dp[u][0][1][1] = w[u], dp[u][0][0][0] = 1e18;
	for (int i=1; 1<<i<dep[u]; i++) {
		fa[u][i] = fa[fa[u][i-1]][i-1];
		for (int p=0; p<=1; p++) for (int q=0; q<=1; q++)
			dp[u][i][p][q] = min(dp[u][i-1][p][0] + dp[fa[u][i-1]][i-1][0][q], dp[u][i-1][p][1] + dp[fa[u][i-1]][i-1][1][q]);
	}
	for (int v : adj[u]) if (v ^ f)
		dfs2(v, u);
}
int getlca1(int u, int v) {
	if (dep[u] < dep[v]) swap(u, v);
	int k = dep[u] - dep[v];
	for (int i=0; i<=17; i++)
		if (k & 1 << i) {
			u = fa[u][i];
			if (u == v) return u;
		}
	for (int i=17; ~i; i--)
		if (fa[u][i] ^ fa[v][i])
			u = fa[u][i], v = fa[v][i];
	return fa[u][0];
}
ll getlca2(int u, int v) {
	ll f[2], g[2], t[2]; f[0] = g[0] = 1e18, f[1] = g[1] = 0;
	if (dep[u] < dep[v]) swap(u, v);
	int k = dep[u] - dep[v];
	for (int i=0; i<=17; i++)
		if (k & 1 << i) {
			for (int p=0; p<=1; p++)
				t[p] = min(f[0] + dp[u][i][0][p], f[1] + dp[u][i][1][p]);
			f[0] = t[0], f[1] = t[1];
			u = fa[u][i];
			if (u == v) return f[1] + w[v];
		}
	for (int i=17; ~i; i--)
		if (fa[u][i] ^ fa[v][i]) {
			for (int p=0; p<=1; p++)
				t[p] = min(f[0] + dp[u][i][0][p], f[1] + dp[u][i][1][p]);
			f[0] = t[0], f[1] = t[1];
			for (int p=0; p<=1; p++)
				t[p] = min(g[0] + dp[v][i][0][p], g[1] + dp[v][i][1][p]);
			g[0] = t[0], g[1] = t[1];
			u = fa[u][i], v = fa[v][i];
		}
	for (int p=0; p<=1; p++)
		t[p] = min(f[0] + dp[u][0][0][p], f[1] + dp[u][0][1][p]);
	f[0] = t[0], f[1] = t[1];
	for (int p=0; p<=1; p++)
		t[p] = min(g[0] + dp[v][0][0][p], g[1] + dp[v][0][1][p]);
	g[0] = t[0], g[1] = t[1];
	return min(f[0] + g[0], f[1] + g[1] + w[fa[u][0]]);
}
typedef pair <ll, int> pli;
int edgenum, Head[N*3], Next[N*10], vet[N*10], val[N*10]; int vis[N]; ll dis[N];
void add(int u, int v, int w) {
	Next[++edgenum] = Head[u];
	Head[u] = edgenum;
	vet[edgenum] = v;
	val[edgenum] = w;
}
int main() {
	freopen ("transmit.in", "r", stdin);
	freopen ("transmit.out", "w", stdout);
	cin >> n >> q >> k;
	for (int i=1; i<=n; i++)
		w[i] = read();
	for (int i=1; i<n; i++)
		u = read(), v = read(), adj[u] += v, adj[v] += u;
	if (k == 3) {
		for (int i=1; i<=n; i++)
			for (int j : adj[i])
				add(i * 3 - 2, j * 3 - 2, w[j]), 
				add(i * 3 - 1, j * 3 - 2, w[j]), 
				add(i * 3 - 0, j * 3 - 2, w[j]), 
				add(i * 3 - 2, j * 3 - 1, 0), 
				add(i * 3 - 1, j * 3 - 0, 0);
		while (q --) {
			u = read(), v = read();
			for (int i=1; i<=n*3; i++)
				dis[i] = 1e18, vis[i] = 0;
			priority_queue <pli, vector <pli>, greater <pli>> que;
			dis[u*3-2] = w[u], que. push(pli (w[u], u*3-2));
			while (1) {
				int u = que. top(). second; que. pop();
				if (u == v * 3 - 2) { write(dis[u]), putchar('\n'); break; }
				if (vis[u]) continue; vis[u] = 1;
				for (int e=Head[u]; e; e=Next[e]) {
					int v=vet[e], w=val[e];
					if (dis[v] > dis[u] + w)
						dis[v] = dis[u] + w, que. push(pli (dis[v], v));
				}
			}
		} return 0;
	}
	k == 1 ? dfs1(1, 0) : dfs2(1, 0);
	while (q --) {
		u = read(), v = read();
		if (k == 1) {
			int lca = getlca1(u, v);
			write(sum[u] + sum[v] - sum[lca] - sum[fa[lca][0]]), putchar('\n');
		} else if (k == 2)
			write(getlca2(u, v)), putchar('\n');
	} return 0;
}
