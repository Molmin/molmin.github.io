#include <bits/stdc++.h>
using namespace std;
const int N = 5e5 + 5;
typedef unsigned long long ull;
int n, m, q, u, v, Cnt, deg[N], del[N], o; ull w[N], all, Hash, sum[N]; basic_string <int> upd[N];
int read() {
	int s = 0; char ch = getchar();
	while (! isdigit(ch)) ch = getchar();
	while (isdigit(ch)) s = s * 10 + ch - '0', ch = getchar();
	return s;
}
int main() { srand(20051231);
	freopen ("galaxy.in", "r", stdin);
	freopen ("galaxy.out", "w", stdout);
	n = read(), m = read();
	for (int i=1; i<=n; i++) {
		for (int j=0; j<64; j++)
			if (rand() & 1)
				w[i] |= 1ull << j;
		all ^= w[i];
	}
	while (m --)
		u = read(), v = read(), Cnt ++, deg[v] ++, Hash ^= w[u], sum[v] ^= w[u];
	q = read();
	while (q --) {
		o = read();
		if (o & 1) {
			u = read(), v = read();
			Cnt += o - 2, Hash ^= w[u], upd[v]. push_back((o - 2) * u);
		} else {
			v = read();
			for (int u : upd[v])
				Cnt += u < 0 ? 1 : - 1, Hash ^= w[abs(u)];
			upd[v]. clear();
			if (del[v] ^ o == 2)
				del[v] ^= 1, Cnt += (o - 3) * deg[v], Hash ^= sum[v];
		} puts (Cnt == n && Hash == all ? "YES" : "NO");
	} return 0;
}
