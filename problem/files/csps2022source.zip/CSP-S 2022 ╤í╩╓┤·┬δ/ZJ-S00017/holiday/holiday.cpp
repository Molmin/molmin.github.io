#include <bits/stdc++.h>
using namespace std;
const int N = 2555;
typedef long long ll;
int n, m, k, u, v, que[N], head, tail, dis[N][N], Max[N][3]; ll s[N], ans; basic_string <int> adj[N];
int main() {
	freopen ("holiday.in", "r", stdin);
	freopen ("holiday.out", "w", stdout);
	cin >> n >> m >> k, k ++;
	for (int i=2; i<=n; i++) scanf ("%lld", &s[i]);
	while (m --) scanf ("%d%d", &u, &v), adj[u] += v, adj[v] += u;
	for (int i=1; i<=n; i++) {
		for (int j=1; j<=n; j++)
			dis[i][j] = 1e9; dis[i][i] = 0;
		que[head=tail=1] = i;
		while (head <= tail) {
			int u = que[head++];
			for (int v : adj[u])
				if (dis[i][v] == 1e9)
					dis[i][v] = dis[i][u] + 1, que[++tail] = v;
		}
		if (i == 1) continue;
		for (int j=2; j<=n; j++)
			if (i != j && dis[i][j] <= k && dis[1][j] <= k) {
				if (s[j] >= s[Max[i][0]])
					Max[i][2] = Max[i][1], Max[i][1] = Max[i][0], Max[i][0] = j;
				else if (s[j] >= s[Max[i][1]])
					Max[i][2] = Max[i][1], Max[i][1] = j;
				else if (s[j] >= s[Max[i][2]])
					Max[i][2] = j;
			}
	}
	for (int i=2; i<=n; i++)
		for (int j=i+1; j<=n; j++)
			if (dis[i][j] <= k) {
				ll res = 0;
				for (int p=0; p<=2; p++)
					for (int q=0; q<=2; q++)
						if (Max[i][p] && Max[i][p] != j && Max[j][q] && Max[j][q] != i && Max[i][p] != Max[j][q])
							res = max(res, s[Max[i][p]] + s[Max[j][q]]);
				if (res) ans = max(ans, res + s[i] + s[j]);
			}
	return cout << ans << endl, 0;
}
