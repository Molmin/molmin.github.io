#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
int n, m, q, a[N], b[N], L[N], ST1[N][20], ST2[N][20], ST3[N][20], ST4[N][20], ST5[N][20], ST6[N][20];
int l1, r1, l2, r2, x, y, t; long long ans;
int read() {
	int s = 0, w = 1; char ch = getchar();
	while (! isdigit(ch)) { if (ch == '-') w = - w; ch = getchar(); }
	while (isdigit(ch)) s = s * 10 + ch - '0', ch = getchar();
	return s * w;
}
void write(long long x) {
	if (x < 0) putchar('-'), x = - x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
int qry0(int ST[][20], int l, int r) {
	int k = L[r-l+1];
	return min(ST[l][k], ST[r-(1<<k)+1][k]);
}
int qry1(int ST[][20], int l, int r) {
	int k = L[r-l+1];
	return max(ST[l][k], ST[r-(1<<k)+1][k]);
}
int main() {
	freopen ("game.in", "r", stdin);
	freopen ("game.out", "w", stdout);
	L[0] = - 1;
	for (int i=1; i<=100000; i++)
		L[i] = L[i>>1] + 1;
	n = read(), m = read(), q = read();
	for (int i=1; i<=n; i++) a[i] = read();
	for (int i=1; i<=m; i++) b[i] = read();
	for (int i=1; i<=n; i++) ST1[i][0] = ST3[i][0] = a[i], ST2[i][0] = a[i] >= 0 ? a[i] : 2e9, ST4[i][0] = a[i] < 0 ? a[i] : - 2e9;
	for (int j=1; j<=L[n]; j++) for (int i=1; i<=n; i++) {
		ST1[i][j] = ST1[i][j-1], ST2[i][j] = ST2[i][j-1], ST3[i][j] = ST3[i][j-1], ST4[i][j] = ST4[i][j-1];
		if (i+(1<<j-1) <= n) ST1[i][j] = max(ST1[i][j], ST1[i+(1<<j-1)][j-1]), ST2[i][j] = min(ST2[i][j], ST2[i+(1<<j-1)][j-1]), ST3[i][j] = min(ST3[i][j], ST3[i+(1<<j-1)][j-1]), ST4[i][j] = max(ST4[i][j], ST4[i+(1<<j-1)][j-1]);
	}
	for (int i=1; i<=m; i++) ST5[i][0] = ST6[i][0] = b[i];
	for (int j=1; j<=L[m]; j++) for (int i=1; i<=m; i++) {
		ST5[i][j] = ST5[i][j-1], ST6[i][j] = ST6[i][j-1];
		if (i+(1<<j-1) <= m) ST5[i][j] = min(ST5[i][j], ST5[i+(1<<j-1)][j-1]), ST6[i][j] = max(ST6[i][j], ST6[i+(1<<j-1)][j-1]);
	}
	while (q --) {
		l1 = read(), r1 = read(), l2 = read(), r2 = read(), ans = - 8e18;
		x = qry0(ST5, l2, r2), y = qry1(ST6, l2, r2);
		t = x >= 0 ? qry1(ST1, l1, r1) : qry0(ST2, l1, r1); if (t >= 0 && t !=   2e9) ans = max(ans, 1ll * x * t);
		t = y <  0 ? qry0(ST3, l1, r1) : qry1(ST4, l1, r1); if (t <  0 && t != - 2e9) ans = max(ans, 1ll * y * t);
		write(ans), putchar('\n');
	} return 0;
}
