#include<bits/stdc++.h>
using namespace std;
struct ZS{
	int x;
	long long v;
}P[4000005];
int n,Q,k,tot,Tot;
int v[2005],q[2005];
int lnk[4005],nxt[4005],son[4005];
int Lnk[2005],Nxt[8000005],Son[8000005];
int mp[2005][2005];
long long V[2005];
inline int read(){
	int ret=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-f;ch=getchar();}
	while(isdigit(ch)){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
void make(int x,int y){son[++tot]=y;nxt[tot]=lnk[x];lnk[x]=tot;}
void Make(int x,int y){Son[++Tot]=y;Nxt[Tot]=Lnk[x];Lnk[x]=Tot;}
void BFS(int x){
	int hed=0,til=0;q[++til]=x;mp[x][x]=1;
	while(hed^til)
		for(int i=lnk[q[++hed]];i;i=nxt[i])if(!mp[x][son[i]]){
			if(mp[x][q[hed]]<=k)mp[x][son[i]]=mp[x][q[hed]]+1,q[++til]=son[i],Make(x,son[i]),Make(son[i],x);
		}
}
long long SPFA(int s,int t){
	memset(V,127,sizeof V);
	int hed=0,til=0;P[++til]=(ZS){s,v[s]};V[s]=v[s];
	while(hed^til){
		hed++;
		for(int i=Lnk[P[hed].x];i;i=Nxt[i])
			if(P[hed].v+v[Son[i]]<V[Son[i]])V[Son[i]]=P[hed].v+v[Son[i]],P[++til]=(ZS){Son[i],V[Son[i]]};
	}
	return V[t];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();Q=read();k=read();
	if(n>2005)return 0;
	for(int i=1;i<=n;i++)v[i]=read();
	for(int i=1;i<n;i++){
		int x=read(),y=read();
		make(x,y);make(y,x);
	}
	for(int i=1;i<=n;i++)BFS(i);
	while(Q--){
		int s=read(),t=read();
		printf("%lld\n",SPFA(s,t));
	}
	return 0;
}
