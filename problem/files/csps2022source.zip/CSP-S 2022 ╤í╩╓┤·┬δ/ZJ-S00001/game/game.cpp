#include<bits/stdc++.h>
using namespace std;
int n,m,q,l,L,r,R;
int a[100005],b[100005],c[2][100005];
int A[4],B[4];
int fa[4][100005][20],fb[4][100005][20];
inline int read(){
	int ret=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-f;ch=getchar();}
	while(isdigit(ch)){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
void make_1(){
	for(int i=1;i<=n;i++)if(a[i]>0)fa[0][i][0]=a[i];
	for(int j=1;j<=log2(n)+1;j++)
	for(int i=1;i+(1<<j)-1<=n;i++)fa[0][i][j]=max(fa[0][i][j-1],fa[0][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=n;i++)if(a[i]>0)fa[1][i][0]=a[i];else fa[1][i][0]=1<<30;
	for(int j=1;j<=log2(n)+1;j++)
	for(int i=1;i+(1<<j)-1<=n;i++)fa[1][i][j]=min(fa[1][i][j-1],fa[1][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=n;i++)if(a[i]<0)fa[2][i][0]=a[i];else fa[2][i][0]=-1<<30;
	for(int j=1;j<=log2(n)+1;j++)
	for(int i=1;i+(1<<j)-1<=n;i++)fa[2][i][j]=max(fa[2][i][j-1],fa[2][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=n;i++)if(a[i]<0)fa[3][i][0]=a[i];
	for(int j=1;j<=log2(n)+1;j++)
	for(int i=1;i+(1<<j)-1<=n;i++)fa[3][i][j]=min(fa[3][i][j-1],fa[3][i+(1<<j-1)][j-1]);
}
void make_2(){
	for(int i=1;i<=m;i++)if(b[i]>0)fb[0][i][0]=b[i];
	for(int j=1;j<=log2(m)+1;j++)
	for(int i=1;i+(1<<j)-1<=m;i++)fb[0][i][j]=max(fb[0][i][j-1],fb[0][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=m;i++)if(b[i]>0)fb[1][i][0]=b[i];else fb[1][i][0]=1<<30;
	for(int j=1;j<=log2(m)+1;j++)
	for(int i=1;i+(1<<j)-1<=m;i++)fb[1][i][j]=min(fb[1][i][j-1],fb[1][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=m;i++)if(b[i]<0)fb[2][i][0]=b[i];else fb[2][i][0]=-1<<30;
	for(int j=1;j<=log2(m)+1;j++)
	for(int i=1;i+(1<<j)-1<=m;i++)fb[2][i][j]=max(fb[2][i][j-1],fb[2][i+(1<<j-1)][j-1]);
	
	for(int i=1;i<=m;i++)if(b[i]<0)fb[3][i][0]=b[i];
	for(int j=1;j<=log2(m)+1;j++)
	for(int i=1;i+(1<<j)-1<=m;i++)fb[3][i][j]=min(fb[3][i][j-1],fb[3][i+(1<<j-1)][j-1]);
}
void add(int x,int y){for(int i=y;i<=n;i+=i&-i)c[x][i]++;}
int get(int x,int y){
	int cnt=0;
	for(int i=y;i;i-=i&-i)cnt+=c[x][i];
	return cnt;
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)a[i]=read();
	for(int i=1;i<=n;i++)if(a[i]==0)add(0,i);
	for(int i=1;i<=m;i++)b[i]=read();
	for(int i=1;i<=n;i++)if(b[i]==0)add(1,i);
	make_1();make_2();
	while(q--){
		l=read();r=read();L=read();R=read();
		A[0]=max(fa[0][l][(int)log2(r-l+1)],fa[0][r-(1<<(int)log2(r-l+1))+1][(int)log2(r-l+1)]);
		A[1]=min(fa[1][l][(int)log2(r-l+1)],fa[1][r-(1<<(int)log2(r-l+1))+1][(int)log2(r-l+1)]);
		A[2]=max(fa[2][l][(int)log2(r-l+1)],fa[2][r-(1<<(int)log2(r-l+1))+1][(int)log2(r-l+1)]);
		A[3]=min(fa[3][l][(int)log2(r-l+1)],fa[3][r-(1<<(int)log2(r-l+1))+1][(int)log2(r-l+1)]);
		B[0]=max(fb[0][L][(int)log2(R-L+1)],fb[0][R-(1<<(int)log2(R-L+1))+1][(int)log2(R-L+1)]);
		B[1]=min(fb[1][L][(int)log2(R-L+1)],fb[1][R-(1<<(int)log2(R-L+1))+1][(int)log2(R-L+1)]);
		B[2]=max(fb[2][L][(int)log2(R-L+1)],fb[2][R-(1<<(int)log2(R-L+1))+1][(int)log2(R-L+1)]);
		B[3]=min(fb[3][L][(int)log2(R-L+1)],fb[3][R-(1<<(int)log2(R-L+1))+1][(int)log2(R-L+1)]);
		long long maxn=-(long long)1<<60;
		for(int i=0;i<=3;i++)if(A[i]!=0&&A[i]!=1<<30&&A[i]!=-1<<30){
			long long minn=(long long)1<<60;
			for(int j=0;j<=3;j++)if(B[j]!=0&&B[j]!=1<<30&&B[j]!=-1<<30)minn=min(minn,(long long)A[i]*B[j]);
			maxn=max(maxn,minn);
			}
		if(maxn<0){
			if(get(0,r)-get(0,l-1))printf("0\n");
			else printf("%lld\n",maxn);
		}else{
			if(get(1,R)-get(1,L-1))printf("0\n");
			else printf("%lld\n",maxn);
		}
	}
	return 0;
}
