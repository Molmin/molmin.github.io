#include<bits/stdc++.h>
using namespace std;
int n,m,k,tot;
int now[10];
int lnk[2505],nxt[20005],son[20005],q[2505];
int mp[2505][2505];
long long ans;
long long s[2505];
bool vis[2505];
inline long long Bread(){
	long long ret=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-f;ch=getchar();}
	while(isdigit(ch)){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
inline int read(){
	int ret=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-f;ch=getchar();}
	while(isdigit(ch)){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
void make(int x,int y){son[++tot]=y;nxt[tot]=lnk[x];lnk[x]=tot;}
void BFS(int x){
	int til=0,hed=0;q[++til]=x;
	while(hed^til)
		for(int i=lnk[q[++hed]];i;i=nxt[i])if(!mp[x][son[i]]){
			mp[x][son[i]]=mp[x][q[hed]]+1;q[++til]=son[i];
		}
}
void dfs(int step,long long v){
	if(step==4&&mp[1][now[step]]==1){
		ans=max(ans,v);
		return;
	}
	if(step<4){
		for(int i=lnk[now[step]];i;i=nxt[i]){
			bool flg=0;
			for(int j=0;j<=step;j++)if(son[i]==now[j]){flg=1;break;}
			if(flg)continue;
			now[step+1]=son[i];
			dfs(step+1,v+s[son[i]]);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=2;i<=n;i++)s[i]=Bread();
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		make(x,y);make(y,x);
	}
	for(int i=1;i<=n;i++)BFS(i);
	if(!k){
		now[0]=1;
		dfs(0,0);
		printf("%lld\n",ans);
		return 0;
	}
	for(int i=2;i<=n;i++)if(mp[1][i]<=k+1){
		vis[i]=1;
		for(int j=2;j<=n;j++)if(mp[i][j]<=k+1&&!vis[j]){
			vis[j]=1;
			for(int h=2;h<=n;h++)if(mp[j][h]<=k+1&&!vis[h]){
				vis[h]=1;
				for(int g=2;g<=n;g++)if(mp[h][g]<=k+1&&mp[g][1]<=k+1&&!vis[g])ans=max(ans,s[i]+s[j]+s[h]+s[g]);
				vis[h]=0;
			}
			if(2*CLOCKS_PER_SEC-clock()<100){printf("%lld\n",ans);return 0;}
			vis[j]=0;
		}
		vis[i]=0;
	}
	printf("%lld\n",ans);
	return 0;
}
