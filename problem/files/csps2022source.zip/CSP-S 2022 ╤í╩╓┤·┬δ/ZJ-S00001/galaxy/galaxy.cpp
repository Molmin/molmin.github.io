#include<bits/stdc++.h>
using namespace std;
int n,m,Q,tot;
int lnk[1005],nxt[10005],son[10005],q[1005];
int mp[1005][1005],MP[1005][1005];
bool vis[1005];
inline int read(){
	int ret=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-')f=-f;ch=getchar();}
	while(isdigit(ch)){ret=ret*10+ch-'0';ch=getchar();}
	return ret*f;
}
void make(int x,int y){son[++tot]=y;nxt[tot]=lnk[x];lnk[x]=tot;}
int topu(int x){
	int hed=0,til=0;q[++til]=x;
	while(hed^til){
		vis[q[hed]]=1;
		for(int i=lnk[q[++hed]];i;i=nxt[i]){
			if(!mp[q[hed]][son[i]])continue;
			q[++til]=son[i];
			if(vis[son[i]])return 1;
		}
	}
	return 0;
}
bool check(){
	for(int i=1;i<=n;i++){
		int num=0;
		for(int j=lnk[i];j;j=nxt[j]){
			if(!mp[i][son[j]])continue;
			num++;
		}
		if(num!=1)return 0;
	}
	bool fg=0;
	for(int i=1;i<=n;i++)if(!vis[i]){
		if(!topu(i))return 0;
		fg=1;
	}
	return fg;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++){
		int x=read(),y=read();
		make(x,y);
		mp[x][y]=1;
		MP[y][x]=1;
	}
	Q=read();
	while(Q--){
		int t,u,v;
		t=read();
		if(t&1)u=read(),v=read();
		else u=read();
		if(t==1)mp[u][v]=0;
		else if(t==2){
			for(int i=1;i<=n;i++)if(MP[u][i])mp[i][u]=0;
		}
		else if(t==3)mp[u][v]=1;
		else if(t==4){
			for(int i=1;i<=n;i++)if(MP[u][i])mp[i][u]=1;
		}
		if(check())printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
