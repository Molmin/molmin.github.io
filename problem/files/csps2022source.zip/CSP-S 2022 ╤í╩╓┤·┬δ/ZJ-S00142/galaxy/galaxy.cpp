#include<iostream>
#include<vector>
using namespace std;
int n,m,q;
int needfix[1005][1005];
int endzfix[1005][1005];
vector <int> endz[1005];
vector <int> e[1005];
int out[1005];
void dele(int from,int to){
    for(int i=0;i<e[from].size();i++){
        int v=e[from][i];
        if(v==to){
            e[from][i]=0;
            needfix[from][to]=i;
            out[from]--;
        }
    }
}
void alldele(int x){
    for(int i=0;i<endz[x].size();i++){
        int v=endz[x][i];
        for(int j=0;j<e[v].size();j++){
            if(e[v][j]==x)dele(v,x);
        }
    }
    return;
}
void restore(int from,int to){
    int v=needfix[from][to];
    e[from][v]=to;
    out[from]++;
}
void allfix(int x){
    for(int i=0;i<endz[x].size();i++){
        int v=endz[x][i];
        if(e[v][needfix[v][x]]!=0)continue;
        else restore(v,x);
    }
}
bool judge(){
    for(int i=1;i<=n;i++){
        if(out[i]!=1){
            return 0;
        }
    }
    return 1;
}
int main(){
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int x,y;
        cin>>x>>y;
        out[x]++;
        e[x].push_back(y);
        endz[y].push_back(x);
    }
    cin>>q;
    for(int i=1;i<=q;i++){
        int opt;
        cin>>opt;
        if(opt==1){
            int x,y;
            cin>>x>>y;
            dele(x,y);
        }
        else if(opt==2){
            int x;
            cin>>x;
            alldele(x);
        }
        else if(opt==3){
            int x,y;
            cin>>x>>y;
            restore(x,y);
        }
        else if(opt==4){
            int x;
            cin>>x;
            allfix(x);
        }
        if(judge()){
            cout<<"YES"<<endl;
        }
        else cout<<"NO"<<endl;
    }
}
