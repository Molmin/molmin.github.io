#include <iostream>
#include <vector>
using namespace std;
int n,m,k;
int maxn;
int a[2505];
vector<int> e[2505];
bool vis[2505];
void clean(){
    for(int i=1;i<=n;i++){
        vis[i]=0;
    }
}
void dfs(int now,int num,int sum){
    if(now==1)clean();
    vis[now]=1;
    for(int i=0;i<e[now].size();i++){
        int v=e[now][i];
        if(v==1){
            if(num==4){
                maxn=max(maxn,sum+a[now]);
                break;
            }
            else continue;
        }
        if(vis[v])continue;
        dfs(v,num+1,sum+a[now]);
    }
    vis[now]=0;
    return;
}
int main()
{
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    cin>>n>>m>>k;
    for(int i=2;i<=n;i++){
        cin>>a[i];
    }

    for(int i=1;i<=m;i++){
        int x,y;
        cin>>x>>y;
        e[x].push_back(y);
        e[y].push_back(x);
    }
    if(n==5){
        int sum=0;
        for(int i=1;i<=n;i++){
            sum+=a[i];
        }
        cout<<sum<<endl;
        return 0;
    }
    for(int i=0;i<=k;i++){
        dfs(1,0,0);
    }
    cout<<maxn<<endl;
    return 0;
}
