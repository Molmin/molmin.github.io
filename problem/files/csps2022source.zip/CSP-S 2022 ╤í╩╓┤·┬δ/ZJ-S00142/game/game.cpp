#include<iostream>
#define int long long
using namespace std;
int n,m,q;
struct query{
    int l1,r1;
    int l2,r2;
}que[1005];
int a[1005],b[1005],c[1005][1005];
signed main(){
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=m;i++){
        cin>>b[i];
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            c[i][j]=a[i]*b[j];
            //cout<<c[i][j]<<' ';
        }
        //cout<<endl;
    }
    for(int i=1;i<=q;i++){
        cin>>que[i].l1>>que[i].r1>>que[i].l2>>que[i].r2;
    }
    for(int i=1;i<=q;i++){
        int x1=que[i].l1,y1=que[i].r1,x2=que[i].l2,y2=que[i].r2;
        int ans=-1145141919810;
        for(int j=x1;j<=y1;j++){
            int linemin=1145141919810;
            for(int k=x2;k<=y2;k++){
                linemin=min(linemin,c[j][k]);
            }
            ans=max(ans,linemin);
        }
        cout<<ans<<endl;
    }
    return 0;
}
