#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long v[2501];
vector<int> u[2501],e[2501];
long long f[2501][2501],g[2501][2501],h[2501][2501];
int mp[2501];
struct kkk{
	long long x,y,z;
}p[5000001];
bool cmp(kkk x,kkk y)
{
	return x.x>y.x;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&v[i]);
	}
	int xx,yy;
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d",&xx,&yy);
		u[xx].push_back(yy);u[yy].push_back(xx);
	}
	for(int i=1;i<=n;i++)
	{
		queue<int> q;
		q.push(i);
		memset(mp,0,sizeof(mp));
		mp[i]=1;
		while(!q.empty())
		{
			int x=q.front();q.pop();
			for(int j=0;j<u[x].size();j++)
			{
				if(mp[u[x][j]]==0)
				{
					mp[u[x][j]]=mp[x]+1;
					e[i].push_back(u[x][j]);
					if(mp[u[x][j]]<=k+1)
						q.push(u[x][j]);
				}
			}
		}
	}
	for(int i=0;i<e[1].size();i++)
	{
		int x=e[1][i];
		for(int j=0;j<e[x].size();j++)
		{
			if(e[x][j]!=1)
			{
				f[x][e[x][j]]=v[x]+v[e[x][j]];
			}
		}
	}
	long long ans=0,t=0;
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=n;j++)
		{
			if(f[i][j])
			{
				t++;
				p[t].x=f[i][j];p[t].y=i;p[t].z=j;
			}
		}
	}
	sort(p+1,p+t+1,cmp);
	for(int i=1;i<=t;i++)
	{
		for(int j=i+1;j<=t;j++)
		{
			if(p[i].y!=p[j].y&&p[i].z!=p[j].y&&p[i].y!=p[j].z&&p[i].z!=p[j].z)
			{
				if(ans<p[i].x+p[j].x)
				{
					ans=p[i].x+p[j].x;
					break;
				}
				else break;
			}
		}
	}
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}