#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int s[1000001];
vector<int> u[1001],v[1001],w[1001],w2[1001];
int f[1001];
int find(int k)
{
	if(k==f[k])return k;
	return f[k]=find(f[k]);
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d %d",&n,&m);
	int xx,yy;
	if(n>5000)
	{
		int sum=0,opt;
		for(int i=1;i<=m;i++)
		{
			scanf("%d %d",&xx,&yy);
			s[xx]++;
		}
		scanf("%d",&k);
		for(int i=1;i<=n;i++)if(s[i]==1)sum++;
		for(int i=1;i<=k;i++)
		{
			scanf("%d",&opt);
			if(opt==1)
			{
				scanf("%d %d",&xx,&yy);
				if(s[xx]==1)sum--;
				s[xx]--;
				if(s[xx]==1)sum++;
			}
			if(opt==3)
			{
				scanf("%d %d",&xx,&yy);
				if(s[xx]==1)sum--;
				s[xx]++;
				if(s[xx]==1)sum++;
			}
			if(sum==n)
			{
				printf("YES\n");
			}
			else
			{
				printf("NO\n");
			}
		}
		fclose(stdin);fclose(stdout);
		return 0;
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d %d",&xx,&yy);
		u[xx].push_back(yy);w[xx].push_back(0);
		v[yy].push_back(xx);w2[yy].push_back(u[xx].size()-1);
		s[xx]++;
	}
	int opt;
	scanf("%d",&k);
	for(int i=1;i<=k;i++)
	{
		scanf("%d",&opt);
		if(opt==1)
		{
			scanf("%d %d",&xx,&yy);
			for(int i=0;i<u[xx].size();i++)
			{
				if(u[xx][i]==yy)
				{
					w[xx][i]=1;
					break;
				}
			}
			s[xx]--;
		}
		else if(opt==2)
		{
			scanf("%d",&xx);
			for(int i=0;i<v[xx].size();i++)
			{
				if(w[v[xx][i]][w2[xx][i]]==0)s[v[xx][i]]--;
				w[v[xx][i]][w2[xx][i]]=1;
			}
		}
		else if(opt==3)
		{
			scanf("%d %d",&xx,&yy);
			for(int i=0;i<u[xx].size();i++)
			{
				if(u[xx][i]==yy)
				{
					w[xx][i]=0;
					break;
				}
			}
			s[xx]++;
		}
		else if(opt==4)
		{
			scanf("%d",&xx);
			for(int i=0;i<v[xx].size();i++)
			{
				if(w[v[xx][i]][w2[xx][i]]==1)s[v[xx][i]]++;
				w[v[xx][i]][w2[xx][i]]=0;
			}
		}
		bool flag=1;
		for(int i=1;i<=n;i++)
		{
			if(s[i]!=1)
			{
				flag=0;break;
			}
		}
		if(flag==1)
		{
			printf("YES\n");
		}
		else
		{
			printf("NO\n");
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}