#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[1001],b[1001],c[1001][1001],minn[1001],f[1001][1001][10];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%lld",&b[i]);
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			c[i][j]=a[i]*b[j];
			f[i][j][0]=c[i][j];
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int l=1;l<=log2((double)m);l++)
		{
			for(int j=1;j<=m;j++)
			{
				f[i][j][l]=min(f[i][j][l-1],f[i][j+(1<<(l-1))][l-1]);
			}
		}
	}
	int l1,r1,l2,r2;
	for(int i=1;i<=k;i++)
	{
		scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
		long long minn1=998244353998244353,minn2=0,maxx1=-998244353998244353,maxx2=0;
		for(int p=l1;p<=r1;p++)
		{
			int l=log2(r2-l2+1);
			long long minnn=min(f[p][l2][l],f[p][r2-(1<<l)+1][l]);
			if(minnn>maxx1)
			{
				maxx1=minnn;
				maxx2=p;
			}
		}
		for(int q=l2;q<=r2;q++)
		{
			if(c[maxx2][q]<minn1)
			{
				minn1=c[maxx2][q];
				minn2=q;
			}
		}
		printf("%lld\n",minn1);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}