#include<bits/stdc++.h>
using namespace std;
int n,q,k;
long long v[200001];
long long f[2001][2001],g[2001][2001];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d %d %d",&n,&q,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&v[i]);
	}
	int xx,yy;
	memset(f,14,sizeof(f));
	for(int i=1;i<n;i++)
	{
		scanf("%d %d",&xx,&yy);
		f[xx][yy]=f[yy][xx]=1;
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
			}
		}
	}
	memset(g,14,sizeof(g));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(j!=i&&f[i][j]<=k)
			{
				g[i][j]=v[j];
			}
		}
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				g[i][j]=min(g[i][j],g[i][k]+g[k][j]);
			}
		}
	}
	for(int i=1;i<=q;i++)
	{
		scanf("%d %d",&xx,&yy);
		printf("%lld\n",g[xx][yy]+v[xx]);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}