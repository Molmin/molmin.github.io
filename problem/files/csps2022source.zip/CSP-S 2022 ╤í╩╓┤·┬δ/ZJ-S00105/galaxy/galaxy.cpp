#include<bits/stdc++.h>
using namespace std;
int n,m,q,t,x,y;
int cd[100001],rd[100001],go[100001];
map<int,map<int,int>>v;
bool check(int ovo)
{
	/*cout<<endl<<ovo<<endl<<t<<" "<<x<<" "<<y<<endl;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
			cout<<v[i][j]<<" ";
		cout<<endl;
	}
	for(int i=1;i<=n;i++) printf("%d ",cd[i]);
	cout<<endl;
	for(int i=1;i<=n;i++) printf("%d ",rd[i]);
	cout<<endl;*/
	for(int i=1;i<=n;i++)
		if(cd[i]!=1) return 0;
	for(int i=1;i<=n;i++)
		if(rd[i]-cd[i]>2) return 0;
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++) scanf("%d%d",&x,&y),v[x][y]=1,cd[x]++,rd[y]++,go[y]++;
	scanf("%d",&q);
/*for(int i=1;i<=n;i++) printf("%d ",cd[i]);
	cout<<endl;
	for(int i=1;i<=n;i++) printf("%d ",rd[i]);
	cout<<endl;*/
	for(int k=1;k<=q;k++)
	{
		scanf("%d",&t);
		if(t==1) {scanf("%d%d",&x,&y);v[x][y]=-1;cd[x]--;rd[y]--;}
		if(t==2) 
		{
			scanf("%d",&x),go[x]=-1,rd[x]=0;
			for(int i=1;i<=n;i++)
				if(v[i][x]==1) cd[i]--,v[i][x]=-1;
		}
		if(t==3) {scanf("%d%d",&x,&y);v[x][y]=1;cd[x]++;rd[y]++;}
		if(t==4) 
		{
			scanf("%d",&x),go[x]=0,rd[x]=go[x];
			for(int i=1;i<=n;i++)
				if(v[i][x]==-1) cd[i]++,v[i][x]=1;
		}
		if(check(k)) printf("YES\n");
		else 		printf("NO\n");
	}
	//printf("%lld",ans);
	return 0; 
	//bfs(1);
}
