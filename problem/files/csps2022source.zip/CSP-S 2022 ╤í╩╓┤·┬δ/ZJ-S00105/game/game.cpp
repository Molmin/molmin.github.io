#include<bits/stdc++.h>
using namespace std;
int n,m,q,l1,r1,l2,r2;
int b[100001],a[100100];
long long ans;
//int qaq[100001][100001];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	//for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=m;i++) scanf("%d",&b[i]);
	
		
	
	while(q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1)
		{
			long long minn=(long long) a[l1]*b[l2];
			for(int i=l2+1;i<=r2;i++)
				minn=min(minn,(long long)a[l1]*b[i]);
			printf("%lld\n",minn);
			continue;
		}
		if(l2==r2)
		{
			long long maxn=(long long)a[l1]*b[l2];
			for(int i=l1+1;i<=r1;i++)
				maxn=max(maxn,(long long)a[i]*b[l2]);
			printf("%lld\n",maxn);
			continue;
		}
		long long minn=b[l2],maxn=b[l2];
		for(int i=l2+1;i<=r2;i++)
				minn=min(minn,(long long)b[i]),maxn=max(maxn,(long long)b[i]);
		long long q3q=min(a[l1]*maxn,a[l1]*minn);
		for(int i=l1+1;i<=r1;i++)
			q3q=max(q3q,min(a[i]*maxn,a[i]*minn));
		printf("%lld\n",q3q);
	}
	//printf("%lld",ans);
	return 0;
}
