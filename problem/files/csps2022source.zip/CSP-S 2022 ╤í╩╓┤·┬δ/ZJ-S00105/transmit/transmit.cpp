#include<bits/stdc++.h>
using namespace std;
int n,Q,k,sum;
int v[1001],s,t,w[1001],vis[1001][1001];
int c[1001][1001],omo[1001][1001];
void Floyd()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				if(vis[i][k]+vis[k][j]<vis[i][j])
				{
					//cout<<i<<" "<<k<<" "<<j<<endl;
					vis[j][i]=vis[i][j]=min(vis[i][j],vis[i][k]+vis[k][j]);
					omo[i][j]=omo[j][i]=k;
				}
}
void find(int qd,int zd)
{
	//cout<<omo[qd][zd]<<endl;
	int qwq=zd;
	while(omo[qd][qwq])
	{
		int owo=omo[qd][qwq];
		if(omo[qd][owo]<=k&&omo[owo][zd]<=k)
			sum=min(sum,w[qd]+w[zd]+w[owo]);
		qwq=owo;
		//cout<<omo[qd][qwq]<<endl;
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(vis,1e9,sizeof(vis));
	scanf("%d%d%d",&n,&Q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&w[i]),vis[i][i]=0;
	for(int i=1;i<=n-1;i++)
		scanf("%d%d",&s,&t),vis[s][t]=vis[t][s]=1;
	Floyd();
	while(Q--)
	{
		sum=1e9;
		scanf("%d%d",&s,&t);
		find(s,t);
		printf("%d\n",sum==1e9?w[s]+w[t]:sum);
	}
	return 0;
}
