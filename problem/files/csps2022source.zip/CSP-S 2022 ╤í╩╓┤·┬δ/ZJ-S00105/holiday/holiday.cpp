#include<bits/stdc++.h>
using namespace std;
int n,m,k,x,y;
int b[3001][3001],c[3001][3001];
int vs[25001],vis[25001];
long long ans,ans1;
int a[31000];
void dfs(int x,long long sum,int t,int dc)
{
	if(t==4&&b[x][1])
	{
		ans=max(sum,ans);
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(b[i][x])
		{
			//cout<<i<<" "<<sum<<" "<<t<<" "<<dc<<endl;
			if(!vs[i]) vs[i]=1,dfs(i,sum+a[i-1],t+1,0),vs[i]=0;
			if(dc+1<=k) dfs(i,sum,t,dc+1);
		}
	}
}
void dfs1(int x,int t,long long sum)
{
	if(t==4&&b[x][1])
	{
		ans1=max(sum,ans1);
		return;
	}
	for(int i=1;i<=n;i++)
		if(c[i][x]-1<=k&&!vis[i]&&i!=x)
			vis[i]=1,dfs1(i,t+1,sum+a[i-1]),vis[i]=0;
	return;
}
void QWQ()
{
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				c[j][i]=c[i][j]=min(c[i][j],c[i][k]+c[k][j]);
	dfs1(1,0,0);
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			c[i][j]=1e9;
	c[n][n]=0;
	//for(int i=1;i<=n;i++) fa[i]=i;
	for(int i=1;i<=n-1;i++) scanf("%d",&a[i]),c[i][i]=0;
	for(int i=1;i<=m;i++) 
	{
		scanf("%d%d",&x,&y);
		c[x][y]=c[y][x]=b[x][y]=b[y][x]=1;
		//add(x,y);
	}
	//vs[1]=1;
	if(n>8) { QWQ();printf("%lld",ans1);}
	else {dfs(1,0,0,0);printf("%lld",ans);}
	//sort(a+1,a+1+n,cmp);
	//for(int i=1,t=0;i<=n&&t<4;i++)
		//if(fa[a[i].dd]==1) ans+=a[i].sum,t++;
	
	return 0;
	//bfs(1);
}
