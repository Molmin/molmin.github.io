#include<bits/stdc++.h>
using namespace std;

const int N=500050;

struct edge{int to,nxt,x;}g[N<<1];
struct edge1{int to,nxt,x;}g1[N<<1];

int n,m,q,h[N],h1[N],tot,tot1;

void add(int u,int v)
{
	g[++tot]={v,h[u],1};h[u]=tot;
}
void add1(int u,int v)
{
	g1[++tot1]={v,h1[u],1};h1[u]=tot1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int u,v;scanf("%d%d",&u,&v);
		add(u,v);
		add1(v,u);
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	{
		int u,v,opt;
		scanf("%d",&opt);
		if(opt==1)
		{
			scanf("%d%d",&u,&v);
			for(int j=h[u];j;j=g[j].nxt)
			{
				int vv=g[j].to;
				if(vv==v)
				{
					g[j].x=0;g1[j].x=0;
				}
			}
		}else if(opt==2)
		{
			scanf("%d",&u);
			for(int j=h1[u];j;j=g1[j].nxt)
				g1[j].x=0,g[j].x=0;
		}else if(opt==3)
		{
			scanf("%d%d",&u,&v);
			for(int j=h[u];j;j=g[j].nxt)
			{
				int vv=g[j].to;
				if(vv==v)
				{
					g[j].x=1;g1[j].x=1;
				}
			}
		}else
		{
			scanf("%d",&u);
			for(int j=h1[u];j;j=g1[j].nxt)
			{
				g1[j].x=1;g[j].x=1;
			}
		}
		bool flag=0;
		for(int j=1;j<=n;j++)
		{
			int cnt=0;
			for(int k=h[j];k;k=g[k].nxt)
				if(g[k].x==1) cnt++;
			if(cnt!=1) flag=1;
		}
		if(flag==0) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
/*
3 6
2 3
2 1
1 2
1 3
3 1
3 2
11
1 3 2
1 2 3
1 1 3
1 1 2
3 1 3
3 3 2
2 3
1 3 1
3 1 3
4 2
1 3 2
*/