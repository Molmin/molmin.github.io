#include<bits/stdc++.h>
using namespace std;

const int N=100010;

typedef long long LL;

int n,m,q,a[N],b[N],Log[N];
int st1[N][20],st2[N][20];
int st3[N][20],st4[N][20];
int st5[N][20],st6[N][20];

int qry1(int l,int r)
{
	int sz=r-l+1;
	return max(st1[l][Log[sz]],st1[r-(1<<Log[sz])+1][Log[sz]]);
}
int qry2(int l,int r)
{
	int sz=r-l+1;
	return min(st2[l][Log[sz]],st2[r-(1<<Log[sz])+1][Log[sz]]);
}
int qry3(int l,int r)
{
	int sz=r-l+1;
	return min(st3[l][Log[sz]],st3[r-(1<<Log[sz])+1][Log[sz]]);
}
int qry4(int l,int r)
{
	int sz=r-l+1;
	return max(st4[l][Log[sz]],st4[r-(1<<Log[sz])+1][Log[sz]]);
}
int qry5(int l,int r)
{
	int sz=r-l+1;
	return max(st5[l][Log[sz]],st5[r-(1<<Log[sz])+1][Log[sz]]);
}
int qry6(int l,int r)
{
	int sz=r-l+1;
	return min(st6[l][Log[sz]],st6[r-(1<<Log[sz])+1][Log[sz]]);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for(int i=2;i<=n;i++)
		Log[i]=Log[i>>1]+1;
	for(int i=n;i>=1;i--)
	{
		st1[i][0]=a[i];
		st2[i][0]=a[i];
		st3[i][0]=a[i]>=0?a[i]:1e9;
		st4[i][0]=a[i]<=0?a[i]:-1e9;
		for(int j=1;i+(1<<j)-1<=n;j++)
		{
			st1[i][j]=max(st1[i][j-1],st1[i+(1<<j-1)][j-1]);
			st2[i][j]=min(st2[i][j-1],st2[i+(1<<j-1)][j-1]);
			st3[i][j]=min(st3[i][j-1],st3[i+(1<<j-1)][j-1]);
			st4[i][j]=max(st4[i][j-1],st4[i+(1<<j-1)][j-1]);
		}
	}
	for(int i=m;i>=1;i--)
	{
		st5[i][0]=b[i];
		st6[i][0]=b[i];
		for(int j=1;i+(1<<j)-1<=m;j++)
		{
			st5[i][j]=max(st5[i][j-1],st5[i+(1<<j-1)][j-1]);
			st6[i][j]=min(st6[i][j-1],st6[i+(1<<j-1)][j-1]);
		}
	}
	for(int i=1;i<=q;i++)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		LL q1=qry1(l1,r1),q2=qry2(l1,r1),q3=qry3(l1,r1),q4=qry4(l1,r1);
		LL q5=qry5(l2,r2),q6=qry6(l2,r2);
//		cout<<"q = "<<q1<<" "<<q2<<" "<<q3<<" "<<q4<<" "<<q5<<" "<<q6<<endl;
//		cout<<st5[2][0]<<endl;
		if(q1<=0)
		{
			if(q5<=0) printf("%lld\n",q2*q5);
			else printf("%lld\n",q1*q5);
		}else if(q2>=0)
		{
			if(q6>=0) printf("%lld\n",q1*q6);
			else printf("%lld\n",q2*q6);
		}else
		{
			if(q5<=0) printf("%lld\n",q2*q5);
			else if(q6>=0) printf("%lld\n",q1*q6);
			else
				printf("%lld\n",max(q3*q6,q4*q5));
		}
	}
	return 0;
}