#include<bits/stdc++.h>
using namespace std;

typedef long long LL;

const int N=2550;
const int M=10010;

struct edge{int to,nxt;}g[M<<1];
struct Node
{
	int x,id;
}p[N];

LL n,m,a[N],d[N],pos[N],h[N];
LL t[N],tot,K,ans;
int b[N][N],dis[N][N];

void add(int u,int v)
{
	g[++tot]={v,h[u]};h[u]=tot;
}
void bfs(int x)
{
	queue<int> q;
	for(int i=1;i<=n;i++)
		dis[x][i]=1e9;
	q.push(x);dis[x][x]=0;
	while(!q.empty())
	{
		int u=q.front();q.pop();
		for(int i=h[u];i;i=g[i].nxt)
		{
			int v=g[i].to;
			if(dis[x][v]==1e9)
			{
				dis[x][v]=dis[x][u]+1;
				q.push(v);
			}
		}
	}
}
void Sort(int x)
{
	memset(t,0,sizeof(t));
	for(int i=1;i<=d[x];i++)
		t[pos[b[x][i]]]=1;
	d[x]=0;
	for(int i=1;i<=n;i++)
		if(t[i])
			b[x][++d[x]]=p[i].id;
}
bool cmp(Node x,Node y)
{
	return x.x<y.x;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>K;
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&a[i]);
		p[i]={a[i],i};
	}
	sort(p+1,p+n+1,cmp);
	for(int i=1;i<=n;i++)
		pos[p[i].id]=i;
	for(int i=1;i<=m;i++)
	{
		int u,v;scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	for(int i=1;i<=n;i++) bfs(i);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(dis[1][i]<=K+1&&dis[i][j]<=K+1)
				b[j][++d[j]]=i;
	for(int i=1;i<=n;i++)
		Sort(i);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j||dis[i][j]>K+1) continue;
			int c1=d[i],c2=d[j];
			while(b[i][c1]==i||b[i][c1]==j)
				c1--;
			while(b[j][c2]==i||b[j][c2]==j||b[j][c2]==b[i][c1])
				c2--;
			if(c1==0||c2==0) continue;
			ans=max(ans,a[i]+a[j]+a[b[i][c1]]+a[b[j][c2]]);
			
		}
	}
	cout<<ans<<endl;
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/