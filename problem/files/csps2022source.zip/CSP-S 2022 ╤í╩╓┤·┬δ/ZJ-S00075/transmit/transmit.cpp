#include<bits/stdc++.h>
using namespace std;

const int N=200020;

typedef long long LL;

LL n,q,K,fa[N][20],f[N][20][2][2],dep[N],a[N];
vector<int> g[N];

void dfs(int u,int ff)
{
	fa[u][0]=ff;
	f[u][0][0][0]=a[u]+a[ff];
	f[u][0][0][1]=a[u];
	f[u][0][1][0]=a[ff];
	for(int i=1;i<20;i++)
	{
		fa[u][i]=fa[fa[u][i-1]][i-1];
		for(int j=0;j<K;j++)
		for(int k=0;k<K;k++)
			for(int l=0;l<K;l++)
			{
				for(int p=0;p<K;p++)
				{
					if(k==0&&l==0)
					{
						f[u][i][j][p]=min(f[u][i][j][p],f[u][i-1][j][k]+f[fa[u][i-1]][i-1][l][p]-a[fa[u][i-1]]);
					}
					else f[u][i][j][p]=min(f[u][i][j][p],f[u][i-1][j][k]+f[fa[u][i-1]][i-1][l][p]);
				}
			}
	}
	for(int i=0;i<g[u].size();i++)
	{
		int v=g[u][i];if(v==ff) continue;
		dep[v]=dep[u]+1;dfs(v,u);
	}
}
LL work(int u,int v)
{
	LL ans1[2]={},ans2[2]={};
	
	if(dep[u]<dep[v]) swap(u,v);
	int tu=u,tv=v,lca;
	for(int i=19;i>=0;i--)
		if(dep[fa[tu][i]]>=dep[tv])
			tu=fa[tu][i];
	if(tu==tv) lca=tv;
	for(int i=19;i>=0;i--)
		if(fa[tu][i]!=fa[tv][i]) tu=fa[tu][i],tv=fa[tv][i];
	if(tu!=tv) lca=fa[tu][0];
	ans1[1]=1e18;ans1[0]=a[u];
	ans2[1]=1e18;ans2[0]=a[v];
	LL ans[2];
	for(int i=19;i>=0;i--)
		if(dep[fa[u][i]]>=dep[lca])
		{
			ans[0]=ans1[0];ans[1]=ans1[1];
			ans1[0]=min(min(ans[1]+f[u][i][1][0],ans[0]+f[u][i][1][0]),
				min(ans[1]+f[u][i][0][0],ans[0]+f[u][i][0][0]-a[u]));
			ans1[1]=min(min(ans[1]+f[u][i][1][1],ans[0]+f[u][i][1][1]),
				min(ans[1]+f[u][i][0][1],ans[0]+f[u][i][0][1]-a[u]));
			u=fa[u][i];
		}
	for(int i=19;i>=0;i--)
		if(dep[fa[v][i]]>=dep[lca])
		{
			ans[0]=ans2[0];ans[1]=ans2[1];
			ans2[0]=min(min(ans[1]+f[v][i][1][0],ans[0]+f[v][i][1][0]),
				min(ans2[1]+f[v][i][0][0],ans[0]+f[v][i][0][0]-a[v]));
			ans2[1]=min(min(ans[1]+f[v][i][1][1],ans[0]+f[v][i][1][1]),
				min(ans[1]+f[v][i][0][1],ans[0]+f[v][i][0][1]-a[v]));
			v=fa[v][i];
		}
	
	return min(min(ans1[0]+ans2[0]-a[lca],ans1[1]+ans2[1]),min(ans1[0]+ans2[1],ans1[1]+ans2[0]));
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(f,-245,sizeof(f));
	cin>>n>>q>>K;
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<n;i++)
	{
		int u,v;scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dep[1]=1;dfs(1,0);
	for(int i=1;i<=q;i++)
	{
		int u,v;scanf("%d%d",&u,&v);
		printf("%lld\n",work(u,v));
	}
	return 0;
}
/*
10 100 2
1 2 3 4 5 6 7 8 9 10
1 2
2 3
3 4
4 5
5 6
1 7
7 8
8 9
9 10
6 10

*/