#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
#define ls u<<1
#define rs u<<1|1
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define N 100010
using namespace std;
int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') f=(ch=='-')?-1:1,ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
int n,m,q;
int a[2][N],minn[2][N<<2],maxx[2][N<<2],miz[2][N<<2],maf[2][N<<2];
void pushup(int u,int k){minn[k][u]=min(minn[k][ls],minn[k][rs]),maxx[k][u]=max(maxx[k][ls],maxx[k][rs]),miz[k][u]=min(miz[k][ls],miz[k][rs]),maf[k][u]=max(maf[k][ls],maf[k][rs]);return;}
void build(int u,int l,int r,int k)
{
	if(l==r)
	{
		if(a[k][l]>=0) minn[k][u]=maxx[k][u]=miz[k][u]=a[k][l],maf[k][u]=-INF;
		else minn[k][u]=maxx[k][u]=maf[k][u]=a[k][l],miz[k][u]=INF;
		return;
	}
	int mid=(l+r)>>1;
	build(ls,l,mid,k),build(rs,mid+1,r,k);
	pushup(u,k);
	return;
}
int queryma(int u,int l,int r,int ll,int rr,int k)
{
	if(l>=ll&&r<=rr) return maxx[k][u];
	int mid=(l+r)>>1,x=-INF;
	if(mid>=ll) x=queryma(ls,l,mid,ll,rr,k);
	if(mid<rr) x=max(x,queryma(rs,mid+1,r,ll,rr,k));
	return x;
}
int querymi(int u,int l,int r,int ll,int rr,int k)
{
	if(l>=ll&&r<=rr) return minn[k][u];
	int mid=(l+r)>>1,x=INF;
	if(mid>=ll) x=querymi(ls,l,mid,ll,rr,k);
	if(mid<rr) x=min(x,querymi(rs,mid+1,r,ll,rr,k));
	return x;
}
int qxz(int u,int l,int r,int ll,int rr,int k)
{
	if(l>=ll&&r<=rr) return miz[k][u];
	int mid=(l+r)>>1,x=INF;
	if(mid>=ll) x=qxz(ls,l,mid,ll,rr,k);
	if(mid<rr) x=min(x,qxz(rs,mid+1,r,ll,rr,k));
	return x;
}
int qdf(int u,int l,int r,int ll,int rr,int k)
{
	if(l>=ll&&r<=rr) return maf[k][u];
	int mid=(l+r)>>1,x=-INF;
	if(mid>=ll) x=qdf(ls,l,mid,ll,rr,k);
	if(mid<rr) x=max(x,qdf(rs,mid+1,r,ll,rr,k));
	return x;
}
void write(long long x)
{
	if(x<0)
	{
		putchar('-'),write(-x);
		return;
	}
	if(x/10) write(x/10);
	putchar((x%10)^48);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++) a[0][i]=read();
	for(int j=1;j<=m;j++) a[1][j]=read();
	build(1,1,n,0),build(1,1,m,1);
	while(q--)
	{
		int l1=read(),r1=read(),l2=read(),r2=read();
		int da1=queryma(1,1,n,l1,r1,0),da2=queryma(1,1,m,l2,r2,1),xi1=querymi(1,1,n,l1,r1,0),xi2=querymi(1,1,m,l2,r2,1);
		if(da1<0&&da2>=0) write(1ll*da1*da2);
		else if(xi1>=0&&xi2<0) write(1ll*xi1*xi2);
		else if(da2<0&&xi1<0) write(1ll*xi1*da2);
		else if(xi2>=0&&da1>=0) write(1ll*da1*xi2);
		else write(max(1ll*qxz(1,1,n,l1,r1,0)*xi2,1ll*qdf(1,1,n,l1,r1,0)*da2));
		puts("");
	}
	return 0;
}