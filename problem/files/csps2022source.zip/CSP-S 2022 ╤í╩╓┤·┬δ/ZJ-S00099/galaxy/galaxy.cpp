#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
#define ls u<<1
#define rs u<<1|1
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define N 200010
using namespace std;
int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') f=(ch=='-')?-1:1,ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
void write(long long x)
{
	if(x<0)
	{
		putchar('-'),write(-x);
		return;
	}
	if(x/10) write(x/10);
	putchar((x%10)^48);
}
int ver[N<<1],ne[N<<1],head[N],tot;
void add(int x,int y){ver[++tot]=y,ne[tot]=head[x],head[x]=tot;}
int n,q,k,a[N],fa[N][25],zhi[N][25],g,d[N],f[N];
long long ans;
void dfs(int x,int ff)
{
	fa[x][0]=ff,d[x]=d[ff]+1,zhi[x][0]=a[x];
	for(int i=head[x];i;i=ne[i])
	{
		int y=ver[i];
		if(y==ff) continue;
		dfs(y,x);
	}
	return;
}
int lca(int x,int y)
{
	ans=0;
	if(d[x]<d[y]) swap(x,y);
	for(int i=g;i>=0;i--)
		if(d[fa[x][i]]<=d[y]) x=fa[x][i],ans+=zhi[x][i];
	if(x==y) return x;
	for(int i=g;i>=0;i--)
		if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i],ans+=zhi[x][i]+zhi[y][i];
	return fa[x][0];
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<n;i++)
	{
		int x=read(),y=read();
		add(x,y),add(y,x);
	}
	dfs(1,0);
	g=log2(n);
	for(int j=1;j<=g;j++)
		for(int i=1;i<=n;i++)
			fa[i][j]=fa[fa[i][j-1]][j-1],zhi[i][j]=zhi[fa[i][j-1]][j-1]+zhi[i][j-1];
	if(k==1)
	{
		while(q--)
		{
			ans=0;
			int x=read(),y=read(),z=lca(x,y);
			printf("%lld\n",ans+a[z]);
		}
		return 0;
	}
	return 0;
}