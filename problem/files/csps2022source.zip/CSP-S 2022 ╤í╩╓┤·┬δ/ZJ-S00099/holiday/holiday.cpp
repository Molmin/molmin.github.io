#include<bits/stdc++.h>
#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
#define N 2510
#define M 10010
#define MM 6250010
using namespace std;
long long read()
{
	long long x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9') f=(ch=='-')?-1:1,ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<1)+(x<<3)+(ch^48),ch=getchar();
	return x*f;
}
struct obj
{
	int x,y;
	long long z;
}b[10010];
long long minn=3e18;
int ver[M<<1],ne[M<<1],head[N],tot;
int v[N],able[N],da[N][N];
long long a[N];
void add(int x,int y){ver[++tot]=y,ne[tot]=head[x],head[x]=tot;}
int n,m,k,siz=0;
void dfs(int x,int s)
{
	v[x]=1;
	for(int i=head[x];i;i=ne[i])
	{
		int y=ver[i];
		if(v[y]) continue;
		able[y]=1;
		if(s<k-1) dfs(y,s+1);
	}
	return;
}
void dfss(int zu,int x,int s)
{
	v[x]=1;
	for(int i=head[x];i;i=ne[i])
	{
		int y=ver[i];
		if(v[y]) continue;
		da[zu][y]=1;
		if(able[zu]&&y!=1)
		{
			long long z=a[zu]+a[y];
			if(siz>=10000)
			{
				if(z>minn) minn=z,b[siz]=(obj){zu,y,z};
			}
			else b[++siz]=(obj){zu,y,z};
			minn=min(minn,z);
		}
		if(s<k-1) dfss(zu,y,s+1);
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read()+1;
	for(int i=2;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++)
	{
		int x=read(),y=read();
		add(x,y),add(y,x);
	}
	dfs(1,0);
	for(int i=2;i<=n;i++) memset(v,0,sizeof(v)),dfss(i,i,0);
	long long maxx=0;
	for(int i=1;i<=siz;i++)
		for(int j=i+1;j<=siz;j++)
			if(da[b[i].y][b[j].y]&&b[i].y!=b[j].y&&b[i].x!=b[j].x&&b[i].x!=b[j].y&&b[i].y!=b[j].x) maxx=max(maxx,b[i].z+b[j].z);
	printf("%lld\n",maxx);
	return 0;
}