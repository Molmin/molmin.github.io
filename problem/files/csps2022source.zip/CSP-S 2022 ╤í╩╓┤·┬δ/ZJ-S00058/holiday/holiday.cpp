//关注向晚喵，关注向晚谢谢喵
#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0,f=1;
	char c=getchar();
	while(!isdigit(c)){if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) x=x*10+(c&15),c=getchar();
	return x*f;
}
vector<int> e[2503];
int dis[2503][2503];
int sz[2503],f[2503][2503];
ll a[2503];
int q[2503],qh,qt;
signed main()
{
#ifndef local
	freopen("holiday.in","r",stdin),
	freopen("holiday.out","w",stdout);
#endif
	int n=read(),m=read(),lim=read()+1;
	for(int i=2; i<=n; ++i) a[i]=read();
	for(int u,v; m--;)
		u=read(),v=read(),
		e[u].push_back(v),
		e[v].push_back(u);
	memset(dis,0x3f,sizeof(dis));
	for(int i=1; i<=n; ++i)
	{
		qh=qt=1,q[1]=i,dis[i][i]=0;
		while(qh<=qt)
		{
			int x=q[qh++];
			for(int y:e[x])
				if(dis[i][y]>=n)
					dis[i][y]=dis[i][x]+1,
					q[++qt]=y;
		}
		if(i==1) continue;
		for(int j=2; j<=n; ++j)
			if(j!=i&&dis[i][j]<=lim&&dis[1][j]<=lim)
				f[i][++sz[i]]=j;
		sort(f[i]+1,f[i]+sz[i]+1,[&](int x,int y){return a[x]>a[y];});
	}
	ll ans=0;
	for(int i=2; i<n; ++i)
		for(int j=i+1; j<=n; ++j) if(dis[i][j]<=lim)
			for(int k=1; k<=min(sz[i],4); ++k)
				for(int l=1; l<=min(sz[j],4); ++l)
					if(f[i][k]!=j&&f[j][l]!=i&&f[i][k]!=f[j][l])
						ans=max(ans,a[i]+a[j]+a[f[i][k]]+a[f[j][l]]);
	printf("%lld\n",ans);
	return 0;
}