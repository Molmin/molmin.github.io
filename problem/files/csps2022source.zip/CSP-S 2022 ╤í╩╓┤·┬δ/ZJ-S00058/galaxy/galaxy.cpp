//关注嘉然喵，关注嘉然谢谢喵
#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c)){if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) x=x*10+(c&15),c=getchar();
	return x*f;
}
const int p1=1019260817,p2=1011451423;
const int b1=19491001,b2=19260817;
int s1,a1,s2,a2;
int g1[500003],g2[500003];
int v1[500003],v2[500003];
int tgr[500003],tsi[500003];
int id[500003],bel[500003];
bool flg[500003],all[500003];
vector<int> tmp[500003];
map<pair<int,int>,int> mp;
signed main()
{
#ifndef local
	freopen("galaxy.in","r",stdin),
	freopen("galaxy.out","w",stdout);
#endif
	int n=read(),m=read();
	v1[0]=v2[0]=1;
	for(int i=1; i<=n; ++i)
		v1[i]=1ll*v1[i-1]*b1%p1,a1=(a1+v1[i])%p1;
	for(int i=1; i<=n; ++i)
		v2[i]=1ll*v2[i-1]*b2%p2,a2=(a2+v2[i])%p2;
	for(int i=1,u,v; i<=m; ++i)
		u=read(),v=read(),id[i]=u,bel[i]=v,
		s1=(s1+v1[u])%p1,s2=(s2+v2[u])%p2,
		g1[v]=(g1[v]+v1[u])%p1,g2[v]=(g2[v]+v2[u])%p2,
		mp[make_pair(u,v)]=i;
	for(int op,x,y,T=read(); T--;)
	{
		op=read(),x=read();
		if(op==1)
		{
			x=mp[make_pair(x,read())];
			if(tsi[x]<tgr[bel[x]])
				// printf("update %d\n",x),
				flg[x]=all[bel[x]],tsi[x]=tgr[bel[x]];
			if(!flg[x])
				// printf("delete %d\n",x),
				tmp[bel[x]].push_back(x),
				s1=(s1+p1-v1[id[x]])%p1,
				s2=(s2+p2-v2[id[x]])%p2,flg[x]=1;
		}
		if(op==2)
		{
			for(int i:tmp[x])
			{
				if(!flg[i]&&all[x])
					// printf("delete %d\n",i),
					s1=(s1+p1-v1[id[i]])%p1,
					s2=(s2+p2-v2[id[i]])%p2;
				else if(flg[i]&&!all[x])
					// printf("add %d\n",i),
					s1=(s1+v1[id[i]])%p1,
					s2=(s2+v2[id[i]])%p2;
				flg[i]=all[x];
			}
			if(!all[x])
				// printf("delete group %d\n",x),
				s1=(s1+p1-g1[x])%p1,s2=(s2+p2-g2[x])%p2,
			++tgr[x],all[x]=1,tmp[x].clear();
		}
		if(op==3)
		{
			x=mp[make_pair(x,read())];
			if(tsi[x]<tgr[bel[x]])
				flg[x]=all[bel[x]],tsi[x]=tgr[bel[x]];
			if(flg[x])
				// printf("add %d\n",x),
				tmp[bel[x]].push_back(x),
				s1=(s1+v1[id[x]])%p1,
				s2=(s2+v2[id[x]])%p2,flg[x]=0;
		}
		if(op==4)
		{
			for(int i:tmp[x])
			{
				if(!flg[i]&&all[x])
					// printf("delete %d\n",i),
					s1=(s1+p1-v1[id[i]])%p1,
					s2=(s2+p2-v2[id[i]])%p2;
				else if(flg[i]&&!all[x])
					// printf("add %d\n",i),
					s1=(s1+v1[id[i]])%p1,
					s2=(s2+v2[id[i]])%p2;
				flg[i]=all[x];
			}
			if(all[x])
				// printf("add group %d\n",x),
				s1=(s1+g1[x])%p1,s2=(s2+g2[x])%p2,
			++tgr[x],all[x]=0,tmp[x].clear();
		}
		if(s1==a1&&s2==a2) puts("YES");
		else puts("NO");
	}
	return 0;
}