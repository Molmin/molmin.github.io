//关注乃琳喵，关注乃琳谢谢喵
#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c)){if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) x=x*10+(c&15),c=getchar();
	return x*f;
}
const ll inf=1e18;
int n,Q,d,s;
struct mat{ll a[5][5];}eps,m0,m1;
mat merge(mat x,mat y)
{
	mat res;
	memset(res.a,0x3f,sizeof(res.a));
	for(int i=0; i<s; ++i)
		for(int j=0; j<s; ++j)
			for(int k=0; k<s; ++k)
				res.a[i][k]=min(res.a[i][k],x.a[i][j]+y.a[j][k]);
	return res;
}
struct segmx
{
    mat f[800003];
	int val[200003],w[200003];
    void build(int nl,int nr,int x)
    {
        if(nl==nr)
		{
			memset(f[x].a,0x3f,sizeof(f[x].a));
			for(int i=0; i+1<d; ++i) f[x].a[i][i+1]=0;
			for(int i=0; i<d; ++i) f[x].a[i][0]=val[nl];
			if(s==5) 
				f[x].a[3][4]=0,f[x].a[3][3]=w[nl],
				f[x].a[0][3]=f[x].a[1][3]=w[nl],
				f[x].a[3][0]=f[x].a[4][0]=val[nl];
			return ;
		}
        int mid=(nl+nr)>>1;
        build(nl,mid,x<<1),build(mid+1,nr,(x<<1)+1),
        f[x]=merge(f[x<<1],f[(x<<1)+1]);
        return ;
    }
    mat query(int nl,int nr,int l,int r,int x)
    {
        if(l<=nl&&nr<=r) return f[x];
        int mid=(nl+nr)>>1;
		if(r<=mid) return query(nl,mid,l,r,x<<1);
		if(l>mid) return query(mid+1,nr,l,r,(x<<1)+1);
        return merge(query(nl,mid,l,r,x<<1),
                query(mid+1,nr,l,r,(x<<1)+1));
    }
}T0,T1;
vector<int> e[200003];
int fa[200003],top[200003],son[200003];
int dfn[200003],idfn[200003],cnt;
int dep[200003],sz[200003];
int a[200003],b[200003];
void dfs1(int x)
{
	sz[x]=1;
	for(int y:e[x])
		if(y!=fa[x])
			fa[y]=x,dep[y]=dep[x]+1,dfs1(y),
			(sz[y]>sz[son[x]])&&(son[x]=y),sz[x]+=sz[y];
	return ;
}
void dfs2(int x,int tp)
{
	top[x]=tp,dfn[x]=++cnt,idfn[x]=n+1-cnt,
	T1.val[cnt]=a[x],T0.val[n+1-cnt]=a[x],
	T1.w[cnt]=b[x],T0.w[n+1-cnt]=b[x];
	if(son[x]) dfs2(son[x],tp);
	for(int y:e[x])
		if(y!=fa[x]&&y!=son[x])
			dfs2(y,y);
}
signed main()
{
#ifndef local
	freopen("transmit.in","r",stdin),
	freopen("transmit.out","w",stdout);
#endif
	n=read(),Q=read(),d=read();
	if(d<=2) s=d; else s=5;
	memset(eps.a,0x3f,sizeof(eps.a));
	for(int i=0; i<s; ++i) eps.a[i][i]=0;
	for(int i=1; i<=n; ++i) a[i]=read();
	for(int i=1,u,v; i<n; ++i)
		u=read(),v=read(),
		e[u].push_back(v),
		e[v].push_back(u);
	memset(b,0x3f,sizeof(b));
	for(int i=1; i<=n; ++i)
		for(int j:e[i]) b[i]=min(b[i],a[j]);
	mt19937 rnd(20061130);
	int rt=rnd()%n+1;
	dfs1(rt),dfs2(rt,rt),T0.build(1,n,1),T1.build(1,n,1);
	for(int x,y; Q--;)
	{
		x=read(),y=read(),m0=m1=eps;
		swap(x,y);
		while(top[x]!=top[y])
			if(dep[top[x]]>dep[top[y]])
				m0=merge(m0,T0.query(1,n,idfn[x],idfn[top[x]],1)),
				x=fa[top[x]]; 
			else 
				m1=merge(T1.query(1,n,dfn[top[y]],dfn[y],1),m1),
				y=fa[top[y]];
		if(dep[x]<dep[y])
			m0=merge(m0,T1.query(1,n,dfn[x],dfn[y],1));
		else m0=merge(m0,T0.query(1,n,idfn[x],idfn[y],1));
		printf("%lld\n",merge(m0,m1).a[d-1][0]);
	}
	return 0;
}