//关注贝拉喵，关注贝拉谢谢喵
#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline int read()
{
    int x=0,f=1;
    char c=getchar();
    while(!isdigit(c)){if(c=='-') f=-1;c=getchar();}
	while(isdigit(c)) x=x*10+(c&15),c=getchar();
	return x*f;
}
struct segmx
{
    int f[400003],val[100003];
    void build(int nl,int nr,int x)
    {
        if(nl==nr){f[x]=val[nl];return ;}
        int mid=(nl+nr)>>1;
        build(nl,mid,x<<1),build(mid+1,nr,(x<<1)+1);
        f[x]=max(f[x<<1],f[(x<<1)+1]);
        return ;
    }
    int query(int nl,int nr,int l,int r,int x)
    {
        if(nr<l||r<nl) return 0xc0c0c0c0;
        if(l<=nl&&nr<=r) return f[x];
        int mid=(nl+nr)>>1;
        return max(query(nl,mid,l,r,x<<1),
                query(mid+1,nr,l,r,(x<<1)+1));
    }
}Ap1,An1,B1;
struct segmn
{
    int f[400003],val[100003];
    void build(int nl,int nr,int x)
    {
        if(nl==nr){f[x]=val[nl];return ;}
        int mid=(nl+nr)>>1;
        build(nl,mid,x<<1),build(mid+1,nr,(x<<1)+1);
        f[x]=min(f[x<<1],f[(x<<1)+1]);
        return ;
    }
    int query(int nl,int nr,int l,int r,int x)
    {
        if(nr<l||r<nl) return 0x3f3f3f3f;
        if(l<=nl&&nr<=r) return f[x];
        int mid=(nl+nr)>>1;
        return min(query(nl,mid,l,r,x<<1),
                query(mid+1,nr,l,r,(x<<1)+1));
    }
}Ap0,An0,B0;
signed main()
{
#ifndef local
    freopen("game.in","r",stdin),
    freopen("game.out","w",stdout);
#endif
	int n=read(),m=read(),q=read();
    memset(An0.val,0x3f,sizeof(An0.val)),
    memset(Ap0.val,0x3f,sizeof(Ap0.val)),
    memset(An1.val,0xc0,sizeof(An1.val)),
    memset(Ap1.val,0xc0,sizeof(Ap1.val));
    for(int i=1,x; i<=n; ++i)
    {
        x=read();
        if(x<=0) An0.val[i]=An1.val[i]=x;
        else Ap0.val[i]=Ap1.val[i]=x;
    }
    An0.build(1,n,1),An1.build(1,n,1),
    Ap0.build(1,n,1),Ap1.build(1,n,1);
    for(int i=1; i<=m; ++i) B0.val[i]=B1.val[i]=read();
    B0.build(1,m,1),B1.build(1,m,1);
    ll ans;
    for(int l1,r1,l2,r2,mn,mx,x,y,z,w; q--;)
    {
        l1=read(),r1=read(),l2=read(),r2=read(),ans=0xc0c0c0c0c0c0c0c0;
        mn=B0.query(1,m,l2,r2,1),
        mx=B1.query(1,m,l2,r2,1),
        x=An0.query(1,n,l1,r1,1),
        y=An1.query(1,n,l1,r1,1),
        z=Ap0.query(1,n,l1,r1,1),
        w=Ap1.query(1,n,l1,r1,1);
        // printf("%d %d %d %d %d %d\n",mn,mx,x,y,z,w);
        if(x!=0x3f3f3f3f) ans=max(ans,1ll*x*mx);
        if(y!=0xc0c0c0c0) ans=max(ans,1ll*y*mx);
        if(z!=0x3f3f3f3f) ans=max(ans,1ll*z*mn);
        if(w!=0xc0c0c0c0) ans=max(ans,1ll*w*mn);
        printf("%lld\n",ans);
    }
    return 0;
}