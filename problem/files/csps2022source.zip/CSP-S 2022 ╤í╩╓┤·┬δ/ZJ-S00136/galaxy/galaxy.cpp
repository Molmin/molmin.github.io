#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll M=5e5+10;
const ll N=5e5+10;
struct node{
	ll from;
	ll to;
	ll next;
	ll nextt;
	bool flag;
}e[M];
ll num,head[N],headt[N];
void add(ll a,ll b){
	num++;
	e[num].from=a;
	e[num].next=head[b];
	head[b]=num;
	e[num].flag=true;
	e[num].to=b;
	e[num].nextt=headt[a];
	headt[a]=num;
}
map<ll,bool> vis;
bool check(ll dot){
	ll poi=0;
	for(ll i=headt[dot];i!=0;i=e[i].nextt){
		if(e[i].flag){
			if(poi!=0){
				return true;
			}
			poi=e[i].to;
		}
	}
	if(poi==0){
		return true;
	}
	if(vis[poi]==true){
		return false;
	}
	vis[poi]=true;
	return check(poi);
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ll n,m,d,q;
	scanf("%lld%lld",&n,&m);
	for(ll i=1;i<=m;i++){
		ll a,b;
		scanf("%lld%lld",&a,&b);
		add(a,b);
	}
	scanf("%lld",&d);
	for(ll i=1;i<=d;i++){
		ll k;
		scanf("%lld",&k);
		if(k==1){
			ll u,v;
			scanf("%lld%lld",&u,&v);
			for(ll i=head[v];i!=0;i=e[i].next){
				if(e[i].from==u){
					e[i].flag=false;
					break;
				}
			}
		}else if(k==2){
			ll u;
			scanf("%lld",&u);
			for(ll i=head[u];i!=0;i=e[i].next){
				e[i].flag=false;
			}
		}else if(k==3){
			ll u,v;
			scanf("%lld%lld",&u,&v);
			for(ll i=head[v];i!=0;i=e[i].next){
				if(e[i].from==u){
					e[i].flag=true;
					break;
				}
			}
		}else if(k==4){
			ll u;
			scanf("%lld",&u);
			for(ll i=head[u];i!=0;i=e[i].next){
				e[i].flag=true;
			}
		}
		bool flg=true;
		for(ll i=1;i<=n;i++){
			vis.clear();
			if(check(i)){
				printf("NO\n");
				flg=false;
				break;
			}
		}
		if(flg){
			printf("YES\n");
		}
	}
	return 0;
}