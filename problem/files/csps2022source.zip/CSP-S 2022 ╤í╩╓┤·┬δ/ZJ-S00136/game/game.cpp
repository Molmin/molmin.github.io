#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=1e5+10;
const ll maxN=1e9+10;
const ll minN=-1e9-10;
ll max2(ll a,ll b){
	if(a>b) return a;
	return b;
}
ll min2(ll a,ll b){
	if(a<b) return a;
	return b;
}
ll a[N];
ll b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ll n,m,q;
	scanf("%lld%lld%lld",&n,&m,&q);
	for(ll i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(ll i=1;i<=m;i++){
		scanf("%lld",&b[i]);
	}
	while(q--){
		ll al,ar,bl,br;
		scanf("%lld%lld%lld%lld",&al,&ar,&bl,&br);
		ll bminz=maxN,bmaxz=0,bminf=0,bmaxf=minN;
		for(ll i=bl;i<=br;i++){
			if(b[i]>=0){
				bminz=min2(bminz,b[i]);
				bmaxz=max2(bmaxz,b[i]);
			}else{
				bmaxf=max2(bmaxf,b[i]);
				bminf=min2(bminf,b[i]);
			}
		}
		ll aminz=maxN,amaxz=0,aminf=0,amaxf=minN;
		for(ll i=al;i<=ar;i++){
			if(a[i]>=0){
				aminz=min2(aminz,a[i]);
				amaxz=max2(amaxz,a[i]);
			}else{
				amaxf=max2(amaxf,a[i]);
				aminf=min2(aminf,a[i]);
			}
		}
		ll ans=minN;
		bool flag=true;
		if(bmaxf==minN){
			if(amaxz==0){
				ans=bmaxz*aminf;
			}else{
				ans=bminz*amaxz;
			}
			flag=false;
		}
		if(bmaxz==0){
			if(amaxf==minN){
				ans=max2(ans,bminf*aminz);
			}else{
				ans=max2(ans,bmaxf*aminf);
			}
			flag=false;
		}
		if(flag){
			ans=max2(ans,bmaxz*amaxf);
			ans=max2(ans,bminf*aminz);	
		}
		printf("%lld\n",ans);
	}
	return 0;
}