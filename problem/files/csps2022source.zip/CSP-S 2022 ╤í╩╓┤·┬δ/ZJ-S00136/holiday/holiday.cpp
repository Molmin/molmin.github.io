#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int M=1e5+10;
const int N=3e3;
struct node{
	ll next;
	ll to;
}e[2*M];
ll head[N],num;
ll max2(ll a,ll b){
	if(a>b){
		return a;
	}
	return b;
}
void add(ll fro,ll t){
	num++;
	e[num].to=t;
	e[num].next=head[fro];
	head[fro]=num;
}
ll n,m,k,a[N],ans;
bool s[N][N],vis[N];
map<ll,ll> mp;
void dfs(ll step,ll dot,ll fro){
	if(mp[dot]==fro) return;
	if(step>k) return;
	mp[dot]=fro;
	for(ll i=head[dot];i!=0;i=e[i].next){
		s[fro][e[i].to]=true;
		dfs(step+1,e[i].to,fro);
	}
}
void final_dfs(ll step,ll now,ll dot){
	if(step==5){
		if(dot==1){
			ans=max2(ans,now);
		}
		return;
	}
	for(ll i=1;i<=n;i++){
		if(s[dot][i]&&dot!=i){
			if(vis[i]){
				continue;
			}
			if(step==4&&i!=1){
				continue;
			}
			vis[i]=true;
			final_dfs(step+1,now+a[i],i);
			vis[i]=false;
		}
	}
	return;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(ll i=2;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(ll i=1;i<=m;i++){
		ll x,y;
		scanf("%lld%lld",&x,&y);
		add(x,y);
		add(y,x);
	}
	for(ll i=1;i<=n;i++){
		mp.clear();
		dfs(0,i,i);
	}
	final_dfs(0,0,1);
	printf("%lld",ans);
	return 0;
}