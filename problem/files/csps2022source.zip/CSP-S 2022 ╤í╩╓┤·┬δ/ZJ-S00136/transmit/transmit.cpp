#include <bits/stdc++.h>
#define ll long long
using namespace std;
const ll N=2e5+10;
const ll maxN=4e10+10;
struct node{
	ll to;
	ll next;
}e[N];
ll v[N],num,head[N];
void add(ll fro,ll t){
	num++;
	e[num].to=t;
	e[num].next=head[fro];
	head[fro]=num;
}
ll n,q,k;
map<ll,bool> s[N];
map<ll,ll> mp;
void dfs(ll step,ll dot,ll fro){
	if(mp[dot]==fro) return;
	if(step>k) return;
	mp[dot]=fro;
	for(ll i=head[dot];i!=0;i=e[i].next){
		s[fro][e[i].to]=true;
		dfs(step+1,e[i].to,fro);
	}
}
ll ans;
ll tmp[N];
void dfs2(ll dot,ll minn,ll t){
	if(dot==t){
		ans=min(ans,minn);
		return;
	}
	if(minn>=tmp[dot]&&tmp[dot]!=-1){
		return;
	}
	if(minn>=ans){
		return;
	}
	if(tmp[dot]==-1){
		tmp[dot]=minn;
	}
	tmp[dot]=min(tmp[dot],minn);
	for(ll i=1;i<=n;i++){
		if(i==dot) continue;
		if(s[dot][i]){
			dfs2(i,minn+v[i],t);
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&k);
	for(ll i=1;i<=n;i++){
		scanf("%lld",&v[i]);
	}
	for(ll i=1;i<n;i++){
		ll a,b;
		scanf("%lld%lld",&a,&b);
		add(a,b);
		add(b,a);
	}
	for(ll i=1;i<=n;i++){
		mp.clear();
		dfs(1,i,i);
	}
	for(ll i=1;i<=q;i++){
		ll a,b;
		scanf("%lld%lld",&a,&b);
		ans=maxN;
		memset(tmp,-1,sizeof(tmp));
		dfs2(a,v[a],b);
		printf("%lld\n",ans);
	}
	return 0;
}