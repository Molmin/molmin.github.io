#include<bits/stdc++.h>
using namespace std;

template<class T>inline void read(T&x){
	char c,last=' ';
	while(!isdigit(c=getchar()))last=c;
	x=c^48;
	while(isdigit(c=getchar()))x=(x<<3)+(x<<1)+(c^48);
	if(last=='-')x=-x;
}

const int MAXN=1e5+7;
int n,m,q;
int a[MAXN],b[MAXN];
int lg[MAXN];
int rpMx[MAXN][27],rpMi[MAXN][27],rnMx[MAXN][27],rnMi[MAXN][20],cMx[MAXN][20],cMi[MAXN][27];
int fp[MAXN][27],fn[MAXN][27];

void init(){
	for(int i=2;i<=max(n,m);++i)lg[i]=lg[i>>1]+1;
	int k=lg[n];
	for(int j=1;j<=k;++j){
		for(int i=1;i+(1<<j)-1<=n;++i){
			rpMx[i][j]=max(rpMx[i][j-1],rpMx[i+(1<<j-1)][j-1]);
			rpMi[i][j]=min(rpMi[i][j-1],rpMi[i+(1<<j-1)][j-1]);
			rnMx[i][j]=max(rnMx[i][j-1],rnMx[i+(1<<j-1)][j-1]);
			rnMi[i][j]=min(rnMi[i][j-1],rnMi[i+(1<<j-1)][j-1]);
			fp[i][j]=fp[i][j-1]|fp[i+(1<<j-1)][j-1];
			fn[i][j]=fn[i][j-1]|fn[i+(1<<j-1)][j-1];
		}
	}
	k=lg[m];
	for(int j=1;j<=k;++j){
		for(int i=1;i+(1<<j)-1<=m;++i){
			cMx[i][j]=max(cMx[i][j-1],cMx[i+(1<<j-1)][j-1]);
			cMi[i][j]=min(cMi[i][j-1],cMi[i+(1<<j-1)][j-1]);
		}
	}
}

int qrpMx(int l,int r){
	int k=lg[r-l+1];
	return max(rpMx[l][k],rpMx[r-(1<<k)+1][k]);
}
int qrpMi(int l,int r){
	int k=lg[r-l+1];
	return min(rpMi[l][k],rpMi[r-(1<<k)+1][k]);
}
int qrnMx(int l,int r){
	int k=lg[r-l+1];
	return max(rnMx[l][k],rnMx[r-(1<<k)+1][k]);
}
int qrnMi(int l,int r){
	int k=lg[r-l+1];
	return min(rnMi[l][k],rnMi[r-(1<<k)+1][k]);
}
int qcMx(int l,int r){
	int k=lg[r-l+1];
	return max(cMx[l][k],cMx[r-(1<<k)+1][k]);
}
int qcMi(int l,int r){
	int k=lg[r-l+1];
	return min(cMi[l][k],cMi[r-(1<<k)+1][k]);
}

int check(int l,int r,int type){
	int k=lg[r-l+1];
	if(type==1)return fp[l][k]|fp[r-(1<<k)+1][k];
	return fn[l][k]|fn[r-(1<<k)+1][k];
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m),read(q);
	for(int i=1;i<=n;++i){
		read(a[i]);
		if(a[i]>0){
			rpMx[i][0]=rpMi[i][0]=a[i];
			rnMx[i][0]=-1e9-7,rnMi[i][0]=1e9+7;
		}
		else{
			rnMx[i][0]=rnMi[i][0]=a[i];
			rpMx[i][0]=-1e9-7,rpMi[i][0]=1e9+7;
		}
		fp[i][0]=a[i]>0;
		fn[i][0]=a[i]<0;
	}
	for(int i=1;i<=m;++i)read(b[i]),cMx[i][0]=cMi[i][0]=b[i];
	init();
	for(int l1,r1,l2,r2;q--;){
		read(l1),read(r1),read(l2),read(r2);
		long long ans=-7e18;
		if(check(l1,r1,1)){
			if(qcMi(l2,r2)>0)ans=max(ans,1ll*qrpMx(l1,r1)*qcMi(l2,r2));
			else ans=max(ans,1ll*qrpMi(l1,r1)*qcMi(l2,r2));
		}
		if(check(l1,r1,2)){
			if(qcMx(l2,r2)<0)ans=max(ans,1ll*qrnMi(l1,r1)*qcMx(l2,r2));
			else ans=max(ans,1ll*qrnMx(l1,r1)*qcMx(l2,r2));
		}
		cout<<ans<<'\n';
	}
	return 0;
}
