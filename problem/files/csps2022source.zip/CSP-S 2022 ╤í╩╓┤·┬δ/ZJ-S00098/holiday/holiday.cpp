#include<bits/stdc++.h>
using namespace std;

template<class T>inline void read(T&x){
	char c,last=' ';
	while(!isdigit(c=getchar()))last=c;
	x=c^48;
	while(isdigit(c=getchar()))x=(x<<3)+(x<<1)+(c^48);
	if(last=='-')x=-x;
}

const int MAXN=2.5e3+7;
int n,m,k;
long long v[MAXN];
vector<int>E[MAXN],e[MAXN];
bitset<MAXN>vis;
int dis[MAXN];

struct node{
	long long v;
	int id;
	node(long long V,int ID):v(V),id(ID){}
};
bool cmp(node a,node b){
	return a.v>b.v;
}
vector<node>v1[MAXN];

void bfs(int x){
	queue<int>q;
	q.push(x);
	dis[x]=0;
	for(int u;!q.empty();){
		u=q.front();q.pop();
		for(int i=0,v;i<(int)E[u].size();++i){
			v=E[u][i];
			if(!vis[v]){
				vis[v]=1;
				dis[v]=dis[u]+1;
				q.push(v);
			}
		}
	}
	for(int i=1;i<=n;++i){
		if(i!=x&&dis[i]<=k)e[x].push_back(i);
	}
}

void init(){
	for(int i=1;i<=n;++i){
		vis.reset();
		bfs(i);
	}
}

void dfs(int x,int fa,int dep,long long V){
	V+=v[x];
	if(dep==2){
		v1[x].push_back(node(V,fa));
		return;
	}
	for(int i=0,son;i<(int)e[x].size();++i){
		son=e[x][i];
		if(son==fa)continue;
		dfs(son,x,dep+1,V);
	}
}

bool check(int a,int b,int c,int d){
	set<int>st;
	st.insert(a);
	st.insert(b);
	st.insert(c);
	st.insert(d);
	return st.size()==4;
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);++k;
	for(int i=2;i<=n;++i)read(v[i]);
	for(int u,v;m--;){
		read(u),read(v);
		E[u].push_back(v);
		E[v].push_back(u);
	}
	init();
	for(int i=0;i<(int)e[1].size();++i)dfs(e[1][i],1,1,0ll);
	for(int i=2;i<=n;++i){
		sort(v1[i].begin(),v1[i].end(),cmp);
	}
	long long ans=0,cnt=0;
	for(int i=2;i<=n;++i){
		for(int o=0,j;o<(int)e[i].size();++o){
			j=e[i][o];
			for(int k=0;k<min((int)v1[i].size(),7);++k){
				if(j==v1[i][k].id)continue;
				for(int l=0;l<min((int)v1[j].size(),7);++l){
					if(v1[j][l].id==i||v1[j][l].id==v1[i][k].id)continue;
					ans=max(ans,v1[i][k].v+v1[j][l].v);
				}
			}
		}
	}
	cout<<ans<<'\n';
	return 0;
}
