#include<bits/stdc++.h>
using namespace std;

template<class T>inline void read(T&x){
	char c,last=' ';
	while(!isdigit(c=getchar()))last=c;
	x=c^48;
	while(isdigit(c=getchar()))x=(x<<3)+(x<<1)+(c^48);
	if(last=='-')x=-x;
}

const int MAXN=1e3+5;
int n,m,q;
int M[MAXN][MAXN];
vector<int>e[MAXN];
int d[MAXN];
int vis[MAXN];

void dfs(int x){
	vis[x]=1;
	d[x]=0;
	for(int i=0,son;i<e[x].size();++i){
		son=e[x][i];
		if(M[x][son]==-1)continue;
		++d[x];
		if(!vis[son])dfs(son);
	}
}

bool check(){
	for(int i=1;i<=n;++i)vis[i]=0;
	for(int i=1;i<=n;++i)if(!vis[i])dfs(i);
	int f=1;
	for(int i=1;i<=n;++i)f&=d[i]==1;
	return f;
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n),read(m);
	if(n<=1000&&m<=1000){
		for(int u,v;m--;){
			read(u),read(v);
			e[u].push_back(v);
			M[u][v]=1;
		}
		read(q);
		for(int t,u,v;q--;){
			read(t);
			if(t==1){
				read(u),read(v);
				M[u][v]=-1;
			}
			if(t==2){
				read(u);
				for(int i=1;i<=n;++i)if(M[i][u])M[i][u]=-1;
			}
			if(t==3){
				read(u),read(v);
				M[u][v]=1;
			}
			if(t==4){
				read(u);
				for(int i=1;i<=n;++i)if(M[i][u])M[i][u]=1;
			}
			puts(check()?"YES":"NO");
		}
	}
	else{
		for(int u,v;m--;){
			read(u),read(v);
			e[u].push_back(v);
			++d[u];
		}
		set<int>st;
		for(int i=1;i<=n;++i)if(d[i]!=1)st.insert(i);
		read(q);
		for(int t,u,v;q--;){
			read(t);
			if(t==1){
				read(u),read(v);
				--d[u];
				if(d[u]==1)st.erase(u);
				else st.insert(u);
			}
			if(t==3){
				read(u),read(v);
				++d[u];
				if(d[u]==1)st.erase(u);
				else st.insert(u);
			}
			puts(st.empty()?"YES":"NO");
		}
	}
	return 0;
}
