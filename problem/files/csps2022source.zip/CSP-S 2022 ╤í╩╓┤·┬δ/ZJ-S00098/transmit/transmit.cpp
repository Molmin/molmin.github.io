#include<bits/stdc++.h>
using namespace std;

template<class T>inline void read(T&x){
	char c,last=' ';
	while(!isdigit(c=getchar()))last=c;
	x=c^48;
	while(isdigit(c=getchar()))x=(x<<3)+(x<<1)+(c^48);
	if(last=='-')x=-x;
}

const int MAXN=2e5+7;
int n,q,k;
int val[MAXN];
long long sum[MAXN];
vector<int>e[MAXN];
int f[MAXN][27],dep[MAXN];
int b[MAXN];
vector<int>v1,v2;
vector<long long>dp;

void dfs(int x,int fa,int d){
	f[x][0]=fa;dep[x]=d;
	sum[x]=sum[fa]+val[x];
	for(int i=1;i<=20;++i)f[x][i]=f[f[x][i-1]][i-1];
	for(int i=0,son;i<e[x].size();++i){
		son=e[x][i];
		if(son==fa)continue;
		dfs(son,x,d);
	}
}

int LCA(int u,int v){
	if(dep[u]<dep[v])swap(u,v);
	for(int i=20;i>=0;--i)if(dep[u]-(1<<i)>=dep[v])u=f[u][i];
	if(u==v)return u;
	for(int i=20;i>=0;--i){
		if(f[u][i]!=f[v][i])u=f[u][i],v=f[v][i];
	}
	return f[u][0];
}

void Pick(int x,int tar,vector<int>&V){
	while(x!=tar){
		b[x]=1;
		V.push_back(val[x]);
		x=f[x][0];
	}
}

void Clear(int x,int tar){
	while(x!=tar){
		b[x]=0;
		x=f[x][0];
	}
}

void dfs1(int x,int dep){
	for(int i=1;i+dep<=k;++i){
			dp[i]=min(dp[i],dp[0]+val[x]+v1[i]);
		}
	if(dep==k-1)return;
	for(int i=0,son;i<e[x].size();++i){
		son=e[x][i];
		if(b[son])continue;
		dfs1(son,dep+1);
	}
}

void dfs2(int x,int dep,int num){
	for(int i=num-2;(num-1-i)+dep<=k;--i){
		dp[num-1]=min(dp[num-1],dp[i]+val[x]+v1[num-1]);
	}
	if(dep==k-1)return;
	for(int i=0,son;i<e[x].size();++i){
		son=e[x][i];
		if(b[son])continue;
		dfs2(son,dep+1,num);
	}
}

void solve(int u,int v){
	int l=LCA(u,v);
	if(k==1){
		cout<<sum[u]+sum[v]-sum[l]-sum[f[l][0]]<<'\n';
	}
	else{
		vector<int>().swap(v1);
		vector<int>().swap(v2);
		Pick(u,l,v1),Pick(v,l,v2);
		b[l]=1;
		int num=(int)v1.size()+1+(int)v2.size();
		reverse(v2.begin(),v2.end());
		v1.push_back(val[l]);
		for(int i=0;i<(int)v2.size();++i)v1.push_back(v2[i]);
		dp=vector<long long>(num+7,(long long)7e18);
		dp[0]=v1[0];
		if(k>=2)dfs1(u,0);
		for(int i=1;i<num;++i){
			dp[i]=7e18;
			for(int j=i-1;j>=i-k&&j>=0;--j)dp[i]=min(dp[i],dp[j]+v1[i]);
		}
		if(k>=2)dfs2(v,0,num);
		cout<<dp[num-1]<<'\n';
		Clear(u,l),Clear(v,l);
		b[l]=0;
	}
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	read(n),read(q),read(k);
	for(int i=1;i<=n;++i)read(val[i]);
	for(int i=1,u,v;i<n;++i){
		read(u),read(v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,1,0);
	for(int u,v;q--;){
		read(u),read(v);
		solve(u,v);
	}
	return 0;
}
