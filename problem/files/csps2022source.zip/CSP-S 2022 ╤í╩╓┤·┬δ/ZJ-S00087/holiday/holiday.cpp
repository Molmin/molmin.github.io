#include<bits/stdc++.h>
#define int unsigned long long
const int N=2509,M=1e4+3;
using namespace std;
int n,i,m,k,cnt,ans;
int a[N],f[N];
int head[N],d[N];//f��i��1�ϵ����ֵ
bool vis[N];
bool ok[N][N];
struct node {
	int id,dis;
	bool operator <(const node &a) const {
		return dis>a.dis;
	}
} b[N],ff[N];
struct ed {
	int to,nxt;
} e[M];
void add(int u,int v) {
	e[++cnt]= {v,head[u]};
	head[u]=cnt;
}
priority_queue<node> q;
void dfs(int u,int aa) {
	for(int i=head[u]; i; i=e[i].nxt) {
		int v=e[i].nxt;
		if(d[v]>k) {
			ok[aa][v]=1;
			f[v]=a[aa];
			return;
		}
		if(d[v]==d[u]+1)dfs(v,aa);
	}
}
#undef int
int main() {
	#define int unsigned long long
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	cin>>n>>m>>k;
	for(i=1; i<n; ++i) {
		cin>>a[i+1];
		d[i+1]=0x7ffffff;
	}
	while(m--) {
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	q.push({1,0});
	vis[1]=1;
	while(!q.empty()) {
		int u=q.top().id;
		q.pop();
		for(i=head[u]; i; i=e[i].nxt) {
			int v=e[i].to;
			if((!vis[v])&&d[u]+1<=d[v]) {
				d[v]=d[u]+1;
				q.push({v,d[v]});
				vis[v]=1;
			}
		}
	}
	k++;
	set<int> g;
	g.clear();
	for(i=2; i<=n; ++i) {
		if(d[i]<=k)
			q.push({i,d[i]});
		else g.insert(i);
		if(d[i]==1)dfs(i,i);
		f[i]=LLONG_MAX;
	}
	if(q.size()==(int)n-1) {
		sort(a+2,a+n+1,greater<int>());
		cout<<a[5]+a[2]+a[3]+a[4]<<'\n';
		return 0;
	}
	set<int> qq;
	while(!q.empty()) {
		qq.clear();
		int u=q.top().id;
		q.pop();
		for(i=2;i<=n;++i)
			if(ok[u][i]){
				qq.insert(i);	
				for(int j=head[i];j;j=e[j].nxt){
					int v=e[j].to;
					if(d[v]==d[i]+1)qq.insert(v);
				}			
			}
		for(i=head[u]; i; i=e[i].nxt){
			int v=e[i].to;
			if(d[v]==d[u]+1)
				for(auto j:qq)
					f[j]=min(f[j],a[v]);
		}
	}
	for(auto x:g)
		for(auto y:g)
			if(x!=y)
				ans=max(ans,f[x]+f[y]+a[x]+a[y]);
	cout<<ans<<'\n';
	return 0;
}
/*
9 9 1
4 5 8 2 1 6 5 4
1 2
1 3
2 4
3 5
4 6
5 7
6 8
7 9
8 9
*/
