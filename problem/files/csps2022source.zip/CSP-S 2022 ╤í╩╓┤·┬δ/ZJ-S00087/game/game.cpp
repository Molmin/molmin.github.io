#include<bits/stdc++.h>
#define ll long long
#define lc x<<1
#define rc x<<1|1
using namespace std;
const int N=1e3+7,M=1e3+7;
int n,m,i,q,j,l1,r1,l2,r2;
int a[N],b[M];
ll c[N][M];
struct tree {
#define mid ((nl+nr)>>1)
	ll t[M<<2];//M<<2!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	ll query(int l,int r,int nl,int nr,int x) {
		if(l<=nl&&nr<=r)return t[x];
		ll ans=LLONG_MAX;
		if(l<=mid)ans=min(ans,query(l,r,nl,mid,lc));
		if(mid<r)ans=min(ans,query(l,r,mid+1,nr,rc));
		return ans;
	}
#undef mid
#define mid ((l+r)>>1)
	void build(int i,int l,int r,int x) {
		if(l==r) {
			t[x]=c[i][l];
			return;
		}
		build(i,l,mid,lc);
		build(i,mid+1,r,rc);
		t[x]=min(t[lc],t[rc]);
	}
} t[N];
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
//	ios::sync_with_stdio(0);
//	cin.tie(0),cout.tie(0);
	cin>>n>>m>>q;
	for(i=1; i<=n; ++i)
		cin>>a[i];
	for(i=1; i<=m; ++i)
		cin>>b[i];
	for(i=1; i<=n; ++i)
		for(j=1; j<=m; ++j)
			c[i][j]=(ll)1ll*a[i]*b[j];
	for(i=1; i<=n; ++i)
		t[i].build(i,1,m,1);
	while(q--) {
		cin>>l1>>r1>>l2>>r2;
		ll ans=LLONG_MIN;
		for(i=l1; i<=r1; ++i) 
			ans=max(t[i].query(l2,r2,1,m,1),ans);
		cout<<ans<<'\n';
	}
	return 0;
}
