#include<bits/stdc++.h>
#define Min(x,y) ((x>y)&&(x=y))
#define Max(x,y) ((x<y)&&(x=y))
using namespace std;

typedef long long ll;
const int inf=0x3f3f3f3f;
const int M=1e5+5;

inline int read()
{
	int x=0,f=1;static char ch;
	while(ch=getchar(),ch<48)if(ch==45)f=0;
	do x=(x<<1)+(x<<3)+(ch^48);
	while(ch=getchar(),ch>=48);
	return f?x:-x;
}

int n,m,q,A[M],B[M];

namespace P60
{
	// Notice! it's from 1 to m
	// Notice! varry use N
	// Notice! ans is over 1e18
	
	const int N=1005;
	
	int mi[N<<2],mx[N<<2];
	#define ls(p) p<<1
	#define rs(p) p<<1|1
	void build(int p,int l,int r)
	{
		if(l==r){mi[p]=mx[p]=B[l];return;}
		int mid=(l+r)>>1;
		build(ls(p),l,mid);
		build(rs(p),mid+1,r);
		mi[p]=min(mi[ls(p)],mi[rs(p)]);
		mx[p]=max(mx[ls(p)],mx[rs(p)]);
	}
	int query_mi(int p,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y)return mi[p];
		int mid=(l+r)>>1,res=inf;
		if(x<=mid)res=query_mi(ls(p),l,mid,x,y);
		if(y>mid)res=min(res,query_mi(rs(p),mid+1,r,x,y));
		return res;
	}
	int query_mx(int p,int l,int r,int x,int y)
	{
		if(x<=l&&r<=y)return mx[p];
		int mid=(l+r)>>1,res=-inf;
		if(x<=mid)res=query_mx(ls(p),l,mid,x,y);
		if(y>mid)res=max(res,query_mx(rs(p),mid+1,r,x,y));
		return res;
	}
	
	void solve()
	{
		build(1,1,m);
		for(int qqq=1,l1,r1,l2,r2;qqq<=q;qqq++)
		{
			l1=read(),r1=read(),l2=read(),r2=read();
			
			ll ans=-1e18;
			ll mx=query_mx(1,1,m,l2,r2);
			ll mi=query_mi(1,1,m,l2,r2);
			for(int i=l1,now;i<=r1;i++)
			{
				if(A[i]<0)Max(ans,1ll*A[i]*mx);
				else if(A[i]>0)Max(ans,1ll*A[i]*mi);
				else Max(ans,0);
//				printf("%lld ",1ll*A[i]*now);
			}
//			printf("\n");
			
			printf("%lld\n",ans);
		}
	}
}
namespace P100
{
	struct cpp
	{
		int mi0,mx0,ze;// >0 min  <0 max
		int mi,mx;// <0 min  >0 max
	}T[2][M<<2],init;
	cpp Push_up(cpp le,cpp ri,int op)
	{
		if(op==1)
			return (cpp){0,0,0,min(le.mi,ri.mi),max(le.mx,ri.mx)};
		return (cpp){min(le.mi0,ri.mi0),max(le.mx0,ri.mx0),(le.ze||ri.ze),min(le.mi,ri.mi),max(le.mx,ri.mx)};
	}
	
	#define ls(p) p<<1
	#define rs(p) p<<1|1
	void build(int p,int l,int r,int op)
	{
		if(l==r)
		{
			if(op==0)
			{
				if(A[l]>0)T[0][p]=(cpp){A[l],-inf,0,inf,A[l]};
				else if(A[l]<0)T[0][p]=(cpp){inf,A[l],0,A[l],-inf};
				else T[0][p]=(cpp){inf,-inf,1,inf,-inf};
			}
			else T[1][p]=(cpp){0,0,0,B[l],B[l]};
			return ;
		}
		int mid=(l+r)>>1;
		build(ls(p),l,mid,op);
		build(rs(p),mid+1,r,op);
		T[op][p]=Push_up(T[op][ls(p)],T[op][rs(p)],op);
	}
	cpp query(int p,int l,int r,int x,int y,int op)
	{
		if(x<=l&&r<=y)return T[op][p];
		int mid=(l+r)>>1;cpp le=init,ri=init;
		if(x<=mid)le=query(ls(p),l,mid,x,y,op);
		if(y>mid)ri=query(rs(p),mid+1,r,x,y,op);
		return Push_up(le,ri,op);
	}
	
	
	void solve()
	{
		init=(cpp){inf,-inf,0,inf,-inf};
		build(1,1,n,0);
		build(1,1,m,1);
		for(int qqq=1,l1,r1,l2,r2;qqq<=q;qqq++)
		{
			l1=read(),r1=read(),l2=read(),r2=read();
			
			cpp A=query(1,1,n,l1,r1,0);
			cpp B=query(1,1,m,l2,r2,1);
			
//			printf("%d %d %d %d %d\n",A.mi0,A.mx0,A.ze,A.mi,A.mx);
//			printf("%d %d\n",B.mi,B.mx);
			
			ll ans=A.ze?0:-1e18;
			if(B.mi<0)
			{
				if(A.mi0<inf)Max(ans,1ll*A.mi0*B.mi);
			}
			else
			{
				if(A.mx>-inf)Max(ans,1ll*A.mx*B.mi);
			}
			if(B.mx>0)
			{
				if(A.mx0>-inf)Max(ans,1ll*A.mx0*B.mx);
			}
			else
			{
				if(A.mi<inf)Max(ans,1ll*A.mi*B.mx);
			}
			
			printf("%lld\n",ans);
		}
	}
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++)A[i]=read();
	for(int i=1;i<=m;i++)B[i]=read();
	
	if(n<=1000)P60::solve();
	else P100::solve();
	
	return 0;
}
/*
5 5 1
-5 -5 -2 3 -5 
-3 -1 -5 -5 2 
4 4 1 2
*/
