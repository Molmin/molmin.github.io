#include<bits/stdc++.h>
#define Min(x,y) ((x>y)&&(x=y))
#define Max(x,y) ((x<y)&&(x=y))
using namespace std;

typedef long long ll;
const int M=2505;

inline ll read()
{
	ll x=0,f=1;static char ch;
	while(ch=getchar(),ch<48)if(ch==45)f=0;
	do x=(x<<1ll)+(x<<3ll)+(ch^48);
	while(ch=getchar(),ch>=48);
	return f?x:-x;
}

int n,m,lim,dis[M][M];
ll s[M];

namespace P40
{
	bool vis[M];
	ll ans=0;
	
	void dfs(int t,int x,ll res)
	{
		if(t==4)
		{
			if(dis[x][1]-1<=lim)Max(ans,res);
			return;
		}
		for(int v=2;v<=n;v++)
			if(!vis[v]&&dis[x][v]-1<=lim)
			{
				vis[v]=true;
				dfs(t+1,v,res+s[v]);
				vis[v]=false;
			}
	}
	
	void solve()
	{
		for(int k=1;k<=n;k++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					Min(dis[i][j],dis[i][k]+dis[k][j]);
		dfs(0,1,0);
		printf("%lld",ans);
	}
}
namespace P70
{
	ll mx[M][3],m1,m2,ans;
	bool mid[305][305];
	
	void solve()
	{
		for(int k=1;k<=n;k++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					Min(dis[i][j],dis[i][k]+dis[k][j]);
		for(int i=2;i<=n;i++)
			for(int j=2;j<=n;j++)
			{
				if(i==j)continue;
				if(dis[i][j]-1<=lim&&dis[1][j]-1<=lim)
				{
//					printf("1 ~ %d ~ %d\n",j,i);
					
					mid[i][j]=true;
					if(s[j]>mx[i][2])mx[i][2]=s[j];
					if(mx[i][2]>mx[i][1])swap(mx[i][2],mx[i][1]);
					if(mx[i][1]>mx[i][0])swap(mx[i][1],mx[i][0]);
				}
			}
		for(int x=2;x<=n;x++)
			for(int y=2;y<=n;y++)
			{
				if(x==y||dis[x][y]-1>lim)continue;
				
//				ans=0;
				
				for(int z=2;z<=n;z++)
				{
					if(x==z||y==z||!mid[x][z])continue;
					if(!mid[y][z])
					{
						if(mx[y][0]&&(!mid[y][x]||s[x]!=mx[y][0]))
							Max(ans,s[x]+s[y]+s[z]+mx[y][0]);
						else if(mx[y][1])Max(ans,s[x]+s[y]+s[z]+mx[y][1]);
					}
					else
					{
						if(!mid[y][x])
						{
							if(mx[y][0]&&s[z]!=mx[y][0])
								Max(ans,s[x]+s[y]+s[z]+mx[y][0]);
							else if(mx[y][1])Max(ans,s[x]+s[y]+s[z]+mx[y][1]);
						}
						else
						{
							m1=max(s[x],s[z]),m2=min(s[x],s[z]);
							if(m1==mx[y][0]&&m2==mx[y][1]&&mx[y][2])
								Max(ans,s[x]+s[y]+s[z]+mx[y][2]);
							else if((m1==mx[y][0]||m2==mx[y][0])&&mx[y][1])
								Max(ans,s[x]+s[y]+s[z]+mx[y][1]);
							else if(mx[y][0])Max(ans,s[x]+s[y]+s[z]+mx[y][0]);
						}
					}
				}
//				printf("x=%d y=%d ans=%lld\n",x,y,ans);
			}
		
		printf("%lld",ans);
	}
}
namespace P100
{
	bool vis[M];
	ll ans=0;
	
	void dfs(int t,int x,ll res)
	{
		if(t==4)
		{
			if(dis[x][1])Max(ans,res);
			return;
		}
		for(int v=2;v<=n;v++)
			if(!vis[v]&&dis[x][v])
			{
				vis[v]=true;
				dfs(t+1,v,res+s[v]);
				vis[v]=false;
			}
	}
	void solve()
	{
		if(lim==0)dfs(0,1,0);
		else
		{
			sort(s+2,s+n+1);
			for(int i=n;i>n-4;i++)
				ans+=s[i];
		}
		printf("%lld",ans);
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	n=read(),m=read(),lim=read();
	for(int i=2;i<=n;i++)s[i]=read();
	
	memset(dis,0x3f,sizeof(dis));
	for(int i=1;i<=n;i++)dis[i][i]=0;
	for(int i=1,x,y;i<=m;i++)
	{
		x=read(),y=read();
		dis[x][y]=dis[y][x]=1;
	}
	if(n<=20)P40::solve();
	else if(n<=300)P70::solve();
	else P100::solve();
	
	return 0;
}
