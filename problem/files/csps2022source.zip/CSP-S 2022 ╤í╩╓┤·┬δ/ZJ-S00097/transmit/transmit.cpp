#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int M=2e5+5;

inline int read()
{
	int x=0,f=1;static char ch;
	while(ch=getchar(),ch<48)if(ch==45)f=0;
	do x=(x<<1)+(x<<3)+(ch^48);
	while(ch=getchar(),ch>=48);
	return f?x:-x;
}

int n,q,k,f[M][20],dep[M];
ll v[M],sum[M];
vector<int> E[M];

void dfs(int x,int fa)
{
	f[x][0]=fa,sum[x]=sum[fa]+v[x];
	dep[x]=dep[fa]+1;
	for(int i=1;i<=18;i++)
		f[x][i]=f[f[x][i-1]][i-1];
	for(int v:E[x])if(v!=fa)dfs(v,x);
}
int lca(int x,int y)
{
	if(x==y)return x;
	if(dep[x]>dep[y])swap(x,y);
	for(int i=18;i>=0;i--)
		if(dep[x]<=dep[f[y][i]])y=f[y][i];
	if(x==y)return x;
	for(int i=18;i>=0;i--)
		if(f[x][i]!=f[y][i])
			x=f[x][i],y=f[y][i];
	return f[x][0];
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	
	n=read(),q=read(),k=read();
	for(int i=1;i<=n;i++)v[i]=read();
	for(int i=1,u,v;i<n;i++)
	{
		u=read(),v=read();
		E[u].push_back(v);
		E[v].push_back(u);
	}
	dfs(1,0);
	for(int i=1,s,t,c;i<=q;i++)
	{
		s=read(),t=read(),c=lca(s,t);
		printf("%lld\n",sum[s]+sum[t]-2*sum[c]+v[c]);
	}
	
	return 0;
}
