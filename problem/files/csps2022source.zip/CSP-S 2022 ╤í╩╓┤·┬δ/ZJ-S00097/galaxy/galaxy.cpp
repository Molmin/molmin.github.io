#include<bits/stdc++.h>
using namespace std;

inline int read()
{
	int x=0,f=1;static char ch;
	while(ch=getchar(),ch<48)if(ch==45)f=0;
	do x=(x<<1)+(x<<3)+(ch^48);
	while(ch=getchar(),ch>=48);
	return f?x:-x;
}

int n,m,q;

namespace P40
{
	const int M=1005;
	int ot[M],nxt[M];
	bool mark[M][M];
	vector<int> E[M],G[M];
	
	bool vis[M];
	
	bool check()
	{
		for(int i=1;i<=n;i++)
			if(ot[i]!=1)return false;
		return true;
//		for(int i=1;i<=n;i++)
//		{
//			vis[i]=nxt[i]=0;
//			for(int v:E[i])
//				if(mark[i][v]){nxt[i]=v;break;}
//		}
//		
//		for(int i=1;i<=n;i++)
//		{
//			if(vis[i])continue;int x=i;
//			while(!vis[x])vis[x]=true,x=nxt[x];
//		}
	}
	
	void solve()
	{
		for(int i=1,u,v;i<=m;i++)
		{
			u=read(),v=read();
			E[u].push_back(v);
			G[v].push_back(u);
			mark[u][v]=true,ot[u]++;
		}
		q=read();
		for(int qqq=1,op,u,v;qqq<=q;qqq++)
		{
			op=read();
			if(op==1)
			{
				u=read(),v=read();
				mark[u][v]=false,ot[u]--;
			}
			else if(op==2)
			{
				u=read();
				for(int las:G[u])
					if(mark[las][u])
						mark[las][u]=false,ot[las]--;
			}
			else if(op==3)
			{
				u=read(),v=read();
				mark[u][v]=true,ot[u]++;
			}
			else
			{
				u=read();
				for(int las:G[u])
					if(!mark[las][u])
						mark[las][u]=true,ot[las]++;
			}
			if(check())printf("YES\n");
			else printf("NO\n");
		}
	}
}
namespace P100
{
	const int M=5e5+5;
	int ot[M],OP[M],U[M],V[M];
	vector<int> E[M],G[M];
	
	bool vis[M],flag_24=true,flag_4=true;
	
	void solve_24()
	{
		int cnt=0;
		for(int i=1;i<=n;i++)
			if(ot[i]==1)cnt++;
		
		for(int qqq=1;qqq<=q;qqq++)
		{
			int op=OP[qqq],u=U[qqq],v=V[qqq];
			if(op==1)
			{
				if(ot[u]==1)cnt--;
				ot[u]--;
				if(ot[u]==1)cnt++;
			}
			else
			{
				if(ot[u]==1)cnt--;
				ot[u]++;
				if(ot[u]==1)cnt++;
			}
			if(cnt==n)printf("YES\n");
			else printf("NO\n");
		}
	}
	
	void solve()
	{
		for(int i=1,u,v;i<=m;i++)
		{
			u=read(),v=read();
			E[u].push_back(v);
			G[v].push_back(u);
			ot[u]++;
		}
		q=read();
		for(int qqq=1;qqq<=q;qqq++)
		{
			OP[qqq]=read();
			if(OP[qqq]==1||OP[qqq]==3)U[qqq]=read(),V[qqq]=read();
			else U[qqq]=read();
			if(OP[qqq]==4)flag_24=false,flag_4=false;
			if(OP[qqq]==2)flag_24=false;
		}
		
		if(flag_24)solve_24();
		else
		{
			for(int i=1;i<=q;i++)
				printf("NO\n");
		}
	}
}

int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	
	n=read(),m=read();
	if(n<=1000&&m<=10000)P40::solve();
	else P100::solve();
	
	return 0;
}
