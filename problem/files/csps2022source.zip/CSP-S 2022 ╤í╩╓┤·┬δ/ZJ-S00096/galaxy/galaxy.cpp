#include<bits/stdc++.h>
#define ri register LL
using namespace std;
typedef long long LL;
inline LL rd(){
	LL x=0,y=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar())if(c=='-')y=1;
	for(;c>='0'&&c<='9';c=getchar())x=x*10+(c-'0');
	return y?-x:x;
}
LL n,m,q,a[500005][15],b[15],nw[15],sm[500005][15],de[500005][15],ad[500005][15];
LL rs=1;inline LL rad(){return rs=(rs*3+7)%998244353;}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=rd();m=rd();
	for(ri i=1;i<=n;++i)
	for(ri j=1;j<=10;++j)a[i][j]=rad(),b[j]+=a[i][j];
	for(ri i=1,x,y;i<=m;++i){
		x=rd();y=rd();
		for(ri j=1;j<=10;++j)sm[y][j]+=a[x][j],de[y][j]+=a[x][j],nw[j]+=a[x][j];
	}
	q=rd();
	for(ri x,y,op;q--;){
		op=rd();x=rd();if(op&1)y=rd();
		if(op==1)for(ri j=1;j<=10;++j)ad[y][j]+=a[x][j],de[y][j]-=a[x][j],nw[j]-=a[x][j];
		else if(op==2)for(ri j=1;j<=10;++j)nw[j]-=de[x][j],ad[x][j]=sm[x][j],de[x][j]=0;
		else if(op==3)for(ri j=1;j<=10;++j)ad[y][j]-=a[x][j],de[y][j]+=a[x][j],nw[j]+=a[x][j];
		else for(ri j=1;j<=10;++j)nw[j]+=ad[x][j],ad[x][j]=0,de[x][j]=sm[x][j];
		ri fl=1;
		for(ri j=1;j<=10;++j)if(nw[j]!=b[j])fl=0;
		puts(fl?"YES":"NO");
	}
	return 0;
}
