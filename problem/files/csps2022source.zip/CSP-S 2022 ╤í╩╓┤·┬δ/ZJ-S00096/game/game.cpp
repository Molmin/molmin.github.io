#include<bits/stdc++.h>
#define ri register LL
using namespace std;
typedef long long LL;
inline LL rd(){
	LL x=0,y=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar())if(c=='-')y=1;
	for(;c>='0'&&c<='9';c=getchar())x=x*10+(c-'0');
	return y?-x:x;
}
const LL mnn=-2000000000,mxx=2000000000;
LL n,m,k,a[100005],b[100005],q,lg[100005],s1,s2,u[5],v[5];
LL azx[100005][20],azn[100005][20],afx[100005][20],afn[100005][20];
LL bzx[100005][20],bzn[100005][20],bfx[100005][20],bfn[100005][20];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=rd(),m=rd(),q=rd();lg[0]=-1;
	for(ri i=1;i<=max(n,m);++i)lg[i]=lg[i>>1]+1;
	for(ri i=1;i<=n;++i){
		a[i]=rd();
		if(a[i]>0)azx[i][0]=azn[i][0]=a[i],afx[i][0]=mnn,afn[i][0]=mxx;
		if(a[i]<0)afx[i][0]=afn[i][0]=a[i],azx[i][0]=mnn,azn[i][0]=mxx;
	}
	for(ri i=1;i<=m;++i){
		b[i]=rd();
		if(b[i]>0)bzx[i][0]=bzn[i][0]=b[i],bfx[i][0]=mnn,bfn[i][0]=mxx;
		if(b[i]<0)bfx[i][0]=bfn[i][0]=b[i],bzx[i][0]=mnn,bzn[i][0]=mxx;
	}
	for(ri i=1;i<=18;++i)
	for(ri j=1,k;j+(1<<i)-1<=n;++j){
		k=j+(1<<i-1);
		azx[j][i]=max(azx[j][i-1],azx[k][i-1]);
		azn[j][i]=min(azn[j][i-1],azn[k][i-1]);
		afx[j][i]=max(afx[j][i-1],afx[k][i-1]);
		afn[j][i]=min(afn[j][i-1],afn[k][i-1]);
	}
	for(ri i=1;i<=18;++i)
	for(ri j=1,k;j+(1<<i)-1<=m;++j){
		k=j+(1<<i-1);
		bzx[j][i]=max(bzx[j][i-1],bzx[k][i-1]);
		bzn[j][i]=min(bzn[j][i-1],bzn[k][i-1]);
		bfx[j][i]=max(bfx[j][i-1],bfx[k][i-1]);
		bfn[j][i]=min(bfn[j][i-1],bfn[k][i-1]);
	}
	for(ri x,y,X,Y,z,Z;q--;){
		x=rd();y=rd();X=rd();Y=rd();s1=s2=0;
		z=lg[y-x+1];Z=y-(1<<z)+1;
		if(max(azx[x][z],azx[Z][z])!=mnn)u[++s1]=max(azx[x][z],azx[Z][z]);
		if(min(azn[x][z],azn[Z][z])!=mxx)u[++s1]=min(azn[x][z],azn[Z][z]);
		if(max(afx[x][z],afx[Z][z])!=mnn)u[++s1]=max(afx[x][z],afx[Z][z]);
		if(min(afn[x][z],afn[Z][z])!=mxx)u[++s1]=min(afn[x][z],afn[Z][z]);
		z=lg[Y-X+1];Z=Y-(1<<z)+1;
		if(max(bzx[X][z],bzx[Z][z])!=mnn)v[++s2]=max(bzx[X][z],bzx[Z][z]);
		if(min(bzn[X][z],bzn[Z][z])!=mxx)v[++s2]=min(bzn[X][z],bzn[Z][z]);
		if(max(bfx[X][z],bfx[Z][z])!=mnn)v[++s2]=max(bfx[X][z],bfx[Z][z]);
		if(min(bfn[X][z],bfn[Z][z])!=mxx)v[++s2]=min(bfn[X][z],bfn[Z][z]);
		ri p=mnn*mxx,P,U;
		for(ri i=1;i<=s1;++i){
			U=mxx*mxx;
			for(ri j=1;j<=s2;++j)U=min(U,u[i]*v[j]);
			if(U>p)p=U,P=i;
		}
		ri q=mxx*mxx;for(ri i=1;i<=s2;++i)q=min(q,v[i]*u[P]);
		printf("%lld\n",q);
	}
	return 0;
}
