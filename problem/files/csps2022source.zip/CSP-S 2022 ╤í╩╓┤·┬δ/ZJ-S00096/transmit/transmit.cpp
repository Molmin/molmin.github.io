#include<bits/stdc++.h>
#define ri register LL
using namespace std;
typedef long long LL;
inline LL rd(){
	LL x=0,y=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar())if(c=='-')y=1;
	for(;c>='0'&&c<='9';c=getchar())x=x*10+(c-'0');
	return y?-x:x;
}
LL n,m,k,f[500005],a[500005],hd[500005],to[1000005],nx[1000005],vl,z,b[500005],cn;
inline void add(LL x,LL y){nx[++cn]=hd[x];hd[x]=cn;to[cn]=y;}
inline LL dfs(LL x,LL fa,LL y){
	if(x==y){b[++z]=x;return 1;}ri fl=0;
	for(ri i=hd[x];i;i=nx[i])if(to[i]!=fa)fl|=dfs(to[i],x,y);
	if(fl)b[++z]=x;return fl;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=rd();m=rd();k=rd();
	for(ri i=1;i<=n;++i)a[i]=rd();
	for(ri i=1,x,y;i<n;++i){x=rd();y=rd();add(x,y);add(y,x);}
	for(ri x,y,p;m--;){
		x=rd();y=rd();z=0;p=dfs(x,0,y);f[1]=a[y];
		for(ri i=2;i<=z;++i){
			f[i]=10000000000000000ll;
			for(ri j=i-1;j>=i-k&&j;--j)f[i]=min(f[i],f[j]);
			if(k==3&&i>=5)for(ri j=hd[b[i-2]];j;j=nx[j])
			f[i]=min(f[i],f[i-4]+a[to[j]]);f[i]+=a[b[i]];
		}
		printf("%lld\n",f[z]);
	}
	return 0;
}
