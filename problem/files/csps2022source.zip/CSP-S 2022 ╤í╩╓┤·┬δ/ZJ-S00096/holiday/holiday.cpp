#include<bits/stdc++.h>
#define ri register LL
using namespace std;
typedef long long LL;
inline LL rd(){
	LL x=0,y=0;char c=getchar();
	for(;c<'0'||c>'9';c=getchar())if(c=='-')y=1;
	for(;c>='0'&&c<='9';c=getchar())x=x*10+(c-'0');
	return y?-x:x;
}
LL n,m,k,a[2505],ds[2505][2505],f[2505][3],s[2505][3],ans;
vector<LL>g[2505];queue<LL>q;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=rd();m=rd();k=rd()+1;
	for(ri i=2;i<=n;++i)a[i]=rd();
	for(ri x,y;m--;){x=rd();y=rd();g[x].push_back(y);g[y].push_back(x);}
	for(ri i=1;i<=n;++i){
		for(ri j=1;j<=n;++j)ds[i][j]=100000000;
		q.push(i);ds[i][i]=0;
		while(!q.empty()){
			ri x=q.front();q.pop();
			for(ri p=0,j=g[x].size(),y;p<j;++p)
			if(ds[i][y=g[x][p]]==100000000)ds[i][y]=ds[i][x]+1,q.push(y);
		}
	}
	for(ri i=2;i<=n;++i){
		f[i][0]=f[i][1]=f[i][2]=-4000000000000000000ll;
		for(ri j=2;j<=n;++j)
		if(i!=j&&ds[i][j]<=k&&ds[j][1]<=k)
		for(ri p=0;p<3;++p)if(a[j]>f[i][p]){
			for(ri q=2;q>p;--q)f[i][q]=f[i][q-1],s[i][q]=s[i][q-1];
			f[i][p]=a[j];s[i][p]=j;break;
		}
	}
	for(ri i=2;i<=n;++i)for(ri j=2;j<=n;++j)if(i!=j&&ds[i][j]<=k)
	for(ri p=0;p<3;++p)for(ri q=0;q<3;++q){
		ri u=s[i][p],v=s[j][q];
		if(u&&v&&i!=v&&j!=u&&u!=v)ans=max(ans,a[i]+a[j]+a[u]+a[v]);
	}
	cout<<ans;return 0;
}
