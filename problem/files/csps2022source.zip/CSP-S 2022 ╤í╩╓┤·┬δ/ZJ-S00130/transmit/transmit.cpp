// This Code was made by Chinese_zjc_.
#include<bits/stdc++.h>
void cmin(long long&A,long long B){A=std::min(A,B);}
int n,q,k,fa[200005],tim,dfn[200005],idfn[200005],heavy[200005],top[200005],
    depth[200005],siz[200005];
long long v[200005],w[200005];
std::vector<int> to[200005];
struct matrix
{
    long long v[3][3];
    matrix(){std::memset(v,0x3f,sizeof(v));}
    friend matrix operator*(const matrix &A,const matrix &B)
    {
        matrix res;
        for(int i=0;i!=3;++i)
            for(int j=0;j!=3;++j)
                for(int k=0;k!=3;++k)
                    cmin(res.v[i][k],A.v[i][j]+B.v[j][k]);
        return res;
    }
}ept,prea[200005],preb[200005];
matrix get(long long x,long long y)
{
    matrix res;
    switch(k)
    {
    case 1:
        res.v[0][0]=x;
        break;
    case 2:
        res.v[0][0]=x;
        res.v[0][1]=0;
        res.v[1][0]=x;
        break;
    case 3:
        res.v[0][0]=x;
        res.v[0][1]=0;
        res.v[1][0]=x;
        res.v[1][1]=y;
        res.v[1][2]=0;
        res.v[2][0]=x;
        break;
    }
    return res;
}
void init1(int now)
{
    siz[now]=1;
    for(auto i:to[now])
    {
        if(i==fa[now])
            continue;
        fa[i]=now;
        depth[i]=depth[now]+1;
        init1(i);
        siz[now]+=siz[i];
        if(siz[i]>siz[heavy[now]])
            heavy[now]=i;
    }
}
void init2(int now)
{
    if(!top[now])
    {
        top[now]=now;
        prea[now]=ept;
        preb[now]=ept;
    }
    prea[now]=prea[now]*get(v[now],w[now]);
    preb[now]=get(v[now],w[now])*preb[now];
    idfn[dfn[now]=++tim]=now;
    if(int i=heavy[now])
    {
        top[i]=top[now];
        prea[i]=prea[now];
        preb[i]=preb[now];
        init2(i);
    }
    for(auto i:to[now])
    {
        if(i==fa[now]||i==heavy[now])
            continue;
        init2(i);
    }
}
struct segtree
{
    #define lson (now<<1)
    #define rson (lson|1)
    #define lmid ((l+r)>>1)
    #define rmid (lmid+1)
    matrix a[1<<19],b[1<<19];
    void pushup(int now)
    {
        a[now]=a[lson]*a[rson];
        b[now]=b[rson]*b[lson];
    }
    void build(int now=1,int l=1,int r=n)
    {
        if(l==r)
        {
            a[now]=b[now]=get(v[idfn[l]],w[idfn[l]]);
            return;
        }
        build(lson,l,lmid);
        build(rson,rmid,r);
        pushup(now);
    }
    matrix querya(int L,int R,int now=1,int l=1,int r=n)
    {
        if(r<L||R<l)
            return ept;
        if(L<=l&&r<=R)
            return a[now];
        return querya(L,R,lson,l,lmid)*querya(L,R,rson,rmid,r);
    }
    matrix queryb(int L,int R,int now=1,int l=1,int r=n)
    {
        if(r<L||R<l)
            return ept;
        if(L<=l&&r<=R)
            return b[now];
        return queryb(L,R,rson,rmid,r)*queryb(L,R,lson,l,lmid);
    }
}tree;
signed main()
{
    freopen("transmit.in","r",stdin)&&freopen("transmit.out","w",stdout);
    std::ios::sync_with_stdio(false);
    for(int i=0;i!=3;++i)
        ept.v[i][i]=0;
    std::cin>>n>>q>>k;
    for(int i=1;i<=n;++i)
        std::cin>>v[i],w[i]=INT_MAX;
    for(int i=1,u,v;i<n;++i)
    {
        std::cin>>u>>v;
        to[u].push_back(v);
        to[v].push_back(u);
    }
    for(int i=1;i<=n;++i)
        for(auto j:to[i])
            cmin(w[i],v[j]);
    init1(1);
    init2(1);
    tree.build();
    for(int i=1,s,t;i<=q;++i)
    {
        std::cin>>s>>t;
        int ss=s,tt=t;
        while(top[ss]!=top[tt])
        {
            if(depth[top[ss]]<depth[top[tt]])
                tt=fa[top[tt]];
            else
                ss=fa[top[ss]];
        }
        if(depth[ss]>depth[tt])
            std::swap(s,t);
        matrix L=ept,R=ept;
        while(top[s]!=top[t])
        {
            if(depth[top[s]]<depth[top[t]])
            {
                R=prea[t]*R;
                t=fa[top[t]];
            }
            else
            {
                L=L*preb[s];
                s=fa[top[s]];
            }
        }
        std::cout<<(L*tree.querya(dfn[s],dfn[t])*R).v[k-1][0]<<'\n';
    }
    return 0;
}