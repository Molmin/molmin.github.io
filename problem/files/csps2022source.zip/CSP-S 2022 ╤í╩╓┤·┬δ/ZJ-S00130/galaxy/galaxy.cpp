// This Code was made by Chinese_zjc_.
#include<bits/stdc++.h>
std::mt19937 Rand(time(nullptr));
long long sum,v[500005],cur[500005],tot[500005];
std::vector<int> to[500005];
int n,m,q,opt[500005],a[500005],b[500005];
bool ans[500005];
signed main()
{
    freopen("galaxy.in","r",stdin)&&freopen("galaxy.out","w",stdout);
    std::ios::sync_with_stdio(false);
    std::cin>>n>>m;
    for(int i=1,u,v;i<=m;++i)
    {
        std::cin>>u>>v;
        to[v].push_back(u);
    }
    std::cin>>q;
    for(int i=1;i<=q;++i)
    {
        std::cin>>opt[i]>>a[i];
        if(opt[i]&1)
            std::cin>>b[i];
        ans[i]=true;
    }
    for(int tim=1;tim<=20;++tim)
    {
        for(int i=1;i<=n;++i)
            v[i]=Rand();
        sum=0;
        for(int i=1;i<=n;++i)
        {
            sum-=v[i];
            tot[i]=0;
            for(auto j:to[i])
                tot[i]+=v[j];
            cur[i]=tot[i];
            sum+=tot[i];
        }
        for(int i=1;i<=q;++i)
        {
            switch(opt[i])
            {
            case 1:
                cur[b[i]]-=v[a[i]];
                sum-=v[a[i]];
                break;
            case 2:
                sum-=cur[a[i]];
                cur[a[i]]=0;
                break;
            case 3:
                cur[b[i]]+=v[a[i]];
                sum+=v[a[i]];
                break;
            case 4:
                sum+=tot[a[i]]-cur[a[i]];
                cur[a[i]]=tot[a[i]];
                break;
            }
            ans[i]&=sum==0;
        }
    }
    for(int i=1;i<=q;++i)
        std::cout<<(ans[i]?"YES":"NO")<<'\n';
    return 0;
}