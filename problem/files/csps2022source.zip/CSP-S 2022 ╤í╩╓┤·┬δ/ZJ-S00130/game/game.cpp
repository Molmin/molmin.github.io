// This Code was made by Chinese_zjc_.
#include<bits/stdc++.h>
void cmin(long long &A,long long B){A=std::min(A,B);}
void cmax(long long &A,long long B){A=std::max(A,B);}
struct node
{
    long long nmin,nmax,min,max;
    node():nmin(INT_MAX),nmax(INT_MIN),min(INT_MAX),max(INT_MIN){}
    friend node operator+(const node &A,const node &B)
    {
        node res;
        res.nmin=std::min(A.nmin,B.nmin);
        res.nmax=std::max(A.nmax,B.nmax);
        res.min=std::min(A.min,B.min);
        res.max=std::max(A.max,B.max);
        return res;
    }
};
struct segtree
{
#define lson (now<<1)
#define rson (lson|1)
#define lmid ((l+r)>>1)
#define rmid (lmid+1)
    node t[1<<18];
    void pushup(int now){t[now]=t[lson]+t[rson];}
    void build(long long *x,int now=1,int l=1,int r=100000)
    {
        if(l==r)
        {
            if(x[l]<=0)
            {
                cmin(t[now].nmin,x[l]);
                cmax(t[now].nmax,x[l]);
            }
            if(x[l]>=0)
            {
                cmin(t[now].min,x[l]);
                cmax(t[now].max,x[l]);
            }
            return;
        }
        build(x,lson,l,lmid);
        build(x,rson,rmid,r);
        pushup(now);
    }
    node query(int L,int R,int now=1,int l=1,int r=100000)
    {
        if(R<l||r<L)
            return node();
        if(L<=l&&r<=R)
            return t[now];
        return query(L,R,lson,l,lmid)+query(L,R,rson,rmid,r);
    }
}A,B;
int n,m,q;
long long a[100005],b[100005];
signed main()
{
    freopen("game.in","r",stdin)&&freopen("game.out","w",stdout);
    std::ios::sync_with_stdio(false);
    std::cin>>n>>m>>q;
    for(int i=1;i<=n;++i)
        std::cin>>a[i];
    for(int i=1;i<=m;++i)
        std::cin>>b[i];
    A.build(a);
    B.build(b);
    for(int i=1,l1,r1,l2,r2;i<=q;++i)
    {
        std::cin>>l1>>r1>>l2>>r2;
        node L=A.query(l1,r1);
        node R=B.query(l2,r2);
        long long x[4]={L.nmin,L.nmax,L.min,L.max},
                  y[4]={R.nmin,R.nmax,R.min,R.max};
        long long ans=LLONG_MIN;
        for(int i=0;i!=4;++i)
            if(x[i]!=INT_MIN&&x[i]!=INT_MAX)
            {
                long long res=LLONG_MAX;
                for(int j=0;j!=4;++j)
                    if(y[j]!=INT_MIN&&y[j]!=INT_MAX)
                        cmin(res,x[i]*y[j]);
                cmax(ans,res);
            }
        std::cout<<ans<<std::endl;
    }
    return 0;
}