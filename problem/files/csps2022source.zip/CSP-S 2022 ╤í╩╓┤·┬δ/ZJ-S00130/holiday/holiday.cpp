// This Code was made by Chinese_zjc_.
#include<bits/stdc++.h>
int n,m,k,dis[2505][2505];
long long a[2505],ans;
std::vector<int> to[2505],val[2505];
signed main()
{
    freopen("holiday.in","r",stdin)&&freopen("holiday.out","w",stdout);
    std::ios::sync_with_stdio(false);
    std::cin>>n>>m>>k;
    ++k;
    for(int i=2;i<=n;++i)
        std::cin>>a[i];
    for(int i=1,u,v;i<=m;++i)
    {
        std::cin>>u>>v;
        to[u].push_back(v);
        to[v].push_back(u);
    }
    std::memset(dis,-1,sizeof(dis));
    for(int i=1;i<=n;++i)
    {
        std::queue<int>que;
        que.push(i);
        dis[i][i]=0;
        while(!que.empty())
        {
            int now=que.front();
            que.pop();
            for(auto j:to[now])
                if(!~dis[i][j])
                    dis[i][j]=dis[i][now]+1,que.push(j);
        }
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            dis[i][j]=0<=dis[i][j]&&dis[i][j]<=k;
    for(int i=2;i<=n;++i)
    {
        for(int j=2;j<=n;++j)
            if(i!=j&&dis[1][j]&&dis[i][j])
                val[i].push_back(j);
        if(val[i].size()>4)
            std::nth_element(val[i].begin(),val[i].begin()+4,val[i].end(),
                             [&](const int &A,const int &B)
                             {return a[A]>a[B];});
    }
    for(int i=2;i<=n;++i)
        for(int j=2;j<i;++j)
            if(dis[i][j])
                for(int k=0;k<std::min(4,int(val[i].size()));++k)
                    for(int l=0;l<std::min(4,int(val[j].size()));++l)
                        if(val[i][k]!=j&&val[j][l]!=i&&val[i][k]!=val[j][l])
                            ans=std::max(ans,a[i]+a[j]+a[val[i][k]]+a[val[j][l]]);
    std::cout<<ans<<std::endl;
    return 0;
}