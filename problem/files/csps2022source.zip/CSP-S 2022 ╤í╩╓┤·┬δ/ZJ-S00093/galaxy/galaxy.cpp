#include<bits/stdc++.h>
using namespace std;
int e[8005][8005];
bool ex[8005][8005];
bool v[8005];
int len[8005];
int n,m,q;
bool dfs(int t)
{
	if(v[t])
		return 1;
	v[t]=1;
	for(int i=1;i<=len[t];i++)
		if(dfs(e[t][i]))
			return 1;
	v[t]=0;
	return 0;
}
bool check()
{
	for(int i=1;i<=n;i++)
	{
		int cnt=0;
		for(int j=1;j<=len[i];j++)
			if(ex[i][j])
			{
				cnt++;
				if(cnt>1)
					return 0;
			}
		if(cnt==0)
			return 0;
		for(int j=1;j<=n;j++)
			v[j]=0;
		if(!dfs(i))
			return 0;
	}
	return 1;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	int u,v;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		e[u][++len[u]]=v;
		ex[u][len[u]]=1;
	}
	scanf("%d",&q);
	for(int p=1;p<=q;p++)
	{
		int t;
		scanf("%d",&t);
		if(t==1)
		{
			scanf("%d%d",&u,&v);
			for(int i=1;i<=len[u];i++)
			{
				if(e[u][i]==v)
				{
					ex[u][i]=0;
					break;
				}
			}
		}
		if(t==2)
		{
			scanf("%d",&u);
			for(int i=1;i<=n;i++)
				for(int j=1;j<=len[i];j++)
					if(e[i][j]==u)
					{
						ex[i][j]=0;
						break;
					}
		}
		if(t==3)
		{
			scanf("%d%d",&u,&v);
			for(int i=1;i<=len[u];i++)
				if(e[u][i]==v)
				{
					ex[u][i]=1;
					break;
				}
		}
		if(t==4)
		{
			scanf("%d",&u);
			for(int i=1;i<=n;i++)
				for(int j=1;j<=len[i];j++)
					if(e[i][j]==u)
					{
						ex[i][j]=1;
						break;
					}
		}
		if(check())
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}
