#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long sc[1005];
long long s[2505][2505][6];
long long dfs(int g,int t)
{
	long long ans=-2e18;
	if(t==5)
	{
		long long maxx=-2e18;
		for(int i=0;i<=k;i++)
			maxx=max(maxx,s[g][1][i]);
		return maxx;
	}
	for(int i=2;i<=n;i++)
	{
		long long maxx=-2e18;
		for(int j=0;j<=k;j++)
			maxx=max(maxx,s[g][i][j]);
		ans=max(ans,maxx+dfs(i,t+1));
	}
	return ans;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	sc[1]=0;
	for(int i=2;i<=n;i++)
		scanf("%lld",&sc[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int t=0;t<=k;t++)
				s[i][j][t]=-2e18;
	int u,v;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		s[u][v][0]=sc[v];
		s[v][u][0]=sc[u];
	}
	if(!k)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				for(int t=1;t<=n;t++)
					for(int p1=0;p1<=k;p1++)
						for(int p2=0;p2<=k;p2++)
							if(i!=j&&i!=k&&j!=k&&p1+p2+1<=k&&s[i][k][p1]+s[k][j][p2]>s[i][j][p1+p2+1])
								s[i][j][p1+p2+1]=s[i][k][p1]+s[k][j][p2];
	printf("%lld",dfs(1,1));
	return 0;
}
