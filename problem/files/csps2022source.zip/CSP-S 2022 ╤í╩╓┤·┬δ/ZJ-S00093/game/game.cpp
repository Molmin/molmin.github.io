#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q;
	int a[100005],b[100005];
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",a+i);
	for(int i=1;i<=m;i++)
		scanf("%d",b+i);
	int l1,r1,l2,r2;
	for(int p=1;p<=q;p++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		int maxx1=-2e9,minn1=2e9,mid1=2e9;
		int maxx2=-2e9,minn2=2e9,mid2=2e9;
		bool flagz1=0,flagf1=0,k1=0;
		bool flagz2=0,flagf2=0,k2=0;
		for(int i=l2;i<=r2;i++)
		{
			maxx2=max(maxx2,b[i]);
			minn2=min(minn2,b[i]);
			mid2=min(mid2,abs(b[i]));
			if(b[mid2]>0)
				k2=1;
			else
				k2=-1;
			if(b[i]>0)
				flagz2=1;
			else if(b[i]<0)
				flagf2=1;
		}
		for(int i=l1;i<=r1;i++)
		{
			maxx1=max(maxx1,a[i]);
			minn1=min(minn1,a[i]);
			mid1=min(mid1,abs(a[i]));
			if(a[mid1]>0)
				k1=1;
			else
				k1=-1;
			if(a[i]>0)
				flagz1=1;
			else if(a[i]<0)
				flagf1=1;
		}
		int u,v;
		if(flagz1==1&&flagf1==0)
			u=minn2;
		else if(flagz1==0&&flagf1==1)
			u=maxx2;
		else if(flagz1==1&&flagf1==1)
			u=mid2*k2;
		else
			u=0;
		if(flagz2==1&&flagf2==0)
			v=maxx1;
		else if(flagz2==0&&flagf2==1)
			v=minn1;
		else if(flagz2==1&&flagf2==1)
			v=mid1*k1;
		else
			v=0;
		long long ans=u;
		ans*=v;
		printf("%lld\n",ans);
	}
	return 0;
}
