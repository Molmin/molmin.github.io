#include<bits/stdc++.h>
using namespace std;
bool e[21005][21005];
int n,Q,k,pa;
int p[21005];
long long c[21005];
void dfs(int st,int f,int t)
{
	p[t]=st;
	if(st==f)
	{
		pa=t;
		return;
	}
	for(int i=1;i<=n;i++)
		if(e[st][i])
			dfs(i,f,t+1);
	return;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&Q,&k);
	int u,v;
	for(int i=1;i<=n;i++)
		scanf("%lld",c+i);
	for(int i=1;i<n;i++)
	{
		scanf("%d%d",&u,&v);
		e[u][v]=1;
	}
	for(int i=1;i<=Q;i++)
	{
		scanf("%d%d",&u,&v);
		dfs(u,v,1);
	long long sum=0;
	for(int i=1;i<=pa;i++)
		sum+=c[p[i]];
	if(k==1)
		printf("%d",sum);
	else
	{
		for(int i=1;i<=pa;i++)
			p[i]=c[p[i]];
		for(int i=3;i<=pa;i++)
			p[i]=min(p[i-1],p[i-2])+p[i];
		printf("%d",p[pa]);
	}
	}
	return 0;
}
