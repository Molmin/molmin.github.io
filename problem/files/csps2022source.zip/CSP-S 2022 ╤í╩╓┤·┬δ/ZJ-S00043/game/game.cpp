#include<bits/stdc++.h>
using namespace std;
long long a[100005][18][4],b[100005][18][4],d[4],c[4],t[1005],x,ans;
int n,m,q,l1,l2,r1,r2;
long long max(long long x,long long y){
	return x>y?x:y;
}
long long min(long long x,long long y){
	return x<y?x:y;
}
namespace stuck1{
	void solve(){
		
	}
}
int main(){
	cin>>n>>m>>q;
	if(n<=18000&&m<=1000&&q<=10000){
		stuck1::solve();
	}else{
		for(int i=0;i<=n;i++){
			cin>>t[i][0];
			a[i][0][0]=t[i];
			a[i][0][1]=t[i];
			a[i][0][2]=t[i];
			a[i][0][3]=t[i];
		}
		for(int k=1;k<=10;k++){
			for(int i=1;i<=n-(1<<k)+1;i++){
				a[i][k][0]=max(a[i][k-1][0],a[i+(1<<(k-1))][k-1][0]);
				a[i][k][1]=max(a[i][k-1][0],a[i+(1<<(k-1))][k-1][0]);
				if(a[i][k-1][2]<0||){
					a[i][k][2]=a[i+(1<<(k-1)][k-1][2];
				}else{
					if(a[i+(1<<(k-1)][k-1][2]<0) a[i][k][2]=a[i][k-1][2];
						else a[i][k][2]=min()
				}
				if(a[i][k-1][3]>0){
					a[i][k][3]=a[i+(1<<(k-1)][k-1][3];
				}else{
					if(a[i+(1<<(k-1)][k-1][3]>0){
						a[i][k][3]=b[i+(1<<(k-1)][k-1][3];
						else a[i][k][3]=max(a[i][k-1][3],a[i+(1<<(k-1)][k-1][3]);
					}
				}
			}
		}
	}
	
	return 0;
}
