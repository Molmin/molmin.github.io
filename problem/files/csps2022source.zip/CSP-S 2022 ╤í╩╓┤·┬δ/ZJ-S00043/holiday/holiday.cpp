#include<bits/stdc++.h>
using namespace std;
int f[2025][2025],x,y,n,m,T,Q,K; 
long long a[2505],ans;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>Q>>K;
	for(int i=2;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		f[x][y]=1;
		f[y][x]=1;
	}
	if(T==0){
		for(int i=2;i<=n;i++){
			if(f[1][i]==1){
				for(int j=i+1;j<=n;j++){
					if(f[1][j]==1){
						for(int k=j+1;k<=n;k++){
							if(f[j][k]==1){
								f[j][k]=a[j]=a[k];
								f[k][j]=a[k]=a[j];
							}
						}
					}
				}
			}
		}
	}					
	cout<<ans;
	else{
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(f[i][j]==0){
					
				}
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
