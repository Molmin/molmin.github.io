#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll mmax(ll x, ll y){return x>y?x:y;}
inline ll mmin(ll x, ll y){return x<y?x:y;}
inline ll read() {
    ll s=0; bool t=0; char ch=getchar();
    for (; ch<'0'||ch>'9'; ch=getchar()) if (ch=='-') t=1;
    for (; ch>='0'&&ch<='9'; ch=getchar()) s=s*10+ch-'0';
    return t?-s:s;
}
const int M=1e5+5, L=20, inf=2e9;
int taa[M*L], tai[M*L], tba[M*L], tbi[M*L], tz[M*L], tf[M*L], lo[M];
int a[M], b[M], tmp1[M], tmp2[M];
int n, m, q;
void initlog() {
    for (int i=2; i<M; i++) lo[i]=lo[i-1]+(i>=(1<<lo[i-1]+1)?1:0);
}
inline int fx(int x, int y){return x*L+y;}
void init(int *st, int *a, int fl) {
    for (int i=n; i>=1; i--) {
        st[fx(i, 0)]=a[i];
        for  (int j=1; i+(1<<j)-1<=n; j++) {
            if (fl) st[fx(i,j)]=mmax(st[fx(i,j-1)], st[fx(i+(1<<j-1),j-1)]);
            else st[fx(i,j)]=mmin(st[fx(i,j-1)], st[fx(i+(1<<j-1),j-1)]);
        }
    }
}
inline int smax(int *st, int l, int r) {
    int B=lo[r-l+1];
    return mmax(st[fx(l,B)], st[fx(r-(1<<B)+1,B)]);
}
inline int smin(int *st, int l, int r) {
    int B=lo[r-l+1];
    return mmin(st[fx(l,B)], st[fx(r-(1<<B)+1,B)]);
}
int main() {
    freopen("game.in", "r", stdin);
    freopen("game.out", "w", stdout);
    initlog();
    n=read(), m=read(), q=read();
    for (int i=1; i<=n; i++) {
        a[i]=read();
        tmp1[i]=(a[i]>=0?a[i]:inf);
        tmp2[i]=(a[i]<=0?a[i]:-inf);
    }
    for (int i=1; i<=m; i++) b[i]=read();
    init(taa, a, 1); init(tai, a, 0);
    init(tba, b, 1); init(tbi, b, 0);
    init(tz, tmp1, 0); init(tf, tmp2, 1);
    while (q--) {
        int l1=read(), r1=read(), l2=read(), r2=read();
        ll amx=smax(taa, l1, r1), amn=smin(tai, l1, r1),
           bmx=smax(tba, l2, r2), bmn=smin(tbi, l2, r2);
        if (bmn>=0) printf("%lld\n", (amx>0?bmn:bmx)*amx);
        else if (bmx<=0) printf("%lld\n", (amn>0?bmn:bmx)*amn);
        else {
            ll azmn=smin(tz, l1, r1), afmx=smax(tf, l1, r1);
            printf("%lld\n", mmax(azmn*bmn, afmx*bmx));
        }
    }
}