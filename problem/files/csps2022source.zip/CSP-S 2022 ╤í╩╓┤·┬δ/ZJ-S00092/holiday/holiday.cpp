#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll mmax(ll x, ll y){return x>y?x:y;}
inline ll read() {
    ll s=0; bool t=0; char ch=getchar();
    for (; ch<'0'||ch>'9'; ch=getchar()) if (ch=='-') t=1;
    for (; ch>='0'&&ch<='9'; ch=getchar()) s=s*10+ch-'0';
    return t?-s:s;
}
const int M=20005, N=2505;
int ed[M], he[N], ne[M], tot, dis[N][N], mx[N][3];
ll a[N];
void add(int x, int y){ed[++tot]=y; ne[tot]=he[x]; he[x]=tot;}
queue <int> q;
void bfs(int st) {
    q.push(st); dis[st][st]=0;
    while (!q.empty()) {
        int x=q.front(); q.pop();
        for (int i=he[x]; i; i=ne[i]) if (!~dis[st][ed[i]]) {
            dis[st][ed[i]]=dis[st][x]+1;
            q.push(ed[i]);
        }
    }
}

int main() {
    freopen("holiday.in", "r", stdin);
    freopen("holiday.out", "w", stdout);
    int n=read(), m=read(), k=read()+1;
    int x, y;
    for (int i=2; i<=n; i++) a[i]=read();
    for (int i=1; i<=m; i++) x=read(), y=read(), add(x, y), add(y, x);
    memset(dis, -1, sizeof(dis));
    for (int i=1; i<=n; i++) bfs(i);
    for (int i=2; i<=n; i++)
        for (int j=2; j<=n; j++) if (j!=i&&dis[i][j]<=k&&dis[1][j]<=k){
            if (a[j]>a[mx[i][0]]) {
                mx[i][2]=mx[i][1];
                mx[i][1]=mx[i][0];
                mx[i][0]=j;
            }
            else if (a[j]>a[mx[i][1]]) {
                mx[i][2]=mx[i][1];
                mx[i][1]=j;
            }
            else if (a[j]>a[mx[i][2]]) mx[i][2]=j;
        }
    ll ans=0;
    for (int b=2; b<=n; b++) 
        for (int c=b+1; c<=n; c++) if (dis[b][c]<=k)
            for (int i=0; i<=2; i++)
                for (int j=0; j<=2; j++) if (mx[b][i]&&mx[c][i]&&mx[b][i]!=mx[c][j]&&mx[b][i]!=c&&mx[c][j]!=b)
                    ans=mmax(ans, a[b]+a[c]+a[mx[b][i]]+a[mx[c][j]]);            
    // for (int i=1; i<=n; i++) printf("%d %d %d\n", mx[i][0], mx[i][1], mx[i][2]);
    // for (int i=1; i<=n; i++)
    //     for (int j=1; j<=n; j++) printf("dis(%d,%d)=%d\n", i, j, dis[i][j]);
    printf("%lld", ans);
}