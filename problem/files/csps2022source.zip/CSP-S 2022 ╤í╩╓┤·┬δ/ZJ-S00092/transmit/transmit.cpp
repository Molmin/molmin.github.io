#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll mmax(ll x, ll y){return x>y?x:y;}
inline ll mmin(ll x, ll y){return x<y?x:y;}
inline ll read() {
    ll s=0; bool t=0; char ch=getchar();
    for (; ch<'0'||ch>'9'; ch=getchar()) if (ch=='-') t=1;
    for (; ch>='0'&&ch<='9'; ch=getchar()) s=s*10+ch-'0';
    return t?-s:s;
}
const int N=2e5+5, M=4e5+5, L=20;
int ed[M], he[N], ne[M], tot, n, d[N], fa[N][L], a[N];
ll sum[N];
void add(int x, int y){ed[++tot]=y; ne[tot]=he[x]; he[x]=tot;}
void init(int rt, int f, int D) {
    fa[rt][0]=f; d[rt]=D; sum[rt]=sum[f]+a[rt];
    for (int i=1; i<L; i++) fa[rt][i]=fa[fa[rt][i-1]][i-1];
    for (int i=he[rt]; i; i=ne[i]) if (ed[i]!=f)
        init(ed[i], rt, D+1);
}
int lca(int x, int y) {
    if (d[x]<d[y]) swap(x, y);
    for (int i=L-1; ~i; i--) if (d[fa[x][i]]>=d[y]) x=fa[x][i];
    if (x==y) return x;
    for (int i=L-1; ~i; i--) if (fa[x][i]!=fa[y][i]) x=fa[x][i], y=fa[y][i];
    return fa[x][0];
}
int main() {
    freopen("transmit.in", "r", stdin);
    freopen("transmit.out", "w", stdout);
    n=read(); int q=read(), k=read(), x, y;
    for (int i=1; i<=n; i++) a[i]=read();
    for (int i=1; i<n; i++) x=read(), y=read(), add(x, y), add(y, x);
    init(1, 0, 1);
        
    while (q--) {
        x=read(), y=read(); int l=lca(x, y);
        printf("%lld\n", sum[x]+sum[y]-2*sum[l]+a[l]);
    }
}