#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll mmax(ll x, ll y){return x>y?x:y;}
inline ll mmin(ll x, ll y){return x<y?x:y;}
inline ll read() {
    ll s=0; bool t=0; char ch=getchar();
    for (; ch<'0'||ch>'9'; ch=getchar()) if (ch=='-') t=1;
    for (; ch>='0'&&ch<='9'; ch=getchar()) s=s*10+ch-'0';
    return t?-s:s;
}
const int N=1e3+5, M=1e4+5;
int ed[M], he[N], ne[M], tot, n, m;
bool ban[N][N];
void add(int x, int y){ed[++tot]=y; ne[tot]=he[x]; he[x]=tot;}
void solve1() {
    int x, y;
    for (int i=1; i<=m; i++) x=read(), y=read(), add(x, y);
    for (int q=read(); q; q--) {
        int fl=read();
        if (fl==1) x=read(), y=read(), ban[x][y]=1;
        if (fl==2) {
            x=read();
            for (int i=1; i<=n; i++)
                for (int j=he[i]; j; j=ne[j]) if (ed[j]==x) ban[i][x]=1;
        }
        if (fl==3) x=read(), y=read(), ban[x][y]=0;
        if (fl==4) {
            x=read();
            for (int i=1; i<=n; i++)
                for (int j=he[i]; j; j=ne[j]) if (ed[j]==x) ban[i][x]=0;
        }
        bool ok=1;
        for (int i=1; i<=n; i++) {
            int cnt=0;
            for (int j=he[i]; j; j=ne[j]) if (!ban[i][ed[j]]) cnt++;
            if (cnt!=1) ok=0;
            // printf("%d %d\n", i, cnt);
        }
        if (ok) printf("YES\n");
        else printf("NO\n");
    }
}
int cnt[500005];
void solve2() {
    int x, y, ans=0;
    for (int i=1; i<=m; i++) x=read(), y=read(), cnt[x]++;
    for (int i=1; i<=n; i++) ans+=(cnt[x]!=1);
    for (int q=read(); q; q--) {
        int fl=read(), x=read(), y=read();
        if (cnt[x]==1) ans++;
        if (fl==1) cnt[x]--;
        else cnt[x]++;
        if (cnt[x]==1) ans--;
        if (ans==0) printf("YES\n");
        else printf("NO\n");
    }
}
int main() {
    freopen("galaxy.in", "r", stdin);
    freopen("galaxy.out", "w", stdout);
    n=read(), m=read(); int x, y;
    if (n<=1000) solve1();
    else solve2();
}