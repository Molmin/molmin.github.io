#include <bits/stdc++.h>
#define rep(i,j,k) for(int i = (j);i <= (k);i++)
#define per(i,j,k) for(int i = (j);i >= (k);i--)
#define ll long long
#define pii pair <int,int>
#define pll pair <ll,ll>
#define mkp make_pair
#define eb emplace_back
#define ull unsigned long long
#define inf 0x3f3f3f3f
#define linf 0x3f3f3f3f3f3f3f3f
using namespace std;

void chkmin(int &x,int y){
	if(x > y) x = y;
}

void chkmax(int &x,int y){
	if(x < y) x = y;
}

void chkmin(ll &x,ll y){
	if(x > y) x = y;
}

void chkmax(ll &x,ll y){
	if(x < y) x = y;
}

bool _st;

int n,q,k;
ll A[200005],S[200005];

int cnt;
int head[200005];
struct eg{
	int to,nxt;
}edge[400005];

void make(int u,int v){
	edge[++cnt].to = v;
	edge[cnt].nxt = head[u];
	head[u] = cnt;
}

struct info{
	ll v[2][2];
	info(){v[0][0] = v[0][1] = v[1][0] = v[1][1] = -linf;}
	void rst(){
		v[0][0] = v[0][1] = v[1][0] = v[1][1] = -linf;
	}
};

info operator + (info a,info b){
	info c;
	//dep[a] > dep[b]
	rep(i,0,1){
		rep(j,0,1){
			chkmax(c.v[i][j],a.v[i][0] + max(b.v[0][j],b.v[1][j]));
			chkmax(c.v[i][j],a.v[i][1] + b.v[0][j]);
		}
	}
	return c;
}

int to[20][200005],dep[200005];
info dp[20][200005];

ll sum[200005];

void dfs1(int u,int f){
	dep[u] = dep[f] + 1;
	sum[u] = sum[f] + A[u];
	S[u] = A[u];
	if(f) chkmin(S[u],A[f]);
	to[0][u] = f;
	for(int i = head[u];i;i = edge[i].nxt){
		int v = edge[i].to;
		if(v == f) continue;
		dfs1(v,u);
		chkmin(S[u],A[v]);
	}
}

int LCA(int u,int v){
	if(dep[u] < dep[v]) swap(u,v);
	per(i,17,0) if(dep[to[i][u]] >= dep[v]) u = to[i][u];
	if(u == v) return u;
	
	per(i,17,0){
		if(to[i][u] != to[i][v]){
			u = to[i][u];
			v = to[i][v];
		}	
	} 
	return to[0][u];
}

void print(info t){
	printf("[0,0] %lld [0,1] %lld [1,0] %lld [1,1] %lld\n",t.v[0][0],t.v[0][1],t.v[1][0],t.v[1][1]);
}

ll solve(int u,int v,int d){
	info pre,suf,tmp;
	int tu = 0,tv = 0;
	
	if(dep[u] < dep[v]) swap(u,v);
	
	//rintf("query :%d %d %d\n",u,v,d);
	per(i,17,0){
		if(dep[to[i][u]] < dep[v]) continue;
		if(tu) pre = pre + dp[i][u];
		else pre = dp[i][u];
		tu = 1;
		u = to[i][u];
	}
	//print(pre);
	if(u == v){
		tmp.rst();
		tmp.v[0][0] = 0;
		tmp.v[1][1] = A[v];
		tmp = pre + tmp;
		return tmp.v[0][0];
	}
	
	per(i,17,0){
		if(to[i][u] == to[i][v]) continue;
		if(tu) pre = pre + dp[i][u];
		else pre = dp[i][u];
		u = to[i][u];
		
		tmp = dp[i][v];
		swap(tmp.v[0][1],tmp.v[1][0]);
		if(tv) suf = tmp + suf;
		else suf = tmp;
		
		v = to[i][v];	
		
		tu = tv = 1;
	}
	if(tu) pre = pre + dp[0][u];
	else pre = dp[0][u];
	
	tmp = dp[0][v];
	swap(tmp.v[0][1],tmp.v[1][0]);
	
	if(tv) suf = tmp + suf;
	else suf = tmp;
	
	tmp.rst();
	tmp.v[0][0] = 0;tmp.v[1][1] = A[d];
	tmp = pre + tmp + suf;
	return tmp.v[0][0];
}

struct M{
	ll v[3][3];
}tmp,ze,st;

M operator *(M a,M b){
	M c;
	rep(i,0,2){
		rep(j,0,2){
			c.v[i][j] = linf;
			rep(K,0,2) chkmin(c.v[i][j],a.v[i][K] + b.v[K][j]);
		}
	}
	return c;
}
M up[20][200005],dwn[20][200005];

bool _ed;

void spsolve(){
	//rep(u,1,n) printf("%d ",S[u]);
	
	
	rep(u,1,n){
		tmp.v[0][1] = tmp.v[1][2] = 0;
		tmp.v[0][0] = tmp.v[1][0] = tmp.v[2][0] = A[u];
		tmp.v[1][1] = S[u];
		tmp.v[0][2] = tmp.v[2][2] = tmp.v[2][1] = linf;
		up[0][u] = dwn[0][u] = tmp;
	}
	
	//tmp = st * up[0][2] * up[0][1] * up[0][3] * up[0][7];
	//printf("%lld\n",tmp.v[0][0]);
//	return;
	rep(i,1,17){
		rep(j,1,n){
			up[i][j] = up[i - 1][j] * up[i - 1][to[i - 1][j]];
			dwn[i][j] = dwn[i - 1][to[i - 1][j]] * dwn[i - 1][j];
		}
	}
	int u,v;
	
	rep(i,0,2){
		rep(j,0,2){
			if(i == j) ze.v[i][j] = 0;
			else ze.v[i][j] = linf;
		}
	}
	
	M pre,suf;
	int op;//direcation
	rep(_i,1,q){
		scanf("%d%d",&u,&v);
		if(dep[u] > dep[v]){
			st.v[0][0] = A[u];
			u = to[0][u];
			st.v[0][1] = st.v[0][2] = linf;
			op = 0;
		}else{
			st.v[0][0] = A[v];
			v = to[0][v];
			st.v[0][1] = st.v[0][2] = linf;
			op = 1;
		}
		if(dep[u] < dep[v]){
			op ^= 1;
			swap(u,v);
		}
		//printf("%d %d %d\n",u,v,op);
		pre = suf = ze;
		
		if(op == 0){
			per(i,17,0){
				if(dep[to[i][u]] < dep[v]) continue;
				pre = pre * up[i][u];
				u = to[i][u];
			}
			if(u == v){
				tmp = st * pre * up[0][u];
				printf("%lld\n",tmp.v[0][0]);
				continue;		
			}
			per(i,17,0){
				if(to[i][u] == to[i][v]) continue;
				pre = pre * up[i][u];
				u = to[i][u];
				suf = dwn[i][v] * suf;
				v = to[i][v];
			}
			pre = pre * up[0][u];
			suf = dwn[0][v] * suf;
			tmp = st * pre * up[0][to[0][u]] * suf;
			printf("%lld\n",tmp.v[0][0]);
		}else{
			per(i,17,0){
				if(dep[to[i][u]] < dep[v]) continue;
				pre = dwn[i][u] * pre;
				u = to[i][u];
			}
			if(u == v){
				tmp = st * up[0][u] * pre;
				printf("%lld\n",tmp.v[0][0]);
				continue;		
			}
			per(i,17,0){
				if(to[i][u] == to[i][v]) continue;
				pre = dwn[i][u] * pre;
				u = to[i][u];
				suf = suf * up[i][v];
				v = to[i][v];
			}
			pre = dwn[0][u] * pre;
			suf = suf * up[0][v];
			tmp = st * suf * up[0][to[0][u]] * pre;
			printf("%lld\n",tmp.v[0][0]);			
		}
	}
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cerr << (&_ed - &_st) / 1048576.0 << endl;
	scanf("%d%d%d",&n,&q,&k);
	rep(i,1,n) scanf("%lld",&A[i]);
	rep(i,1,n - 1){
		int u,v;
		scanf("%d%d",&u,&v);
		make(u,v);make(v,u);
	}
	dfs1(1,0);
	rep(i,1,n){
		dp[0][i].v[1][1] = A[i];
		dp[0][i].v[0][0] = 0;
	}
	rep(i,1,18){
		rep(j,1,n){
			to[i][j] = to[i - 1][to[i - 1][j]];
			dp[i][j] = dp[i - 1][j] + dp[i - 1][to[i - 1][j]];
			/*if(to[i][j]){
				info t = dp[i][j];		
				//printf("dp %d %d\n",i,j);
				//print(dp[i][j]);	
			}*/
		}
	}
	if(k == 3){
		spsolve();
		return 0;
	}
	int s,t,d;
	ll ssum;
	rep(i,1,q){
		scanf("%d%d",&s,&t);
		d = LCA(s,t);
		ssum = sum[s] + sum[t] - 2 * sum[d] + A[d];
		if(k == 1){
			printf("%lld\n",ssum);
			continue;
		}
		printf("%lld\n",ssum - solve(s,t,d));
	}
	return 0;
}
