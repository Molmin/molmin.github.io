#include <bits/stdc++.h>
#define rep(i,j,k) for(int i = (j);i <= (k);i++)
#define per(i,j,k) for(int i = (j);i >= (k);i--)
#define ll long long
#define mkp make_pair
#define eb emplace_back
#define ull unsigned long long
#define inf 0x3f3f3f3f
using namespace std;

void chkmin(int &x,int y){
	if(x > y) x = y;
}

void chkmax(int &x,int y){
	if(x < y) x = y;
}

void chkmin(ll &x,ll y){
	if(x > y) x = y;
}

void chkmax(ll &x,ll y){
	if(x < y) x = y;
}

bool st;

int n,m,q;
int a[100005],b[100005];

struct RMQ{
	int N,ST[20][100005],op;//op = 0 min,op = 1 max
	
	int chk(int x,int y){
		if(!op) return min(x,y);
		else return max(x,y);
	}
	void init(){
		rep(i,1,17){
			rep(j,1,N){
				if(j + (1 << i) - 1 > n) break;
				ST[i][j] = chk(ST[i - 1][j],ST[i - 1][j + (1 << (i - 1))]);
			}
		}
	}
	int qry(int l,int r){
		int x = __lg(r - l + 1);
		return chk(ST[x][l],ST[x][r - (1 << x) + 1]);
	}
}bMn,bMx,pMn,pMx,nMn,nMx;

bool ed;

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	rep(i,1,n) scanf("%d",&a[i]);
	rep(i,1,m) scanf("%d",&b[i]);
	//printf("!!!");
	bMn.N = bMx.N = m;
	pMn.N = pMx.N = nMn.N = nMx.N = n;
	bMn.op = pMn.op = nMn.op = 0;
	bMx.op = pMx.op = nMx.op = 1;
	rep(i,1,n){
		pMn.ST[0][i] = inf;
		pMx.ST[0][i] = -inf;
		nMn.ST[0][i] = inf;
		nMx.ST[0][i] = -inf;
		if(a[i] >= 0){
			pMn.ST[0][i] = pMx.ST[0][i] = a[i];
		}
		if(a[i] <= 0){
			nMn.ST[0][i] = nMx.ST[0][i] = a[i];
		}
	}
	rep(i,1,m){
		bMn.ST[0][i] = bMx.ST[0][i] = b[i];
	}
	bMn.init();bMx.init();
	pMn.init();pMx.init();
	nMn.init();nMx.init();
	int l1,r1,l2,r2;
	ll x,y,ans,tmp;
	rep(i,1,q){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ans = -1145141919810114514;
		x = bMn.qry(l2,r2);
		y = bMx.qry(l2,r2);
		tmp = pMn.qry(l1,r1);
		if(abs(tmp) != inf) chkmax(ans,min(x * tmp,y * tmp));
		tmp = pMx.qry(l1,r1);
		if(abs(tmp) != inf) chkmax(ans,min(x * tmp,y * tmp));
		tmp = nMn.qry(l1,r1);
		if(abs(tmp) != inf) chkmax(ans,min(x * tmp,y * tmp));
		tmp = nMx.qry(l1,r1);
		if(abs(tmp) != inf) chkmax(ans,min(x * tmp,y * tmp));
		printf("%lld\n",ans);
	}
	cerr << (&ed - &st) / 1048576.0 << endl;
	return 0;
}
