#include <bits/stdc++.h>
#define rep(i,j,k) for(int i = (j);i <= (k);i++)
#define per(i,j,k) for(int i = (j);i >= (k);i--)
#define ll long long
#define pii pair <int,int>
#define pll pair <ll,ll>
#define mkp make_pair
#define eb emplace_back
#define ull unsigned long long
#define inf 0x3f3f3f3f
#define linf 0x3f3f3f3f3f3f3f3f
using namespace std;

void chkmin(int &x,int y){
	if(x > y) x = y;
}

void chkmax(int &x,int y){
	if(x < y) x = y;
}

void chkmin(ll &x,ll y){
	if(x > y) x = y;
}

void chkmax(ll &x,ll y){
	if(x < y) x = y;
}
int n,m,q;
int _u[500005],_v[500005];
pii val[500005];

int deg[500005];

pii P[500005];

int ans;

int res[500005];

int calc(){
	rep(i,1,n) res[i] = 0;
	rep(i,1,m) res[_u[i]] += max(P[_v[i]],val[i]).second;
	
	rep(i,1,n) if(res[i] != 1) return 0;
	return 1;	
}
map <int,int> M[500005];

int rk[500005];

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans = m;
	rep(i,1,m){
		scanf("%d%d",&_u[i],&_v[i]);
		M[_u[i]][_v[i]] = i;
		deg[_v[i]]++;
		val[i] = mkp(0,1);
	}
	rep(i,1,n) P[i] = mkp(0,1);
	
	scanf("%d",&q);
	int op,u,v,id;
	rep(i,1,q){
		scanf("%d",&op);
		if(op == 1 || op == 3){
			scanf("%d%d",&u,&v);
			id = M[u][v];
		}else{
			scanf("%d",&u);
		}
		if(op == 1){
			val[id] = mkp(i,0);
			ans--;
			if(P[v].second == 0){
				rk[v]--;
			}else{
				rk[v]++;
			}
		}else if(op == 2){
			if(P[u].second == 1){
				ans += rk[u];
				rk[u] = 0;
				ans -= deg[u];
			}else{
				ans -= rk[u];
				rk[u] = 0;
			}
			P[u] = mkp(i,0);
		}else if(op == 3){
			val[id] = mkp(i,1);
			ans++;
			if(P[v].second == 1){
				rk[v]--;
			}else{
				rk[v]++;
			}	
		}else{
			if(P[u].second == 0){
				ans -= rk[u];
				rk[u] = 0;
				ans += deg[u];
			}else{
				ans += rk[u];
				rk[u] = 0;
			}			
			P[u] = mkp(i,1);
		}
		if(ans != n){
			printf("NO\n");
			continue;
		}
		if(calc()) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
