#include <bits/stdc++.h>
#define rep(i,j,k) for(int i = (j);i <= (k);i++)
#define per(i,j,k) for(int i = (j);i >= (k);i--)
#define ll long long
#define pii pair <int,int>
#define pll pair <ll,ll>
#define mkp make_pair
#define eb emplace_back
#define ull unsigned long long
#define inf 0x3f3f3f3f
#define linf 0x3f3f3f3f3f3f3f3f
using namespace std;

void chkmin(int &x,int y){
	if(x > y) x = y;
}

void chkmax(int &x,int y){
	if(x < y) x = y;
}

void chkmin(ll &x,ll y){
	if(x > y) x = y;
}

void chkmax(ll &x,ll y){
	if(x < y) x = y;
}
int n,m,k;
ll a[2505];

int cnt;
int head[2505];
struct eg{
	int to,nxt;
}edge[20005];

void make(int u,int v){
	edge[++cnt].to = v;
	edge[cnt].nxt = head[u];
	head[u] = cnt;
}
int dis[2505][2505];

queue <int> Q;

void bfs(int s){
	dis[s][s] = 0;
	Q.push(s);
	while(!Q.empty()){
		int u = Q.front();
		Q.pop();
		for(int i = head[u];i;i = edge[i].nxt){
			int v = edge[i].to;
			if(dis[s][v] > dis[s][u]){
				dis[s][v] = dis[s][u] + 1;
				Q.push(v);
			}
		}
	}
}

pii S[2505][2505];

ll ans = -linf;

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	k++;
	rep(i,2,n) scanf("%lld",&a[i]);
	rep(i,1,m){
		int u,v;
		scanf("%d%d",&u,&v);
		make(u,v);make(v,u);
	}
	memset(dis,0x3f,sizeof(dis));
	rep(u,1,n) bfs(u);
	
	/*rep(u,1,n){
		rep(v,u,n){
			printf("%d %d %d\n",u,v,dis[u][v]);
		}
	}*/
	cerr << clock() << endl;
	
	rep(u,2,n){
		rep(v,2,n){
			if(v != u && dis[u][v] <= k && dis[1][v] <= k) S[u][v] = mkp(-a[v],v);
			else S[u][v] = mkp(inf,v);
			//printf("(%d,%d) %d\n",u,v,S[u][v].first);
		}
		nth_element(S[u] + 2,S[u] + 4,S[u] + n + 1);
		sort(S[u] + 2,S[u] + 4);
		//sort(S[u] + 2,S[u] + 4,S[u] + n + 1);
	}
	cerr << clock() << endl;
	
	ll tmp;
	rep(u,2,n){
		rep(v,u + 1,n){
			if(dis[u][v] > k) continue;
			rep(i,2,4){
				if(S[u][i].second == v) continue;
				if(S[u][i].first > 0) break;
				
				rep(j,2,4){
					if(S[v][j].second == u) continue;
					if(S[v][j].first > 0) break;
					
					if(S[u][i].second == S[v][j].second) continue;
					tmp = a[u] + a[S[u][i].second] + a[v] + a[S[v][j].second];
					//if(ans < tmp) printf("check result %d %d %d %d\n",S[u][i].second,u,v,S[v][j].second);
					chkmax(ans,tmp);	
				}
			}
		}
	}
	cerr << clock() << endl;
	printf("%lld\n",ans);
	return 0;
}
