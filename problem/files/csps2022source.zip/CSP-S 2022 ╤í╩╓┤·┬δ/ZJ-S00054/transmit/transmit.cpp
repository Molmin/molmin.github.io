#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define For(i, j, k) for ( int i = (j) ; i <= (k) ; i++ )
#define Fol(i, j, k) for ( int i = (j) ; i >= (k) ; i-- )
inline void read(int &x)
{
	char c = getchar(); for ( ; c < '0' || c > '9' ; c = getchar() );
	for ( x = 0 ; c >= '0' && c <= '9' ; c = getchar() ) x = x * 10 + c - '0';
}
int n, q, k, a[200009], u, v;
vector < int > g[200009];
namespace k1
{
	int w[19][200009], fa[19][200009], h[200009];
	inline void dfs(int u, int v, int d)
	{
		fa[0][u] = v, h[u] = d;
		for ( int i : g[u] ) if ( i != v ) dfs(i, u, d + 1);
	}
	inline ll lca(int x, int y)
	{
		ll ret = 0;
		if ( h[x] > h[y] ) swap(x, y);
		Fol(i, 18, 0) if ( h[fa[i][y]] >= h[x] )
			ret += w[i][y], y = fa[i][y];
		if ( x == y ) return ret;
		For(i, 18, 0) if ( fa[i][x] != fa[i][y] )
			ret += w[i][x] + w[i][y], x = fa[i][x], y = fa[i][y];
		return ret + w[1][x] + w[0][y];
	}
	inline void work()
	{
		dfs(1, 0, 1); For(i, 1, n) w[0][i] = a[i];
		For(i, 1, 18) For(j, 1, n)
			fa[i][j] = fa[i - 1][fa[i - 1][j]],
			w[i][j] = w[i - 1][j] + w[i - 1][fa[i - 1][j]];
		For(qq, 1, q) read(u), read(v), printf("%lld\n", lca(u, v));
	}
}
namespace bf
{
	ll d[200009]; vector < int > gg[200009]; bool used[200009];
	priority_queue < pair < ll, int > > pq;
	inline void dfs(int u, int fa, int v, int id)
	{
		if ( v ) gg[id].push_back(u);
		if ( v == k ) return;
		for ( int i : g[u] ) dfs(i, u, v + 1, id);
	}
	inline ll dij()
	{
		For(i, 1, n) d[i] = LLONG_MAX / 2, used[i] = false;
		for ( pq.emplace(d[u] = a[u], u) ; pq.size() ; )
		{
			u = pq.top().second, pq.pop();
			if ( used[u] ) continue; used[u] = true;
			for ( int i : gg[u] ) if ( d[i] > d[u] + a[i] )
				d[i] = d[u] + a[i], pq.emplace(-d[i], i);
		}
		return d[v];
	}
	inline void work()
	{
		For(i, 1, n)
			dfs(i, 0, 0, i), sort(gg[i].begin(), gg[i].end()),
			gg[i].erase(unique(gg[i].begin(), gg[i].end()), gg[i].end());
		For(qq, 1, q) read(u), read(v), printf("%lld\n", dij());
	}
}
int main()
{
	freopen("transmit.in", "r", stdin), freopen("transmit.out", "w", stdout);
	read(n), read(q), read(k); For(i, 1, n) read(a[i]);
	For(i, 2, n) read(u), read(v), g[u].push_back(v), g[v].push_back(u);
	if ( k == 1 ) k1::work(); else bf::work();
	return 0;
}