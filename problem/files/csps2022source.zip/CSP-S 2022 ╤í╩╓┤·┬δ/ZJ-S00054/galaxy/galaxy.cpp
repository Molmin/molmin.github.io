#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define For(i, j, k) for ( int i = (j) ; i <= (k) ; i++ )
#define Fol(i, j, k) for ( int i = (j) ; i >= (k) ; i-- )
inline void read(int &x)
{
	char c = getchar(); for ( ; c < '0' || c > '9' ; c = getchar() );
	for ( x = 0 ; c >= '0' && c <= '9' ; c = getchar() ) x = x * 10 + c - '0';
}
int n, m, q, op, u, v, c[500009]; set < int > g[500009], f[500009], ans;
int main()
{
	freopen("galaxy.in", "r", stdin), freopen("galaxy.out", "w", stdout);
	read(n), read(m);
	For(i, 1, m) read(u), read(v), g[v].insert(u), c[u]++;
	For(i, 1, n) if ( c[i] == 1 ) ans.insert(i);
	read(q); For(qq, 1, q)
	{
		read(op), read(u);
		if ( op == 1 )
		{
			read(v), g[v].erase(u), f[v].insert(u), c[u]--;
			if ( !c[u] ) ans.erase(u);
			else if ( c[u] == 1 ) ans.insert(u);
		}
		else if ( op == 3 )
		{
			read(v), g[v].insert(u), f[v].erase(u), c[u]++;
			if ( c[u] > 1 ) ans.erase(u);
			else if ( c[u] == 1 ) ans.insert(u);
		}
		else if ( op == 2 )
		{
			for ( int i : g[u] )
			{
				f[u].insert(i), c[i]--;
				if ( !c[i] ) ans.erase(i);
				else if ( c[i] == 1 ) ans.insert(i);
			}
			g[u].clear();
		}
		else
		{
			for ( int i : f[u] )
			{
				g[u].insert(i), c[i]++;
				if ( c[i] > 1 ) ans.erase(i);
				else if ( c[i] == 1 ) ans.insert(i);
			}
			f[u].clear();
		}
		puts(ans.size() == n ? "YES" : "NO");
	}
	return 0;
}