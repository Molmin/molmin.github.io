#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define For(i, j, k) for ( int i = (j) ; i <= (k) ; i++ )
#define Fol(i, j, k) for ( int i = (j) ; i >= (k) ; i-- )
inline void read(int &x)
{
	char c = getchar(); for ( ; c < '0' || c > '9' ; c = getchar() );
	for ( x = 0 ; c >= '0' && c <= '9' ; c = getchar() ) x = x * 10 + c - '0';
}
inline void read(ll &x)
{
	char c = getchar(); for ( ; c < '0' || c > '9' ; c = getchar() );
	for ( x = 0 ; c >= '0' && c <= '9' ; c = getchar() ) x = x * 10 + c - '0';
}
int n, m, k, d[2509][2509], u, v, p1, p2, pp1, pp2; queue < int > q;
vector < int > g[2509]; bool f[2509][2509];
pair < ll, int > ans[2509][9], p; ll s[2509], sum, w, tmp;
inline void bfs(int x)
{
	while ( q.size() ) q.pop();
	q.push(x), d[x][x] = 0;
	while ( q.size() )
	{
		u = q.front(), q.pop(), f[x][u] = true;
		if ( d[x][u] == k ) continue;
		for ( int i : g[u] ) if ( d[x][i] > d[x][u] + 1 )
			d[x][i] = d[x][u] + 1, q.push(i);
	}
}
int main()
{
	freopen("holiday.in", "r", stdin), freopen("holiday.out", "w", stdout);
	read(n), read(m), read(k), k++, memset(d, 0x3f, sizeof(d));
	For(i, 2, n) read(s[i]);
	For(i, 1, m) read(u), read(v), g[u].push_back(v), g[v].push_back(u);
	For(i, 1, n) bfs(i);
	For(i, 2, n) For(j, 2, n) if ( i != j && f[1][j] && f[j][i] )
	{
		p = make_pair(s[j], j);
		For(ii, 0, 3) if ( p.first > ans[i][ii].first )
			swap(p, ans[i][ii]);
	}
	For(i, 2, n) For(j, 2, n) if ( i != j && f[i][j] )
	{
		sum = s[i] + s[j], p1 = p2 = 0;
		while ( ans[i][p1].second == i || ans[i][p1].second == j ) p1++;
		while ( ans[j][p2].second == i || ans[j][p2].second == j ) p2++;
		if ( !ans[i][p1].second || !ans[j][p2].second ) continue;
		if ( ans[i][p1].second == ans[j][p2].second )
		{
			tmp = 0, pp1 = p1 + 1, pp2 = p2 + 1;
			while ( ans[i][pp1].second == i || ans[i][pp1].second == j ) pp1++;
			while ( ans[j][pp2].second == i || ans[j][pp2].second == j ) pp2++;
			if ( ans[i][pp1].second )
				tmp = max(tmp, ans[i][pp1].first + ans[j][p2].first);
			if ( ans[j][pp2].second )
				tmp = max(tmp, ans[i][p1].first + ans[j][pp2].first);
			if ( !tmp ) continue;
			sum += tmp;
		}
		else sum += ans[i][p1].first + ans[j][p2].first;
	w = max(w, sum);
	}
	return printf("%lld\n", w), 0;
}