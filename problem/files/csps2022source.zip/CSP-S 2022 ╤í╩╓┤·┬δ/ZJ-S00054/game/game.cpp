#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define For(i, j, k) for ( int i = (j) ; i <= (k) ; i++ )
#define Fol(i, j, k) for ( int i = (j) ; i >= (k) ; i-- )
inline void read(int &x)
{
	char c = getchar(); bool flag = false;
	for ( ; c < '0' || c > '9' ; c = getchar() ) flag |= c == '-';
	for ( x = 0 ; c >= '0' && c <= '9' ; c = getchar() ) x = x * 10 + c - '0';
	flag && ( x = -x );
}
int n, m, q, l1, l2, r1, r2, lg[100009], a[100009], b[100009];
ll ans;
struct ST
{
	int max1[19][100009], max2[19][100009], min1[19][100009], min2[19][100009];
	bool fl[19][100009];
	inline void build(int *x, int l)
	{
		For(i, 1, l)
			max1[0][i] = max2[0][i] = INT_MIN,
			min1[0][i] = min2[0][i] = INT_MAX, fl[0][i] = false;
		For(i, 1, l)
		{
			if ( x[i] > 0 ) max1[0][i] = min1[0][i] = x[i];
			if ( x[i] < 0 ) max2[0][i] = min2[0][i] = x[i];
			if ( !x[i] ) fl[0][i] = true;
		}
		For(i, 1, lg[l]) For(j, 1, l + 1 - ( 1 << i ))
			max1[i][j] = max(max1[i - 1][j], max1[i - 1][j + ( 1 << ( i - 1 ) )]),
			max2[i][j] = max(max2[i - 1][j], max2[i - 1][j + ( 1 << ( i - 1 ) )]),
			min1[i][j] = min(min1[i - 1][j], min1[i - 1][j + ( 1 << ( i - 1 ) )]),
			min2[i][j] = min(min2[i - 1][j], min2[i - 1][j + ( 1 << ( i - 1 ) )]),
			fl[i][j] = fl[i - 1][j] || fl[i - 1][j + ( 1 << ( i - 1 ) )];
	}
	inline int querymax1(int l, int r)
	{
		int t = lg[r + 1 - l];
		return max(max1[t][l], max1[t][r + 1 - ( 1 << t )]);
	}
	inline int querymax2(int l, int r)
	{
		int t = lg[r + 1 - l];
		return max(max2[t][l], max2[t][r + 1 - ( 1 << t )]);
	}
	inline int querymin1(int l, int r)
	{
		int t = lg[r + 1 - l];
		return min(min1[t][l], min1[t][r + 1 - ( 1 << t )]);
	}
	inline int querymin2(int l, int r)
	{
		int t = lg[r + 1 - l];
		return min(min2[t][l], min2[t][r + 1 - ( 1 << t )]);
	}
	inline int queryfl(int l, int r)
	{
		int t = lg[r + 1 - l];
		return fl[t][l] || fl[t][r + 1 - ( 1 << t )];
	}
}	st1, st2;
int main()
{
	freopen("game.in", "r", stdin), freopen("game.out", "w", stdout);
	read(n), read(m), read(q);
	For(i, 2, max(n, m)) lg[i] = lg[i >> 1] + 1;
	For(i, 1, n) read(a[i]); For(i, 1, m) read(b[i]);
	st1.build(a, n), st2.build(b, m);
	For(i, 1, q)
	{
		read(l1), read(r1), read(l2), read(r2), ans = LLONG_MIN;
		if ( st1.queryfl(l1, r1) ) ans = max(ans, 0ll);
		if ( st1.querymin1(l1, r1) != INT_MAX )
		{
			if ( st2.querymax2(l2, r2) != INT_MIN )
				ans = max(ans, (ll)st1.querymin1(l1, r1) * st2.querymin2(l2, r2));
			else if ( st2.queryfl(l2, r2) ) ans = max(ans, 0ll);
			else ans = max(ans, (ll)st1.querymax1(l1, r1) * st2.querymin1(l2, r2));
		}
		if ( st1.querymax2(l1, r1) != INT_MIN )
		{
			if ( st2.querymin1(l2, r2) != INT_MAX )
				ans = max(ans, (ll)st1.querymax2(l1, r1) * st2.querymax1(l2, r2));
			else if ( st2.queryfl(l2, r2) ) ans = max(ans, 0ll);
			else ans = max(ans, (ll)st1.querymin2(l1, r1) * st2.querymax2(l2, r2));
		}
		printf("%lld\n", ans);
	}
	return 0;
}