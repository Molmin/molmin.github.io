#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x;
}
int n,Q,k,tot;
int b[50010];
ll a[50010],f[50010];
vector<int> edge[50010];
int l,r;
bool vis[50010],flag;
inline void dfs(int x){
	vis[x]=1;
	for(int i=0;i<edge[x].size();i++)
		if(vis[edge[x][i]]==0){
			vis[edge[x][i]]=1;b[++tot]=edge[x][i];
			if(edge[x][i]==r){flag=1;return;}
			dfs(edge[x][i]);
			if(flag==1)return;
			vis[edge[x][i]]=0;
			tot--;
		}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read();Q=read();k=read();
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	int x,y;
	for(int i=1;i<n;i++){
		x=read();y=read();
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	while(Q--){
		memset(vis,0,sizeof(vis));
		memset(f,0x3f,sizeof(f));
		l=read();r=read();
		flag=0;tot=1;b[tot]=l;dfs(l);
		f[1]=a[l]; 
		for(int i=2;i<=tot;i++)
			for(int j=i-k>0?i-k:1;j<i;j++)
				f[i]=min(f[i],f[j]+a[b[i]]);
		printf("%lld\n",f[tot]);
	}
	return 0;
}
