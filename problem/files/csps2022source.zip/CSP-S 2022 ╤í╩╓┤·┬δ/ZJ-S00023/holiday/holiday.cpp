#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline int read(){
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x;
}
int n,m,k,num=1,b[3010];
ll a[3010],ans;
ll f[3010][5];
bool vis[10010];
vector<int> edge[10010];
inline void dfs(int x,int tot,ll sum){
	int y;
	if(tot>=5)return ;
	for(int i=0;i<edge[x].size();i++){
		y=edge[x][i];
		if(y==1&&tot+1==5){
				ans=max(ans,sum+a[y]);
				continue;
			}
		else if(vis[y]==0){
			if(tot+1>=5)continue;
			else{
				vis[y]=1;
				dfs(y,tot+1,sum+a[y]);
				vis[y]=0;
			}
		}
	}
}
inline void init(int x){
	vis[x]=1;
	for(int i=0;i<edge[x].size();i++)
		if(vis[edge[x][i]]==0){
			vis[edge[x][i]]=1;num++;
			b[num]=edge[x][i];
			init(edge[x][i]);
		}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();k=read();
	for(int i=2;i<=n;i++)scanf("%lld",&a[i]);
	int x,y;
	for(int i=1;i<=m;i++){
		x=read();y=read();
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	if(k==0){
		vis[1]=1;
		dfs(1,0,0);
		printf("%lld",ans);
		return 0;
	}
	else if(m==n){
		b[1]=1;init(1);
		memset(f,0,sizeof(f));
		for(int i=2;i<=n;i++)f[b[i]][1]=a[b[i]];
		for(int i=2;i<=n;i++)
			for(int j=i-k-1;j<i;j++){
				f[b[i]][2]=max(f[b[i]][2],f[b[j]][1]+a[b[i]]);
				f[b[i]][3]=max(f[b[i]][3],f[b[j]][2]+a[b[i]]);
				f[b[i]][4]=max(f[b[i]][4],f[b[j]][3]+a[b[i]]);
			}
		for(int i=n-k-1;i<=n;i++)ans=max(ans,f[b[i]][4]);
		printf("%lld",ans);
		return 0;
	}
	else{
		ll maxn1=-1,maxn2=-1,maxn3=-1,maxn4=-1;
		for(int i=2;i<=n;i++){
			if(a[i]>maxn1)maxn4=maxn3,maxn3=maxn2,maxn2=maxn1,maxn1=a[i];
			else if(a[i]>maxn2)maxn4=maxn3,maxn3=maxn2,maxn2=a[i];
			else if(a[i]>maxn3)maxn4=maxn3,maxn3=a[i];
			else maxn4=max(maxn4,a[i]);
		}
		printf("%lld",maxn1+maxn2+maxn3+maxn4);
		return 0;
	}
	return 0;
}
