#include<bits/stdc++.h>
#define ll long long
using namespace std;
inline ll read(){
	ll x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int lA,lB,rA,rB;
int n,m,q;
ll a[1010],b[1010],c[1010][1010],d[1010],ans;
int main(){
	register int i,j;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(i=1;i<=n;i++)a[i]=read();
	for(i=1;i<=m;i++)b[i]=read();
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	while(q--){
		ans=-1e18;
		lA=read();rA=read();lB=read();rB=read();
		for(i=lA;i<=rA;i++)d[i]=1e18;
		for(i=lA;i<=rA;i++)
			for(j=lB;j<=rB;j++)
				d[i]=min(d[i],c[i][j]);
		for(i=lA;i<=rA;i++)ans=max(ans,d[i]);
		printf("%lld\n",ans);
	}
	return 0;
}

