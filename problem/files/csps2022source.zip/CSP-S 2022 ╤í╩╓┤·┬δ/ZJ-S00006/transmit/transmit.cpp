#include<bits/stdc++.h>
using namespace std;
int n,q,k,fa[200005][21],dep[200005];
long long dis[200005][21],c[200005];
vector<int> g[200005];

void pre(int x){
	for(int i = 1; i <= 20; i++) fa[x][i]=fa[fa[x][i-1]][i-1],dis[x][i]=dis[fa[x][i-1]][i-1]+dis[x][i-1];
	for(int i = 0; i < g[x].size(); i++){
		int to = g[x][i];
		if(to!=fa[x][0]){
			dep[to]=dep[x]+1;
			fa[to][0]=x;
			dis[to][0]=c[to];
			pre(to);
		}
	}
}

long long lca(int x, int y){
	if(dep[x]<=dep[y])swap(x,y);
	//cout << x << " " << dep[x] << "/" << y << " " << dep[y] << endl;
	long long ret = 0;
	for(int i = 20; i >= 0; i--){
		if(dep[fa[x][i]]>=y){
			ret += dis[x][i];
			x = fa[x][i];
		//	cout << "x:" << x << " " << ret << endl;
		}
	}
	if(x==y)return ret+c[x];
	for(int i = 20; i >= 0; i--){
		if(fa[x][i]!=fa[y][i]){
			ret+=dis[x][i]+dis[y][i];
			x = fa[x][i];
			y = fa[y][i];
			//cout <<"x+y:" << x << " " << y << " " << ret << endl;
		}
	}
	return ret+c[x]+c[y]+c[fa[x][0]];
}

void sol1(){
	dep[1]=1;
	pre(1);
	while(q--){
		int a,b;
		scanf("%d%d",&a,&b);
		printf("%lld\n",lca(a,b));
	}
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i = 1; i <= n; i++)scanf("%lld",&c[i]);
	for(int i = 1; i < n; i++){
		int a,b;
		scanf("%d%d",&a,&b);
		g[a].push_back(b);
		g[b].push_back(a);
	}
	if(k==1)sol1();
	return 0;
}
/*
5 5 1
1 2 3 4 5
1 2
2 3
1 4
4 5

1 2
2 3
3 5
3 4
2 5

*/