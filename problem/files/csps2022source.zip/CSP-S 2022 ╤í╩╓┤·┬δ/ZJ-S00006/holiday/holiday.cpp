#include<bits/stdc++.h>
using namespace std;
vector<int> g[2505];
struct it{
	int id,val;	
};
vector<it> cir[5005];
int n,m,K,q[5005],fr,tl,dis[2505][2505];
bool vis[2505],e[2505][2505];
long long w[2505],ans,tot,t[5005],h[5005],cnt;
bool cmp(int x, int y){
	return x>y;
}
bool cmp2(it x, it y){
	return x.val > y.val;
}
void dfs(int x, int step, long long sum){
	if(step==4){
		if(e[x][1])ans = max(ans,sum);
		return;
	}
	for(int i = 0; i < g[x].size();i++){
		if(vis[g[x][i]])continue;
		vis[g[x][i]]=1;
		dfs(g[x][i],step+1,sum+w[g[x][i]]);
		vis[g[x][i]]=0;
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	for(int i = 2; i <= n; i++)scanf("%lld",&w[i]);
	for(int i = 1; i <= m; i++){
		int u,v;
		scanf("%d%d",&u,&v);
		g[u].push_back(v);
		g[v].push_back(u);
		e[u][v]=e[v][u]=1;
	}
	memset(dis,0x3f,sizeof(dis));
	for(int i = 1; i <= n; i++){
		fr=tl=1;
		q[1]=i;
		dis[i][i]=0;
		while(fr <= tl){
			int x = q[fr++];
			for(int j = 0; j < g[x].size(); j++){
				int to = g[x][j];
				if(dis[i][to]==0x3f3f3f3f){
					dis[i][to]=dis[i][x]+1;
					q[++tl]=to;
				}
			}
		}
	}
	K++;
	if(K==1&&n<=300){
		dfs(1,0,0);
		cout << ans;	
	}else if(n <= 50){
		for(int i = 2; i <= n; i++){
			if(dis[1][i]>K)continue;
			for(int j = 2; j <= n; j++){
				if(i == j||dis[i][j]>K)continue;
				for(int k = 2; k <= n; k++){
					if(k == i || k == j || dis[j][k] > K)continue;
					for(int l = 2; l <= n; l++){
						if(l == i || l == j || l == k || dis[k][l] > K || dis[l][1]>K)continue;
						//cout << i << " " << j << " " << k << " " << l << endl;
						ans = max(ans,w[i]+w[j]+w[k]+w[l]);
					}
				}
			}
		}
		cout << ans;
	}else{
		for(int i = 1; i <= n; i++)if(dis[1][i] <= K) t[++tot]=w[i],vis[i]=1;
		for(int i = 1; i <= n; i++){
			if(!vis[i]){
				for(int j = 1; j <= n; j++){
					if(vis[j]&&dis[i][j]<=K){
						h[++cnt]=w[i];
						break;
					}
				}
			}
		}
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= n; j++){
				if(i!=j&&vis[j]){
					cir[i].push_back({j,w[j]});
				}
			}
		}
		
		sort(h+1,h+1+cnt,cmp);
		for(int i = 1; i <= min(cnt,2ll); i++)t[++tot]=h[i];
		sort(t+1,t+1+tot,cmp);
		cout << t[1]+t[2]+t[3]+t[4];
		
	}
	return 0;
}
		