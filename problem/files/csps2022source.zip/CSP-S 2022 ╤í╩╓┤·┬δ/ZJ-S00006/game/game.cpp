#include<bits/stdc++.h>
using namespace std;
const long long inf = -2e18,inr = 2e18;
long long a[100005],b[100005];
long long amax0[100005][20],amin0[100005][20],amax1[100005][20],amin1[100005][20];
int lg[100005];
int n,m,q,l1,r1,l2,r2;

long long getamax(int l, int r,int id){
	int len = r-l+1;
	if(id==0)return max(amax0[r][lg[len]],amax0[l+(1<<(lg[len]))-1][lg[len]]);
	else return max(amax1[r][lg[len]],amax1[l+(1<<(lg[len]))-1][lg[len]]);
}

long long getamin(int l, int r,int id){
	int len = r-l+1;
	if(id==0)return min(amin0[r][lg[len]],amin0[l+(1<<(lg[len]))-1][lg[len]]);
	else return min(amin1[r][lg[len]],amin1[l+(1<<(lg[len]))-1][lg[len]]);
}

struct seg{
	long long ma,mi;
}t[400005];

void push_up(int x){
	t[x].ma = max(t[x*2].ma,t[x*2+1].ma);
	t[x].mi = min(t[x*2].mi,t[x*2+1].mi);
}

void build(int x, int l, int r){
	if(l==r){
		t[x].ma = t[x].mi = b[l];
		return;
	}
	int mid = (l+r)>>1;
	build(x*2,l,mid);
	build(x*2+1,mid+1,r);
	push_up(x);
}

long long ask(int x, int l, int r, int ql, int qr, int type){
	if(ql <= l && r <= qr){
		if(type==1)return t[x].mi;
		return t[x].ma;
	}
	if(type){
		long long ans = inr;
		int mid = (l+r)>>1;
		if(ql <= mid) ans = min(ans,ask(x*2,l,mid,ql,qr,type));
		if(qr > mid) ans = min(ans,ask(x*2+1,mid+1,r,ql,qr,type));
		return ans;
	}else{
		long long ans = inf;
		int mid = (l+r)>>1;
		if(ql <= mid) ans = max(ans,ask(x*2,l,mid,ql,qr,type));
		if(qr > mid) ans = max(ans,ask(x*2+1,mid+1,r,ql,qr,type));
		return ans;
	}
}

void sol1(){
	build(1,1,m);
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long out = inf;
		for(int i = l1; i <= r1; i++){
			if(a[i]<0)out = max(out,ask(1,1,m,l2,r2,0)*a[i]);
			else out = max(out,ask(1,1,m,l2,r2,1)*a[i]);
		}
		printf("%lld\n",out);
	}
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	memset(amin0,0x3f,sizeof(amin0));
	memset(amin1,0x3f,sizeof(amin1));
	memset(amax0,0x9f,sizeof(amax0));
	memset(amax1,0x9f,sizeof(amax1));
	scanf("%d%d%d",&n,&m,&q);
	for(int i = 1; i <= n; i++){
		scanf("%lld",&a[i]);
		if(a[i]>=0)amax0[i][0]=amin0[i][0]=a[i];
		else amax1[i][0]=amin1[i][0]=a[i];
	}
	for(int i = 1; i <= m; i++){
		scanf("%lld",&b[i]);
	}
	
	if(n<=1000){
		sol1();
		return 0;
	}
	build(1,1,m);
	for(int i = 2; i <= 100001; i++)lg[i]=lg[i/2]+1;
	for(int j = 1; j <= lg[n]; j++){
		for(int i = (1 << (j-1))+1; i <= n; i++){
			amax0[i][j]=max(amax0[i][j-1],amax0[i-(1<<(j-1))][j-1]);
			amin0[i][j]=min(amin0[i][j-1],amin0[i-(1<<(j-1))][j-1]);	
			amax1[i][j]=max(amax1[i][j-1],amax1[i-(1<<(j-1))][j-1]);
			amin1[i][j]=min(amin1[i][j-1],amin1[i-(1<<(j-1))][j-1]);
		}
	}
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long out = inf;
		long long aval = getamax(l1,r1,0);
		if(aval>=0 && aval <= 2e9){
			out = max(out,aval*ask(1,1,m,l2,r2,1));
		}
		//cout << aval << " " << out << endl;
		aval = getamax(l1,r1,1);
		if(aval>=-2e9 && aval <= 0){
			out = max(out,aval*ask(1,1,m,l2,r2,0));
		}
		//cout << aval << " " << out << endl;
		aval = getamin(l1,r1,0);
		if(aval>=0 && aval <= 2e9){
			out = max(out,aval*ask(1,1,m,l2,r2,1));
		}
		//cout << aval << " " << out << endl;
		aval = getamin(l1,r1,1);
		if(aval>=-2e9 && aval <= 0){
			out = max(out,aval*ask(1,1,m,l2,r2,0));
		}
		//cout << aval << " " << out << endl;
		printf("%lld\n",out);
	}
	return 0;
}