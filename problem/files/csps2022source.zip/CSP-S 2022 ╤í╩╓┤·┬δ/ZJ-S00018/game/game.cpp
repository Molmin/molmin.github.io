#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e5+3;
int n,m,q,a[N],b[N],l1,r1,l2,r2,min1,min2,max1,max2,minn,maxn;
signed main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1; i<=n; i++)scanf("%d",a+i);
	for(int i=1; i<=m; i++)scanf("%d",b+i);
	while(q--) {
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		min1=min2=2e9;
		max1=max2=-2e9;
		for(int i=l1; i<=r1; i++) {
			min1=min(min1,a[i]);
			max1=max(max1,a[i]);
		}
		for(int i=l2; i<=r2; i++) {
			min2=min(min2,b[i]);
			max2=max(max2,b[i]);
		}
		if(max1<=0) {
			if(min2>=0)	printf("%lld\n",1ll*max1*max2);
			else if(max2<=0)printf("%lld\n",1ll*min1*min2);
			else printf("%lld\n",1ll*max1*max2);
		} else if(min1>=0) {
			if(min2>=0)printf("%lld\n",1ll*max1*min2);
			else if(max2<=0)printf("%lld\n",1ll*min1*min2);
			else printf("%lld\n",1ll*min1*min2);
		} else {
			if(min2>=0)printf("%lld\n",1ll*max1*min2);
			else if(max2<=0)printf("%lld\n",1ll*min1*max2);
			else {
				int f=1;
				minn=2e9,maxn=-2e9;
				for(int i=l1; i<=r1; i++)if(a[i]==0)f=0;
				for(int i=l1; i<=r1; i++) {
					minn=min(minn,max(a[i],f));
					maxn=max(maxn,min(a[i],-1*f));
				}
				printf("%lld\n",1ll*max(1ll*minn*max2,1ll*maxn*max2));
			}
		}
	}
	return 0;
}
