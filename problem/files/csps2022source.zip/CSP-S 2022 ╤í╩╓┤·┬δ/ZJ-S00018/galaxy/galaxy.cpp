#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,q,u,v,t,a,b;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=0;i<m;i++)scanf("%d%d",&u,&v);
	cin>>q;
	while(q--){
		scanf("%d%d%d",&t,&a,&b);
		printf("NO\n");
	}
	return 0;
}
