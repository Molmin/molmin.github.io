#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=2e5+5;
int n,q,k,v[N],a,b,s,t,dp[2003][2003];
vector<int>G[N];
ll ans=2e18,sum;
void dfs(int now,int pre,int lst){
	for(int i=0;i<G[now].size();i++){
		int nxt=G[now][i];
		if(nxt==pre)continue;
		sum+=v[now];
		dfs(nxt,now,t);
		sum-=v[now];
	}if(now==lst)ans=min(ans,sum+v[t]);
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)scanf("%d",v+i);
	for(int i=1;i<n;i++){
		scanf("%d%d",&a,&b);
		G[a].push_back(b);
		G[b].push_back(a);
	}
	while(q--){
		scanf("%d%d",&s,&t);
		ans=2e18;
		dfs(s,0,t);
		cout<<ans<<endl;
	}
	return 0;
}

