#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,k,m,x,y,a[2502];
vector<int> G[2502];
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)scanf("%d",a+i);
	for(int i=0;i<m;i++){
		scanf("%d%d",&x,&y);
	}
	srand(time(0));
	printf("%d",rand()+1);
	return 0;
}
