#include <bits/stdc++.h>
using namespace std;
int n,m,q;
vector<int> ee[500005];
int en[500005],nn[500005];
int ex[500005],nx[500005];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		en[u]++,nn[u]++;
		ex[v]++,nx[u]++;
		ee[v].push_back(u);
	}
	for(int i=1;i<=n;i++)
		sort(ee[i].begin(),ee[i].end());
	scanf("%d",&q);
	while(q--)
	{
		int t;
		scanf("%d",&t);
		switch(t)
		{
			case 1:{
				int u,v;
				scanf("%d%d",&u,&v);
				m--;
				en[u]--;
				ex[v]--;
				if(m!=n)
				{
					puts("NO");
					break;
				}
				int p=1; 
				for(int i=1;i<=n;i++)
					if(en[i]!=1)
					{
						puts("NO");
						break;
					}
				puts("YES");
				break;
			}
			case 3:{
					
				int u,v;
				scanf("%d%d",&u,&v);
				m++;
				en[u]++;
				ex[v]++;
				if(m!=n)
				{
					puts("NO");
					break;
				}
				int p=1; 
				for(int i=1;i<=n;i++)
					if(en[i]!=1)
					{
						puts("NO");
						break;
					}
				puts("YES");
				break;
			}
		}
	}
	return 0;
}
