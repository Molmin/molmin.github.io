#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[100001];
ll b[100001];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	int T;scanf("%d",&T);
	for(int i=1;i<=n;i++)
		scanf("%lld",a+i);
	for(int i=1;i<=m;i++)
		scanf("%lld",b+i);
	while(T--)
	{
		int l1,r1,l2,r2;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ll bmin=0x7f7f7f7f7f7f7f7f,bmax=0x8080808080808080;
		for(int i=l2;i<=r2;i++)
			bmax=max(b[i],bmax),
			bmin=min(b[i],bmin);
		if(bmin>=0)
		{
			ll amax=0x8080808080808080;
			for(int i=l1;i<=r1;i++)
				amax=max(amax,a[i]);
			printf("%lld\n",min(bmax*amax,bmin*amax));
		}
		else if(bmax<=0)
		{
			ll amin=0x7f7f7f7f7f7f7f7f;
			for(int i=l1;i<=r1;i++)
				amin=min(amin,a[i]);
			printf("%lld\n",min(bmax*amin,bmin*amin));
		}
		else
		{
			ll amax=0x8080808080808080,amin=0x7f7f7f7f7f7f7f7f;
			for(int i=l1;i<=r1;i++)
				amax=a[i]<=0?max(amax,a[i]):amax,
				amin=a[i]>=0?min(amin,a[i]):amin;
			printf("%lld\n",max(bmin*amin,bmax*amax));
		}
	}
	return 0;
}
