#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define inf 0x3f3f3f3f
vector<int> e[2505];
int d[2505][2505];
ll val[2505];
ll ret=-1;

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n=2500,m=0,k=0;
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",val+i);
	memset(d,inf,sizeof(d));
	for(int i=1;i<=m;i++)
	{
		int x,y;
		scanf("%d%d",&x,&y);
		d[x][y]=d[y][x]=0;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				d[j][k]=d[k][j]=min(d[k][j],d[i][k]+d[i][j]+1);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(d[i][j]<=k&&i!=j)
				e[i].push_back(j);
	for(auto i=e[1].begin();i!=e[1].end();i++)
		for(auto i1=e[1].begin();i1!=e[1].end();i1++)
		{
			if(*i1==*i)continue;
			for(auto j=e[*i].begin();j!=e[*i].end();j++)
			{
				if(*j==*i1)continue;
				for(auto j1=e[*i1].begin();j1!=e[*i1].end();j1++)
					if(*i!=*j1&&*j!=*j1&&d[*j][*j1]<=k)
						ret=max(ret,val[*i]+val[*i1]+val[*j]+val[*j1]);
			}
		}
	printf("%lld",ret);				
	return 0;
}
