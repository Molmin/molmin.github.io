#include<bits/stdc++.h>
using namespace std;
int n,m,kk,a[100100],x,y,f[2525][2525],ans;
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>kk;
	for (int i=2;i<=n;i++)
		scanf("%d",&a[i]);
	memset(f,63,sizeof(f));
	for (int i=1;i<=m;i++)
		scanf("%d%d",&x,&y),f[x][y]=1,f[y][x]=1;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			for (int k=1;k<=n;k++)
				f[j][k]=min(f[j][k],f[j][i]+f[i][k]);
	for (int i=2;i<=n;i++)
	if (f[1][i]<=kk+1)
		for (int j=2;j<=n;j++)
		if (i!=j&&f[i][j]<=kk+1)
			for (int k=2;k<=n;k++)
			if (i!=k&&j!=k&&f[j][k]<=kk+1)
				for (int ii=2;ii<=n;ii++)
					if (i!=ii&&j!=ii&&k!=ii&&f[k][ii]<=kk+1&&f[ii][1]<=kk+1)
					ans=max(ans,a[i]+a[j]+a[k]+a[ii]);
	cout<<ans<<endl;
 } 
