#include<bits/stdc++.h>
using namespace std;
int n,m,pd[500500],u,v,q,t,used[500500];
struct node
{
	int x,y,next;
}ex[500500];
int head[500500];
int cnt;
void add(int x,int y)
{
	cnt++;
	ex[cnt].x=x;
	ex[cnt].y=y;
	ex[cnt].next=head[x];
	head[x]=cnt;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		add(u,v);
	}
	cin>>q;
	for (int i=1;i<=q;i++)
	{
		scanf("%d",&t);
		if (t==1)
		{
			scanf("%d%d",&u,&v);
			for (int j=head[u];j;j=ex[j].next)
			if (ex[j].y==v)
			{
				used[j]=1;
				break;
			}
		}
		else if (t==2)
		{
			scanf("%d",&u);
			for (int j=1;j<=m;j++)
			if(ex[j].y==u) used[j]=1;
		}
		else if (t==3)
		{
			scanf("%d%d",&u,&v);
			for (int j=head[u];j;j=ex[j].next)
			if (ex[j].y==v)
			{
				used[j]=0;
				break;
			}
		}
		else if (t==4)
		{
			scanf("%d",&u);
			for (int j=1;j<=m;j++)
			if (ex[j].y==u) used[j]=0;
		}
		int flag=1;
		for (int j=1;j<=n;j++)
			pd[j]=0;
		for (int j=1;j<=m;j++)
		if (used[j]==0)
		{
			pd[ex[j].x]++;
			if (pd[ex[j].x]==2)
			{
				flag=0;
				break;
			}
		}
		if (flag)
		for (int j=1;j<=n;j++)
		if (pd[j]!=1)
		{
			flag=0;
			break;
		}
		if (flag==1) printf("YES\n");
		else printf("NO\n");
	}
}//�� 
