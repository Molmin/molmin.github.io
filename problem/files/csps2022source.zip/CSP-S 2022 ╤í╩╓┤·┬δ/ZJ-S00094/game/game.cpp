#include<bits/stdc++.h>
using namespace std;
int tree1[400400],tree2[400400],tree3[400400],tree4[400400];
int tree5[400400],tree6[400400],tree7[400400],tree8[400400];
int a[100100],b[100100],n,m,q;
int build1(int p,int l,int r)
{
	if (l==r) return tree1[p]=a[l];
	if (l>=r) return INT_MIN;
	int mid=(l+r)>>1;
	return tree1[p]=max(build1(p<<1,l,mid),build1(p<<1|1,mid+1,r));
}
int build2(int p,int l,int r)
{
	if (l==r) return tree2[p]=b[l];
	if (l>=r) return INT_MAX;
	int mid=(l+r)>>1;
	return tree2[p]=min(build2(p<<1,l,mid),build2(p<<1|1,mid+1,r));
}
int build3(int p,int l,int r)
{
	if (l==r) return tree3[p]=a[l];
	if (l>=r) return INT_MAX;
	int mid=(l+r)>>1;
	return tree3[p]=min(build3(p<<1,l,mid),build3(p<<1|1,mid+1,r));
}
int build4(int p,int l,int r)
{
	if (l==r) return tree4[p]=b[l];
	if (l>=r) return INT_MIN;
	int mid=(l+r)>>1;
	return tree4[p]=max(build4(p<<1,l,mid),build4(p<<1|1,mid+1,r));
}
int build5(int p,int l,int r)
{
	if (l==r) 
	{
		if (a[l]>=0)return tree5[p]=a[l];
		else return tree5[p]=INT_MAX;
	}
	if (l>=r) return INT_MAX;
	int mid=(l+r)>>1;
	return tree5[p]=min(build5(p<<1,l,mid),build5(p<<1|1,mid+1,r));
}
int build6(int p,int l,int r)
{
	if (l==r) 
	{
		if (b[l]>=0)return tree6[p]=b[l];
		else return tree6[p]=INT_MAX;
	}
	if (l>=r) return INT_MAX;
	int mid=(l+r)>>1;
	return tree6[p]=min(build6(p<<1,l,mid),build6(p<<1|1,mid+1,r));
}
int build7(int p,int l,int r)
{
	if (l==r) 
	{
		if (a[l]<=0)return tree7[p]=a[l];
		else return tree7[p]=INT_MIN;
	}
	if (l>=r) return INT_MIN;
	int mid=(l+r)>>1;
	return tree7[p]=max(build7(p<<1,l,mid),build7(p<<1|1,mid+1,r));
}
int build8(int p,int l,int r)
{
	if (l==r) 
	{
		if (b[l]<=0)return tree8[p]=b[l];
		else return tree8[p]=INT_MIN;
	}
	if (l>=r) return INT_MIN;
	int mid=(l+r)>>1;
	return tree8[p]=max(build8(p<<1,l,mid),build8(p<<1|1,mid+1,r));
}
int suan1(int p,int l,int r,int ll,int rr)
{
	
	if (ll<=l&&r<=rr) return tree1[p];
	if (l>r) return INT_MIN;
	int mid=(l+r)>>1,sum=INT_MIN;
	if (ll<=mid) sum=suan1(p<<1,l,mid,ll,rr);
	if (rr>=mid+1)sum=max(sum,suan1(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan2(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree2[p];
	if (l>r) return INT_MAX;
	int mid=(l+r)>>1,sum=INT_MAX;
	if (ll<=mid) sum=suan2(p<<1,l,mid,ll,rr);
	if (rr>=mid+1) sum=min(sum,suan2(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan3(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree3[p];
	if (l>r) return INT_MAX;
	int mid=(l+r)>>1,sum=INT_MAX;
	if (ll<=mid) sum=suan3(p<<1,l,mid,ll,rr);
	if (rr>=mid+1)sum=min(sum,suan3(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan4(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree4[p];
	if (l>r) return INT_MIN;
	int mid=(l+r)>>1,sum=INT_MIN;
	if (ll<=mid) sum=suan4(p<<1,l,mid,ll,rr);
	if (rr>=mid+1) sum=max(sum,suan4(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan5(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree5[p];
	if (l>r) return INT_MAX;
	int mid=(l+r)>>1,sum=INT_MAX;
	if (ll<=mid) sum=suan5(p<<1,l,mid,ll,rr);
	if (rr>=mid+1)sum=min(sum,suan5(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan6(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree6[p];
	if (l>r) return INT_MAX;
	int mid=(l+r)>>1,sum=INT_MAX;
	if (ll<=mid) sum=suan6(p<<1,l,mid,ll,rr);
	if (rr>=mid+1) sum=min(sum,suan6(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan7(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree7[p];
	if (l>r) return INT_MIN;
	int mid=(l+r)>>1,sum=INT_MIN;
	if (ll<=mid) sum=suan7(p<<1,l,mid,ll,rr);
	if (rr>=mid+1)sum=max(sum,suan7(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int suan8(int p,int l,int r,int ll,int rr)
{
	if (ll<=l&&r<=rr) return tree8[p];
	if (l>r) return INT_MIN;
	int mid=(l+r)>>1,sum=INT_MIN;
	if (ll<=mid) sum=suan8(p<<1,l,mid,ll,rr);
	if (rr>=mid+1) sum=max(sum,suan8(p<<1|1,mid+1,r,ll,rr));
	return sum;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for (int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	build1(1,1,n);
	build3(1,1,n);
	build5(1,1,n);
	build7(1,1,n);
	for (int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	build2(1,1,m);
	build4(1,1,m);
	build6(1,1,m);
	build8(1,1,m);
	int l1,l2,r1,r2;
	for (int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long k1=suan1(1,1,n,l1,r1);
		long long k2=suan2(1,1,m,l2,r2);
		long long k3=suan3(1,1,n,l1,r1);
		long long k4=suan4(1,1,m,l2,r2);
		long long k5=suan5(1,1,n,l1,r1);
		long long k6=suan6(1,1,m,l2,r2); 
		long long k7=suan7(1,1,n,l1,r1);
		long long k8=suan8(1,1,m,l2,r2); 
		long long ans;
		if (k5==INT_MAX&&k6==INT_MAX&&k7==INT_MIN&&k8==INT_MIN)ans=max(min(k1*k2,k1*k4),min(k3*k2,k3*k4));
		else if (k5==INT_MAX&&k6==INT_MAX&&k7==INT_MIN) ans=max(min(k1*k2,min(k1*k4,k1*k8)),min(k3*k2,min(k3*k4,k3*k8)));
		else if (k6==INT_MAX&&k7==INT_MIN&&k8==INT_MIN)ans=max(min(k1*k2,k1*k4),max(min(k3*k2,k3*k4),min(k5*k2,k5*k4)));
		else if (k5==INT_MAX&&k7==INT_MIN&&k8==INT_MIN) ans=max(min(k1*k2,min(k1*k4,k1*k6)),min(k3*k2,min(k3*k4,k3*k6)));
		else if (k5==INT_MAX&&k6==INT_MAX&&k8==INT_MIN) ans=max(min(k1*k2,k1*k4),max(min(k3*k2,k3*k4),min(k7*k2,k7*k4)));
		else if (k5==INT_MAX&&k6==INT_MAX)ans=max(min(k1*k2,min(k1*k4,k1*k8)),max(min(k3*k2,min(k3*k4,k3*k8)),min(k7*k2,min(k7*k4,k7*k8))));
		else if (k5==INT_MAX&&k8==INT_MIN)ans=max(min(k1*k2,min(k1*k4,k1*k6)),max(min(k3*k2,min(k3*k4,k3*k6)),min(k7*k2,min(k7*k4,k7*k6))));
		else if (k6==INT_MAX&&k7==INT_MIN)ans=max(min(k1*k2,min(k1*k4,k1*k8)),max(min(k3*k2,min(k3*k4,k3*k8)),min(k5*k2,min(k5*k4,k5*k8))));
		else if (k7==INT_MIN&&k8==INT_MIN)ans=max(min(k1*k2,min(k1*k4,k1*k6)),max(min(k3*k2,min(k3*k4,k3*k6)),min(k5*k2,min(k5*k4,k5*k6))));
		else if (k5==INT_MAX&&k7==INT_MIN)ans=max(min(min(k1*k2,k1*k6),min(k1*k4,k1*k8)),min(min(k3*k2,k3*k6),min(k3*k4,k3*k8)));
		else if (k6==INT_MAX&&k8==INT_MIN) ans=max(max(min(k1*k2,k1*k4),min(k5*k2,k5*k4)),max(min(k3*k2,k3*k4),min(k7*k2,k7*k4)));
		else if (k5==INT_MAX) ans=max(min(min(k1*k2,k1*k6),min(k1*k4,k1*k8)),max(min(min(k3*k2,k3*k6),min(k3*k4,k3*k8)),min(min(k7*k2,k7*k6),min(k7*k4,k7*k8))));
		else if (k8==INT_MIN)ans=max(max(min(min(k1*k2,k1*k4),k1*k6),min(min(k5*k2,k5*k4),k5*k6)),max(min(min(k3*k2,k3*k4),k3*k6),min(min(k7*k2,k7*k4),k7*k6)));
		else if (k7==INT_MIN)ans=max(min(min(k1*k2,k1*k6),min(k1*k4,k1*k8)),max(min(min(k3*k2,k3*k6),min(k3*k4,k3*k8)),min(min(k5*k2,k5*k6),min(k5*k4,k5*k8))));
		else if (k6==INT_MAX)ans=max(max(min(min(k1*k2,k1*k4),k1*k8),min(min(k5*k2,k5*k4),k5*k8)),max(min(min(k3*k2,k3*k4),k3*k8),min(min(k7*k2,k7*k4),k7*k8)));
		else  ans=max(max(min(min(k1*k2,k1*k6),min(k1*k4,k1*k8)),min(min(k5*k2,k5*k6),min(k5*k4,k5*k8))),max(min(min(k3*k2,k3*k6),min(k3*k4,k3*k8)),min(min(k7*k2,k7*k6),min(k7*k4,k7*k8))));
		printf("%lld\n",ans);
	}
}
