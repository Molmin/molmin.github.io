#include<bits/stdc++.h>
using namespace std;
int n,q,k;
long long ans,v[200100];
struct node
{
	int x,y,next;
}ex[200200];
int head[200200];
int cnt;
void add(int x,int y)
{
	cnt++;
	ex[cnt].x=x;
	ex[cnt].y=y;
	ex[cnt].next=head[x];
	head[x]=cnt;
}
void dfs(int x,int fa,int y,int step,long long sum)
{
	if (step>=k) return ;
	if (sum>=ans) return ;
	if (y==x) 
	{
		if (step==0)ans=min(ans,sum);
		return ;
	}
	for (int i=head[x];i;i=ex[i].next)
	if (ex[i].y!=fa)
	{
		dfs(ex[i].y,x,y,step+1,sum);
		dfs(ex[i].y,x,y,0,sum+v[ex[i].y]);
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for (int i=1;i<=n;i++)
		scanf("%d",&v[i]);
		int a,b,s,t;
	for (int i=1;i<n;i++)
	{
		scanf("%d%d",&a,&b);
		add(a,b);add(b,a);
	}
	for (int i=1;i<=q;i++)
	{
		scanf("%d%d",&s,&t);
		ans=1e18;
		dfs(s,s,t,0,v[s]);
		printf("%lld\n",ans);
	}
}
