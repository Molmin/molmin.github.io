#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;

int const N=100005;

int A[N],B[N];
int n,m,q;

int findmax1(int AA[N],int al,int ar){
	int maxa=AA[al];
	for(int i=al+1;i<=ar;i++){
		if(AA[i]>maxa)maxa=AA[i];
	}
	return maxa;
}

int findmax0(int AA[N],int al,int ar){
	int maxa=AA[al];
	for(int i=al+1;i<=ar;i++){
		if(AA[i]<maxa)maxa=AA[i];
	}
	return maxa;
}

int findmin1(int AA[N],int al,int ar){
	int i,mina;
	for(i=al;i<=ar;i++){
		if(AA[i]>0){
		mina=AA[i];
		break;
		}
	}
	for(;i<=ar;i++){
		if(AA[i]>0 && AA[i]<mina)mina=AA[i];
		
	}
	return mina;
}

int findmin0(int AA[N],int al,int ar){
	int i,mina;
	for(i=al;i<=ar;i++){
		if(AA[i]<0){
		mina=AA[i];
		break;
		}
	}
	for(;i<=ar;i++){
		if(AA[i]<0 && AA[i]>mina)mina=AA[i];
		
	}
	return mina;
}

int check(int AA[N],int al,int ar){
	bool flagz=false,flag0=false,flagf=false;
	for(int i=al;i<=ar;i++){
		if(AA[i]>0)flagz=true;
		if(AA[i]==0)flag0=true;
		if(AA[i]<0)flagf=true;
	}
	if(flagz){
		if(flag0){
			if(flagf) return 5;
			return 2;
		}
		return 0;
		if(flagf) return 4;
	}else{
		if(flagf){
			if(flag0) return 3;
		return 1;
		}
	}
	return 0;
	
	
	
}





int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	
	cin>>n>>m>>q;
	
	for(int i=1;i<=n;i++){
		int ui;
		scanf("%d",&ui);
		A[i]=ui;	
	}	
	for(int i=1;i<=m;i++){
		int ui;
		scanf("%d",&ui);	
		B[i]=ui;
	}
	int l1,r1,l2,r2;
	
	for(int ii=1;ii<=q;ii++){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l2==r2){
			int b=B[l2],a;
			if(b==0){
				cout<<0;
				
			}
			if(b>0){
				a=findmax1(A,l1,r1);
				cout<<a*b;
				
			}
			if(b<0){
				a=findmax0(A,l1,r1);
				cout<<a*b;
				
			}
		}
		if(l1==r1){
			int a=A[r1],b;
			if(a==0){
				cout<<0;
				
			}
			if(a>0){
				b=findmax0(B,l2,r2);
				cout<<a*b;
				
			}
			if(a<0){
				b=findmax1(B,l2,r2);
				cout<<a*b;
				
			}
		
		}
		
		int bbb=check(B,l2,r2);
		int aaa=check(A,l1,r1);
		if(aaa==0 && bbb==0) cout<<(findmax1(A,l1,r1)*findmin1(B,l2,r2));
		
		
		
		
		
		
		
	
	}
	
	return 0;
}
