#pragma GCC optimize(2)
#include <bits/stdc++.h>
using namespace std;

int n,m,k;
long long Sum=0;
int Map[2505][2505]={0};
long long fenshu[2505];
int c[2505];

int dfs(int x,int t,long long sum){
	
	
	if(t==5){
		
		if(Map[1][x]==1 && sum>=Sum)Sum=sum;
			
		
		return 0;
	}
	for(int i=1;i<=n;i++){
		if(Map[x][i]==1 && c[i]==1){
			c[i]=0;
			dfs(i,t+1,(sum+fenshu[i]));
			c[i]=1;
		}
	}
	return 0;
	
}



int main(){
	freopen("holiday2.in","r",stdin);
	freopen("holiday2.out","w",stdout);
	
	cin>>n>>m>>k;
	
	
	
	for(int i=2;i<=n;i++){
		long long s;scanf("%lld",&s);fenshu[i]=s;
	}
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);Map[x][y]=1;Map[y][x]=1;
	}
	
	for(int i=2;i<=n;i++)c[i]=1;
	dfs(1,0,0);
	
	cout<<Sum;
	
	return 0;
}
