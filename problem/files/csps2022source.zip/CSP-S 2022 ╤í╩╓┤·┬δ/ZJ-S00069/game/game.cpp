#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

int n,m,q;

namespace P25
{
	const int M=1e5+5;
		
	int l1,r1,l2,r2;
	ll a[M],b[M];
	
	void solve()
	{
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		for(int i=1;i<=m;i++)
			scanf("%lld",&b[i]);
		while(q--)
		{
			ll ans=-1e18;
			scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
			for(int i=l1;i<=r1;i++)
			{
				ll res=1e18;
				for(int j=l2;j<=r2;j++)
					res=min(res,a[i]*b[j]);
				ans=max(ans,res);
			}
			printf("%lld\n",ans);
		}
	}
}

namespace P60
{
	const int M=1e5+5;
	int l1,r1,l2,r2;
	ll a[M],b[M];
	
	void solve()
	{
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		for(int i=1;i<=m;i++)
			scanf("%lld",&b[i]);
		while(q--)
		{
			scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
			bool okz=0,okf=0,ok0=0;
			ll ans=-1e18,z_max=-1e18,f_max=-1e18,z_min=1e18,f_min=1e18;
			for(int i=l2;i<=r2;i++)
			{
				if(b[i]>0)
				{
					z_max=max(z_max,b[i]);
					z_min=min(z_min,b[i]);
					okz=1;
				}
				else if(b[i]<0)
				{
					f_max=max(f_max,b[i]);
					f_min=min(f_min,b[i]);
					okf=1;
				}
				else ok0=1;
			}
			
//			printf("::::%lld %lld %lld %lld\n",z_max,z_min,f_max,f_min);
			
			for(int i=l1;i<=r1;i++)
			{
				if(a[i]>0)
				{
					if(okf)ans=max(ans,a[i]*f_min);
					else if(ok0)ans=max(ans,0ll);
					else if(okz)ans=max(ans,a[i]*z_min);
				}
				else if(a[i]<0)
				{
//					printf("%d :: %d %d\n",a[i],a[i]*z_max,a[i]*f_min);
					if(okz)ans=max(ans,a[i]*z_max);
					else if(ok0)ans=max(ans,0ll);
					else if(okf)ans=max(ans,a[i]*f_max);
				}
				else ans=max(ans,0ll);
			}
			printf("%lld\n",ans);
		}
	}
}

namespace P75
{
	const int M=1e5+5;
	int l1,r1,l2,r2;
	ll a[M][3];
	
	#define ls(x) x<<1
	#define rs(x) x<<1|1
	
	struct Node
	{
		int l,r;
		ll val;
	};
	
	struct Tree
	{
		Node t[M<<2];
		
		void pushup_max(int x)
		{
			t[x].val=max(t[ls(x)].val,t[rs(x)].val);
		}
		void pushup_min(int x)
		{
			t[x].val=min(t[ls(x)].val,t[rs(x)].val);
		}
		
		void build(int x,int l,int r,int id)
		{
			t[x].l=l,t[x].r=r;
			if(l==r)
			{
				t[x].val=a[l][id];
				return ;
			}
			int mid=l+r>>1;
			build(ls(x),l,mid,id);
			build(rs(x),mid+1,r,id);
			if(!id)pushup_max(x);
			else pushup_min(x);
		}
		ll query_max(int x,int l,int r)
		{
			if(t[x].l>=l&&t[x].r<=r)return t[x].val;
			int mid=t[x].l+t[x].r>>1;
			ll res=0;
			if(mid>=l)res=max(res,query_max(ls(x),l,r));
			if(mid<r)res=max(res,query_max(rs(x),l,r));
			return res;
		}
		ll query_min(int x,int l,int r)
		{
			if(t[x].l>=l&&t[x].r<=r)return t[x].val;
			int mid=t[x].l+t[x].r>>1;
			ll res=1e18;
			if(mid>=l)res=min(res,query_min(ls(x),l,r));
			if(mid<r)res=min(res,query_min(rs(x),l,r));
			return res;
		}
		
	}ta,tb;
	
	
	void solve()
	{
		for(int i=1;i<=n;i++)
			scanf("%lld",&a[i][0]);
		for(int i=1;i<=m;i++)
			scanf("%lld",&a[i][1]);
		
		ta.build(1,1,n,0),tb.build(1,1,m,1);
		
//		printf("%d \n",tb.query_min(1,4,5));
		while(q--)
		{
			scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
			ll mx=ta.query_max(1,l1,r1),mi=tb.query_min(1,l2,r2);
//			cout<<mx<<" "<<mi<<endl;
			printf("%lld\n",mx*mi);
		}
	}
	
}

int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	
	scanf("%d %d %d",&n,&m,&q);
	if(n<=200&&m<=200&&q<=200)P25::solve();
	else if(n<=1000&&m<=1000&&q<=1000)P60::solve();
	else P75::solve();
	
	fclose(stdin);
	fclose(stdout);
}
/*
3 2 2
0 1 -2
-3 4
1 3 1 2
2 3 2 2

6 4 5
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4
1 5 1 4
1 4 1 2
2 6 3 4
2 5 2 3

6 4 1
3 -1 -2 1 2 0
1 2 -1 -3
1 6 1 4

2

5 5 5
22251 25267 2159 1713 7543 
17590 27574 16943 14150 7597 
5 7 1 5
5 6 2 5
1 5 2 5
4 5 2 5
4 7 2 5



*/