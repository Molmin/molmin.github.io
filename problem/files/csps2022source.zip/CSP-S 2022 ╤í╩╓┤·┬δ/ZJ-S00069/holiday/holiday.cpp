#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

int n,m,tot;

namespace P70
{
	const int M=305;
	
	struct van
	{
		ll po,val;
	};
	bool cmp(van a,van b)
	{
		return a.val>b.val;
	}
	
	int x,y;
	int dis[M][M];
	ll ans,s[M];
	vector<van> go[M][M];
		
	void solve()
	{
		memset(dis,0x3f,sizeof(dis));
		s[1]=0;
		for(int i=2;i<=n;i++)
			scanf("%d",&s[i]);
		while(m--)
		{
			scanf("%d %d",&x,&y);
			dis[x][y]=0,dis[y][x]=0;
		}
		
		for(int i=1;i<=n;i++)dis[i][i]=0;
		for(int k=1;k<=n;k++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]+1);
		
		
		for(int i=2;i<=n;i++)
		{
			for(int j=2;j<=n;j++)
			{
				if(i==j)continue;
				if(dis[1][j]<=tot&&dis[j][i]<=tot)
					go[1][i].push_back((van){j,s[j]});
			}
			sort(go[1][i].begin(),go[1][i].end(),cmp);
		}
			
		
		for(int b=2;b<=n;b++)
			for(int c=2;c<=n;c++)
			{
				if(b==c)continue;
				for(int d=2;d<=n;d++)
				{
					if(b==d||c==d)continue;
					if(dis[b][c]<=tot&&dis[c][d]<=tot&&dis[d][1]<=tot)
					{
						int res=0,a=-1;
						for(int i=0;i<go[1][b].size();i++)
						{
							a=go[1][b][i].po;
							if(a==b||a==c||a==d)continue;
							res=go[1][b][i].val;
							break;
						}
						
						if(a!=-1)ans=max(ans,s[b]+s[c]+s[d]+res);
					}
				}
			}
				
				
		printf("%lld",ans);
	}
}

namespace P100
{
	const int M=2505;
	#define val first
	#define ed second
	typedef pair<int,int> pii;
	
	struct van
	{
		ll po,val;
	};
	bool cmp(van a,van b)
	{
		return a.val>b.val;
	}
	
	int x,y;
	int dis[M][M];
	bool vis[M];
	ll ans,s[M];
	vector<van> go1[M],go2[M];
	vector<pii> mp[M];
	
	void dij(int st)
	{
		memset(vis,0,sizeof(vis));
		priority_queue< pii,vector<pii>,greater<pii> > q;
		dis[st][st]=0;
		q.push(pii{0,st});
		while(!q.empty())
		{
			pii now=q.top();
			q.pop();
			if(vis[now.ed])continue;
			vis[now.ed]=true;
			for(int i=0;i<mp[now.ed].size();i++)
			{
				int to=mp[now.ed][i].ed,v=mp[now.ed][i].val;		
				if(dis[st][to]>dis[st][now.ed]+v)
				{
					dis[st][to]=dis[st][now.ed]+v;
					q.push(pii{dis[st][to],to});
				}
			}
		}
	}
	
	void solve()
	{
		memset(dis,0x3f,sizeof(dis));
		s[1]=0;
		for(int i=2;i<=n;i++)
			scanf("%d",&s[i]);
		while(m--)
		{
			scanf("%d %d",&x,&y);
			mp[x].push_back(pii{1,y});
			mp[y].push_back(pii{1,x});
		}

		memset(dis,0x3f,sizeof(dis));

		for(int i=1;i<=n;i++)
			dij(i);
		
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(dis[i][j])dis[i][j]--;
		
		for(int i=2;i<=n;i++)
		{
			for(int j=2;j<=n;j++)
			{
				if(i==j)continue;
				if(dis[1][j]<=tot&&dis[j][i]<=tot)
					go1[i].push_back((van){j,s[j]});
			}
			sort(go1[i].begin(),go1[i].end(),cmp);
			
			for(int j=2;j<=n;j++)
			{
				if(i==j)continue;
				if(dis[i][j]<=tot&&dis[j][1]<=tot)
					go2[i].push_back((van){j,s[j]});
					
			}
			sort(go2[i].begin(),go2[i].end(),cmp);
		}
			
		
		for(int b=2;b<=n;b++)
			for(int c=2;c<=n;c++)
			{
				if(b==c)continue;
				if(dis[b][c]>tot)continue;
				bool ok=0;
				for(int i=0;i<go1[b].size();i++)
				{
					int a=go1[b][i].po;
					if(a==b||a==c)continue;
					for(int j=0;j<go2[c].size();j++)
					{
						int d=go2[c][j].po;
						
						if(b==d||c==d||a==d)continue;
						ans=max(ans,s[b]+s[c]+s[d]+s[a]);
						ok=true;
						break;
					}
					if(ok)break;
				}
			}
				
				
		printf("%lld",ans);
	}
}

int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	scanf("%d %d %d",&n,&m,&tot);
	if(n<=300&&m<=1000)P70::solve();
	else P100::solve();
	
	fclose(stdin);
	fclose(stdout);
}
/*
8 8 1
9 7 1 8 2 3 6
1 2 
2 3
3 4
4 5
5 6
6 7
7 8
8 1

7 9 0
1 1 1 2 3 4
1 2 
2 3
3 4
1 5
1 6
1 7
5 4
6 4
7 4



*/