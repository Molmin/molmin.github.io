#include<bits/stdc++.h>
using namespace std;



int n,q,k;


namespace P16
{	
	const int M=2e5+5;
		
	int a,b,s,t;
	int v[M],lg[M],val[M];
	vector<int> mp[M];
	int dep[M],fa[M][30];
	
	void dfs(int now,int fat)
	{
		dep[now]=dep[fat]+1,val[now]=val[fat]+v[now],fa[now][0]=fat;
		for(int i=0;i<mp[now].size();i++)
		{
			int to=mp[now][i];
			if(to==fat)continue;
			dfs(to,now);
		}
		for(int i=1;i<=lg[dep[now]];i++)
			fa[now][i]=fa[fa[now][i-1]][i-1];
	}
	int LCA(int x,int y)
	{
		if(dep[x]<dep[y])swap(x,y);
		while(dep[x]>dep[y])
		{
			x=fa[x][lg[dep[x]-dep[y]]];
//			cout<<x;
		}
		if(x==y)return x;
		for(int i=lg[dep[x]]-1;i>=0;i--)
			if(fa[x][i]!=fa[y][i])
			{
				x=fa[x][i];
				y=fa[y][i];
			}
		return fa[x][0];
	}
	void solve()
	{
		for(int i=1;i<=M-5;i++)
			lg[i]=log2(i);
		for(int i=1;i<=n;i++)scanf("%d",&v[i]);
		for(int i=1;i<=n-1;i++)
		{
			scanf("%d %d",&a,&b);
			mp[a].push_back(b);
			mp[b].push_back(a);
		}
		
		dfs(1,0);
		
//		cout<<LCA(6,7);
		
		while(q--)
		{
			scanf("%d %d",&s,&t);
			int lca=LCA(s,t);
			printf("%d\n",val[s]+val[t]-val[lca]*2+v[lca]);
		}
	}
}

int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	
	scanf("%d %d %d",&n,&q,&k);
	
	if(k==1)P16::solve();
	
	
	fclose(stdin);
	fclose(stdout);
}

/*

7 3 1
1 2 3 4 5 6 7
1 2 
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2


*/