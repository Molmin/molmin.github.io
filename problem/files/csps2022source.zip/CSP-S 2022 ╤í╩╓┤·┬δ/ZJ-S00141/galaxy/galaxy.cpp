#include<bits/stdc++.h>
#define re register
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	srand(0);
	int n,m;
	cin>>n>>m;
	for(re int i=1;i<=m;++i){
		int u,v;
		cin>>u>>v;
	}
	int q;
	cin>>q;
	while(q--){
		int x=rand()%2;
		cout<<(x?"YES":"NO")<<endl;
	}
} 
