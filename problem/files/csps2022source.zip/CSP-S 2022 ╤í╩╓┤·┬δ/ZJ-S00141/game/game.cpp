#include<bits/stdc++.h>
#define re register
#define int long long
#define inf 0x7fffffff
#define N 100010
using namespace std;
int s1[6][N][21],s2[6][N][21];
int sum[3][N];
int n,m,q;
int a[N],b[N];
int query1(int id,int l,int r){
	int k=log2(r-l+1);
	if(id==1||id==4) return max(s1[id][l][k],s1[id][r-(1<<k)+1][k]);
	else return min(s1[id][l][k],s1[id][r-(1<<k)+1][k]);
}
int query2(int id,int l,int r){
	int k=log2(r-l+1);
	if(id==1||id==4) return max(s2[id][l][k],s2[id][r-(1<<k)+1][k]);
	else return min(s2[id][l][k],s2[id][r-(1<<k)+1][k]);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>q;
	for(re int i=1;i<=n;++i){
		cin>>a[i];
		if(a[i]>0){
			s1[1][i][0]=a[i];//�������ֵ 
			s1[2][i][0]=a[i];//������Сֵ 
			s1[3][i][0]=0;//������Сֵ 
			s1[4][i][0]=-inf;//�������ֵ 
		}
		if(a[i]<0) {
			s1[1][i][0]=0;
			s1[2][i][0]=inf;
			s1[3][i][0]=a[i];
			s1[4][i][0]=a[i];
		} 
		if(a[i]==0){
			s1[1][i][0]=0;
			s1[2][i][0]=inf;
			s1[3][i][0]=0;
			s1[4][i][0]=-inf;
			sum[1][i]=sum[1][i-1]+1;
		}else sum[1][i]=sum[1][i-1];
	}
//	cout<<-inf<<endl;
	for(re int i=1;i<=m;++i){
		cin>>b[i];
		if(b[i]>0){
			s2[1][i][0]=b[i];//�������ֵ 
			s2[2][i][0]=b[i];//������Сֵ 
			s2[3][i][0]=0;//������Сֵ 
			s2[4][i][0]=-inf;//�������ֵ 
		}
		if(b[i]<0) {
			s2[1][i][0]=0;
			s2[2][i][0]=inf;
			s2[3][i][0]=b[i];
			s2[4][i][0]=b[i];
		} 
		if(b[i]==0){
			s2[1][i][0]=0;
			s2[2][i][0]=inf;
			s2[3][i][0]=0;
			s2[4][i][0]=-inf;
			sum[2][i]=sum[2][i-1]+1;
		}else sum[2][i]=sum[2][i-1];
	}
	for(re int i=1;i<=20;++i){
		for(re int j=1;j+(1<<i)-1<=n;++j){
			s1[1][j][i]=max(s1[1][j][i-1],s1[1][j+(1<<(i-1))][i-1]);
			s1[2][j][i]=min(s1[2][j][i-1],s1[2][j+(1<<(i-1))][i-1]);
			s1[3][j][i]=min(s1[3][j][i-1],s1[3][j+(1<<(i-1))][i-1]);
			s1[4][j][i]=max(s1[4][j][i-1],s1[4][j+(1<<(i-1))][i-1]);
		}
	}
	for(re int i=1;i<=20;++i){
		for(re int j=1;j+(1<<i)-1<=m;++j){
			s2[1][j][i]=max(s2[1][j][i-1],s2[1][j+(1<<(i-1))][i-1]);
			s2[2][j][i]=min(s2[2][j][i-1],s2[2][j+(1<<(i-1))][i-1]);
			s2[3][j][i]=min(s2[3][j][i-1],s2[3][j+(1<<(i-1))][i-1]);
			s2[4][j][i]=max(s2[4][j][i-1],s2[4][j+(1<<(i-1))][i-1]);
		}
	}
//	cout<<query1(1,1,7)<<endl;
//	cout<<log2(7)<<endl;
//	cout<<query1(4,3,3)<<endl;
	while(q--){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		int x1=query1(4,l1,r1);//a[l1,r1]�еĸ������ֵ 
		int x2=query2(4,l2,r2);//b[l2,r2]�еĸ������ֵ
//		cout<<x1<<" "<<x2<<endl;
		int y1=sum[1][r1]-sum[1][l1-1];
		int y2=sum[2][r2]-sum[2][l2-1];
		if(x1==-inf&&x2==-inf){
//			cout<<1<<endl;
			if(y2!=0){
				cout<<0<<endl;
				continue;
			}
			int z1=query1(1,l1,r1);
			int z2=query2(2,l2,r2);
			cout<<z1*z2<<endl;
			continue;
		} 
		int q1=query1(2,l1,r1);
		int q2=query2(2,l2,r2);
		if(q1==inf&&q2==inf){
//			cout<<2<<endl;
			if(y2!=0){
				cout<<0<<endl;
				continue;
			}
			int z1=query1(3,l1,r1);
			int z2=query2(4,l2,r2);
			cout<<z1*z2<<endl;
			continue;
		}
		if(x1==-inf&&q2==inf){
			int z1=query1(2,l1,r1);
			int z2=query2(3,l2,r2);
//			cout<<8<<endl;
			cout<<z1*z2<<endl;
			continue;
		}
		if(q1==inf&&x2==-inf){
			int z1=query1(4,l1,r1);
			int z2=query2(1,l2,r2);
//			cout<<9<<endl;
			cout<<z1*z2<<endl;
			continue;
		}
		if(x1==-inf){
//			cout<<3<<endl;
			int z1=query1(2,l1,r1);
			int z2=query2(3,l2,r2);
			cout<<z1*z2<<endl;
			continue;
		}
		if(x2==-inf){
//			cout<<4<<endl;
			int z1=query1(1,l1,r1);
			int z2=query2(2,l2,r2);
//			cout<<z1<<" "<<z2<<endl;
			cout<<z1*z2<<endl;
			continue;
		}
		if(q1==inf){
//			cout<<5<<endl;
			int z1=query1(4,l1,r1);
			int z2=query2(1,l2,r2);
//			if(z1==0||z2==0) cout<<-1<<endl;
			cout<<z1*z2<<endl;
			continue;
		}
		if(q2==inf){
//			cout<<6<<endl;
			int z1=query1(3,l1,r1);
			int z2=query2(4,l2,r2);
			cout<<z1*z2<<endl;
			continue;
		}
		int w1=query2(3,l2,r2);
		int w2=query2(1,l2,r2);
		int z1=query1(2,l1,r1);
		int z2=query1(4,l1,r1);
		if(sum[1][r1]-sum[1][l1-1]!=0){
//			cout<<7<<endl;
			cout<<0<<endl;
			continue;
		}
//		cout<<8<<endl;
		cout<<max(w1*z1,w2*z2)<<endl;
	}
} 
