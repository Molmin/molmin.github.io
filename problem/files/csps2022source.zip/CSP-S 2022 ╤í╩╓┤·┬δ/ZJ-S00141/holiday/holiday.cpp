#include<bits/stdc++.h>
#define re register
#define inf 0x7fffffff
#define N 2501
#define M 30001
using namespace std;
int n,m,k;
struct edge{
	int next,to;
}e[M];
int head[M<<2],cnt;
int a[N];
vector<int> v[N];
void add(int u,int v){
	e[++cnt].to=v;
	e[cnt].next=head[u];
	head[u]=cnt;
}
struct node{
	int pos,dis;
	bool operator < (const node &x) const{
		return x.dis<dis;
	}
};
priority_queue<node> q;
int dis[N][6],vis[N];
int f[N][N];
void bfs(int s){
	memset(vis,0,sizeof vis);
	for(re int i=1;i<=n;++i) dis[i][0]=inf;
	dis[s][0]=-1;
	q.push((node){s,-1});
	while(!q.empty()){
		node tmp=q.top();
		q.pop();
		int x=tmp.pos,t=tmp.dis;
//		cout<<x<<" "<<t<<endl;
		if(t>k){
			continue;
	    }
		if(vis[x]) continue;
		vis[x]=1;
		for(re int i=head[x];i;i=e[i].next){
			int y=e[i].to;
			if(dis[y][0]>dis[x][0]+1){
				dis[y][0]=dis[x][0]+1;
				if(!vis[y]&&dis[y][0]<=k){
					q.push((node){y,dis[y][0]});
				}
			}
		}
	}
	for(re int i=1;i<=n;++i){
		if(dis[i][0]<=k){
			f[s][i]=1;
			v[s].push_back(i);
		} 
//		cout<<dis[i]<<" ";
	}
//	cout<<endl;
}
struct point{
	int pos,dis,time;
	bool operator < (const point &x)const{
		return x.dis>dis;
	}
}; 
priority_queue<point> q2;
void dijsktra(){
	memset(vis,0,sizeof vis);
	for(re int i=1;i<=n;++i) dis[i][0]=-inf;
	dis[1][0]=0;
	q2.push((point){1,0,0});
	while(!q2.empty()){
		point tmp=q2.top();
		q2.pop();
		int x=tmp.pos,t=tmp.time,d=tmp.dis;
//		cout<<x<<" "<<t<<endl;
		if(t>=4) continue;
		if(vis[x]) continue;
		vis[x]=1;
//		cout<<x<<" "<<t<<endl;
		for(re int i=0;i<v[x].size();++i){
			int y=v[x][i];
			if(dis[y][t+1]<dis[x][t]+a[y]&&t!=5&&x!=y){
				dis[y][t+1]=dis[x][t]+a[y];
				if(!vis[y]){
					q2.push((point){y,dis[y][t+1],t+1});
				}
			}
		}
	}
	int ans=0;
	for(re int i=2;i<=n;++i){
		if(f[i][1]){
			ans=max(ans,dis[i][4]);
		}
	}
//	for(re int i=1;i<=n;++i){
//		cout<<dis[i][0]<<" ";
//	}
//	cout<<endl;
	cout<<ans<<endl;
}
int ans=0;
int d[N][5];
void dfs(int x,int k,int sum){
//	cout<<x<<" "<<k<<" "<<sum<<endl;
	if(k==4){
		if(f[x][1]==1){
			ans=max(ans,sum);
		}
		return;
	}
	if(d[x][k]>sum) return;
	d[x][k]=sum;
	for(re int i=0;i<v[x].size();++i){
		int y=v[x][i];
		if(!vis[y]){
			vis[y]=1;
			dfs(y,k+1,sum+a[y]);
			vis[y]=0;
		}
	}
}
bool cmp(int x,int y){
	return a[x]>a[y];
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	for(re int i=2;i<=n;++i){
		cin>>a[i];
	}
	for(re int i=1;i<=m;++i){
		int u,v;
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	for(re int i=1;i<=n;++i){
		bfs(i);
	}
//	for(re int i=1;i<=n;++i,cout<<endl){
//		for(re int j=1;j<=n;++j){
//			cout<<f[i][j]<<" ";
//		}
//	}
//	for(re int i=1;i<=n;++i,cout<<endl){
//		for(re int j=0;j<v[i].size();++j){
//			cout<<v[i][j]<<" ";
//		}
//	}
	for(re int i=1;i<=n;++i){
		sort(v[i].begin(),v[i].end(),cmp);
	}
//	for(re int i=1;i<=n;++i,cout<<endl){
//		for(re int j=0;j<v[i].size();++j){
//			cout<<a[v[i][j]]<<" ";
//		}
//	}
	memset(vis,0,sizeof vis);
	
    vis[1]=1;
	dfs(1,0,0); 
	cout<<ans<<endl;
} 
