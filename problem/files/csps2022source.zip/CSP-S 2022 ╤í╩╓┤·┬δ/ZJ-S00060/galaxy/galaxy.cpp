#include<bits/stdc++.h>
#define I inline
#define RI register int
#define rep(i,a,b) for(RI i=a;i<=b;++i)
#define dow(i,a,b) for(RI i=a;i>=b;--i)
using namespace std;
const int N=1e3+5;
int n,m,q,op,x,y,z,vis[N],a[N],in[N],b[N],fa[N],mp[N][N];
int find(int u){ return u==fa[u]?u:fa[u]=find(fa[u]); }
I bool check(){
	rep(i,1,n) in[i]=0,fa[i]=i;
	RI mi=0,mj=0;
	rep(i,1,m) {
		in[a[i]]+=vis[i];
		RI x=find(a[i]),y=find(b[i]);
		if(x==y) mi=x,mj=y;
		else fa[x]=y; 
	}
	rep(i,1,n) if(in[i]^1) return 0;
	RI x=find(1);rep(i,2,n) if(find(i)^x) return 0;
	return mi==x;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,m) scanf("%d%d",&a[i],&b[i]),vis[i]=1,mp[a[i]][b[i]]=i;
	scanf("%d",&q);
	while(q--){
		scanf("%d",&op);
		if(op==1) scanf("%d%d",&x,&y),vis[mp[x][y]]=0;
		if(op==2){
			scanf("%d",&x);
			rep(i,1,m) if(b[i]==x) vis[i]=0;
		}
		if(op==3) scanf("%d%d",&x,&y),vis[mp[x][y]]=1;
		if(op==4){
			scanf("%d",&x);
			rep(i,1,m) if(b[i]==x) vis[i]=1;
		}
		puts(check()?"YES":"NO");
	}
	return 0;
}
