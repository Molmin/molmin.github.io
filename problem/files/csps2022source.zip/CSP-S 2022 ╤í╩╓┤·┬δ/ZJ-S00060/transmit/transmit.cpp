#include<bits/stdc++.h>
#define int long long
#define I inline
#define RI register int
#define rep(i,a,b) for(RI i=a;i<=b;++i)
#define dow(i,a,b) for(RI i=a;i>=b;--i)
#define edg(i,u,v) for(RI v,i=head[u];v=e[i].to,i;i=e[i].next)
using namespace std;
const int N=2e5+5;
struct edge{ int to,next; } e[N<<1];
int n,rt,q,k,cnt,vis[N],ans[N];
int fa[N],col[N],st[N],top,ma[N],FA[N][20],maxn[N],top2,stk[N],sz[N],m,x,y,dep[N],sum,head[N],w[N],dp[3][N];
vector<int> vec[N];
I void add(int from,int to){ e[++cnt]=(edge){to,head[from]},head[from]=cnt; }
I void calcsize(int u,int f,int x){
	sz[u]=1,dep[u]=x?0:dep[f]+1;
	maxn[u]=0x3f3f3f3f3f3f3f3f;edg(i,u,v) if(v^f&&!vis[v]) maxn[u]=min(maxn[u],w[v]);
	edg(i,u,v) if(v^f&&!vis[v]) calcsize(v,u,0),sz[u]+=sz[v],ma[u]=max(ma[u],sz[v]);
	ma[u]=max(ma[u],sum-sz[u]);if(!rt||ma[u]<ma[rt]) rt=u;
}
I void DP(int u,int f,int de){
	fa[u]=FA[u][0]=f;
	rep(i,1,19)FA[u][i]=FA[FA[u][i-1]][i-1];
	if(dep[u]<de){
		dp[de][u]=0x3f3f3f3f3f3f3f3f;
		edg(i,u,v) if(!vis[v]&&v^f) DP(v,u,de);
		return;
	}
	if(dep[u]==de){
		dp[de][u]=w[u];
		edg(i,u,v) if(!vis[v]&&v^f) DP(v,u,de);
		return;
	}
	dp[de][u]=0x3f3f3f3f3f3f3f3f;
	RI x=u;rep(i,1,k) dp[de][u]=min(dp[de][u],dp[de][x=fa[x]]+w[u]);
	RI now=fa[fa[fa[fa[u]]]];
	if(k==3) dp[de][u]=min(dp[de][u],dp[de][now]+maxn[fa[fa[u]]]+w[u]);
	edg(i,u,v) if(!vis[v]&&v^f) DP(v,u,de);
}
I void dfs(int u,int f){
	st[++top]=u;
	edg(i,u,v) if(v^f) dfs(v,u);
}
I int calc(int u,int v,int val,int rt){
	RI ans=dp[0][u]+dp[0][v]-val;
	rep(i,1,k) rep(j,1,k) if(i+j<=k) ans=min(ans,dp[i][u]+dp[j][v]);
	rep(j,1,k-1) ans=min(ans,min(dp[j][u]+dp[0][v],dp[0][u]+dp[j][v]));
	if(k==3) {
		ans=min(ans,dp[2][u]+dp[2][v]+maxn[rt]);
//		RI now=x,f=dep[x]-1;dow(i,log2(dep[x]-1),0) if(f>>i&1) x=FA[x][i];
//		RI pre=y,f=dep[x]-1;dow(i,log2(dep[x]-1),0) if(f>>i&1) y=FA[x][i];
	}
	return ans;
}
I void dfz(int u){
	fa[u]=0,vis[u]=1;rep(i,0,k-1) DP(u,0,i);
	top2=0;RI now=w[u],dot=u;
	edg(i,u,v) if(!vis[v]){
		top=0;
		dfs(v,u);
		rep(i,1,top){
			RI x=st[i];
			for(RI j=0;j<vec[x].size();++j){
				RI y=vec[x][j]/N,id=vec[x][j]%N;
				if(y==u) ans[id]=dp[0][x];
				if(col[y]) ans[id]=calc(x,y,now,dot);
			}
		}
		rep(i,1,top) stk[++top2]=st[i],col[st[i]]=1;
	}
	while(top2) col[stk[top2]]=0,--top2;
	edg(i,u,v) if(!vis[v])
		sum=sz[v],rt=0,calcsize(v,u,0),calcsize(rt,u,1),maxn[rt]=min(maxn[rt],w[u]),dfz(rt);
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	dp[1][0]=dp[2][0]=dp[0][0]=0x3f3f3f3f3f3f3f3f;
	scanf("%lld%lld%lld",&n,&q,&k),sum=n;
	rep(i,1,n) scanf("%lld",&w[i]);
	rep(i,2,n) scanf("%lld%lld",&x,&y),add(x,y),add(y,x);
	rep(i,1,q) scanf("%lld%lld",&x,&y),vec[x].push_back(y*N+i),vec[y].push_back(x*N+i);
	calcsize(1,0,0),calcsize(rt,0,1);
	dfz(rt);
	rep(i,1,q) printf("%lld\n",ans[i]);
	return 0;
}
