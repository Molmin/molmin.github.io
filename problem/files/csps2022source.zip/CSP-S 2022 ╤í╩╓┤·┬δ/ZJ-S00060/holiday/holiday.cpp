#include<bits/stdc++.h>
#define int long long
#define I inline
#define RI register int
#define rep(i,a,b) for(RI i=a;i<=b;++i)
#define dow(i,a,b) for(RI i=a;i>=b;--i)
#define edg(i,u,v) for(RI v,i=head[u];v=e[i].to,i;i=e[i].next)
using namespace std;
const int N=2e5+5;
struct edge{ int to,next; } e[N<<1];
int n,m,k,ans,cnt,x,y,vis[N],w[N],f[N],dp[N][3],mj[N][3],dis[2505][2505],head[N<<1];
vector<int> v[N];
I void add(int from,int to){ e[++cnt]=(edge){to,head[from]},head[from]=cnt; }
I void bfs(int s){
	queue<int> q;vis[s]=1,q.push(s);
	rep(i,1,n) vis[i]=0,dis[s][i]=-1;dis[s][s]=0;
	while(!q.empty()){
		RI u=q.front();q.pop();
		edg(i,u,v) if(!vis[v]) vis[v]=1,dis[s][v]=dis[s][u]+1,q.push(v);
	} dis[s][s]=-1;
}
I bool check(int a,int b,int c,int d){ return d^a&&d^c; }
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);++k;
	rep(i,2,n) scanf("%lld",&w[i]);
	rep(i,1,m) scanf("%lld%lld",&x,&y),add(x,y),add(y,x);
	rep(i,1,n) bfs(i);
	rep(i,1,n) rep(j,1,n) if(dis[i][j]>k) dis[i][j]=-1;
	rep(i,1,n) if(dis[1][i]!=-1) f[i]=w[i];
	rep(i,2,n) rep(j,2,n) if(dis[j][i]!=-1) {
		if(f[j]+w[i]>dp[i][0])
			dp[i][2]=dp[i][1],mj[i][2]=mj[i][1],
			dp[i][1]=dp[i][0],mj[i][1]=mj[i][0],dp[i][0]=f[j]+w[i],mj[i][0]=j;
		else if(f[j]+w[i]>dp[i][1]) dp[i][2]=dp[i][1],mj[i][2]=mj[i][1],dp[i][1]=f[j]+w[i],mj[i][1]=j;
		else if(f[j]+w[i]>dp[i][2]) dp[i][2]=f[j]+w[i],mj[i][2]=j;
	}
	rep(i,2,n) rep(j,2,n) if(i^j&&dis[i][j]!=-1){
		rep(k,0,2) if(mj[i][k]&&mj[i][k]!=j) rep(l,0,2) if(mj[j][l]&&check(i,j,mj[i][k],mj[j][l]))
			ans=max(ans,dp[i][k]+dp[j][l]);
	}
	return printf("%lld\n",ans),0;
}
