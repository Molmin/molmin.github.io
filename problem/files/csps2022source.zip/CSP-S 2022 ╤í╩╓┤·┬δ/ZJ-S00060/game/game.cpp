#include<bits/stdc++.h>
#define int long long
#define I inline
#define RI register int
#define rep(i,a,b) for(RI i=a;i<=b;++i)
#define dow(i,a,b) for(RI i=a;i>=b;--i)
using namespace std;
const int N=1e3+5;
int n,m,q,l1,r1,l2,r2,a[N],b[N],c[N][N],st[N][N][11];
I int query(int k,int l,int r){
	RI lg=log2(r-l+1);
	return min(st[k][l][lg],st[k][r-(1<<lg)+1][lg]);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	rep(i,1,n) scanf("%lld",&a[i]);
	rep(i,1,m) scanf("%lld",&b[i]);
	rep(i,1,n) rep(j,1,m) c[i][j]=st[i][j][0]=a[i]*b[j];
	rep(k,1,n) rep(j,1,10) rep(i,1,m) st[k][i][j]=min(st[k][i][j-1],st[k][i+(1<<j-1)][j-1]);
	while(q--){
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		RI ans=-0x7f7f7f7f7f7f7f7f;
		rep(i,l1,r1) ans=max(ans,query(i,l2,r2));
		printf("%lld\n",ans);
	}
	return 0;
}
