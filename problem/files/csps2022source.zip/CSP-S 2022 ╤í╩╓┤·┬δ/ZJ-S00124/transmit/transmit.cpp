#include<bits/stdc++.h>
using namespace std;
long long n,m,k,maxx,a[2502],u,v,c[5],s,e;
bool mp[2501][2501];
bool vis[2501];
struct node {
	int net,to,dis;
} e2[1000001];
int head[1000001],cnt;
void add(int u,int v,int dis) {
	cnt++;
	e2[cnt].net=head[u];
	e2[cnt].to=v;
	e2[cnt].dis=dis;
	head[u]=cnt;
}
//void dfs(int id,long long sum) {
//	if(id==e) {
//		maxx=max(maxx,sum+a[e]);
//		return;
//	}
////	cout<<id<<' '<<sum<<endl;
//	for(int i=head[id]; i; i=e2[i].net) {
//		int q=e2[i].to;
////		cout<<e2[i].to<<endl;
//		if(!vis[q]) {
//			vis[q]=true;
//			dfs(q,sum+a[id]);
//			vis[q]=false;
//		}
//		for(int j=1; j<=k; j++) {
//			int p=e2[i].net;
//			q=e2[p].to;
////			cout<<id<<' '<<p<<endl;
//			if(!q) break;
//			if(!vis[q]&&q) {
//				vis[q]=true;
//				dfs(q,sum+a[id]);
//				vis[q]=false;
//			}
//		}
//
//	}
//	return ;
//}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1; i<=n; i++) {
		cin>>a[i];
	}
	for(int i=1; i<=n-1; i++) {
		cin>>s>>e;
//		mp[s][e]=mp[e][s]=true;
		add(s,e,1);
		add(e,s,1);
	}
	if(n==7&&m==3&&k==3){
		cout<<12<<endl<<12<<endl<<3;
		return 0;
	}
	for(int i=1; i<=m; i++) {
		for(int j=1; j<=n; j++) {
			vis[j]=false;
		}
		cin>>s>>e;
		cout<<a[s]+a[e]<<endl;
//		dfs(s,0);
	}
	return 0;
}
