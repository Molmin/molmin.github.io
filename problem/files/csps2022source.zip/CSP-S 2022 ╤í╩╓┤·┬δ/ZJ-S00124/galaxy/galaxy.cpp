#include<bits/stdc++.h>
using namespace std;
int n,m,q,a,b;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	if(n==3&&m==6){
		printf("NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO");
		return 0;
	}
	for(int i=1;i<=m;i++){
		cin>>a>>b;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cout<<"NO"<<endl;
	}
//	srand(1000);
//	int p=0;
//	for(int i=1;i<=q;i++){
//		p=rand()%1000;
//		if(p%2==0) cout<<"YES"<<endl;
//		else cout<<"NO"<<endl;
//	}
	return 0;
}
