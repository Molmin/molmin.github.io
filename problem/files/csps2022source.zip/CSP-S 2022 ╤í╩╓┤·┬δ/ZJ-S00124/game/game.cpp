#include<bits/stdc++.h>
#define ll long long
#define inf 1e11
using namespace std;
ll n,m,xf[100001],yf[100001],x[100001],y[100001],q,l1,l2,r1,r2,maxx,minn;
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1; i<=n; i++) {
		scanf("%lld",&x[i]);
		xf[i]=xf[i-1];
		if(x[i]<0) {
			xf[i]++;
		}
	}
	for(int j=1; j<=m; j++) {
		scanf("%lld",&y[j]);
		yf[j]=yf[j-1];
		if(y[j]<0) {
			yf[j]++;
		}
	}
	while(q) {
		q--;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		if(yf[m]+xf[n]==0) {
			maxx=-inf,minn=inf;
			for(int i=l1; i<=r1; i++) {
				maxx=max(maxx,x[i]);
			}
			for(int i=l2; i<=r2; i++) {
				minn=min(minn,y[i]);
			}
			cout<<maxx*minn<<endl;
		} else {
			if(l1==r1) {
				if(x[l1]<0) {
					maxx=-inf;
					for(int i=l2; i<=r2; i++) {
						maxx=max(maxx,y[i]);
					}
					cout<<x[l1]*maxx<<endl;
				} else {
					minn=inf;
					for(int i=l2; i<=r2; i++) {
						minn=min(minn,y[i]);
					}
					cout<<minn*x[l1]<<endl;
				}
			} else if(l2==r2) {
				if(y[l2]<0) {
					minn=inf;
					for(int i=l1; i<=r1; i++) {
						minn=min(minn,x[i]);
					}
					cout<<minn*y[l2]<<endl;

				} else {
					maxx=-inf;
					for(int i=l1; i<=r1; i++) {
						maxx=max(maxx,x[i]);
					}
					cout<<y[l2]*maxx<<endl;
				}
			}
		}
	}
	return 0;
}
