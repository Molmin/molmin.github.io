#include<bits/stdc++.h>
using namespace std;
long long n,m,k,maxx,a[2502],u,v,c[5];
bool mp[2501][2501];
int vis[2501];
void dfs(int dep,int id,long long sum){
	if(dep==5){
		maxx=max(maxx,sum);
		return;
	}
	for(int i=1;i<=n;i++){
		if(i==id) continue;
		if(mp[id][i]&&vis[i]==k){
			vis[i]++;
			c[dep]=i;
			dfs(dep+1,i,sum+a[i]);
			vis[i]--;
		}
	}
	return ;
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2; i<=n; i++) {
		scanf("%lld",&a[i]);
	}
	for(int i=1; i<=m; i++) {
		scanf("%lld%lld",&u,&v);
		mp[u][v]=mp[v][u]=true;
	}
	dfs(1,1,0);
	cout<<maxx;
	return 0;
}
