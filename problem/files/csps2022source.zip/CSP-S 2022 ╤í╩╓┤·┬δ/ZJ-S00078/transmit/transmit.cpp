#include<bits/stdc++.h>
using namespace std;
int main ()
{
	freopen("transmit.out","w",stdin);
	srand(time(NULL));
	printf("%d",rand()%1000000000);
}
