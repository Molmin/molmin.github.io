#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int a[100005];
int b[100005];
int read()
{
	char ch=getchar();
	int f=1;
	while((ch<'0')||(ch>'9'))
	{
		if(ch=='-')
		{
			f=-1;
		}
		ch=getchar();
	}
	int s=0;
	while((ch>='0')&&(ch<='9'))
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return f*s;
}
int tree1[400005][5];
int tree2[400005][5];
bool tree10[400005];
bool tree20[400005];
void build(int p,int l,int r,int op)
{
	if(l==r)
	{
		if(op==1)
		{
			if(a[l]>0)
			{
				tree1[p][1]=a[l];tree1[p][3]=a[l];
				tree1[p][2]=0;tree1[p][4]=-1e9;
				tree10[p]=false;
			}
			if(a[l]<0)
			{
				tree1[p][1]=0;tree1[p][3]=1e9;
				tree1[p][2]=a[l];tree1[p][4]=a[l];
				tree10[p]=false;
			}
			if(a[l]==0)
			{
				tree1[p][1]=0;tree1[p][3]=1e9;
				tree1[p][2]=0;tree1[p][4]=-1e9;
				tree10[p]=true;
			}
		}
		else
		{
			if(b[l]>0)
			{
				tree2[p][1]=b[l];tree2[p][3]=b[l];
				tree2[p][2]=0;tree2[p][4]=-1e9;
				tree20[p]=false;
			}
			if(b[l]<0)
			{
				tree2[p][1]=0;tree2[p][3]=1e9;
				tree2[p][2]=b[l];tree2[p][4]=b[l];
				tree20[p]=false;
			}
			if(b[l]==0)
			{
				tree2[p][1]=0;tree2[p][3]=1e9;
				tree2[p][2]=0;tree2[p][4]=-1e9;
				tree20[p]=true;
			}
		}
		return;
	}
	int mid=(l+r)/2;
	build(p*2,l,mid,op);
	build(p*2+1,mid+1,r,op);
	if(op==1)
	{
		tree1[p][1]=max(tree1[p*2][1],tree1[p*2+1][1]);tree1[p][3]=min(tree1[p*2][3],tree1[p*2+1][3]);tree1[p][2]=min(tree1[p*2][2],tree1[p*2+1][2]);tree1[p][4]=max(tree1[p*2][4],tree1[p*2+1][4]);
		tree10[p]=tree10[p*2]|tree10[p*2+1];
	}
	else
	{
		tree2[p][1]=max(tree2[p*2][1],tree2[p*2+1][1]);tree2[p][3]=min(tree2[p*2][3],tree2[p*2+1][3]);tree2[p][2]=min(tree2[p*2][2],tree2[p*2+1][2]);tree2[p][4]=max(tree2[p*2][4],tree2[p*2+1][4]);
		tree20[p]=tree20[p*2]|tree20[p*2+1];
	}
}
int query(int p,int l,int r,int x,int y,int op1,int op2)
{
	if((r<x)||(y<l))
	{
		if(op2==1)
		{
			return 0;
		}
		if(op2==2)
		{
			return 0;
		}
		if(op2==3)
		{
			return 1e9;
		}
		if(op2==4)
		{
			return -1e9;
		}
	}
	if((x<=l)&&(r<=y))
	{
		if(op1==1)
		{
			return tree1[p][op2];
		}
		else
		{
			return tree2[p][op2];
		}
	}
	int mid=(l+r)/2;
	int t1=query(p*2,l,mid,x,y,op1,op2),t2=query(p*2+1,mid+1,r,x,y,op1,op2);
	if(op2==1)
	{
		return max(t1,t2);
	}
	if(op2==2)
	{
		return min(t1,t2);
	}
	if(op2==3)
	{
		return min(t1,t2);
	}
	if(op2==4)
	{
		return max(t1,t2);
	}
}
bool query1(int p,int l,int r,int x,int y,int op)
{
	if((r<x)||(y<l))
	{
		return false;
	}
	if((x<=l)&&(r<=y))
	{
		if(op==1)
		{
			return tree10[p];
		}
		else
		{
			return tree20[p];
		}
	}
	int mid=(l+r)/2;
	return query1(p*2,l,mid,x,y,op)|query1(p*2+1,mid+1,r,x,y,op);
}
int main ()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();m=read();q=read();
	for(int i=1;i<=n;i++)
	{
		a[i]=read();
	}
	for(int i=1;i<=m;i++)
	{
		b[i]=read();
	}
	build(1,1,n,1);
	build(1,1,m,2);
	while(q--)
	{
		long long ans=-1e18;
		int l1=read(),r1=read(),l2=read(),r2=read();
		int mx1=query(1,1,n,l1,r1,1,1),mx_1=query(1,1,n,l1,r1,1,2),mn1=query(1,1,n,l1,r1,1,3),mn_1=query(1,1,n,l1,r1,1,4);
		int mx2=query(1,1,m,l2,r2,2,1),mx_2=query(1,1,m,l2,r2,2,2),mn2=query(1,1,m,l2,r2,2,3),mn_2=query(1,1,m,l2,r2,2,4);
		bool p1=query1(1,1,n,l1,r1,1),p2=query1(1,1,m,l2,r2,2);
		if(mx1!=0)
		{
			if(mx_2!=0)
			{
				ans=max(ans,(long long)mx1*mx_2);
			}
			else if(p2==true)
			{
				ans=max(ans,(long long)0);
			}
			else
			{
				ans=max(ans,(long long)mx1*mn2);
			}
		}
		if(mx_1!=0)
		{
			if(mx2!=0)
			{
				ans=max(ans,(long long)mx_1*mx2);
			}
			else if(p2==true)
			{
				ans=max(ans,(long long)0);
			}
			else
			{
				ans=max(ans,(long long)mx_1*mn_2);
			}
		}
		if(p1==true)
		{
			ans=max(ans,(long long)0);
		}
		if(mn1!=1e9)
		{
			if(mx_2!=0)
			{
				ans=max(ans,(long long)mn1*mx_2);
			}
			else if(p2==true)
			{
				ans=max(ans,(long long)0);
			}
			else
			{
				ans=max(ans,(long long)mn1*mn2);
			}
		}
		if(mn_1!=-1e9)
		{
			if(mx2!=0)
			{
				ans=max(ans,(long long)mn_1*mx2);
			}
			else if(p2==true)
			{
				ans=max(ans,(long long)0);
			}
			else
			{
				ans=max(ans,(long long)mn_1*mn_2);
			}
		}
		printf("%lld\n",ans);
	}
}
