#include<bits/stdc++.h>
using namespace std;
int n,m,t;
int init[500005];
bool c[500005];
vector<int> mp[500005];
vector<int> mp1[500005];
queue<int> q;
int read()
{
	char ch=getchar();
	while((ch<'0')||(ch>'9'))
	{
		ch=getchar();
	}
	int s=0;
	while((ch>='0')&&(ch<='9'))
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s;
}
bool bfs()
{
	while(!q.empty())
	{
		int t=q.front();q.pop();
		for(int i=0;i<mp[t].size();i++)
		{
			if(c[mp[t][i]]==true)
			{
				return true;
			}
			c[mp[t][i]]=true;
			q.push(mp[t][i]);
		}
	}
	return false;
}
int main ()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		int u,v;
		u=read();v=read();
		mp[u].push_back(v);
		mp1[v].push_back(u);
		init[v]++;
	}
	t=read();
	while(t--)
	{
		int op=read(),x,y;
		if(op==1)
		{
			x=read();y=read();
			mp[x].erase(find(mp[x].begin(),mp[x].end(),y));
			init[x]--;
		}
		if(op==2)
		{
			x=read();
			for(int i=0;i<mp1[x].size();i++)
			{
				if(find(mp[mp1[x][i]].begin(),mp[mp1[x][i]].end(),x)!=mp[mp1[x][i]].end())
				{
					mp[mp1[x][i]].erase(find(mp[mp1[x][i]].begin(),mp[mp1[x][i]].end(),x));
					init[mp1[x][i]]=0;
				}
			}
		}
		if(op==3)
		{
			x=read();y=read();
			mp[x].push_back(y);
			init[x]++;
		}
		if(op==4)
		{
			x=read();
			for(int i=0;i<mp1[x].size();i++)
			{
				if(find(mp[mp1[x][i]].begin(),mp[mp1[x][i]].end(),x)==mp[mp1[x][i]].end())
				{
					mp[mp1[x][i]].push_back(x);
					init[mp1[x][i]]++;
				}
			}
		}
		bool p=true;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				c[j]=false;
			}
			while(!q.empty())
			{
				q.pop();
			}
			q.push(i);
			c[i]=true;
			if((bfs()!=true)||(init[i]!=1))
			{
				printf("NO\n");
				p=false;
				break;
			}
		}
		if(p==true)
		{
			printf("YES\n");
		}
	}
}
