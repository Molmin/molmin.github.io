#include<bits/stdc++.h>
using namespace std;
struct node
{
	int x,y;
	int a[5];
};
int n,m,k;
long long a[2505];
int dis[2505][2505];
long long f[6][2505];
queue<node> q;
void bfs()
{
	while(!q.empty())
	{
		node t=q.front();q.pop();
		if(t.x==4)
		{
			if(dis[t.y][1]-1>k)
			{
				continue;
			}
			f[5][1]=max(f[5][1],f[t.x][t.y]);
			continue;
		}
		for(int i=2;i<=n;i++)
		{
			if((i==t.a[1])||(i==t.a[2])||(i==t.a[3])||(i==t.a[4]))
			{
				continue;
			}
			if(dis[t.y][i]-1>k)
			{
				continue;
			}
			if(f[t.x+1][i]>=f[t.x][t.y]+a[i])
			{
				continue;
			}
			f[t.x+1][i]=f[t.x][t.y]+a[i];
			node p;
			p.x=t.x+1;p.y=i;
			p.a[1]=t.a[1];p.a[2]=t.a[2];p.a[3]=t.a[3];p.a[4]=t.a[4];
			p.a[p.x]=i;
			q.push(p);
		}
	}
}
int main ()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			dis[i][j]=1e9;
		}
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		dis[u][v]=dis[v][u]=1;
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if((i==j)||(i==k)||(j==k))
				{
					continue;
				}
				dis[i][j]=min(dis[i][j],dis[i][k]+dis[k][j]);
			}
		}
	}
	node t;
	t.x=0;t.y=1;
	t.a[1]=-1;t.a[2]=-1;t.a[3]=-1;t.a[4]=-1;
	q.push(t);
	bfs();
	printf("%lld",f[5][1]);
}
