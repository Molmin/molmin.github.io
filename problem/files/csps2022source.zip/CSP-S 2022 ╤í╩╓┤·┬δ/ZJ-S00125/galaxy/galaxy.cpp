#include <bits/stdc++.h>
using namespace std;
#define ll long long
int read()
{
	int x=0,f=1;
	char ch = getchar();
	while (ch < '0' || ch > '9')
		{
			if (ch == '-')
				f = -1;
			ch = getchar();
		}
	while (ch >= '0' && ch <= '9')
		{
			x = x * 10 + ch - '0';
			ch = getchar();
		}
	return x*f;
}
int n,m,q,opt,x,y;
int head[1001000],nnext[1001000],to[1001000],cnt;
int anti_head[1001000],anti_nnext[1001000],anti_to[1001000],anti_cnt;
int brk[1001000],cnts[1001000],totcnt;
void add(int u,int v)
{
	++cnt;
	nnext[cnt] = head[u];
	head[u] = cnt;
	to[cnt] = v;
}
void anti_add(int u,int v)
{
	++anti_cnt;
	anti_nnext[anti_cnt] = anti_head[u];
	anti_head[u] = anti_cnt;
	anti_to[anti_cnt] = v;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n = read();
	m = read();
	for (int i=1;i<=m;++i)
		{
			int a,b;
			a = read();
			b = read();
			add(a,b);
			anti_add(b,a);
			++cnts[a];
			brk[i] = 0;
		}
	totcnt = m;
	q = read();
	for (int i=1;i<=q;++i)
		{
			opt = read();
			x = read();
			if (opt == 1)
				{
					y = read();
					for (int j=head[x];j;j=nnext[j])
						{
							int k = to[j];
							if (k == y)
								{
									if (brk[j] == 0)
										{
											--cnts[x];
											--totcnt;
											brk[j] = 1;
										}
									break;
								}
						}
				}
			else if (opt == 2)
				{
					for (int j=anti_head[x];j;j=anti_nnext[j])
						{
							int k = anti_to[j];
							if (brk[j] == 0)
								{
									--cnts[k];
									--totcnt;
									brk[j] = 1;
								}
						}
				}
			else if (opt == 3)
				{
					y = read();
					for (int j=head[x];j;j=nnext[j])
						{
							int k = to[j];
							if (k == y)
								{
									if (brk[j] == 1)
										{
											++cnts[x];
											++totcnt;
											brk[j] = 0;
										}
									break;
								}
						}
				}
			else
				{
					for (int j=anti_head[x];j;j=anti_nnext[j])
						{
							int k = anti_to[j];
							if (brk[j] == 1)
								{
									++cnts[k];
									++totcnt;
									brk[j] = 0;
								}
						}
				}
			if (totcnt != n)
				printf("NO\n");
			else
				{
					int flag = 1;
					for (int j=1;j<=n;++j)
						if (cnts[j] != 1)
							{
								flag = 0;
								break;
							}
					if (flag)
						printf("YES\n");
					else
						printf("NO\n");
				}
		}
	return 0;
}