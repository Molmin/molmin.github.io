#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll read()
{
	ll x=0,f=1;
	char ch = getchar();
	while (ch < '0' || ch > '9')
		{
			if (ch == '-')
				f = -1;
			ch = getchar();
		}
	while (ch >= '0' && ch <= '9')
		{
			x = x * 10 + ch - '0';
			ch = getchar();
		}
	return x*f;
}
ll n,q,k;
ll v[200100];
ll head[400100],nnext[400100],to[400100],cnt;
ll Path[2010][2010],vis[2010],dis[2010];
void add(ll u,ll v)
{
	++cnt;
	nnext[cnt] = head[u];
	head[u] = cnt;
	to[cnt] = v;
}
void dfs(ll st,ll x,ll len)
{
	if (len > k)
		return;
	vis[x] = 1;
	if (x != st)
		Path[st][x] = 1;
	for (int i=head[x];i;i=nnext[i])
		{
			ll y = to[i];
			dfs(st,y,len+1);
		}
}
void dfs2(ll x,ll fath)
{
	for (int i=1;i<=n;++i)
		if (Path[x][i] && vis[i] == 0)
			{
				if (i == fath)
					continue;
				dis[i] = min(dis[i],dis[x]+v[x]);
				vis[i] = 1;
				dfs2(i,x);
				vis[i] = 0;
			}          
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n = read();
	q = read();
	k = read();
	for (int i=1;i<=n;++i)
		v[i] = read();
	for (int i=1;i<n;++i)
		{
			int a,b;
			a = read();
			b = read();
			add(a,b);
			add(b,a);
		}
	if (n <= 2000)
		{
			for (int i=1;i<=n;++i)
				{
					for (int j=1;j<=n;++j)
						vis[j] = 0;
					dfs(i,i,0);
				}
			for (int i=1;i<=q;++i)
				{
					int st,ed;
					st = read();
					ed = read();
					for (int j=1;j<=n;++j)
						dis[j] = 1000000000000;
					for (int j=1;j<=n;++j)
						vis[j] = 0;
					dis[st] = 0;
					dfs2(st,0);
					printf("%lld\n",dis[ed]+v[ed]);
				}
		}
	return 0;
}