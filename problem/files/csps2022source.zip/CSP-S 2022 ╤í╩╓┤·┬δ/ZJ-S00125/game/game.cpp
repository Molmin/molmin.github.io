#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll read()
{
	ll x=0,f=1;
	char ch = getchar();
	while (ch < '0' || ch > '9')
		{
			if (ch == '-')
				f = -1;
			ch = getchar();
		}
	while (ch >= '0' && ch <= '9')
		{
			x = x * 10 + ch - '0';
			ch = getchar();
		}
	return x*f;
}
const ll INF = 1000000000000000000;
class Segment_tree
{
	public:
		ll maxx[2000100],minn[2001000],num[200100];
		void Get_num(ll x)
		{
			for (int i=1;i<=x;++i)
				num[i] = read();
		}
		void Build(ll l,ll r,ll id)
		{
			maxx[id] = -INF;
			minn[id] = INF;
			if (l == r)
				{
					maxx[id] = num[l];
					minn[id] = num[l];
					return;
				}
			ll mid = (l+r) / 2;
			Build(l,mid,id*2);
			Build(mid+1,r,id*2+1);
			maxx[id] = max(maxx[id*2],maxx[id*2+1]);
			minn[id] = min(minn[id*2],minn[id*2+1]);
		}
		ll Find_max(ll l,ll r,ll ql,ll qr,ll id)
		{
			if (ql <= l && r <= qr)
				return maxx[id];
			ll mid = (l+r) / 2;
			ll maxxi = -INF; 
			if (ql <= mid)
				maxxi = max(maxxi,Find_max(l,mid,ql,qr,id*2));
			if (mid < qr)
				maxxi = max(maxxi,Find_max(mid+1,r,ql,qr,id*2+1));
			return maxxi;
		}
		ll Find_min(ll l,ll r,ll ql,ll qr,ll id)
		{
			if (ql <= l && r <= qr)
				return minn[id];
			ll mid = (l+r) / 2;
			ll minni = INF; 
			if (ql <= mid)
				minni = min(minni,Find_min(l,mid,ql,qr,id*2));
			if (mid < qr)
				minni = min(minni,Find_min(mid+1,r,ql,qr,id*2+1));
			return minni;
		}
};
Segment_tree ax,bx;
ll n,m,q,lx,rx,ly,ry;
ll Score[1010][1010];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n = read();
	m = read();
	q = read();
	ax.Get_num(n);
	bx.Get_num(m);
	if (n <= 1000 && m <= 1000 && q <= 1000)
		{
			for (int i=1;i<=n;++i)
				for (int j=1;j<=m;++j)
					Score[i][j] = ax.num[i] * bx.num[j];
			for (int i=1;i<=q;++i)
				{
					lx = read();
					ly = read();
					rx = read();
					ry = read();
					ll maxxl;
					maxxl = -INF;
					for (int i=lx;i<=ly;++i)
						{
							ll minnl = INF;
							for (int j=rx;j<=ry;++j)
								minnl = min(minnl,Score[i][j]);
							maxxl = max(maxxl,minnl);
						}
					printf("%lld\n",maxxl);
				}
		}
	else
		{
			ax.Build(1,n,1);
			bx.Build(1,m,1);
			for (int i=1;i<=q;++i)
				{
					lx = read();
					ly = read();
					rx = read();
					ry = read();
					ll maxxb = bx.Find_max(1,m,rx,ry,1);
					ll minnb = bx.Find_min(1,m,rx,ry,1);
					ll maxxa = ax.Find_max(1,n,lx,ly,1);
					ll minna = ax.Find_min(1,n,lx,ly,1);
					if (lx == ly)
						{
							if (ax.num[lx] >= 0)
								printf("%lld\n",ax.num[lx]*minnb);
							else
								printf("%lld\n",ax.num[lx]*maxxb);
						}
					else if (rx == ry)
						{
							if (bx.num[rx] >= 0)
								printf("%lld\n",bx.num[rx]*maxxa);
							else
								printf("%lld\n",bx.num[rx]*minna);
						}
					else if (minna > 0 && minnb > 0)
						printf("%lld\n",maxxa*minnb);
				}
		}
	return 0;
}