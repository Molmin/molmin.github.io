#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll read()
{
	ll x=0,f=1;
	char ch = getchar();
	while (ch < '0' || ch > '9')
		{
			if (ch == '-')
				f = -1;
			ch = getchar();
		}
	while (ch >= '0' && ch <= '9')
		{
			x = x * 10 + ch - '0';
			ch = getchar();
		}
	return x*f;
}
ll n,m,k;
ll Score[5020],Path[2510][2510],vis[5020];
ll s[5020],sum[5020];
ll new_path[2510][2510];
ll f[2510][7];
void dfs(ll st,ll x,ll len)
{
	vis[x] = 1;
	if (x != st)
		new_path[st][x] = 1;
	if (len > k)
		return;
	for (int i=1;i<=n;++i)
		if (Path[x][i])
			dfs(st,i,len+1);
}
void dfs1(ll x,ll fath,ll tot,ll nows)
{
	if (tot > 5)
		return;
	if (tot == 5)
		{
			if (new_path[x][1] == 1)	
				f[1][tot] = max(f[1][tot],nows);
			return;
		}
	for (int i=1;i<=n;++i)
		if (new_path[x][i] && vis[i] != 1)
			{
				if (i == fath)
					continue;
				f[i][tot] = max(f[i][tot],nows);
				vis[i] = 1;
				dfs1(i,x,tot+1,nows+Score[i]);
				vis[i] = 0;
			}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n = read();
	m = read();
	k = read();
	Score[1] = 0;
	for (int i=2;i<=n;++i)
		s[i] = Score[i] = read();
	sort(s+1,s+n+1);
	for (int i=2;i<=n;++i)
		sum[i] = sum[i-1]+s[i];
	for (int i=1;i<=m;++i)
		{
			int a,b;
			a = read();
			b = read();
			Path[a][b] = 1;
			Path[b][a] = 1;
		}
	for (int i=1;i<=n;++i)
		{
			for (int j=1;j<=n;++j)
				vis[j] = 0;
			dfs(i,i,0);
		}
	memset(f,0x80,sizeof(f));
	memset(vis,0,sizeof(vis));
	f[1][0] = 0;
	vis[1] = 1;
	dfs1(1,0,1,0);
	printf("%lld",f[1][5]);
	return 0;
}