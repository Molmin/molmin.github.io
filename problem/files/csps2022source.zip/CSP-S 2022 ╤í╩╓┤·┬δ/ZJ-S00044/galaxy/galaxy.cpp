#include<bits/stdc++.h>
using namespace std;
int read(){
	int num=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		num=num*10+c-48;c=getchar();
	}
	return num;
}
int main(){
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	return 0;
} 
