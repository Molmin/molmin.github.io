#include<bits/stdc++.h>
#define ll long long
using namespace std;
queue <ll>q;
ll n,m,kk,h[2505],ct=1,dis[2505][2505],used[2505][2505],score[2505],ans;
struct node{
	ll v,n;
}e[20005];
void add(ll u,ll v){
	e[ct].v=v;
	e[ct].n=h[u];
	h[u]=ct++;
}
ll read(){
	ll num=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		num=num*10+c-48;c=getchar();
	}
	return num;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>kk;
	for(ll i=2;i<=n;i++){
		score[i]=read();
	}
	for(ll i=1;i<=m;i++){
		ll u=read(),v=read();
		add(u,v);
		add(v,u);
	}
	memset(dis,31,sizeof(dis));
	for(ll i=1;i<=n;i++){
		dis[i][i]=-1;
		q.push(i);
		while(!q.empty()){
			ll u=q.front();
			for(ll j=h[u];j;j=e[j].n){
				if(dis[i][e[j].v]>dis[i][u]+1){
					dis[i][e[j].v]=dis[i][u]+1;
					if(!used[i][e[j].v])q.push(e[j].v);
				}
			}
			used[i][u]=0;
			q.pop();
		}
	}
	for(ll i=2;i<=n;i++){
		if(dis[1][i]>kk)continue;
		for(ll j=2;j<=n;j++){
			if(dis[i][j]>kk||i==j)continue;
			for(ll k=2;k<=n;++k){
				if(dis[j][k]>kk||j==k||k==i)continue;
				for(ll l=2;l<=n;++l){
					if(dis[k][l]>kk||dis[l][1]>kk||k==l||l==j||l==i)continue;
					ans=max(score[i]+score[j]+score[k]+score[l],ans);
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
} 
