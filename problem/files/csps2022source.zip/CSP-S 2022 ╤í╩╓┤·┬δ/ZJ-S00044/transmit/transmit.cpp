#include<bits/stdc++.h>
using namespace std;
int read(){
	int num=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		num=num*10+c-48;c=getchar();
	}
	return num;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q;
	cin>>n>>q;
	srand(time(0));
	for(int i=1;i<=q;i++)cout<<rand()%100<<endl;
	return 0;
} 
