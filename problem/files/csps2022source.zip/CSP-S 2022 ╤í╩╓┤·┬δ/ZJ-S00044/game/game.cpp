#include<bits/stdc++.h>
using namespace std;
long long n,m,q,aa[100010],bb[100010];
long long read(){
	long long num=0,f=1;char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		num=num*(long long)10+c-(long long)48;c=getchar();
	}
	return num*f;
}

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(long long i=1;i<=n;i++)aa[i]=read();
	for(long long i=1;i<=m;i++)bb[i]=read();
	while(q--){
		long long a=read(),b=read(),c=read(),d=read();
		long long zmin=((long long)1<<62),fmax=-((long long)1<<62),z=-((long long)1<<62),f=((long long)1<<62);
		long long zmin2=((long long)1<<62),fmax2=-((long long)1<<62),z2=-((long long)1<<62),f2=((long long)1<<62);
		for(long long i=a;i<=b;i++){
			z=max(aa[i],z);
			if(aa[i]>=0)zmin=min(aa[i],zmin);
			if(aa[i]<=0)fmax=max(aa[i],fmax);
			f=min(aa[i],f);
		}
		for(long long i=c;i<=d;i++){
			z2=max(bb[i],z2);
			if(bb[i]>=0)zmin2=min(bb[i],zmin2);
			if(bb[i]<=0)fmax2=max(bb[i],fmax2);
			f2=min(bb[i],f2);
		}
		if(z2<0){
			if(f<=0)cout<<f*fmax2<<"\n";
			else if(f>0)cout<<f*f2<<"\n";
		}
		else if(z2>=0&&f2<=0){
			if(z<0)cout<<fmax*z2<<'\n';
			else if(z>=0&&f<=0)cout<<max(fmax*z2,zmin*f2)<<'\n';
			else if(f>0)cout<<zmin*f2<<'\n';
		}else{
			if(z>=0)cout<<z*zmin2<<"\n";
			else cout<<z*z2<<"\n";
		}
	}
	
	return 0;
} 
