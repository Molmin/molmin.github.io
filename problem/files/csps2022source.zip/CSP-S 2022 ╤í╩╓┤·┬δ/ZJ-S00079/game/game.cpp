#include<bits/stdc++.h>
using namespace std;
int n,m,q,inf=1e9+7,tmp[100010];
int a[400010][4],b[400010][2];
void build1(int p,int l,int r){
	if(l==r){
		a[p][2]=a[p][3]=tmp[l];
		if(tmp[l]>0)a[p][0]=tmp[l],a[p][1]=-inf;
		else if(tmp[l]<0)a[p][0]=inf,a[p][1]=tmp[l];
		return;
	}
	int mid=(l+r)>>1;
	build1(p<<1,l,mid),build1(p<<1|1,mid+1,r);
	a[p][0]=min(a[p<<1][0],a[p<<1|1][0]);
	a[p][1]=max(a[p<<1][1],a[p<<1|1][1]);
	a[p][2]=min(a[p<<1][2],a[p<<1|1][2]);
	a[p][3]=max(a[p<<1][3],a[p<<1|1][3]);
}
void build2(int p,int l,int r){
	if(l==r){
		b[p][0]=b[p][1]=tmp[l];
		return;
	}
	int mid=(l+r)>>1;
	build2(p<<1,l,mid),build2(p<<1|1,mid+1,r);
	b[p][0]=min(b[p<<1][0],b[p<<1|1][0]);
	b[p][1]=max(b[p<<1][1],b[p<<1|1][1]);
}
int mx0(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return inf;
	if(l>=ll&&r<=rr)return a[p][0];
	int mid=(l+r)>>1;
	return min(mx0(p<<1,l,mid,ll,rr),mx0(p<<1|1,mid+1,r,ll,rr));
}
int mx1(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return -inf;
	if(l>=ll&&r<=rr)return a[p][3];
	int mid=(l+r)>>1;
	return max(mx1(p<<1,l,mid,ll,rr),mx1(p<<1|1,mid+1,r,ll,rr));
}
int mx2(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return -inf;
	if(l>=ll&&r<=rr)return b[p][1];
	int mid=(l+r)>>1;
	return max(mx2(p<<1,l,mid,ll,rr),mx2(p<<1|1,mid+1,r,ll,rr));
}
int mn0(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return -inf;
	if(l>=ll&&r<=rr)return a[p][1];
	int mid=(l+r)>>1;
	return max(mn0(p<<1,l,mid,ll,rr),mn0(p<<1|1,mid+1,r,ll,rr));
}
int mn1(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return inf;
	if(l>=ll&&r<=rr)return a[p][2];
	int mid=(l+r)>>1;
	return min(mn1(p<<1,l,mid,ll,rr),mn1(p<<1|1,mid+1,r,ll,rr));
}
int mn2(int p,int l,int r,int ll,int rr){
	if(l>rr||r<ll)return inf;
	if(l>=ll&&r<=rr)return b[p][0];
	int mid=(l+r)>>1;
	return min(mn2(p<<1,l,mid,ll,rr),mn2(p<<1|1,mid+1,r,ll,rr));
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",tmp+i);
	build1(1,1,n);
	for(int i=1;i<=m;i++)scanf("%d",tmp+i);
	build2(1,1,m);
	while(q--){
		int u,d,l,r;
		scanf("%d%d%d%d",&u,&d,&l,&r);
		long long x2=mx2(1,1,m,l,r),n2=mn2(1,1,m,l,r);
		if(n2>=0){
			long long mx=mx1(1,1,n,u,d);
			if(mx>=0)printf("%lld\n",mx*n2);
			else printf("%lld\n",mx*x2);
			continue;
		}
		if(x2<=0){
			long long mn=mn1(1,1,n,u,d);
			if(mn<=0)printf("%lld\n",mn*x2);
			else printf("%lld\n",mn*n2);
			continue;
		}
		long long ans1=n2*mx0(1,1,n,u,d),ans2=x2*mn0(1,1,n,u,d);
		printf("%lld\n",max(ans1,ans2));
	}
	return 0;
}
