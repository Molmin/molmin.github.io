#include<bits/stdc++.h>
using namespace std;
int n,m,cnt[500010],st[500010],q;
bool del[500010];
vector<int>g[500010];
map<pair<int,int>,int>id;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int x;
		scanf("%d%d",st+i,&x);
		g[x].push_back(i),cnt[st[i]]++;
		id[make_pair(st[i],x)]=i;
	}
	int tot=0;
	for(int i=1;i<=n;i++)if(cnt[i]==1)tot++;
	scanf("%d",&q);
	while(q--){
		int opt,x,y;
		scanf("%d",&opt);
		if(opt==1){
			scanf("%d%d",&x,&y);
			del[id[make_pair(x,y)]]=true;
			if(--cnt[x]==1)tot++;
			else if(!cnt[x])tot--;
		}
		else if(opt==2){
			scanf("%d",&x);
			for(auto i:g[x]){
				if(!del[i]){
					del[i]=true;
					if(--cnt[st[i]]==1)tot++;
					else if(!cnt[st[i]])tot--;
				}
			}
		}
		else if(opt==3){
			scanf("%d%d",&x,&y);
			del[id[make_pair(x,y)]]=false;
			if(cnt[x]++==1)tot--;
			else if(cnt[x]==1)tot++;
		}
		else{
			scanf("%d",&x);
			for(auto i:g[x]){
				if(del[i]){
					del[i]=false;
					if(cnt[st[i]]++==1)tot--;
					else if(cnt[st[i]]==1)tot++;
				}
			}
		}
		printf(tot!=n?"NO\n":"YES\n");
	}
	return 0;
}
