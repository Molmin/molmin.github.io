#include<bits/stdc++.h>
using namespace std;
int n,k,q,fa[200010],dep[200010];
int pnt[200010],tmp[200010],cnt1,cnt2;
int fe[200010][20];
long long v[200010],f[200010];
vector<int>g[200010];
void dfs(int p){
	dep[p]=dep[fa[p]]+1;
	for(auto i:g[p]){
		if(i!=fa[p])fa[i]=p,dfs(i);
	}
}
void dfs2(int p){
	v[p]+=v[fa[p]],fe[p][0]=fa[p];
	for(int i=1;i<=18;i++)fe[p][i]=fe[fe[p][i-1]][i-1];
	for(auto i:g[p]){
		if(i!=fa[p])dfs2(i);
	}
}
int lca(int tx,int ty){
	if(dep[tx]>dep[ty])swap(tx,ty);
	for(int i=18;~i;i--)if(dep[fe[ty][i]]>=dep[tx])ty=fe[ty][i];
	for(int i=18;~i;i--)if(fe[tx][i]!=fe[ty][i])tx=fe[tx][i],ty=fe[ty][i];
	if(tx!=ty)tx=fa[tx];
	return tx;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)scanf("%d",&v[i]);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y),g[y].push_back(x);
	}
	dfs(1);
	dfs2(1);
	if(k==1){
		while(q--){
			int x,y;
			scanf("%d%d",&x,&y);
			int tx=lca(x,y);
			printf("%lld\n",v[x]+v[y]-v[fa[tx]]-v[tx]);
		}
		return 0;
	}
	while(q--){
		int x,y;
		scanf("%d%d",&x,&y);
		cnt1=cnt2=0;
		if(dep[x]>dep[y])swap(x,y);
		while(dep[x]<dep[y])tmp[++cnt2]=y,y=fa[y];
		while(x!=y)pnt[++cnt1]=x,x=fa[x],tmp[++cnt2]=y,y=fa[y];
		pnt[++cnt1]=x;
		while(cnt2)pnt[++cnt1]=tmp[cnt2--];
		f[1]=v[pnt[1]]-v[fa[pnt[1]]];
		for(int i=2;i<=cnt1;i++){
			f[i]=f[i-1];
			for(int j=2;j<=k&&j<i;j++)f[i]=min(f[i],f[i-j]);
			f[i]+=v[pnt[i]]-v[fa[pnt[i]]];
		}
		printf("%lld\n",f[cnt1]);
	}
	return 0;
}
