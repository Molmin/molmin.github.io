#include<bits/stdc++.h>
using namespace std;
int n,m,k,pri[2510],used[2510],st[10],nxt[2510];
int can[2510][2510];
int dis[2510];
long long v[2510],ans;
bool cmp(int x,int y){return v[x]>v[y];}
vector<int>g[2510];
void check(){
	for(int i=0;i<=4;i++)if(!can[pri[st[i]]][pri[st[i+1]]])return;
	for(int i=1;i<=4;i++)ans+=v[pri[st[i]]];
	printf("%lld\n",ans);
	exit(0);
}
void dfs(int dep){
	if(dep==4){
		do{check();}while(next_permutation(st+1,st+5));
		return;
	}
	for(int i=nxt[st[dep]];i<n;i=nxt[i])st[dep+1]=i,dfs(dep+1);
}
void reach(int p){
	queue<int>q;
	q.push(p);
	while(!q.empty()){
		int x=q.front();q.pop();
		if(can[p][x]==k)break;
		for(auto i:g[x])if(!can[p][i])can[p][i]=can[p][x]+1,q.push(i);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);k++;
	for(int i=2;i<=n;i++)scanf("%lld",v+i),pri[i]=i;
	pri[1]=1;
	sort(pri+1,pri+1+n,cmp);
	while(m--){
		int x,y;
		scanf("%d%d",&x,&y);
		g[x].push_back(y),g[y].push_back(x);
	}
	queue<int>q;
	q.push(1);
	while(!q.empty()){
		int x=q.front();q.pop();
		for(auto i:g[x])if(!dis[i])dis[i]=dis[x]+1,q.push(i);
	}
	int lst=n;
	for(int i=1;i<=n;i++)if(dis[pri[i]]&&dis[pri[i]]<=k<<1)nxt[lst]=i,lst=i;
	for(int i=1;i<=n;i++)reach(i);
	st[5]=st[0]=n;
	dfs(0);
	return 0;
}
