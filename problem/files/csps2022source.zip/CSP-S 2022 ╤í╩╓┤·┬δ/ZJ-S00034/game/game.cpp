#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ull unsigned long long
const int M=1e5+5;
int n,m,q;
int l1,l2,r1,r2;
int a[M],b[M];
ll sum,ans,minn,maxx;
int main() {
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1; i<=n; ++i) {
		scanf("%d",&a[i]);
	}
	for(int i=1; i<=m; ++i) {
		scanf("%d",&b[i]);
	}
	for(int i=1; i<=q; ++i) {
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		sum=0,ans=-2147483628;
		for(int j=l1;j<=r1;++j) {
			minn=1e9+5;
			for(int k=l2;k<=r2;++k)
			{
				sum=a[j]*b[k];
				minn=min(minn,sum);
			}
			ans=max(ans,minn);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
