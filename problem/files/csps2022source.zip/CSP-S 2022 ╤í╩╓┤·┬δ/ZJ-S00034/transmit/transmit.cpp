#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int M=2e5+5;
int head[M],fa[M],v[M];
int ans,n,q,k;
int id;
struct edge
{
	int to,nxt;
}E[M*2];
void add(int u,int v)
{
	E[++id]=((edge){v,head[u]});
	head[u]=id;
}
void dfs(int x,int f)
{
	fa[x]=f;
	for(int i=x;i;i=fa[i])
	{
	}
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(int i=1;i<=n;++i)
	{
		scanf("%d",&v[i]);
		ans+=v[i];
	}
	for(int i=1;i<=n-1;++i)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		add(a,b);
		add(b,a);
	}
	dfs(1,0);
	dfs(n,0);
	while(q--)
	{
		int s,t;
		scanf("%d%d",&s,&t);
		cout<<ans<<endl;
	}
	return 0;
}
