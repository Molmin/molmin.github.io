#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int M=5e5+5;
int n,m,q;
int a,b;
int t,x,y;
bool ma[1010][1010];
bool c;
int sum[1010];
int chack() {
	c=0;
	if(c!=1) {
		for(int i=1; i<=n-1; ++i) {
			if(ma[i][i+1]!=1) {
				c=0;
				break;
			}
			if(i==n-1) c=1;
		}
	}
	if(c!=1) {
		for(int i=n; i>=2; --i) {
			if(ma[i][i-1]!=1) {
				c=0;
				break;
			}
			if(i==2) c=1;
		}
	}
	if(c!=1) {
		for(int i=1; i<=n-1; ++i) {
			for(int j=i+1; j<=n; ++j) {
				if(ma[i][j]==1 && ma[j][i]==1) {
					c=1;
					break;
				}
			}
			if(c=1) break;
		}
	}
	if(c==1)
	{
		for(int i=1;i<=n;++i)
		{
			if(sum[i]==1 && i==n) c=1;
			if(sum[i]==1) continue;
			else
			{
				c=0;
				break;
			}
		}
	}
	return c;
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=m; ++i) {
		scanf("%d%d",&a,&b);
		ma[a][b]=1;
		sum[a]++;
	}
	cin>>q;
	while(q--) {
		scanf("%d",&t);
		if(t==1) {
			scanf("%d%d",&x,&y);
			ma[x][y]=0;
			sum[x]--;
		} else if(t==2) {
			scanf("%d",&x);
			for(int i=1; i<=n; ++i) {
				if(ma[i][x]==1) {
					ma[i][x]=0;
					sum[i]--;
				}
			}
		} else if(t==3) {
			scanf("%d%d",&x,&y);
			ma[x][y]=1;
			sum[x]++;
		} else if(t==4) {
			scanf("%d",&x);
			for(int i=1; i<=n; ++i) {
				if(ma[i][x]==0) {
					ma[i][x]=1;
					sum[i]++;
				}
				if(ma[x][i]==0) {
					ma[x][i]=1;
					sum[x]++;
				}
			}
		}
		if(chack()==0) printf("NO\n");
		else printf("YES\n");
	}
	return 0;
}
