#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int M=1e5+5;
bool ma[2505][2505];
int sum[2505],v[2505];
int n,m,k,cnt;
bool b[2505];
ll ans;
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2; i<=n; ++i) {
		int a;
		scanf("%d",&a);
		v[i]=a;
	}
	for(int i=1; i<=m; ++i) {
		int x,y;
		scanf("%d%d",&x,&y);
		ma[x][y]=1;
		ma[y][x]=1;
	}
	for(int i=2; i<=n; ++i)
	if(ma[1][i]==1)
	{
		b[i]=1;cnt++;
		for(int j=2; j<=n; ++j) 
		if(b[j]==0 && ma[i][j]==1)
		{
			b[j]=1;cnt++;
			for(int p=2; p<=n; ++p)
			if(b[p]==0 && ma[j][p]==1)
			{
				b[p]=1;cnt++;
				for(int q=2;q<=n;++q)
				if(b[q]==0 && ma[q][1]==1)
					ans=max(ans,(ll)v[i]+v[j]+v[p]+v[q]);
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
