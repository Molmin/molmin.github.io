#include <bits/stdc++.h>
using namespace std;
int v[2505];
vector <int> e[2505];
set <int> d[2505];
void dfs (int n,int m,int k) {
	if (k >= 0) {
		for (int i : e[m]) {
			dfs(n,i,k-1);
			d[n].insert(i);
		}
	}
}
long long dfs2 (int n,int k,set <int> s) {
	if (k == 0 && d[n].find(1) == d[n].end()) return -4000000000000000000;
	else if (k == 0) return 0;
	long long ans = 0;
	bool flag = 1;
	for (int i : d[n]) {
		if (s.find(i) != s.end() || i == 1) continue;
		s.insert(i);
		flag = 0;
		ans = max(ans,v[i]+dfs2(i,k-1,s));
		s.erase(i);
	}
	if (!flag)return ans;
	return -4000000000000000000;
} 
int main (void) {
	int n,m,k;
	FILE * fin = fopen ("holiday.in","r");
	FILE * fout = fopen ("holiday.out","w");
	fscanf (fin,"%d%d%d",&n,&m,&k);
	for (int j = 2;j <= n;j++) {
		fscanf (fin,"%d",v+j);
	}
	for (int j = 0;j < m;j++) {
		int x,y;
		fscanf (fin,"%d%d",&x,&y);
		e[x].push_back(y);
		e[y].push_back(x);
	}
	for (int j = 1;j <= n;j++) {
		dfs(j,j,k);
		if (d[j].find(j) != d[j].end()) d[j].erase(j);
	}
	set <int> ss;
	ss.clear();
	fprintf (fout,"%lld\n",dfs2(1,4,ss));
	return 0;
}