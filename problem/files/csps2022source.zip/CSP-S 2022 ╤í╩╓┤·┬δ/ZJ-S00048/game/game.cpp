#include <bits/stdc++.h>
using namespace std;
vector <int> a;
vector <int> b;
int v[200005][20];
int v2[200005][20];
struct seg1 {
	int n;
	seg1(vector <int> &t) {
		n = t.size();
		for (int j = 0;j < n;j++) v[j][0] = t[j];
		int tt = floor(log(n) / log(2));
		for (int k = 1;k < tt+1;k++) {
			for (int j = 0;j < n;j++) {
				v[j][k] = max(v[j][k-1],v[j+(1<<(k-1))][k-1]);
			}
		} 
	}
	int search (int l,int r) {
		int len = r-l+1;
		int le = floor(log(len)/log(2));
		if (le == 0) return v[l][0];
		return max(v[l][le],v[r-(1<<le)+1][le]);
	}
};
struct seg2 {
	int n;
	seg2(vector <int> &t) {
		n = t.size();
		for (int j = 0;j < n;j++) v2[j][0] = t[j];
		int tt = floor(log(n) / log(2));
		for (int k = 1;k < tt+1;k++) {
			for (int j = 0;j < n;j++) {
				v2[j][k] = min(v2[j][k-1],v2[j+(1<<(k-1))][k-1]);
			}
		} 
	}
	int search (int l,int r) {
		int len = r-l+1;
		int le = floor(log(len)/log(2));
		if (le == 0) return v2[l][0];
		return min(v2[l][le],v2[r-(1<<le)+1][le]);
	}
};
int main (void) {
	int n,m,q;
	FILE * fin = fopen ("game.in","r");
	FILE * fout = fopen ("game.out","w");
	fscanf (fin,"%d%d%d",&n,&m,&q);
	for (int j = 0;j < n;j++) {
		int x;
		fscanf (fin,"%d",&x);
		a.push_back(x);
	}
	for (int j = 0;j < m;j++) {
		int x;
		fscanf (fin,"%d",&x);
		b.push_back(x);
	}
	seg1 bb(b);
	seg2 sb(b);
	while (q--) {
		long long ans = -1000000000000000000;
		int l1,l2,r1,r2;
		fscanf (fin,"%d%d%d%d",&l1,&r1,&l2,&r2);
		l1--;
		r1--;
		l2--;
		r2--;
		int l = bb.search(l2,r2);
		int s = sb.search(l2,r2);
		for (int j = l1;j <= r1;j++) {
			ans = max(ans,min((long long)l*a[j],(long long)s*a[j]));
		}
		fprintf (fout,"%lld\n",ans);
	}
	return 0;
}