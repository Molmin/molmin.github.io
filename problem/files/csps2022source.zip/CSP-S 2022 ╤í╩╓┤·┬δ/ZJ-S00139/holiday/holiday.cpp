#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<queue>
#define Max(a,b) (((a)>(b))?(a):(b))
#define Min(a,b) (((a)<(b))?(a):(b))
using namespace std;
const int Mxn=2505,Mxm=10005;
struct E {
	int To;
	int Next;
} Eg[Mxm*2];
int Tot,iHead[Mxn];
void MyAdd(int x,int y) {
	Eg[++Tot].To=y;
	Eg[Tot].Next=iHead[x];
	iHead[x]=Tot;
}
int N,M,K,X,Y;
long long S[Mxn],ANS;
void MyDFS(int x,int Father,int Loc,long long Sco) {
	if(Loc==4) {
		for(int i=iHead[x]; i; i=Eg[i].Next) {
			if(Eg[i].To==1) {
				ANS=Max(ANS,Sco);
				return;
			}
		}
		return ;
	}
	for(int i=iHead[x]; i; i=Eg[i].Next) {
		if(Eg[i].To==Father) continue;
//		cout<<Eg[i].To<<" "<<Loc+1<<" "<<Sco+S[Eg[i].To]<<endl;
		MyDFS(Eg[i].To,x,Loc+1,Sco+S[Eg[i].To]);
	}
}
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&N,&M,&K);
	for(int i=2; i<=N; i++) scanf("%lld",&S[i]);
	for(int i=1; i<=M; i++) {
		scanf("%d%d",&X,&Y);
		MyAdd(X,Y),MyAdd(Y,X);
	}
	if(K==0) {
		MyDFS(1,-1,0,0);
		printf("%lld\n",ANS);
		fclose(stdin);
		fclose(stdout);
		return 0;
	} else {
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}