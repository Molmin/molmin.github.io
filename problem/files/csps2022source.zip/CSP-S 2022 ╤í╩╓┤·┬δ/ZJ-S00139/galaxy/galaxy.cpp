#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<queue>
#define Max(a,b) (((a)>(b))?(a):(b))
#define Min(a,b) (((a)<(b))?(a):(b))
using namespace std;
const int Mxn=1005,Mxm=10005;
struct E {
	int To;
	int Next;
} Eg[Mxm*2];
int Tot,iHead[Mxn];
int Out[Mxn];
bool G[Mxn][Mxn];
void MyAdd(int x,int y) {
	Eg[++Tot].To=y;
	Eg[Tot].Next=iHead[x];
	iHead[x]=Tot;
	G[x][y]=true;
	Out[x]++;
}
int N,M,X,Y,Q,C,U,V;
bool Visit[Mxn],Ret;
void MyDFS(int x) {
	Visit[x]=true;
	for(int i=iHead[x]; i; i=Eg[i].Next) {
		if(!G[x][Eg[i].To]) continue;
//		cout<<Eg[i].To<<" ";
		if(Visit[Eg[i].To]) {
			Ret=true;
			return;
		}
		MyDFS(Eg[i].To);
	}
}
bool MyInfinityCheck() {
	Ret=false;
	for(int i=1; i<=N; i++) Visit[i]=false;
	for(int S=1; S<=N; S++) {
		MyDFS(S);
		if(!Ret)return false;
	}
	return true;
}
bool MyDegreeCheck() {
//	for(int S=1; S<=N; S++) cout<<Out[S]<<" "; cout<<endl;
	for(int S=1; S<=N; S++) {
		if(Out[S]!=1) return false;
	}
	return true;
}
bool MyCheck() {
	return (MyDegreeCheck()&&MyInfinityCheck());
}
void MyPrint() {
	if(MyCheck()) printf("YES\n");
	else printf("NO\n");
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&N,&M);
	for(int i=1; i<=M; i++) {
		scanf("%d%d",&X,&Y);
		MyAdd(X,Y);
	}
	scanf("%d",&Q);
	if(N<=1000&&M<=10000) {
		while(Q--) {
			scanf("%d",&C);
			if(C==1) {
				scanf("%d%d",&U,&V);
				Out[U]=Max(0,Out[U]-1),G[U][V]=false;
				MyPrint();
			} else if(C==2) {
				scanf("%d",&U);
				for(int S=1; S<=N; S++) {
					if(S==U) continue;
					if(G[S][U]) {
						G[S][U]=false;
						Out[S]=Max(0,Out[S]-1);
					}
				}
				MyPrint();
			} else if(C==3) {
				scanf("%d%d",&U,&V);
				Out[U]++,G[U][V]=true;
				MyPrint();
			} else if(C==4) {
				scanf("%d",&U);
				for(int S=1; S<=N; S++) {
					if(S==U) continue;
					if(G[S][U]) {
						G[S][U]=true;
						Out[S]++;
					}
				}
				MyPrint();
			}
		}
	} else {
		while(Q--) {
			scanf("%d",&C);
			if(C==1)scanf("%d%d",&U,&V);
			else if(C==2)scanf("%d",&U);
			else if(C==3)scanf("%d%d",&U,&V);
			else if(C==4)scanf("%d",&U);
			printf("NO\n");
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}