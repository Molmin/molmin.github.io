#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<queue>
#define Max(a,b) (((a)>(b))?(a):(b))
#define Min(a,b) (((a)<(b))?(a):(b))
using namespace std;
const int Mxn=1005;
const long long INF=4e18;
int N,M,Q,L1,R1,L2,R2;
long long A[Mxn],B[Mxn];
long long C[Mxn][Mxn];
int main() {
//	cout<<(sizeof(A)+sizeof(B)+sizeof(C))/1024/1024<<endl;
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&N,&M,&Q);
	for(int i=1;i<=N;i++) scanf("%lld",&A[i]);
	for(int i=1;i<=M;i++) scanf("%lld",&B[i]);
	for(int i=1;i<=N;i++){
		for(int j=1;j<=M;j++){
			C[i][j]=A[i]*B[j];
//			printf("%lld ",C[i][j]);
		}
//		putchar('\n');
	}
	while(Q--){
		scanf("%d%d%d%d",&L1,&R1,&L2,&R2);
		long long ANS=-INF;
		for(int i=L1;i<=R1;i++){
			long long Tmp=INF;
			for(int j=L2;j<=R2;j++){
				Tmp=Min(Tmp,C[i][j]);
//				cout<<Tmp<<" ";
			}
			ANS=Max(ANS,Tmp);
		}
		printf("%lld\n",ANS);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}