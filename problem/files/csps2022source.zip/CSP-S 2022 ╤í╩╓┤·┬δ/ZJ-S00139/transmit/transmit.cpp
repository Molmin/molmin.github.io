#include<algorithm>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<queue>
#define Max(a,b) (((a)>(b))?(a):(b))
#define Min(a,b) (((a)<(b))?(a):(b))
using namespace std;
const int Mxn=200005;
struct E {
	int To;
	int Next;
} Eg[Mxn*2];
int Tot,iHead[Mxn];
void MyAddE(int x,int y) {
	Eg[++Tot].To=y;
	Eg[Tot].Next=iHead[x];
	iHead[x]=Tot;
}
int Father[Mxn],Lay[Mxn];
bool Visit[Mxn];
void MyDFS(int x,int Dep) {
	Visit[x]=true,Father[x]=x;
	Lay[x]=Dep;
	for(int i=iHead[x]; i; i=Eg[i].Next) {
		if(Visit[Eg[i].To]) continue;
		MyDFS(Eg[i].To,Dep+1);
		Father[Eg[i].To]=x;
	}
}
int N,Q,K,X,Y,V[Mxn];
int MySolve(int x,int y) {
	int ANS=0;
	ANS+=V[x]+V[y];
	if(Lay[x]<Lay[y]) {
		while(Lay[x]<Lay[y]) {
			y=Father[y];
			ANS+=V[y];
		}
	} else if(Lay[x]>Lay[y]) {
		while(Lay[x]>Lay[y]) {
			x=Father[x];
			ANS+=V[x];
		}
	}
	while(x!=y) {
		x=Father[x],y=Father[y];
		ANS+=V[x]+V[y];
	}
	ANS-=V[x];
	return ANS;
}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&N,&Q,&K);
	for(int i=1; i<=N; i++) scanf("%d",&V[i]);
	for(int i=1; i<N; i++) {
		scanf("%d%d",&X,&Y);
		MyAddE(X,Y),MyAddE(Y,X);
	}
	MyDFS(1,0);
//	for(int i=1;i<=N;i++) cout<<i<<" "<<Father[i]<<endl;
//	for(int i=1; i<=N; i++) cout<<i<<" "<<Lay[i]<<endl;
//	for(int i=1;i<=N;i++) cout<<V[i]<<" "; cout<<endl;
	if(K==1) {
		while(Q--) {
			scanf("%d%d",&X,&Y);
			printf("%d\n",MySolve(X,Y));
		}
	} else {
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}