#include<bits/stdc++.h>
using namespace std;
const int N = 1005;
int n, m, x, y, s[N], k[N], q, a, b, c;
bool t[N][N], d[N][N];
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	cin >> n >> m;
	while (m--) {
		cin >> x >> y; s[x]++; k[x]++; t[x][y] = true;
	}
	cin >> q;
	while (q--) {
		cin >> a >> b;
		if (a == 1) {
			cin >> c; s[b]--;
		}
		else if (a == 2) {
			for (int i = 1; i <= n; i++) {
				if (t[b][i] && !d[b][i]) s[i]--, d[b][i] = true;
			}
		}
		else if (a == 3) {
			cin >> c; s[b]++;
		}
		else {
			for (int i = 1; i <= n; i++) {
				if (t[b][i] && d[b][i]) s[i]++, d[b][i] = false;
			}
			s[b] = k[b];
		}
		bool can = true;
		for (int i = 1; i <= n; i++) {
			if (s[i] != 1) {
				can = false; break;
			}
		}
		if (can) cout << "YES\n";
		else cout << "NO\n";
	}
	return 0;
}

