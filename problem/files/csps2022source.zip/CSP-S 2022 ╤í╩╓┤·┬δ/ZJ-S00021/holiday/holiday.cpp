#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2505, M = 2e4 + 5, K = 100, D = 7;
int n, m, k, ways[N][N];
int head[N], to[M], nex[M], cnt = 0;
ll val[N], dp[N][D][K];
bool vis[N][D][K], goes[N];
void add(int u, int v) {
	to[++cnt] = v; nex[cnt] = head[u]; head[u] = cnt;
}
ll dfs(int u, int step, int last) {
	if (vis[u][step][last]) return dp[u][step][last];
	dp[u][step][last] = -1;
	for (int i = head[u]; i; i = nex[i]) {
		int v = to[i];
		if (step && !goes[u]) {
			goes[u] = true;
			ll dv = dfs(v, step - 1, k);
			if (dv != -1) dp[u][step][last] = max(dp[u][step][last], dv + val[u]);
			goes[u] = false;
		}
		if (last) {
			ll dv = dfs(v, step, last - 1);
			if (dv != -1) dp[u][step][last] = max(dp[u][step][last], dv);
		}
		
	}
	return dp[u][step][last];
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int x, y;
	cin >> n >> m >> k;
	for (int i = 2; i <= n; i++) cin >> val[i];
	for (int i = 1; i <= m; i++) {
		cin >> x >> y; add(x, y); add(y, x);
	}
	for (int i = 0; i <= k; i++) {
		vis[1][0][i] = true; dp[1][0][i] = 0;
	}
	for (int i = 2; i <= n; i++) {
		vis[i][0][0] = true; dp[i][0][0] = -1;
	}
	cout << dfs(1, 5, 0);
	return 0;
}

