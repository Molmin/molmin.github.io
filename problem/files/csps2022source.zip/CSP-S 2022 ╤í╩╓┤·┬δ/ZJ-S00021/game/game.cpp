#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1005;
int n, m, q, a[N], b[N];
int mxa[N][N], mna[N][N], mxb[N][N], mnb[N][N];
int _mxa[N][N], _mna[N][N], _mxb[N][N], _mnb[N][N];
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	memset(mxa, -1, sizeof mxa); memset(_mxa, 0, sizeof _mxa);
	memset(mna, -1, sizeof mna); memset(_mna, 0, sizeof _mna);
	memset(mxb, -1, sizeof mxb); memset(_mxb, 0, sizeof _mxb);
	memset(mnb, -1, sizeof mnb); memset(_mnb, 0, sizeof _mnb);
	cin >> n >> m >> q;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		if (a[i] >= 0) {
			mxa[i][i] = mna[i][i] = a[i];
			for (int j = 1; j < i; j++) {
				if (mxa[j][i - 1] == -1) mxa[j][i] = a[i];
				else mxa[j][i] = max(mxa[j][i - 1], a[i]); 
			}
			for (int j = 1; j < i; j++) {
				if (mna[j][i - 1] == -1) mna[j][i] = a[i];
				else mna[j][i] = min(mna[j][i - 1], a[i]); 
			}
			for (int j = 1; j < i; j++) _mxa[j][i] = _mxa[j][i - 1];
			for (int j = 1; j < i; j++) _mna[j][i] = _mna[j][i - 1];
		}
		else {
			_mxa[i][i] = _mna[i][i] = a[i];
			for (int j = 1; j < i; j++) {
				if (_mxa[j][i - 1] == 0) _mxa[j][i] = a[i];
				else _mxa[j][i] = max(_mxa[j][i - 1], a[i]);
			} 
			for (int j = 1; j < i; j++) {
				if (_mna[j][i - 1] == 0) _mna[j][i] = a[i];
				else _mna[j][i] = min(_mna[j][i - 1], a[i]);
			}	
			for (int j = 1; j < i; j++) mxa[j][i] = mxa[j][i - 1];
			for (int j = 1; j < i; j++) mna[j][i] = mna[j][i - 1];
		}
	}
	for (int i = 1; i <= m; i++) {
		cin >> b[i];
		if (b[i] >= 0) {
			mxb[i][i] = mnb[i][i] = b[i];
			for (int j = 1; j < i; j++) {
				if (mxb[j][i - 1] == -1) mxb[j][i] = b[i];
				else mxb[j][i] = max(mxb[j][i - 1], b[i]); 
			}
			for (int j = 1; j < i; j++) {
				if (mnb[j][i - 1] == -1) mnb[j][i] = b[i];
				else mnb[j][i] = min(mnb[j][i - 1], b[i]); 
			}
			for (int j = 1; j < i; j++) _mxb[j][i] = _mxb[j][i - 1];
			for (int j = 1; j < i; j++) _mnb[j][i] = _mnb[j][i - 1];
		}
		else {
			_mxb[i][i] = _mnb[i][i] = b[i];
			for (int j = 1; j < i; j++) {
				if (_mxb[j][i - 1] == 0) _mxb[j][i] = b[i];
				else _mxb[j][i] = max(_mxb[j][i - 1], b[i]); 
			}
			for (int j = 1; j < i; j++) {
				if (_mnb[j][i - 1] == 0) _mnb[j][i] = b[i];
				else _mnb[j][i] = min(_mnb[j][i - 1], b[i]);
			}	
			for (int j = 1; j < i; j++) mxb[j][i] = mxb[j][i - 1];
			for (int j = 1; j < i; j++) mnb[j][i] = mnb[j][i - 1];
	}
	}
	while (q--) {
		int q, w, e, r; cin >> q >> w >> e >> r;
		if (_mxb[e][r] == 0) {
			if (mxa[q][w] != -1) cout << (ll)mnb[e][r] * mxa[q][w] << '\n';
			else cout << (ll)mxb[e][r] * _mxa[q][w] << '\n';
		}
		else if (mxb[e][r] == -1) {
			if (_mna[q][w] != 0) cout << (ll)_mxb[e][r] * _mna[q][w] << '\n';
			else cout << (ll)_mnb[e][r] * mna[q][w] << '\n';
		}
		else {
			if (mxa[q][w] == -1) cout << (ll)_mxa[q][w] * mxb[e][r] << '\n';
			else if (_mxa[q][w] == 0) cout << (ll)mna[q][w] * _mnb[e][r] << '\n';
			else cout << max((ll)mna[q][w] * _mnb[e][r] , (ll)_mxa[q][w] * mxb[e][r]) << '\n';
		}
	}
	return 0;
}

