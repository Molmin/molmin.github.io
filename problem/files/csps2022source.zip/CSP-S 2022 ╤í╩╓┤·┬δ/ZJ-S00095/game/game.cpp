#include<bits/stdc++.h>
#define int long long
#define For(i, a, b) for(int i = a; i <= b; i++)
using namespace std;
const int N = 100000 + 5, INF = 1e18;
int read(){
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9'){
		if(ch == '-') f = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9'){
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
}
struct node{
	int l1, l2, r1, r2;
}x[N];
int n, m, q, a[N], b[N], c[N], d[N], ans;
signed main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n = read();
	m = read();
	q = read();
	For(i, 1, n) a[i] = read();
	For(i, 1, m) b[i] = read();
	For(i, 1, q){
		x[i].l1 = read();
		x[i].r1 = read();
		x[i].l2 = read();
		x[i].r2 = read();
	}
	if(n <= 10000 && m <= 10000 && q <= 10000){
		For(i, 1, q){
			ans = -INF;
			For(j, x[i].l1, x[i].r1){
				int mn = a[j] * b[x[i].l2];
				For(k, x[i].l2 + 1, x[i].r2) mn = min(mn, a[j] * b[k]);
				ans = max(ans, mn);
			}
			cout << ans << endl;
		}
		return 0;
	}
	For(i, 1, q){
		bool yz = 0, yf = 0;
		For(j, x[i].l1, x[i].r1) c[j] = a[j];
		sort(c + x[i].l1, c + x[i].r1 + 1);
		For(j, x[i].l2, x[i].r2) d[j] = b[j], yz |= (d[j] > 0), yf |= (d[j] < 0);
		sort(d + x[i].l2, d + x[i].r2 + 1);
		if(c[x[i].r1] > 0){
			if(yf){
				int p = x[i].r1;
				while(c[p] > 0 && p >= x[i].l1) p--;
				ans = c[p + 1] * d[x[i].l2];
			}
			else ans = c[x[i].r1] * d[x[i].l2];
		}
		if(c[x[i].l1] < 0){
			if(yz){
				int p = x[i].l1;
				while(c[p] < 0) p++;
				ans = max(ans, c[p - 1] * d[x[i].r2]);
			}
			else ans = max(ans, c[x[i].l1] * d[x[i].r2]);
		}
		For(j, x[i].l1, x[i].r1)
			if(c[j] == 0) ans = max(ans, (long long)0);
		For(j, x[i].l2, x[i].r2)
			if(d[j] == 0) ans = min(ans, (long long)0);
		printf("%lld\n", ans);
	}
	return 0;
}