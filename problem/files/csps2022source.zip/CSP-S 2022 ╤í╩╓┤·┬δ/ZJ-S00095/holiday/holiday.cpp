#include<bits/stdc++.h>
#define int long long
#define For(i, a, b) for(int i = a; i <= b; i++)
using namespace std;
const int N = 2500 + 5;
inline int read(){
	int x = 0, f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9'){
		if(ch == '-') f = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9'){
		x = x * 10 + ch - '0';
		ch = getchar();
	}
	return x * f;
}
int n, m, t;
int v[N], mp[N][N], mp1[N][N], ans, cnt[N];
bool vis[N];
void dfs(int dep, int noww, int jd){
	if(dep == 5){
		if(mp1[noww][1]) ans = max(ans, jd + v[noww]);
		return;
	}
	For(i, 1, cnt[noww]){
		if(!vis[mp[noww][i]]){
			vis[mp[noww][i]] = 1;
			dfs(dep + 1, mp[noww][i], jd + v[noww]);
			vis[mp[noww][i]] = 0;
		}
	}
	return;
}
signed main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n = read();
	m = read();
	t = read();
	memset(mp, 0x3f, sizeof(mp));
	For(i, 2, n) v[i] = read();
	For(i, 1, m){
		int x, y;
		x = read();
		y = read();
		mp[x][++cnt[x]] = y;
		mp[y][++cnt[y]] = x;
		mp1[x][y] = mp1[y][x] = 1;
	}
	vis[1] = 1;
	dfs(1, 1, 0);
	cout << ans << endl;
	return 0;
}