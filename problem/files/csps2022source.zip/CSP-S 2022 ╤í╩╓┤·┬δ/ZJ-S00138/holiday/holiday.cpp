#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[2505],f[2505][2505],ans;
struct str{
	int val,x;
}ff[1000005];
bool cmp(str x,str y)
{
	return x.val>y.val;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	k+=1;
	for(int i=2;i<=n;i++)
	{
		cin>>a[i];
	}	
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			f[i][j]=k+2;
		}
	}
	for(int i=1;i<=m;i++)
	{
		int x,y;
		cin>>x>>y;
		f[x][y]=1;
	}

	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int q=1;q<=n;q++)
			{
				f[i][j]=min(f[i][j],f[i][q]+f[q][j]);
			}
		}
	}
	for(int q=2;q<=n;q++)
	{
		int t=0;
		for(int i=2;i<=n;i++)
		{
			if(i==q)continue;
			if(f[1][i]<=k&&f[i][q]<=k)
			{
				t++;
				ff[t].val=a[i];
				ff[t].x=i;
			}
			sort(ff+1,ff+1+t,cmp);
		}
		for(int i=2;i<=n;i++)
		{
			if(i==q)continue;
			for(int j=2;j<=n;j++)
			{
				if(j==i||j==q)continue;
				if(f[1][i]<=k&&f[i][j]<=k&&f[j][q]<=k)
				{
					for(int w=1;w<=5;w++)
					{
						if(ff[w].x!=i&&ff[w].x!=j)
						{
							ans=max(ans,ff[w].val+a[i]+a[j]+a[q]);
						}
					}
				}
			}
		}
	}
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
}
