#include<bits/stdc++.h>
using namespace std;
int n,m,q,a[100005],b[100005],zzamax,zzamin,ffamax,ffamin,bbmax,bbmin,aazero;
struct str{
	int l,r,zamax,zamin,famax,famin,bmax,bmin,azero;
}c[400105],d[400105];
void build1(int l,int r,int t)
{
	c[t].l=l;
	c[t].r=r;
	if(l==r)
	{
		
		if(a[l]>0)
		{
			c[t].zamax=c[t].zamin=a[l];
			c[t].famax=c[t].famin=1;
		}
		else if(a[l]<0)
		{
			c[t].famax=c[t].famin=a[l];
			c[t].zamax=c[t].zamin=-1;
		}
		else
		{
			c[t].famax=c[t].famin=1;
			c[t].zamax=c[t].zamin=-1;
			c[t].azero=1;
		}
		return;
	}
	int mid=(l+r)>>1;
	build1(l,mid,t<<1);
	build1(mid+1,r,(t<<1)|1);
	c[t].zamax=max(c[t<<1].zamax,c[(t<<1)|1].zamax);
	c[t].famin=min(c[t<<1].famin,c[(t<<1)|1].famin);
	c[t].azero=c[t<<1].azero|c[(t<<1)|1].azero;
	if(c[t<<1].famax==1)c[t].famax=c[(t<<1)|1].famax;
	else if(c[(t<<1)|1].famax==1)c[t].famax=c[t<<1].famax;
	else c[t].famax=max(c[t<<1].famax,c[(t<<1)|1].famax);
	if(c[t<<1].zamin==-1)c[t].zamin=c[(t<<1)|1].zamin;
	else if(c[(t<<1)|1].zamin==-1)c[t].zamin=c[t<<1].zamin;
	else c[t].zamin=min(c[t<<1].zamin,c[(t<<1)|1].zamin);
	return;
}
void build2(int l,int r,int t)
{
	d[t].l=l;
	d[t].r=r;
	if(l==r)
	{
		
		d[t].bmin=d[t].bmax=b[l];
		return;
	}
	int mid=(l+r)>>1;
	build2(l,mid,t<<1);
	build2(mid+1,r,(t<<1)|1);
	d[t].bmax=max(d[t<<1].bmax,d[(t<<1)|1].bmax);
	d[t].bmin=min(d[t<<1].bmin,d[(t<<1)|1].bmin);
	return;
}
inline int read()
{
	register int s=0,w=1;
	register char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')w=-1;
		ch=getchar();
	}
	while('0'<=ch&&ch<='9')
	{
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*w;
}
void find1(int l,int r,int t)
{
	int mid=(c[t].l+c[t].r)>>1;
	if(c[t].l>=l&&c[t].r<=r)
	{
		zzamax=max(zzamax,c[t].zamax);
		ffamin=min(ffamin,c[t].famin);
		aazero=aazero|c[t].azero;
		if(ffamax==1)ffamax=c[t].famax;
		else if(c[t].famax!=1)ffamax=max(ffamax,c[t].famax);
		if(zzamin==-1)zzamin=c[t].zamin;
		else if(c[t].zamin!=-1)zzamin=min(zzamin,c[t].zamin);
		return;
	}
	if(l<=mid)find1(l,r,t*2);
	if(r>mid)find1(l,r,t*2+1);
	return;
}
void find2(int l,int r,int t)
{
	int mid=(d[t].l+d[t].r)>>1;
	if(d[t].l>=l&&d[t].r<=r)
	{
		bbmax=max(bbmax,d[t].bmax);
		bbmin=min(bbmin,d[t].bmin);
		return;
	}
	if(l<=mid)find2(l,r,t*2);
	if(r>mid)find2(l,r,t*2+1);
	return;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++) b[i]=read();
	build1(1,n,1);
	build2(1,m,1);
	for(int i=1;i<=q;i++)
	{
		int l1,r1,l2,r2;
		l1=read();
		r1=read();
		l2=read();
		r2=read();
		zzamin=-1;
		ffamax=1;
		bbmin=ffamin=1000000005;
		bbmax=zzamax=-1000000005;
		aazero=0;
		find1(l1,r1,1);
		find2(l2,r2,1);
		/*cout<<"i="<<i<<endl;
		cout<<zzamin<<" "<<zzamax<<" "<<ffamin<<" "<<ffamax<<" "<<bbmin<<" "<<bbmax<<" "<<aazero<<endl;*/
		long long s1=-1000000000000000005,s2=-1000000000000000005,s3=-1000000000000000005;	
		if(zzamin>0)
		{
			if(bbmin>=0)
			{
				s1=zzamax;
				s1*=bbmin;
			}
			else 
			{
				s1=zzamin;
				s1*=bbmin;
			}
			//cout<<zzamin<<" "<<zzamax<<" "<<bbmin<<" "<<s1<<endl;
		}
		if(ffamax<0)
		{
			if(bbmax<=0)
			{
				s2=ffamin;
				s2*=bbmax;
			}
			else 
			{
				s2=ffamax;
				s2*=bbmax;
			}
		//	cout<<ffamin<<" "<<ffamax<<" "<<bbmax<<" "<<ffamax*bbmax<<" "<<s2<<endl;
		}
		if(aazero)s3=0;
		s1=max(s1,max(s2,s3));
		cout<<s1<<endl;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
