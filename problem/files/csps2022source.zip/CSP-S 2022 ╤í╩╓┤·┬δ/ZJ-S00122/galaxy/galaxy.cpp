#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int N=5e5+7;
int n,m,q;
vector<int>e[N>>1];
int num[N];

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m;int x,y;
	for(int i=1;i<=m;++i){
		cin>>x>>y;num[y]++;
		e[x].push_back(y);
		e[x][y]=1;
	}
//	for(int i=1;i<=m;++i){
//		for(int j=0;j<e[i].size();++j){
//			cout<<e[i][j]<<" ";
//		}
//	}
	cin>>q;int t;
	while(q--){
		cin>>t;
		if(t==1){
			cin>>x>>y;
			e[x][y]=0;
		}
		else if(t==2){
			cin>>x;
			num[x]=0;
			for(int i=0;i<e[x].size();++i){
				e[x][i]=0;
			}
		}
		else if(t==3){
			cin>>x>>y;
			e[x][y]=1;
			num[x]++;
		}
		else if(t==4){
			num[x]=e[x].size();
			for(int i=0;i<e[x].size();++i){
				e[x][i]=1;
			}
		}bool f=1;
		for(int i=1;i<=n;++i){
			if(f){
				int sum=0;
				for(int j=0;j<e[i].size();++j){
					if(e[i][j])sum++;
					if(sum>1){
						f=0;
						cout<<"NO"<<endl;
						break;
					}
				}
			}
		}
		if(f){
			cout<<"YES"<<endl;
		}
	}
	return 0;
}
