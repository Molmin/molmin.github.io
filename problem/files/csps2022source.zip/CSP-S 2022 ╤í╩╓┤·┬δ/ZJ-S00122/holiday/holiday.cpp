#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int N=2506;
int n,m,k,tot=0;
ll head[N];
unsigned ll ans=0;
struct edge{
	int to,ne;
	unsigned long long w;
}e[N];
void add(int x,int y){
	e[++tot].ne=head[x];e[tot].to=y;head[x]=tot;
	e[++tot].ne=head[y];e[tot].to=x;head[y]=tot;
}
inline unsigned ll find(int x,int num,unsigned ll res){
	num++;
	if(num==4){
		if(e[x].to!=1)return 0;
		return res;
	}
	res+=e[x].w;
//	cout<<"x:"<<x<<" num:"<<num<<" res:"<<res<<endl;
	find(e[x].ne,num,res);
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>n>>m>>k;int x,y;e[1].w=0;
	for(int i=2;i<=n;++i)cin>>e[i].w;
	for(int i=1;i<=m;++i){
		cin>>x>>y;
		add(x,y);
	}
	for(int i=1;i<=n;++i){
		unsigned ll  t=0;
//		cout<<"i:"<<i<<"ans:"<<ans<<endl;
		ans=max(ans,find(e[i].ne,0,t));
//		cout<<"_________________"<<endl;
	}
	cout<<ans;
	return 0;
}
