#include <bits/stdc++.h>
using namespace std;
const int N=1e5+6;
int n,m,r1,r2,l1,l2,t;
long long a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>t;
	for(int i=1;i<=n;++i)cin>>a[i];
	for(int i=1;i<=m;++i)cin>>b[i];
	while(t--){
		cin>>l1>>r1>>l2>>r2;
		bool flag=0;
		long long _max=0-1e10,_min=1e10;
		if(l1==r1){//q MIN
			if(a[l1]==0){
				cout<<0<<endl;
				continue;
			}
			else if(a[l1]<0){
				for(int i=l2;i<=r2;++i){
					if(!flag){
						if(b[i]>=0){
							flag=1;
							_max=b[i];
							continue;
						}
						_min=min(_min,b[i]);
					}
					else{
						_max=max(_max,b[i]);
					}
				}
				if(flag){
					cout<<_max*a[l1]<<endl;
					continue;
				}
				else {
					cout<<_min*a[l1]<<endl;
					continue;
				}
			}
			else {
				for(int i=l2;i<=r2;++i){
					_min=min(_min,b[i]);
				}
				cout<<_min*a[l1]<<endl;
				continue;
			}
			
		}
		else if(l2==r2){//l MAX
			if(b[l2]==0){
				cout<<0<<endl;
				continue;
			}
			else if(b[l2]<0){
				for(int i=l1;i<=r1;++i){
					_min=min(_min,a[i]);
				}
				cout<<_min*b[l2]<<endl;
				continue;
			}
			else {
				for(int i=l1;i<=r1;++i){
					if(!flag){
						if(a[i]>=0){
							flag=1;
							_max=a[i];
							continue;
						}
						_min=min(_min,a[i]);
					}
					else{
						_max=max(_max,a[i]);
					}
				}
				if(flag){
					cout<<b[l2]*_max<<endl;
				}
				else cout<<b[l2]*_min<<endl;;
			}
		}
		else {
			bool a0=0,a_=0,b0=0,b_=0;
			long long amin,amax,bmin,bmax;
			for(int i=l1;i<=r1;++i){
				if(a[i]==0)a0=1;
				if(a[i]<0)a_=1;
				amax=max(amax,a[i]);
				amin=min(amin,a[i]);
			}
			for(int i=l2;i<=r2;++i){
				if(b[i]==0)b0=1;
				if(b[i]<0)b_=1;
				bmax=max(bmax,b[i]);
				bmin=min(bmin,b[i]);
			}
			if(a0||b0){
				cout<<0<<endl;
				continue;
			}
			else if(b_&&!a_){
				cout<<amin*bmax<<endl;
				continue;
			}
			else {
				cout<<(a[l1+r1>>1])*(b[l2+r2>>1])<<endl;
				continue;
			}
		}
	}
	return 0;
}