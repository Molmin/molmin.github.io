#include<bits/stdc++.h>
using namespace std;
int sk[305][305],dp[305][305],ans,n,m,kt,q,a[100005],xt,yt;
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>kt;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++) sk[i][j]=1e9;
	for(int i=1;i<=n;i++) sk[i][i]=0; 
	for(int i=1;i<n;i++)
	{
		cin>>xt>>yt;
		sk[xt][yt]=sk[yt][xt]=1;
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
				sk[i][j]=min(sk[i][j],sk[i][k]+sk[k][j]);
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
			dp[i][j]=1e9;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j) continue;
			if(sk[i][j]<=kt) dp[i][j]=a[j];
		}
	}
	for(int i=1;i<=n;i++) dp[i][i]=0;
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			if(dp[i][k]==1e9) continue;
			for(int j=1;j<=n;j++)
			{
				if(dp[k][j]==1e9) continue;
				dp[i][j]=min(dp[i][k]+dp[k][j],dp[i][j]);
			}
		}
	}
	while(q--)
	{
		cin>>xt>>yt;	
		cout<<a[xt]+dp[xt][yt]<<endl;
	}
	return 0;
}
