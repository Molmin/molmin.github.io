#include<bits/stdc++.h>
using namespace std;
struct edge
{
	int next,to;
}e[100005];
int n,m,cnt,head[100005],xt,yt,ru[100005],chu[100005],q,t,now,noww,vdm[100005],ddiv[100005];
bool f[1005][1005],vis[10005];
int vt[10005][1005],l[10005];
void add(int x,int y)
{
	e[++cnt].next=head[x];
	e[cnt].to=y;
	head[x]=cnt;
}
void tarjan(int u)
{
	vdm[u]=ddiv[u]=++noww;
	vis[u]=1;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(!f[u][v]) continue;
		if(!ddiv[v])
		{
			tarjan(v);
			vdm[u]=min(vdm[u],vdm[v]);
		}
		else if(vis[v]) vdm[u]=min(vdm[u],vdm[v]);
	}
	return;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>xt>>yt;
		add(xt,yt);
		f[xt][yt]=1;
		chu[xt]++;
		ru[yt]++;
		vt[yt][++l[yt]]=xt;
	}
	for(int i=1;i<=n;i++) 
	{
		if(chu[i]==1) 
			now++;
	}
	cin>>q;
	while(q--)
	{
		cin>>t>>xt;
		if(t==1)
		{
			cin>>yt;
			f[xt][yt]=0;
			if(chu[xt]==1) now--;
			chu[xt]--;
			ru[yt]--;
			if(chu[xt]!=1) cout<<"NO"<<endl;
			if(chu[xt]==1)
			{
				now++;
				if(now==n)
				{
					noww=0;
					for(int i=1;i<=n;i++) ddiv[i]=vdm[i]=0;
					for(int i=1;i<=n;i++) vis[i]=0;
					for(int i=1;i<=n;i++)
					{
						if(!vis[i]) tarjan(i);
					}
					bool ft=1;
					for(int i=1;i<n;i++)
					{
						if(vdm[i]!=vdm[i+1]) 
						{
							ft=0;
							break;
						}
					}
					if(ft==1) cout<<"YES"<<endl;
					else cout<<"NO"<<endl;
				}
				else
					cout<<"NO"<<endl;
			}
		}
		else if(t==2)
		{
			for(int i=1;i<=l[xt];i++)
			{
				if(f[vt[xt][i]][xt]==1)
				{
					if(chu[vt[xt][i]]==1) now--;
					chu[vt[xt][i]]--;
					if(chu[vt[xt][i]]==1) now++;
				}
				f[vt[xt][i]][xt]=0;
			}
			ru[xt]=0;
			if(now==n)
			{
				noww=0;
				for(int i=1;i<=n;i++) ddiv[i]=vdm[i]=0;
				for(int i=1;i<=n;i++) vis[i]=0;
				for(int i=1;i<=n;i++)
				{
					if(!vis[i]) tarjan(i);
				}
				bool ft=1;
				for(int i=1;i<n;i++)
				{
					if(vdm[i]!=vdm[i+1]) 
					{
						ft=0;
						break;
					}
				}
				if(ft==1) cout<<"YES"<<endl;
				else cout<<"NO"<<endl;				
			}
			else
				cout<<"NO"<<endl;
		}
		else if(t==3)
		{
			cin>>yt;
			f[xt][yt]=1;
			if(chu[xt]==1) now--;
			chu[xt]++;
			ru[yt]++;
			if(chu[xt]!=1) cout<<"NO"<<endl;
			if(chu[xt]==1)
			{
				now++;
				if(now==n)
				{
					noww=0;
					for(int i=1;i<=n;i++) ddiv[i]=vdm[i]=0;
					for(int i=1;i<=n;i++) vis[i]=0;
					for(int i=1;i<=n;i++)
					{
						if(!vis[i]) tarjan(i);
					}
					bool ft=1;
					for(int i=1;i<n;i++)
					{
						if(vdm[i]!=vdm[i+1]) 
						{
							ft=0;
							break;
						}
					}
					if(ft==1) cout<<"YES"<<endl;
					else cout<<"NO"<<endl;
				}
				else
					cout<<"NO"<<endl;
			}
		}
		else
		{
			for(int i=1;i<=l[xt];i++)
			{
				if(f[vt[xt][i]][xt]==0)
				{				
					if(chu[vt[xt][i]]==1) now--;
					chu[vt[xt][i]]++;
					if(chu[vt[xt][i]]==1) now++;
				}
				f[vt[xt][i]][xt]=1;
			}
			ru[xt]=l[xt];
			if(now==n)
			{
				noww=0;
				for(int i=1;i<=n;i++) ddiv[i]=vdm[i]=0;
				for(int i=1;i<=n;i++) vis[i]=0;
				for(int i=1;i<=n;i++)
				{
					if(!vis[i]) tarjan(i);
				}
				bool ft=1;
				for(int i=1;i<n;i++)
				{
					if(vdm[i]!=vdm[i+1]) 
					{
						ft=0;
						break;
					}
				}
				if(ft==1) cout<<"YES"<<endl;
				else cout<<"NO"<<endl;				
			}
			else
				cout<<"NO"<<endl;
		}
	}
	return 0;
}
