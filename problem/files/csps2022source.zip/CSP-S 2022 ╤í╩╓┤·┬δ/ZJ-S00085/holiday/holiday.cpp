#include<bits/stdc++.h>
using namespace std;
int sk[305][305],dp[305][305],ans,n,m,kt,a[100005],cnt,head[100005],xt,yt,s[100005];
bool vis[100005],vvis[100005];
int viss[305][305][305];
struct edge
{
	int next,to,dis;
}e[100005];
queue<int> q;
void add(int x,int y,int z)
{
	e[++cnt].next=head[x];
	e[cnt].to=y;
	e[cnt].dis=z;
	head[x]=cnt;
}
void dfs(int u,int now,int nows)
{
	if(dp[u][now]>=nows) return;
	if(now==4)
	{
		if(sk[u][1]>kt+1) return;
		dp[u][now]=max(dp[u][now],nows);
		ans=max(ans,dp[u][now]);
		return;
	}
	dp[u][now]=nows;
	for(int i=head[u];i;i=e[i].next)
	{
		int v=e[i].to;
		if(vvis[v]==0)
		{
			vvis[v]=1;
			dfs(v,now+1,nows+a[v]);
			vvis[v]=0;
		}
	}
	vvis[u]=0;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>kt;
	for(int i=2;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++) sk[i][j]=1e9;
	for(int i=1;i<=n;i++) sk[i][i]=0; 
	for(int i=1;i<=m;i++)
	{
		cin>>xt>>yt;
		sk[xt][yt]=sk[yt][xt]=1;
	}
	for(int k=1;k<=n;k++)
	{
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
				sk[i][j]=min(sk[i][j],sk[i][k]+sk[k][j]);
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j) continue;
			if(sk[i][j]<=kt+1) add(i,j,a[j]);
		}
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<=kt;j++)
			dp[i][j]=-1;
	}
	vvis[1]=1;
	dfs(1,0,0);
	cout<<ans<<endl;
	return 0;
}
