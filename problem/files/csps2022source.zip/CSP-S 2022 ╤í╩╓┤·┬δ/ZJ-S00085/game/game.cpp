#include<bits/stdc++.h>
using namespace std;
int n,m,q,xt,yt,xtt,ytt,a[100005],b[1000005];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	for(int i=1;i<=q;i++) cin>>xt>>yt>>xtt>>ytt;
	for(int i=1;i<=q;i++) cout<<0<<endl;
	return 0;
}
