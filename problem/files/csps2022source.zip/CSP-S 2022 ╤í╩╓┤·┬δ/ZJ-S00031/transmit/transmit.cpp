#include<bits/stdc++.h>
using namespace std;
struct edge{
	int to,nxt;
}e[400010];
int head[200010],tot;
long long n,q,m,c[200010],u,v;
long long g[200010][4],st[200010][20],f[200010][20][3];
long long dep[200010];
long long lca,a[3],b[3],tmp[3],ret;
void link(int x,int y)
{
	e[++tot].nxt=head[x];
	head[x]=tot;
	e[tot].to=y;
}
void dfs(int x,int fa)
{
	if(x==3)
	{
		int gtgyt=0;
		gtgyt++;
	}
	dep[x]=dep[fa]+1;
	g[x][0]=x;
	for(int i=1;i<=3;i++)
		g[x][i]=g[fa][i-1];
	st[x][0]=fa;
	for(int i=0;i<=18;i++)
	{
		if(i>=1) st[x][i]=st[st[x][i-1]][i-1];
		for(int j=0;j<m;j++)
			if(dep[x]-dep[g[st[x][i]][j]]<=m)
				f[x][i][j]=c[g[st[x][i]][j]];
		for(int j=0;j<m;j++)
			for(int k=0;k<m;k++)
				f[x][i][j]=min(f[x][i][j],f[x][i-1][k]+f[g[st[x][i-1]][k]][i-1][j-k]);
	}
	for(int i=head[x];i;i=e[i].nxt)
		if(e[i].to!=fa) dfs(e[i].to,x);
}
int LCA(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	for(int i=18;i>=0;i--)
		if(dep[st[x][i]]>=dep[y])
			x=st[x][i];
	if(x==y) return x;
	for(int i=18;i>=0;i--)
	{
		if(st[x][i]!=st[y][i])
		{
			x=st[x][i];
			y=st[y][i];
		}
	}
	return st[x][0];
}
int dist(int x,int y)
{
	return dep[x]+dep[y]-2*dep[LCA(x,y)];
}
long long getans(int x,int y)
{
	if(dist(x,y)<=m) return 0;
	lca=LCA(x,y);
	memset(a,0x3f,sizeof(a));
	memset(b,0x3f,sizeof(b));
	if(dep[x]==dep[lca]+1&&m>=1)
		a[0]=0;
	else if(dep[x]==dep[lca]+2&&m>=2)
	{
		a[0]=0;
		a[1]=c[g[x][1]];
	}
	else
	{
		a[0]=0;
		if(m>=2) a[1]=c[g[x][1]];
		if(m>=3) a[2]=c[g[x][2]];
	}
	if(dep[y]==dep[lca]+1&&m>=1)
	{
		b[0]=0;
	}
	else if(dep[y]==dep[lca]+2&&m>=2)
	{
		b[0]=0;
		b[1]=c[g[y][1]];
	}
	else
	{
		b[0]=0;
		if(m>=2) b[1]=c[g[y][1]];
		if(m>=3) b[2]=c[g[y][2]];
	}
	for(int i=18;i>=0;i--)
	{
		if(dep[st[x][i]]>=dep[lca]+m)
		{
			for(int j=0;j<3;j++)
				tmp[j]=a[j];
			memset(a,0x3f,sizeof(a));
			for(int j=0;j<m;j++)
				for(int k=0;k<m;k++)
					a[j]=min(a[j],tmp[k]+f[g[x][k]][i][j-k]);
			x=st[x][i];
		}
	}
	for(int i=18;i>=0;i--)
	{
		if(dep[st[y][i]]>=dep[lca]+m)
		{
			for(int j=0;j<3;j++)
				tmp[j]=b[j];
			memset(b,0x3f,sizeof(b));
			for(int j=0;j<m;j++)
				for(int k=0;k<m;k++)
					b[j]=min(b[j],tmp[k]+f[g[y][k]][i][j-k]);
			y=st[y][i];
		}
	}
	ret=1e18;
	if(x==lca)
	{
		for(int i=0;i<m;i++)
			ret=min(ret,b[i]);
		return ret;
	}
	if(y==lca)
	{
		for(int i=0;i<m;i++)
			ret=min(ret,a[i]);
		return ret;
	}
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<m;j++)
		{
			if(dist(g[x][i],g[y][j])<=m)
				ret=min(ret,a[i]+b[j]);
		}
	}
	for(int i=0;i<m;i++)
		for(int j=0;j<m;j++)
			ret=min(ret,a[i]+b[j]+c[lca]);
	return ret;
}
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%lld%lld%lld",&n,&q,&m);
	memset(c,0x3f,sizeof(c));
	for(int i=1;i<=n;i++)
		scanf("%lld",&c[i]);
	for(int i=1;i<n;i++)
	{
		scanf("%lld%lld",&u,&v);
		link(u,v);
		link(v,u);
	}
	memset(f,0x3f,sizeof(f));
	dfs(1,0);
	for(int i=1;i<=q;i++)
	{
		scanf("%lld%lld",&u,&v);
		printf("%lld\n",c[u]+c[v]+getans(u,v));
	}
	return 0;
}
//生死即在须臾,为自己立下教训