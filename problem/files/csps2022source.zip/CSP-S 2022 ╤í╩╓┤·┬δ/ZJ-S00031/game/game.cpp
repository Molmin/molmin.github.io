#include<bits/stdc++.h>
using namespace std;
struct SegmentTree{
	long long minn[2],maxn[2];
	//0为负1为正
}c[2][400010],tmp[2];
long long n,m,q,a[2][100010],l1,r1,l2,r2,ans;
SegmentTree merge(SegmentTree l,SegmentTree r)
{
	SegmentTree ret;
	ret.minn[0]=min(l.minn[0],r.minn[0]);
	ret.minn[1]=min(l.minn[1],r.minn[1]);
	ret.maxn[0]=max(l.maxn[0],r.maxn[0]);
	ret.maxn[1]=max(l.maxn[1],r.maxn[1]);
	return ret;
}
void ini(int l,int r,int rt,int ver)
{
	if(l==r)
	{
		if(a[ver][l]>=0)
		{
			c[ver][rt].minn[0]=2e9;
			c[ver][rt].maxn[0]=-2e9;
			c[ver][rt].minn[1]=a[ver][l];
			c[ver][rt].maxn[1]=a[ver][l];
		}
		else
		{
			c[ver][rt].minn[1]=2e9;
			c[ver][rt].maxn[1]=-2e9;
			c[ver][rt].minn[0]=a[ver][l];
			c[ver][rt].maxn[0]=a[ver][l];
		}
		return;
	}
	int mid=(l+r)>>1;
	ini(l,mid,rt<<1,ver);
	ini(mid+1,r,rt<<1|1,ver);
	c[ver][rt]=merge(c[ver][rt<<1],c[ver][rt<<1|1]);
}
SegmentTree query(int l,int r,int L,int R,int rt,int ver)
{
	if(L<=l&&r<=R) return c[ver][rt];
	int mid=(l+r)>>1;
	if(mid>=L&&mid<R) return merge(query(l,mid,L,R,rt<<1,ver),query(mid+1,r,L,R,rt<<1|1,ver));
	else if(mid>=L) return query(l,mid,L,R,rt<<1,ver);
	else return query(mid+1,r,L,R,rt<<1|1,ver);
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[0][i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&a[1][i]);
	ini(1,n,1,0);
	ini(1,m,1,1);
	for(int i=1;i<=q;i++)
	{
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		tmp[0]=query(1,n,l1,r1,1,0);
		tmp[1]=query(1,m,l2,r2,1,1);
		ans=-4e18;
		if(tmp[0].minn[1]<=1e9)
		{
			if(tmp[1].minn[0]<=1e9)
				ans=max(ans,tmp[0].minn[1]*tmp[1].minn[0]);
			else ans=max(ans,tmp[0].minn[1]*tmp[1].minn[1]);
			if(tmp[1].minn[0]<=1e9)
				ans=max(ans,tmp[0].maxn[1]*tmp[1].minn[0]);
			else ans=max(ans,tmp[0].maxn[1]*tmp[1].minn[1]);
		}
		if(tmp[0].minn[0]<=1e9)
		{
			if(tmp[1].maxn[1]>=-1e9)
				ans=max(ans,tmp[0].minn[0]*tmp[1].maxn[1]);
			else ans=max(ans,tmp[0].minn[0]*tmp[1].maxn[0]);
			if(tmp[1].maxn[1]>=-1e9)
				ans=max(ans,tmp[0].maxn[0]*tmp[1].maxn[1]);
			else ans=max(ans,tmp[0].maxn[0]*tmp[1].maxn[0]);
		}
		printf("%lld\n",ans);
	}
	return 0;
}