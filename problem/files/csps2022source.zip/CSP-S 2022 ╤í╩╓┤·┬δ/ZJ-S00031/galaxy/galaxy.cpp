#include<bits/stdc++.h>
using namespace std;
int head[500010],tot;
int n,m,q,u,v,op;
int cnt[500010],num;
set<int> s1[500010],s2[500010];
set<int>::iterator it;
//s1为有,s2为无
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		s1[v].insert(u);
		if(cnt[u]==1) num--;
		cnt[u]++;
		if(cnt[u]==1) num++;
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++)
	{
		scanf("%d",&op);
		if(op==1)
		{
			scanf("%d%d",&u,&v);
			s1[v].erase(u);
			s2[v].insert(u);
			if(cnt[u]==1) num--;
			cnt[u]--;
			if(cnt[u]==1) num++;
		}
		if(op==2)
		{
			scanf("%d",&u);
			for(it=s1[u].begin();it!=s1[u].end();it++)
			{
				if(cnt[*it]==1) num--;
				cnt[*it]--;
				if(cnt[*it]==1) num++;
				s2[u].insert(*it);
			}
			s1[u].clear();
		}
		if(op==3)
		{
			scanf("%d%d",&u,&v);
			s1[v].insert(u);
			s2[v].erase(u);
			if(cnt[u]==1) num--;
			cnt[u]++;
			if(cnt[u]==1) num++;
		}
		if(op==4)
		{
			scanf("%d",&u);
			for(it=s2[u].begin();it!=s2[u].end();it++)
			{
				if(cnt[*it]==1) num--;
				cnt[*it]++;
				if(cnt[*it]==1) num++;
				s1[u].insert(*it);
			}
			s2[u].clear();
		}
		if(num==n) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}