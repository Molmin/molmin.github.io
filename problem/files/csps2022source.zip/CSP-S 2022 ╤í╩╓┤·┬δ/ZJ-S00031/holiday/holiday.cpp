#include<bits/stdc++.h>
using namespace std;
struct edge{
	int to,nxt;
}e[20010];
int head[2510],tot;
int n,m,k,u,v,f[2510][2510],tmp,wi,wj;
long long a[2510],maxn[2510][3],pos[2510][3],ans;
bool vis[2510];
queue<int> q;
void link(int x,int y)
{
	e[++tot].nxt=head[x];
	head[x]=tot;
	e[tot].to=y;
}
void bfs(int x)
{
	memset(vis,0,sizeof(vis));
	q.push(x);
	vis[x]=1;
	f[x][x]=0;
	while(q.size())
	{
		tmp=q.front();
		q.pop();
		for(int i=head[tmp];i;i=e[i].nxt)
		{
			if(!vis[e[i].to])
			{
				f[x][e[i].to]=f[x][tmp]+1;
				q.push(e[i].to);
				vis[e[i].to]=1;
			}
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		link(u,v);
		link(v,u);
	}
	memset(f,0x3f,sizeof(f));
	for(int i=1;i<=n;i++)
		bfs(i);
	memset(maxn,0xc0,sizeof(maxn));
	for(int i=2;i<=n;i++)
	{
		for(int j=2;j<=n;j++)
		{
			if(i!=j&&f[i][j]<=k+1&&f[1][j]<=k+1)
			{
				if(a[j]>=maxn[i][0])
				{
					maxn[i][2]=maxn[i][1];
					pos[i][2]=pos[i][1];
					maxn[i][1]=maxn[i][0];
					pos[i][1]=pos[i][0];
					maxn[i][0]=a[j];
					pos[i][0]=j;
				}
				else if(a[j]>=maxn[i][1])
				{
					maxn[i][2]=maxn[i][1];
					pos[i][2]=pos[i][1];
					maxn[i][1]=a[j];
					pos[i][1]=j;
				}
				else if(a[j]>=maxn[i][2])
				{
					maxn[i][2]=a[j];
					pos[i][2]=j;
				}
			}
		}
	}
	for(int i=2;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			if(f[i][j]<=k+1)
			{
				wi=wj=0;
				if(pos[i][wi]==j) wi=1;
				if(pos[j][wj]==i) wj=1;
				if(pos[i][wi]==pos[j][wj])
					ans=max(ans,a[i]+a[j]+maxn[i][wi]+max(maxn[i][wi+1],maxn[j][wj+1]));
				else ans=max(ans,a[i]+a[j]+maxn[i][wi]+maxn[j][wj]);
			}
		}
	}
	printf("%lld",ans);
	return 0;
}