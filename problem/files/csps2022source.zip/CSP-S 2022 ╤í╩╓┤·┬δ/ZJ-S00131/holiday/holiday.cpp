#include<bits/stdc++.h>
using namespace std;
long long a[2505],f[6][515],ans;
vector<int> b[2505];
int p[2505],cnt,n,m,kk;
bool vis[2505],v[2505];
int sum=0;
void dp(){
	if(cnt<4||cnt>5*kk+4||v[p[cnt]]) return;
	memset(f,0,sizeof(f));
	for(int i=1;i<=cnt;i++) v[p[i]]=1;
	f[1][1]=a[p[1]];
	for(int i=1;i<=4;i++){
		for(int j=max(i,cnt-(5-i)*(kk+1)+1);j<=kk*i+i&&j<=cnt-4+i;j++){
			for(int k=max(1,j-kk-1);k<j;k++){
				f[i][j]=max(f[i][j],f[i-1][k]+a[p[j]]);
			}
		}
	}
	for(int i=cnt-kk;i<=cnt;i++) ans=max(ans,f[4][i]);
	return;
}
void dfs(int x){
	bool flag=0;
	for(int i=0;i<b[x].size();i++){
		if(b[x][i]==1) flag=1;
		else if(!vis[b[x][i]]){
			vis[b[x][i]]=1;
			p[++cnt]=b[x][i];
			dfs(b[x][i]);
			p[cnt--]=0;
			vis[b[x][i]]=0;
		}
	}
	if(flag) dp();
	return;
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int x,y;
	scanf("%d%d%d",&n,&m,&kk);
	for(int i=2;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		b[x].push_back(y);
		b[y].push_back(x);
	}
	vis[1]=1;
	dfs(1);
	printf("%lld",ans);
	return 0;
}
