#include<bits/stdc++.h>
using namespace std;
long long a[100005],b[100005];
long long mxff,mnff,mz,mf;
struct node1{
	int l,r;
	long long mx,mn,mnz,mxf;
}t1[400020];
struct node2{
	int l,r;
	long long mx,mn;
}t2[400020];
void build1(int l,int r,int cnt){
	t1[cnt].l=l;
	t1[cnt].r=r;
	if(l==r){
		t1[cnt].mx=a[l];
		t1[cnt].mn=a[l];
		if(a[l]>=0){
			t1[cnt].mnz=a[l];
			t1[cnt].mxf=-1000000005;
		}
		else{
			t1[cnt].mxf=a[l];
			t1[cnt].mnz=1000000005;
		}
		return;
	}
	int mid=(l+r)/2;
	build1(l,mid,cnt*2);
	build1(mid+1,r,cnt*2+1);
	t1[cnt].mx=max(t1[cnt*2].mx,t1[cnt*2+1].mx);
	t1[cnt].mn=min(t1[cnt*2].mn,t1[cnt*2+1].mn);
	t1[cnt].mnz=min(t1[cnt*2].mnz,t1[cnt*2+1].mnz);
	t1[cnt].mxf=max(t1[cnt*2].mxf,t1[cnt*2+1].mxf);
	return;
}
void build2(int l,int r,int cnt){
	t2[cnt].l=l;
	t2[cnt].r=r;
	if(l==r){
		t2[cnt].mx=b[l];
		t2[cnt].mn=b[l];
		return;
	}
	int mid=(l+r)/2;
	build2(l,mid,cnt*2);
	build2(mid+1,r,cnt*2+1);
	t2[cnt].mx=max(t2[cnt*2].mx,t2[cnt*2+1].mx);
	t2[cnt].mn=min(t2[cnt*2].mn,t2[cnt*2+1].mn);
	return;
}
void find2(int l,int r,int cnt){
	if(l==t2[cnt].l&&r==t2[cnt].r){
		mxff=max(mxff,t2[cnt].mx);
		mnff=min(mnff,t2[cnt].mn);
		return;
	}
	int mid=(t2[cnt].l+t2[cnt].r)/2;
	if(r<=mid) find2(l,r,cnt*2);
	else if(l>mid) find2(l,r,cnt*2+1);
	else{
		find2(l,mid,cnt*2);
		find2(mid+1,r,cnt*2+1);
	}
	return;
}
long long find1(int l,int r,int cnt,int op){
	if(l==t1[cnt].l&&r==t1[cnt].r){
		if(op==0) return t1[cnt].mn;
		else return t1[cnt].mx;
	}
	int mid=(t1[cnt].l+t1[cnt].r)/2;
	if(r<=mid) return find1(l,r,cnt*2,op);
	else if(l>mid) return find1(l,r,cnt*2+1,op);
	else{
		if(op==1) return max(find1(l,mid,cnt*2,op),find1(mid+1,r,cnt*2+1,op));
		else return min(find1(l,mid,cnt*2,op),find1(mid+1,r,cnt*2+1,op));
	}
}
void find3(int l,int r,int cnt){
	if(l==t1[cnt].l&&r==t1[cnt].r){
		mz=min(mz,t1[cnt].mnz);
		mf=max(mf,t1[cnt].mxf);
		return;
	}
	int mid=(t1[cnt].l+t1[cnt].r)/2;
	if(r<=mid) find3(l,r,cnt*2);
	else if(l>mid) find3(l,r,cnt*2+1);
	else{
		find3(l,mid,cnt*2);
		find3(mid+1,r,cnt*2+1);
	}
	return;
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	long long n,m,q,l1,r1,l2,r2,p,ans;
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	build1(1,n,1);
	for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
	build2(1,m,1);
	while(q--){
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		mxff=-1000000005,mnff=1000000005;
		find2(l2,r2,1);
		if(mxff<=0){
			p=find1(l1,r1,1,0);
			if(p>0) ans=p*mnff;
			else ans=p*mxff;
		}
		else if(mnff>=0){
			p=find1(l1,r1,1,1);
			if(p>0) ans=p*mnff;
			else ans=p*mxff;
		}
		else{
			mf=-1000000005,mz=1000000005;
			find3(l1,r1,1);
			if(mz==0) ans=0;
			else ans=max(mf*mxff,mz*mnff);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
