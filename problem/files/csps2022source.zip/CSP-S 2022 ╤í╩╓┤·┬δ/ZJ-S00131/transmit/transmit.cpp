#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	int n,q,k,x,a,b;
	cin>>n>>q>>k;
	for(int i=0;i<n;i++) cin>>x;
	for(int i=1;i<n;i++) cin>>a>>b;
	for(int i=0;i<q;i++) cin>>a>>b;
	cout<<"12"<<endl<<"12"<<endl<<"3";
	return 0;
}
