#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,q,t;
int s[1005];
bool a[1005][1005],b[1005][1005];
int sm[500005];
vector<int> c[500005];
vector<bool> d[500005];
int sum=0;
void pf(){
	for(int i=1;i<=n;i++) sm[i]=0;
	for(int i=0;i<m;i++){
		scanf("%d%d",&x,&y);
		sm[x]++;
		c[y].push_back(x);
		d[y].push_back(1);
	}
	for(int i=1;i<=n;i++) if(sm[i]==1) sum++;
	scanf("%d",&q);
	for(int i=0;i<q;i++){
		scanf("%d",&t);
		scanf("%d%d",&x,&y);
		if(sm[x]==1) sum--;
		if(t==1) sm[x]--;
		if(t==3) sm[x]++;
		if(sm[x]==1) sum++;
		if(sum==n) printf("YES\n");
		else printf("NO\n");
	}
	return;
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n>1000){
		pf();
		return 0;
	}
	for(int i=0;i<m;i++){
		scanf("%d%d",&x,&y);
		a[x][y]=1;
		b[x][y]=1;
		s[x]++;
	}
	for(int i=1;i<=n;i++){
		if(s[i]==1) sum++;
	}
	scanf("%d",&q);
	for(int i=0;i<q;i++){
		scanf("%d",&t);
		if(t==1||t==3){
			scanf("%d%d",&x,&y);
			if(s[x]==1) sum--;
			if(t==1){
				a[x][y]=0;
				s[x]--;
			}
			else{
				a[x][y]=1;
				s[x]++;
			}
			if(s[x]==1) sum++;
			if(sum==n) printf("YES\n");
			else printf("NO\n");
		}
		else{
			scanf("%d",&x);
			if(t==2){
				for(int j=1;j<=n;j++){
					if(a[j][x]){
						a[j][x]=0;
						if(s[j]==1) sum--;
						s[j]--;
						if(s[j]==1) sum++;
					}
				}
			}
			else{
				for(int j=1;j<=n;j++){
					if(b[j][x]){
						if(!a[j][x]){
							a[j][x]=1;
							if(s[j]==1) sum--;
							s[j]++;
							if(s[j]==1) sum++;
						}
					}
				}
			}
			if(sum==n) printf("YES\n");
			else printf("NO\n");
		}
	}
	return 0;
}
