#include<bits/stdc++.h>
using namespace std;
int n,m,a[1100],b[1100],st[1010][20][1010],l1,l2,r1,r2,t,x,ans,q;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++) cin>>b[i];
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		st[i][0][j]=a[i]*b[j];
	}
	x=log2(m-1)+1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=x;j++){
			for(int k=1;k<=m-(1<<j)+1;k++){
				st[i][j][k]=min(st[i][j-1][k],st[i][j-1][k+(1<<(j-1))]);
				cout<<i<<" "<<j<<" "<<k<<":"<<st[i][j][k]<<endl;
			}
		}
	}
	for(int i=1;i<=q;i++){
		cin>>l1>>r1>>l2>>r2;
		t=log2(r2-l2+1);
		ans=INT_MIN;
		for(int j=l1;j<=r1;j++){
			ans=max(ans,min(st[j][t][l2],st[j][t][r2-(1<<t)+1]));
		}
		cout<<ans<<endl;
	}
}
