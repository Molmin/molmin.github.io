#include<bits/stdc++.h>
using namespace std;
long long n,a[2510],k,ans,f[2510][110][5],x,y,m;
bool u[2510],vis[2510];
vector<long long> b[2510];
vector<long long> c[2510];
long long dfs(int x,int y,int z){
	if(y>k) return -2147483648;
	if(f[x][y][z]!=0) return f[x][y][z];
	if(z>4){
		if(vis[x]) return 0;
		else return -2147483648;
	}
	int l=b[x].size();
	bool flag=1;
	for(int i=0;i<l;i++){
		if(!u[b[x][i]]&&b[x][i]!=1){
			flag=0;
			u[b[x][i]]=1;
			f[x][y][z]=max(f[x][y][z],a[b[x][i]]+dfs(b[x][i],0,z+1));
			u[b[x][i]]=0;
		}
		if(y<k){
			flag=0;
			f[x][y][z]=max(f[x][y][z],dfs(b[x][i],y+1,z));
		}
	}
	if(flag) return -2147483648;
	return f[x][y][z];
}
void dfs2(int x,int y){
	vis[x]=1;
	if(y>k) return;
	int l=b[x].size();
	for(int i=0;i<l;i++){
		if(!vis[b[x][i]]){
			dfs2(b[x][i],y+1);
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++) cin>>a[i];
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		b[x].push_back(y);
		b[y].push_back(x);
	}
	dfs2(1,0);
	dfs(1,0,1);
	cout<<f[1][0][1];
	return 0;
}
