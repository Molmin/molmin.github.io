#include<bits/stdc++.h>
using namespace std;
int n,m,x,y,q,t,o=-1,ll[500010],l2[500010],l3[500010],l4[500010],l5[500010];
vector<int> a[500010];
vector<int> b[500010];
queue<int> p;
bool u[10010][10010];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>x>>y;
		a[x].push_back(y);
		b[y].push_back(x);
		ll[y]++;
		l2[y]++;
		l4[x]++;
		l5[x]++;
	}
	cin>>q;
	while(q--){
		cin>>t;
		if(t==1){
			cin>>x>>y;
			l2[y]--;
			l5[x]--;
			u[x][y]=1;
		}
		else if(t==2){
			cin>>x;
			int l=b[x].size();
			l2[x]=0;
			for(int i=0;i<l;i++){
				if(u[b[x][i]][x]==0){
					l5[b[x][i]]--;
					u[b[x][i]][x]=1;
				}
			}
		}
		else if(t==3){
			cin>>x>>y;
			l2[y]++;
			l5[x]++;
			u[x][y]=0;
		}
		else if(t==4){
			cin>>x;
			l2[x]=ll[x];
			int l=b[x].size();
			for(int i=0;i<l;i++){
				if(u[b[x][i]][x]){
					l5[b[x][i]]++;
					u[b[x][i]][x]=0;
				}
			}
		}
		bool flag=0;
		for(int i=1;i<=n;i++){
			if(l5[i]!=1){
				flag=1;
				cout<<"NO"<<endl;
				break;
			}
		}
		if(flag) continue;
		int cnt=n;
		while(!p.empty()) p.pop();
		for(int i=1;i<=n;i++){
			l3[i]=l2[i];
			if(l3[i]==0) p.push(i),cnt--;
		}
		while(!p.empty()){
			int t=p.front();
			p.pop();
			int l=a[t].size();
			for(int i=0;i<l;i++){
				if(!u[t][a[t][i]]){
					l3[a[t][i]]--;
					if(l3[a[t][i]]==0) p.push(a[t][i]),cnt--;
				}
			}
		}
		if(cnt==0){
			cout<<"NO"<<endl;
		}
		else{
			cout<<"YES"<<endl;
		}
	}
}
