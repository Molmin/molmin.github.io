#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

inline int read(){
	register int x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=x*10+(ch-'0');ch=getchar();}
	return x*f;
}
const int maxn=1e5+10;
const ll inf=1e18;
int n,m,q;
int a[maxn],b[maxn];
struct T{
	int ls,rs;
	ll v;
}tr[maxn*100];

void push_up(int p){
	tr[p].v=min(tr[tr[p].ls].v,tr[tr[p].rs].v);
}
int tot=0;
int build(int p,int l,int r,const int id){
	if(p==0) p=++tot;
	tr[p].ls=0;tr[p].rs=0;tr[p].v=0;
	if(l==r){
		tr[p].v=1ll*a[id]*b[l];
		return p;
	}
	int mid=l+r>>1;
	tr[p].ls=build(tr[p].ls,l,mid,id);
	tr[p].rs=build(tr[p].rs,mid+1,r,id);
	push_up(p);
	return p;
}
ll query(int p,int l,int r,const int ql,const int qr){//min
//cout<<l<<" "<<r<<' '<<ql<<' '<<qr<<" "<<tr[p].v<<"\n";
	if(ql<=l && r<=qr){
		return tr[p].v;
	}
	ll res=inf;
	int mid=l+r>>1;//1 2 =1
	if(mid>=ql) res=min(res,query(tr[p].ls,l,mid,ql,qr));
	if(mid+1<=qr) res=min(res,query(tr[p].rs,mid+1,r,ql,qr));
	return res;
}
int root[maxn];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(int i=1;i<=n;i++){a[i]=read();}
	for(int i=1;i<=m;i++){b[i]=read();}
	for(int i=1;i<=n;i++){
		root[i]=build(root[i],1,m,i);
	}
	for(int Q=1;Q<=q;Q++){
		int la=read(),ra=read();
		
		int lb=read(),rb=read();
		ll ans=LLONG_MIN;
		for(int i=la;i<=ra;i++){
			ans=max(ans,query(root[i],1,m,lb,rb));
		}cout<<ans<<"\n";
	}
	return 0;
}

