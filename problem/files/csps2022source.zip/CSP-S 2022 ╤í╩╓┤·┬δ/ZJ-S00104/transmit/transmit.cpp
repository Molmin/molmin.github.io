#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline ll read(){
	register ll x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=x*10+(ch-'0');ch=getchar();}
	return x*f;
}
const ll maxn=1e5+10;
const ll logn=19;
ll n,q,k;
ll a[maxn];
vector<ll>g[maxn];
ll f[maxn][25];
ll dep[maxn];
ll sum[maxn];
ll sum2[maxn];
void dfs(ll u,ll fa){
	sum[u]=sum[fa]+a[u];
	//sum2[u]=min(sum2[fa]+a[u],sum2[f[fa][0]]+a[u]);
	dep[u]=dep[fa]+1;
	f[u][0]=fa;
	for(ll j=1;j<=logn;j++) f[u][j]=f[f[u][j-1]][j-1];
	for(ll i=0;i<g[u].size();i++){
		ll to=g[u][i];
		if(to==fa) continue;
		dfs(to,u);
	}
}
ll lca(ll u,ll v){
	if(dep[v]>dep[u]){swap(u,v);}
	//cout<<dep[u]<<" "<<dep[v]<<"\n";
	for(ll j=logn;j>=0;j--){
		if(dep[f[u][j]] >= dep[v]) u=f[u][j];
	}
	//cout<<dep[u]<<" "<<dep[v]<<"\n";
	if(u==v) return u;
	
	for(ll j=logn;j>=0;j--){
		if(f[u][j] == f[v][j]) continue;
		u=f[u][j],v=f[v][j];
	}
	return f[u][0];
}
void dfs2(ll u,ll fa){
	f[u][0]=fa;
	for(ll j=1;j<=logn;j++) f[u][j]=f[f[u][j-1]][j-1];
	//cout<<"u="<<u<<" "<<sum2[u]<<"\n";
	sum2[u]=min(sum2[fa]+a[u],sum2[f[fa][0]]+a[u]);
	//cout<<"u="<<u<<" "<<sum2[u]<<"\n";
	for(ll i=0;i<g[u].size();i++){
		ll to=g[u][i];
		if(to==fa) continue;
		dfs2(to,u);
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n>>q>>k;
	for(ll i=1;i<=n;i++) cin>>a[i];
	for(ll i=1;i<=n-1;i++){
		ll u,v;
		cin>>u>>v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dep[0]=-1;
	dfs(1,0); 
	//ll t=read();
	for(ll Q=1;Q<=q;Q++){
		ll s,t;
		cin>>s>>t;
		if(k==1){
			ll l=lca(s,t);
			ll ans=sum[s]+sum[t]-sum[l]-sum[f[l][0]];
			cout<<ans<<endl;
		}
		if(k==2){
			for(ll i=1;i<=n;i++) sum2[i]=1e18;
			for(ll i=1;i<=n;i++) for(ll j=0;j<=20;j++)f[i][j]=0;
			sum2[0]=0;
			sum2[s]=a[s];
			for(ll i=0;i<g[s].size();i++){
				ll to=g[s][i];
				sum2[to]=a[s]+a[to];
				f[to][0]=s;
				for(ll j=0;j<g[to].size();j++){
					
					ll tto=g[to][j];
					if(tto==s) continue;
					//f[tto][0 ]=to;
					//f[tto][1]=s;
					dfs2(tto,to);
				}
			}
			cout<<sum2[t]<<"\n";
		}
	}


	return 0;
}
	/*
10 
7
2
1 2 3 4 5 6 7 8 9 10
1 2
2 3
1 5 
1 6
1 4
4 7
4 8
8 9
9 10
1 2
2 3
1 4
6 5
8 9
9 10
8 7

	*/

