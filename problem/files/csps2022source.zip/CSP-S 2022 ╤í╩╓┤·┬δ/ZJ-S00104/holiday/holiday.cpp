#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

inline ll read(){
	register ll x=0,f=1;char ch=getchar();
	while(!isdigit(ch)){if(ch=='-') f=-f;ch=getchar();}
	while(isdigit(ch)){x=x*10+(ch-'0');ch=getchar();}
	return x*f;
}

const ll maxn=3000;

ll n,m,k;
ll a[maxn];
vector<ll> g[maxn];
ll dist[maxn][maxn];
ll ans=0;

void bfs(ll u){
	queue<pair<ll,ll> > q;
	q.push(make_pair(u,0));
	while(q.size()){
		ll tp=q.front().first;
		ll d=q.front().second;
		q.pop();
		for(ll i=0;i<g[tp].size();i++){
			ll to=g[tp][i];
			if(dist[u][to]==0) {
				dist[u][to]=d+1;
				q.push(make_pair(to,(ll)d+1));
			}
		}
	}
}
inline ll D(ll x,ll y){
	return dist[x][y];
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();m=read();k=read();
	for(ll i=2;i<=n;i++) a[i]=read();
	for(ll i=1;i<=m;i++) {
		ll u=read();ll v=read();
		g[u].push_back(v);
		g[v].push_back(u);
	}
	for(ll i=1;i<=n;i++) bfs(i);
	for(ll i=2;i<=n;i++) {
	//	if( D(1,i)>k+1 )continue;
		for(ll j=2;j<=n;j++){
		//	if(i==j) continue;
		//	if( D(i,j)>k+1 )continue;
			for(ll l=2;l<=n;l++){
			//	if(i==l || j==l) continue;
			//	if( D(j,l)>k+1 )continue;
				for(ll r=2;r<=n;r++){
				//	if(i==r || j==r || l==r) continue;
				//	if( D(l,r)>k+1 || D(r,1)>k+1) continue;
					if(i==j || i==l || i==r || j==l || j==r || l==r) continue;
					if( D(1,i)<=k+1 && D(i,j)<=k+1 && D(j,l)<=k+1 && D(l,r)<=k+1 &&  D(r,1)<=k+1 ){
						ans=max(ans,a[i]+a[j]+a[l]+a[r]);
					}
				}
			}
		}
	}
	cout<<ans;
	
	


	return 0;
}

