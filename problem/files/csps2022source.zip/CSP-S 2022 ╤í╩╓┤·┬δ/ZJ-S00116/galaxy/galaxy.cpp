#include <bits/stdc++.h>
using namespace std;
int n,m,q,mp[1001][1001],g[1001];
bool b[1001],ph[1001][1001];
bool fd(int z){
	b[z]=1;
	for(int i=1;i<=n;i++){
		if(i!=z&&mp[z][i]&&!ph[z][i]){
			if(b[i]) return 1;
			else if(fd(i)) return 1;
		}
	}
	b[z]=0;
	return 0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		mp[x][y]=1;
		g[x]++;
	}
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		int op,x,y;
		scanf("%d",&op);
			if(op==1){	
				scanf("%d %d",&x,&y);
				if(ph[x][y]==0){
					ph[x][y]=1;
					g[x]--;
				}
			}
			else if(op==2){
				scanf("%d",&x);
				for(int j=1;j<=n;j++) if(mp[j][x]&&ph[j][x]==0){
					ph[j][x]=1;
					g[j]--;
				} 
			}
			else if(op==3){
				scanf("%d %d",&x,&y);
				ph[x][y]=0;
				g[x]++;	
			}
			else if(op==4){
				scanf("%d",&x);
				for(int j=1;j<=n;j++) if(mp[j][x]&&ph[j][x]){
					ph[j][x]=0;
					g[j]++;
				};
			}
		bool f=1;
		for(int j=1;j<=n;j++) b[j]=0;
		for(int j=1;j<=n;j++){
			if(g[j]!=1){
				f=0;
				break;
			}
		}
		for(int j=1;j<=n;j++){
			if(f==0) break;
			if(b[j]==0){
				fd(j);
				if(b[j]==0){
					f=0;
					break;
				}
			}
		}
		if(f) printf("YES\n");
		else printf("NO\n");
	}
}
