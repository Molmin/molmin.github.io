#include <bits/stdc++.h>
using namespace std;
struct rd{
	int v,w;
};
long long v[2501],as;
int mp[2501][2501],n,m,k;
bool b[2501];
void ss(int p,int c,long long s){
	if(c==5){
		as=max(as,s);
		return;
	}
	for(int i=2;i<=n;i++){
		if(!b[i]&&mp[p][i]<=k+1){
			b[i]=1;
			ss(i,c+1,s+v[i]);
			b[i]=0;
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=2;i<=n;i++) scanf("%d",&v[i]);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			mp[i][j]=999999999;
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d %d",&a,&b);
		mp[a][b]=1;
		mp[b][a]=1;
	}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int k=1;k<=n;k++)
				mp[j][k]=min(mp[j][k],mp[j][i]+mp[i][k]);
	ss(1,1,0);
	cout<<as;
}
