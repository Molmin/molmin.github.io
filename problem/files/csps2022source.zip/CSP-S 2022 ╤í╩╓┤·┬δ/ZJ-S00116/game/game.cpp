#include <bits/stdc++.h>
using namespace std;
struct nd{
	int l,r;
	long long sm,bg;
};
nd tra[300001],trb[300001];
int n,m,q,la,lb;
long long a[100001],b[100001],sp=9223372036854775807;
bool f=1;
void bd(int p,int l,int r,nd *tr,long long *s){
	if(l==r){
		tr[p].l=l;
		tr[p].r=r;
		tr[p].sm=s[l];
		tr[p].bg=s[l];
		return;
	}
	int md=(l+r)>>1;
	bd(p*2,l,md,tr,s);
	bd(p*2+1,md+1,r,tr,s);
	tr[p].l=l;
	tr[p].r=r;
	tr[p].sm=min(tr[p*2].sm,tr[p*2+1].sm);
	tr[p].bg=max(tr[p*2].bg,tr[p*2+1].bg);
}
long long fd(int p,int l,int r,nd *tr,bool rl){
	if(tr[p].l==l&&tr[p].r==r) return (rl?tr[p].bg:tr[p].sm);
	if(tr[p*2].r>=r) return fd(p*2,l,r,tr,rl);
	if(tr[p*2+1].l<=l) return fd(p*2+1,l,r,tr,rl);
	long long t1=fd(p*2,l,tr[p*2].r,tr,rl),t2=fd(p*2+1,tr[p*2+1].l,r,tr,rl);
	if(rl) return max(t1,t2);
	else return min(t1,t2);
}
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d %d %d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
	for(int i=1;i<=n;i++) if(a[i]<0) f=0;
	for(int i=1;i<=m;i++) if(b[i]<0) f=0;
	bd(1,1,n,tra,a);
	bd(1,1,m,trb,b);
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2;
		scanf("%d %d %d %d",&l1,&r1,&l2,&r2);
		if(l1==r1) printf("%lld\n",a[l1]*fd(1,1,m,trb,0));
		else if(l2==r2) printf("%lld\n",b[l2]*fd(1,1,n,tra,1));
		else if(f) printf("%lld\n",fd(1,1,n,tra,1)*fd(1,1,m,trb,0));
		else{
			long long t1=fd(1,1,n,tra,1),t2=fd(1,1,n,tra,0),t3=fd(1,1,m,trb,1),t4=fd(1,1,m,trb,0);
			if(t1<0&&t3<0) printf("%lld\n",t2*t3);
			else if(t2>0&&t4>0) printf("%lld\n",t1*t4);
			else if((t1==0&&t4>0)||(t4==0&&t2>0)) printf("0\n");
			else if(t1<0&&t4>0) printf("%lld\n",t1*t3);
			else if(t2>0&&t3<0) printf("%lld\n",t2*t4);
			else{
				long long t6=sp,t5=-sp;
				for(int j=l1;j<=r1;j++){
					t6=sp;
					for(int k=l2;k<=r2;k++){
						t6=min(a[j]*b[k],t6);
					} 
					t5=max(t5,t6);
				}
				printf("%lld\n",t5);
			}
		}
	}
}
