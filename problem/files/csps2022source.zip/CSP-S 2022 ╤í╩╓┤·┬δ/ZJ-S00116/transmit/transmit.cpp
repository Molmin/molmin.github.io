#include <bits/stdc++.h>
using namespace std;
int n,q,k;
long long v[200001];
vector<int> p[200001];
bool b[200001];
int dl[200001],asl[200001],ls,lls;
long long mp[200001],d[200001];
void ss1(int x,int y){
	if(x==y){
		for(int i=1;i<=ls;i++) asl[i]=dl[i];
		lls=ls;
		return;
	}
	for(int i=0,l=p[x].size();i<l;i++){
		int z=p[x][i];
		if(b[z]==0){
			b[z]=1;
			dl[++ls]=z;
			ss1(z,y);
			ls--;
			b[z]=0;
		}
	}
}
void mpp(){
	int dll[200001],lll=0,hh=1;
	dll[++lll]=1;
	while(lll>=hh){
		int x=dll[hh++];
		for(int i=0,llll=p[x].size();i<llll;i++){
			int y=p[x][i];
			if(mp[y]==92233720368){
				mp[y]=mp[x]+1;
				dll[++lll]=y;
			}
		}
	}
}
void ar1(){
	mpp();
	for(int i=1;i<=q;i++){
		int x,y;
		ls=0;
		scanf("%d %d",&x,&y);
		dl[++ls]=x;
		b[x]=1;
		ss1(x,y);
		b[x]=0;
		d[1]=v[x];
		for(int o=2;o<=lls;o++) d[o]=9223372036854775807;
		for(int o=2;o<=lls;o++)
			for(int j=1;j<=min(k,o-1);j++)
				d[o]=min(d[o-j]+v[asl[o]],d[o]);
		cout<<d[lls]<<endl;
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d %d %d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&v[i]);
	for(int i=1;i<=n;i++)
		mp[i]=92233720368;
	for(int i=2;i<=n;i++){
		int x,y;
		scanf("%d %d",&x,&y);
		p[x].push_back(y);
		p[y].push_back(x);
	}
	ar1();
	
}
