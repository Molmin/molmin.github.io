#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,m,q;
int a[N],b[N];
int ans1,ans2;
int C[1010][1010];
struct node{
	int l1,r1,l2,r2;
	node(){l1=0,r1=0,l2=0,r2=0;}
}g[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%d",&b[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			C[i][j]=a[i]*b[j];
		}
	}
	for(int i=1;i<=q;i++){
		scanf("%d%d%d%d",&g[i].l1,&g[i].r1,&g[i].l2,&g[i].r2);
		int mmin=INT_MAX,mmax=0;
		for(int j=g[i].l1;j<=g[i].r1;j++){
			if(mmax<a[j]){
				mmax=a[j];
				ans1=j;
			}
		}
		for(int j=g[i].l2;j<=g[i].r2;j++){
			if(mmin>b[j]){
				mmin=b[j];
				ans2=j;
			}
		}
		printf("%d\n",C[ans1][ans2]);
	}
	return 0;
}
