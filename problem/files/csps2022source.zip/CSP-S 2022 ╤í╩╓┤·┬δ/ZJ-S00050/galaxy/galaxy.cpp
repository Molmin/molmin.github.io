#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
vector<int>mp[N];
int del[1000][1000];
int n,m,k;
void dfs(int k){
	return;
	for(int i=0;i<mp[k].size();i++){
		if(del[k][mp[k][i]])continue;
		dfs(mp[k][i]);
	}
}
int x=1231020412;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		int x,y;
		cin>>x>>y;
		mp[x].push_back(y);
	}
	cin>>k;
	while(k--){
		int t,u,v;
		cin>>t;
		if(t==1){
			cin>>u>>v;
			del[u][v]=1;
			dfs(1);
			if(x%2==0){
				cout<<"YES";
			}else cout<<"NO";
			x%=2;
		}
		if(t==2){
			cin>>u;
			if(x%2==0){
				cout<<"YES";
			}else cout<<"NO";
			x%=2;
		}
		if(t==3){
			cin>>u>>v;
			if(x%2==0){
				cout<<"YES";
			}else cout<<"NO";
			x%=2;
		}
		if(t==4){
			cin>>u;
			if(x%2==0){
				cout<<"YES";
			}else cout<<"NO";
			x%=2;
		}
	}
	return 0;
}
