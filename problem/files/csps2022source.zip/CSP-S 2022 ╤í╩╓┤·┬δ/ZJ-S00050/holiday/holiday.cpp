#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=1e5+10;
int n,m,k;
int a[N],dist[N];
int vis[N],step=0;
int ans;
vector<int>mp[N];
void dfs(int now,int step){
	if(step==4&&now==1){
		ans=max(ans,dist[now]);
	}else if(step==4)return;
	vis[now]=1;
	for(int i=0;i<mp[now].size();i++){
		if(vis[mp[now][i]])continue;
		dist[mp[now][i]]=dist[now]+a[mp[now][i]];
		dfs(mp[now][i],step+1);
	}
	vis[now]=0;
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen(" holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		mp[x].push_back(y);
		mp[y].push_back(x);
	}
	for(int i=0;i<mp[1].size();i++){
		dist[mp[1][i]]=a[mp[1][i]];
		dfs(mp[1][i],0);
	}
	printf("%d",ans);
	return 0;
}
