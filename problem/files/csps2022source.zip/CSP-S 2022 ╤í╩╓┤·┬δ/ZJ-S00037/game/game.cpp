//💕when???
#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define pc putchar
#define fi first
#define se second
#define chkmx(a,b) (a)=max((a),(b))
#define chkmn(a,b) (a)=min((a),(b))
#define eb emplace_back
#define lc (x<<1)
#define rc (x<<1|1)
#define mid ((l+r)>>1)
typedef long long ll;
template<class T>void read(T&x){x=0;char c=getchar();bool f=0;for(;!isdigit(c);c=getchar())f|=c=='-';for(;isdigit(c);c=getchar())x=x*10+(c-'0');if(f)x=-x;}
template<class T,class ...Arg>void read(T&x,Arg&...arg){read(x);read(arg...);}
template<class T>void write(T x){if(x<0)pc('-'),x=-x;if(x>=10)write(x/10);pc(x%10+'0');}
template<class T,class ...Arg>void write(T x,Arg ...arg){write(x);pc(' ');write(arg...);}
template<class ...Arg>void writeln(Arg ...arg){write(arg...);pc('\n');}
const int N=1e5+10;
const ll inf=2e18;
int n,m,q;
int a[N],b[N];
struct SGT{
	int mx[N<<2],mn[N<<2],a[N];
	void pushup(int x){
		mx[x]=max(mx[lc],mx[rc]);
		mn[x]=min(mn[lc],mn[rc]);
	}
	void build(int x,int l,int r){
		if(l==r)return mx[x]=mn[x]=a[l],void();
		build(lc,l,mid);build(rc,mid+1,r);pushup(x);
	}
	int qmx(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr)return mx[x];
		if(qr<=mid)return qmx(lc,l,mid,ql,qr);
		if(mid<ql)return qmx(rc,mid+1,r,ql,qr);
		return max(qmx(lc,l,mid,ql,qr),qmx(rc,mid+1,r,ql,qr));
	}
	int qmn(int x,int l,int r,int ql,int qr){
		if(ql<=l&&r<=qr)return mn[x];
		if(qr<=mid)return qmn(lc,l,mid,ql,qr);
		if(mid<ql)return qmn(rc,mid+1,r,ql,qr);
		return min(qmn(lc,l,mid,ql,qr),qmn(rc,mid+1,r,ql,qr));
	}
}TB,TAP,TAN;
int ap[N],an[N],az[N];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n,m,q);
	for(int i=1;i<=n;i++){
		read(a[i]);
		ap[i]=ap[i-1];an[i]=an[i-1];az[i]=az[i-1];
		if(a[i]>0)TAP.a[++ap[i]]=a[i];
		else if(a[i]<0)TAN.a[++an[i]]=a[i];
		else ++az[i];
	}
	for(int i=1;i<=m;i++)read(b[i]),TB.a[i]=b[i];
	if(ap[n])TAP.build(1,1,ap[n]);
	if(an[n])TAN.build(1,1,an[n]);
	TB.build(1,1,m);
	while(q--){
		int l1,r1,l2,r2,L,R;read(l1,r1,l2,r2);
		int Bmx=TB.qmx(1,1,m,l2,r2),Bmn=TB.qmn(1,1,m,l2,r2);
		auto calc=[&](int A){return min(1ll*A*Bmx,1ll*A*Bmn);};
		ll ans=-inf;
		L=ap[l1-1]+1;
		R=ap[r1];
		if(L<=R){
			chkmx(ans,calc(TAP.qmn(1,1,ap[n],L,R)));
			chkmx(ans,calc(TAP.qmx(1,1,ap[n],L,R)));
		}
		L=an[l1-1]+1;
		R=an[r1];
		if(L<=R){
			chkmx(ans,calc(TAN.qmn(1,1,an[n],L,R)));
			chkmx(ans,calc(TAN.qmx(1,1,an[n],L,R)));
		}
		if(az[r1]!=az[l1-1])chkmx(ans,0ll);
		writeln(ans);
	}
	return 0;
}
