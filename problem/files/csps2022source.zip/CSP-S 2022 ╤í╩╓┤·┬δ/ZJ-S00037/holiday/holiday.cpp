//💑👀😭
#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define pc putchar
#define fi first
#define se second
#define chkmx(a,b) (a)=max((a),(b))
#define chkmn(a,b) (a)=min((a),(b))
#define eb emplace_back
typedef long long ll;
template<class T>void read(T&x){x=0;char c=getchar();bool f=0;for(;!isdigit(c);c=getchar())f|=c=='-';for(;isdigit(c);c=getchar())x=x*10+(c-'0');if(f)x=-x;}
template<class T,class ...Arg>void read(T&x,Arg&...arg){read(x);read(arg...);}
template<class T>void write(T x){if(x<0)pc('-'),x=-x;if(x>=10)write(x/10);pc(x%10+'0');}
template<class T,class ...Arg>void write(T x,Arg ...arg){write(x);pc(' ');write(arg...);}
template<class ...Arg>void writeln(Arg ...arg){write(arg...);pc('\n');}
const int N=2500+10;
const ll inf=4.5e18;
int n,m,k;vector<int>e[N];int q[N],hd,tl;
ll s[N];bool c[N][N];int dis[N];
pair<ll,int>mx[N][4];
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	memset(mx,0x3f,sizeof mx);
	read(n,m,k);
	for(int i=2;i<=n;i++)read(s[i]);
	for(int i=1,u,v;i<=m;i++)
		read(u,v),e[u].pb(v),e[v].pb(u);
	for(int i=1;i<=n;i++){
		memset(dis,0xff,sizeof dis);
		dis[i]=0;q[hd=tl=1]=i;
		while(hd<=tl){
			int u=q[hd++];
			for(auto v:e[u])if(dis[v]==-1)
				dis[q[++tl]=v]=dis[u]+1;
		}
		for(int j=1;j<=n;j++)c[i][j]=(dis[j]<=k+1);
	}
	for(int i=2;i<=n;i++){
		int tot=0;
		for(int j=2;j<=n;j++)if(i!=j&&c[1][j]&&c[j][i])
			mx[i][tot++]=mp(-s[j],j),sort(mx[i],mx[i]+tot),chkmn(tot,3);
	}
	ll res=-inf;
	for(int i=2;i<=n;i++)
		for(int j=i+1;j<=n;j++)if(c[i][j])
			for(int a=0;a<3;a++)
				for(int b=0;b<3;b++)
					if(mx[i][a].se!=j&&mx[j][b].se!=i&&mx[i][a].se!=mx[j][b].se)
						chkmx(res,s[i]+s[j]-mx[i][a].fi-mx[j][b].fi);
	writeln(res);
	return 0;
}
