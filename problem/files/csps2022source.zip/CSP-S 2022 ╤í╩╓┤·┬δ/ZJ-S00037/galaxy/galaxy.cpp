//CJL👎
#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define pc putchar
#define fi first
#define se second
#define chkmx(a,b) (a)=max((a),(b))
#define chkmn(a,b) (a)=min((a),(b))
#define eb emplace_back
typedef long long ll;
template<class T>void read(T&x){x=0;char c=getchar();bool f=0;for(;!isdigit(c);c=getchar())f|=c=='-';for(;isdigit(c);c=getchar())x=x*10+(c-'0');if(f)x=-x;}
template<class T,class ...Arg>void read(T&x,Arg&...arg){read(x);read(arg...);}
template<class T>void write(T x){if(x<0)pc('-'),x=-x;if(x>=10)write(x/10);pc(x%10+'0');}
template<class T,class ...Arg>void write(T x,Arg ...arg){write(x);pc(' ');write(arg...);}
template<class ...Arg>void writeln(Arg ...arg){write(arg...);pc('\n');}
const int N=5e5+10;
int n,m,q,x[N],y[N];
namespace solve0{
	int deg[N],c1;set<int>e[N][2];
	void work(){
		for(int i=1;i<=m;i++)
			deg[x[i]]++,e[y[i]][1].insert(x[i]);
		for(int i=1;i<=n;i++)c1+=deg[i]==1;
		while(q--){
			int t,u,v;
			read(t,u);
			if(t==1){
				read(v);
				e[v][1].erase(u);
				e[v][0].insert(u);
				c1-=deg[u]==1;
				deg[u]--;
				c1+=deg[u]==1;
			}else if(t==2){
				v=u;for(auto u:e[v][1]){
					e[v][0].insert(u);
					c1-=deg[u]==1;
					deg[u]--;
					c1+=deg[u]==1;
				}
				e[v][1].clear();
			}else if(t==3){
				read(v);
				assert(e[v][0].count(u));
				e[v][0].erase(u);
				e[v][1].insert(u);
				c1-=deg[u]==1;
				deg[u]++;
				c1+=deg[u]==1;
			}else{
				v=u;for(auto u:e[v][0]){
					e[v][1].insert(u);
					c1-=deg[u]==1;
					deg[u]++;
					c1+=deg[u]==1;
				}
				e[v][0].clear();
			}
			if(c1==n)puts("YES");
			else puts("NO");
		}
	}
}
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	read(n,m);
	for(int i=1;i<=m;i++)read(x[i],y[i]);
	read(q);
	solve0::work();
	return 0;
}

