//💘😅
#include<bits/stdc++.h>
using namespace std;
#define mp make_pair
#define mt make_tuple
#define pb push_back
#define pc putchar
#define fi first
#define se second
#define chkmx(a,b) (a)=max((a),(b))
#define chkmn(a,b) (a)=min((a),(b))
#define eb emplace_back
typedef long long ll;
template<class T>void read(T&x){x=0;char c=getchar();bool f=0;for(;!isdigit(c);c=getchar())f|=c=='-';for(;isdigit(c);c=getchar())x=x*10+(c-'0');if(f)x=-x;}
template<class T,class ...Arg>void read(T&x,Arg&...arg){read(x);read(arg...);}
template<class T>void write(T x){if(x<0)pc('-'),x=-x;if(x>=10)write(x/10);pc(x%10+'0');}
template<class T,class ...Arg>void write(T x,Arg ...arg){write(x);pc(' ');write(arg...);}
template<class ...Arg>void writeln(Arg ...arg){write(arg...);pc('\n');}
const int N=2e5+100,M=18;
const ll inf=1e18;
bool s;
int n,q,k,v[N];
vector<int>e[N];int fa[N][M],dep[N];
void dfs1(int u){dep[u]=dep[fa[u][0]]+1;for(auto v:e[u])if(v!=fa[u][0])fa[v][0]=u,dfs1(v);}
struct mat{ll a[3][3];ll*operator[](int x){return a[x];}};
struct vec{ll a[3];ll&operator[](int x){return a[x];}};
mat up[N][M],dw[N][M],tmp;
void mul(mat&res,mat&a,mat&b){
	for(int i=0;i<k;i++)for(int j=0;j<k;j++)res[i][j]=inf;
	for(int i=0;i<k;i++)for(int j=0;j<k;j++)for(int w=0;w<k;w++)
		chkmn(res[i][w],a[i][j]+b[j][w]);
}
void mul(vec&res,mat&b){
	vec a=res;
	for(int i=0;i<k;i++)res[i]=inf;
	for(int j=0;j<k;j++)for(int w=0;w<k;w++)
		chkmn(res[w],a[j]+b[j][w]);
}
int lca(int u,int v){
	if(dep[u]<dep[v])swap(u,v);
	for(int i=M-1;~i;i--)if(dep[fa[u][i]]>=dep[v])u=fa[u][i];
	if(u==v)return u;
	for(int i=M-1;~i;i--)if(fa[u][i]!=fa[v][i])u=fa[u][i],v=fa[v][i];
	return fa[u][0];
}
vec res;
void jump1(int x,int k){
	if(!k)return;
	int i=__lg(k);
	mul(res,up[x][i]);
	jump1(fa[x][i],k-(1<<i));
}
void jump2(int x,int k){
	if(!k)return;
	int i=__lg(k);
	jump2(fa[x][i],k-(1<<i));
	mul(res,dw[x][i]);
}
bool t;
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	read(n,q,k);
	for(int i=1;i<=n;i++)read(v[i]);
	for(int i=1,a,b;i<n;i++)read(a,b),e[a].pb(b),e[b].pb(a);
	dfs1(1);
	if(k==1){
		for(int i=1;i<=n;i++){
			tmp[0][0]=v[i];
			up[i][0]=dw[i][0]=tmp;
		}
	}else if(k==2){
		for(int i=1;i<=n;i++){
			tmp[0][0]=v[i];tmp[0][1]=0;
			tmp[1][0]=v[i];tmp[1][1]=inf;
			up[i][0]=dw[i][0]=tmp;
		}
	}else{
		for(int i=1;i<=n;i++){
			int mn=0x3f3f3f3f;
			for(auto j:e[i])chkmn(mn,v[j]);
			tmp[0][0]=v[i];
			tmp[0][1]=0;
			tmp[0][2]=inf;
			tmp[1][0]=v[i];
			tmp[1][1]=mn;
			tmp[1][2]=0;
			tmp[2][0]=v[i];
			tmp[2][1]=inf;
			tmp[2][2]=inf;
			up[i][0]=dw[i][0]=tmp;
		}
	}
	for(int j=1;j<M;j++)
		for(int i=1;i<=n;i++)
			if((fa[i][j]=(fa[fa[i][j-1]][j-1]))!=0){
				mul(up[i][j],up[i][j-1],up[fa[i][j-1]][j-1]);
				mul(dw[i][j],dw[fa[i][j-1]][j-1],dw[i][j-1]);
			}
	while(q--){
		int s,t;read(s,t);int l=lca(s,t);
		memset(res.a,0x3f,sizeof res.a);
		res[k-1]=0;
		jump1(s,dep[s]-dep[l]);
		mul(res,up[l][0]);
		jump2(t,dep[t]-dep[l]);
		writeln(res[0]);
	}
	//cerr<<1.*clock()/CLOCKS_PER_SEC<<endl;
	return 0;
}
