#include<bits/stdc++.h>
using namespace std;
long long n,m,zcc,a[2505],f[2505][2505],x,y,maxx[2505][4],ans=-0x3f3f3f3f,d_1,d_2;
int main(){
freopen("holiday.in","r",stdin);freopen("holiday.out","w",stdout);
	memset(f,0x3f,sizeof(f));f[1][1]=0;
	scanf("%lld%lld%lld",&n,&m,&zcc);zcc++;
	for(int i=2;i<=n;i++)f[i][i]=0,scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)scanf("%lld%lld",&x,&y),f[x][y]=f[y][x]=1;
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(i!=j&&i!=k&&j!=k)f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)
			if(i!=j&&f[i][j]<=zcc&&f[1][j]<=zcc){
				if(a[j]>a[maxx[i][0]])maxx[i][2]=maxx[i][1],maxx[i][1]=maxx[i][0],maxx[i][0]=j;
				else{ 
					if(a[j]>a[maxx[i][1]])maxx[i][2]=maxx[i][1],maxx[i][1]=j;
					else if(a[j]>a[maxx[i][2]])maxx[i][2]=j;
				}
			}
	for(int i=2;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			if(f[i][j]<=zcc)
				for(int i1=0;i1<3;i1++)
					for(int j1=0;j1<3;j1++){
						d_1=maxx[i][i1];d_2=maxx[j][j1];
						if(d_1!=0&&d_2!=0&&d_1!=d_2&&d_1!=j&&d_2!=i&&a[i]+a[j]+a[d_1]+a[d_2]>ans)ans=a[i]+a[j]+a[d_1]+a[d_2];
					}
	printf("%lld",ans);return 0;
}
