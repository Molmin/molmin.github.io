#include<bits/stdc++.h>
using namespace std;
long long T;
int main(){
freopen("galaxy.in","r",stdin);freopen("galaxy.out","w",stdout);
	scanf("%lld",&T);
	while(T--)puts("NO");
	return 0;
}
