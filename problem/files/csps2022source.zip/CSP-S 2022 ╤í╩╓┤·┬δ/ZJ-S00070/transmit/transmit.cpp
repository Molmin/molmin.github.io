#include<bits/stdc++.h>
using namespace std;typedef long long ll;
ll read(){
	ll s=0;char c=getchar();
	while(c<48||c>57)c=getchar();
	while(c>47&&c<58)s=(s<<3)+(s<<1)+(c^48),c=getchar();
	return s;
}
const int MAX=200005;
ll n,T,k,a[MAX],x,y,tot,edge[MAX<<2],nextt[MAX<<2],headd[MAX],f[MAX][20],qzh[MAX],d[MAX],lcaa;
void add(ll x,ll y){edge[++tot]=y,nextt[tot]=headd[x],headd[x]=tot;return;}
void dfs(ll x,ll fa){
	d[x]=d[fa]+1;f[x][0]=fa;qzh[x]=qzh[fa]+a[x];
	for(int i=1;f[x][i-1]!=0;i++)f[x][i]=f[f[x][i-1]][i-1];
	for(int i=headd[x];i;i=nextt[i])
		if(edge[i]!=fa)dfs(edge[i],x);
	return;
}
ll lca(ll x,ll y){
	if(d[x]<d[y])swap(x,y);
	for(int i=18;i>=0;i--)
		if(d[f[x][i]]>=d[y])x=f[x][i];
	if(x==y)return x;
	for(int i=18;i>=0;i--)
		if(f[x][i]!=f[y][i])x=f[x][i],y=f[y][i];
	return f[x][0];
}
int main(){
freopen("transmit.in","r",stdin);freopen("transmit.out","w",stdout);
	n=read();T=read();k=read();
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<n;i++)scanf("%lld%lld",&x,&y),add(x,y),add(y,x);
	dfs(1,0);
	while(T--)scanf("%lld%lld",&x,&y),lcaa=lca(x,y),printf("%lld\n",qzh[x]+qzh[y]-2*qzh[lcaa]+a[lcaa]);
	return 0;
}
