#include<bits/stdc++.h>
using namespace std;typedef int ll;
ll read(){
	ll s=0,w=1;char c=getchar();
	while(c<48||c>57){if(c=='-')w=-1;c=getchar();}
	while(c>47&&c<58)s=(s<<3)+(s<<1)+(c^48),c=getchar();
	return s*w;
}
void write(long long x){
	if(x<0)putchar('-'),x=-x;
	if(x>=10)write(x/10);
	putchar(x%10+48);
	return;
}
const ll MAX=0x3f3f3f3f,MIN=-0x3f3f3f3f,MAXN=100005;
ll n,m,T,l_1,r_1,l_2,r_2,faminn,famaxn,fbminn,fbmaxn,zaminn,zamaxn,zbminn,zbmaxn,logg1,logg2,a[MAXN],b[MAXN],fa_min[MAXN][20],fb_min[MAXN][20],za_min[MAXN][20],zb_min[MAXN][20],fa_max[MAXN][20],fb_max[MAXN][20],za_max[MAXN][20],zb_max[MAXN][20];
int main(){
freopen("game.in","r",stdin);freopen("game.out","w",stdout);
	n=read();m=read();T=read();
	for(int i=1;i<=n;i++){
		a[i]=read();
		if(a[i]==0)fa_min[i][0]=fa_max[i][0]=za_min[i][0]=za_max[i][0]=0;
		else if(a[i]<0)fa_min[i][0]=fa_max[i][0]=a[i],za_min[i][0]=MAX,za_max[i][0]=MIN;
		else if(a[i]>0)za_min[i][0]=za_max[i][0]=a[i],fa_min[i][0]=MAX,fa_max[i][0]=MIN;
	}
	for(int i=1;(1<<i)<=n;i++)
		for(int j=1;j-1+(1<<i)<=n;j++)
			fa_min[j][i]=min(fa_min[j][i-1],fa_min[j+(1<<(i-1))][i-1]),
			za_min[j][i]=min(za_min[j][i-1],za_min[j+(1<<(i-1))][i-1]),
			fa_max[j][i]=max(fa_max[j][i-1],fa_max[j+(1<<(i-1))][i-1]),
			za_max[j][i]=max(za_max[j][i-1],za_max[j+(1<<(i-1))][i-1]);
	for(int i=1;i<=m;i++){
		b[i]=read();
		if(b[i]==0)fb_min[i][0]=fb_max[i][0]=zb_min[i][0]=zb_max[i][0]=0;
		else if(b[i]<0)fb_min[i][0]=fb_max[i][0]=b[i],zb_min[i][0]=MAX,zb_max[i][0]=MIN;
		else if(b[i]>0)zb_min[i][0]=zb_max[i][0]=b[i],fb_min[i][0]=MAX,fb_max[i][0]=MIN;
	}
	for(int i=1;(1<<i)<=m;i++)
		for(int j=1;j-1+(1<<i)<=m;j++)
			fb_min[j][i]=min(fb_min[j][i-1],fb_min[j+(1<<(i-1))][i-1]),
			zb_min[j][i]=min(zb_min[j][i-1],zb_min[j+(1<<(i-1))][i-1]),
			fb_max[j][i]=max(fb_max[j][i-1],fb_max[j+(1<<(i-1))][i-1]),
			zb_max[j][i]=max(zb_max[j][i-1],zb_max[j+(1<<(i-1))][i-1]);
	while(T--){
		l_1=read();r_1=read();l_2=read();r_2=read();
		logg1=(int)(log(double(r_1-l_1+1))/log(2.0));logg2=(int)(log(double(r_2-l_2+1))/log(2.0));
		faminn=min(fa_min[l_1][logg1],fa_min[r_1-(1<<logg1)+1][logg1]);
		famaxn=max(fa_max[l_1][logg1],fa_max[r_1-(1<<logg1)+1][logg1]);
		fbminn=min(fb_min[l_2][logg2],fb_min[r_2-(1<<logg2)+1][logg2]);
		fbmaxn=max(fb_max[l_2][logg2],fb_max[r_2-(1<<logg2)+1][logg2]);
		zaminn=min(za_min[l_1][logg1],za_min[r_1-(1<<logg1)+1][logg1]);
		zamaxn=max(za_max[l_1][logg1],za_max[r_1-(1<<logg1)+1][logg1]);
		zbminn=min(zb_min[l_2][logg2],zb_min[r_2-(1<<logg2)+1][logg2]);
		zbmaxn=max(zb_max[l_2][logg2],zb_max[r_2-(1<<logg2)+1][logg2]);
		if(zbmaxn==MIN){
			if(famaxn==MIN)write(1ll*zaminn*fbminn);
			else write(1ll*faminn*fbmaxn);
		}
		else if(fbmaxn==MIN){
			if(zamaxn==MIN)write(1ll*famaxn*zbmaxn);
			else write(1ll*zamaxn*zbminn);
		}
		else if(famaxn==MIN)write(1ll*zaminn*fbminn);
		else if(zamaxn==MIN)write(1ll*famaxn*zbmaxn);
		else write(max(1ll*zaminn*fbminn,1ll*famaxn*zbmaxn));
		putchar('\n');
	}
	return 0;
}
