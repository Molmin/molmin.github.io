#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

#define fo(_var,_a,_b) for(int _var=_a;_var<=_b;_var++)
#define fr(_var,_a,_b) for(int _var=_a;_var>=_b;_var--)

int n,m;
int u,v;
int q;

int main()
{
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    scanf("%d%d",&n,&m);
    fo(i,1,m)
    {
        scanf("%d%d",&u,&v);
    }
    scanf("%d",&q);
    fo(i,1,q)
    {
        printf("NO\n");
    }
    return 0;
}