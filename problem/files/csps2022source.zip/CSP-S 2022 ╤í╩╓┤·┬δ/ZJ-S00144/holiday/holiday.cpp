#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

#define fo(_var,_a,_b) for(int _var=_a;_var<=_b;_var++)
#define fr(_var,_a,_b) for(int _var=_a;_var>=_b;_var--)

int n,m,k;
int a[2510];
int x,y;

int main()
{
    freopen("holiday.in","r",stdin);
    freopen("holiday.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    fo(i,1,n-1)
    {
        scanf("%d",&a[i]);
    }
    fo(i,1,m)
    {
        scanf("%d%d",&x,&y);
    }
    sort(a+1,a+n);
    printf("%d",a[n-1]+a[n-2]+a[n-3]+a[n-4]);
    return 0;
}