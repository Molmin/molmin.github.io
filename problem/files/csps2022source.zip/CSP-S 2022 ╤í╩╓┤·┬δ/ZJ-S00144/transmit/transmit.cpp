/*
# CSP2022-S2 游记

## Day -1

天天晚上在机房里划水捏（

就是说作业没做完会被老师们追着打（（（

## Day 0

和 xinglian 还有 dsaykc233 一起愉快地在机房打 Hunter Game。

看了看一些板子，明天不要考太多图论啊，这样子 arkerny 会过不了的捏（图论巨差无比）。

9：30 下了晚自修回家，到家 10：00 了。

回家整理了下东西（丢三落四的总是怕有啥玩意忘带），10：50 睡的觉（第二天还要早点起……）。

## Day 1

早上 7：00 起床去学校。

到学校之后发现手机电只有 80%。

在机房里整理了下东西，看了些易错的点。

9：00 出发的大概。

车上听了两个多小时的歌。

下车手机电还有 65%。

中午找了家餐馆吃了下，十多个人还是比较挤的，杭州菜还不错，挺合口味的，就是有点辣，然后又有些感冒。

然后休息、玩手机、看了下 J 组的题。

到考场手机就只有 40% 的电了。

看到了经亨颐写的恕园的恕，对不起校长我给你来丢脸了（嘤呜

在 16 号楼门口等，和 djwj233、jinanran、Golden_Breath 等人愉快聊天，拍了点照。

和 jinanran 共同认为不要来太多图论，否则要寄。

手机电只有 30% 了，于是进考场，关机。

解压密码是 `Belief2022`。

前面 30min 先把

写不完了（（（

*/
#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

#define fo(_var,_a,_b) for(int _var=_a;_var<=_b;_var++)
#define fr(_var,_a,_b) for(int _var=_a;_var>=_b;_var--)

int main()
{
    // freopen("transmit.in","r",stdin);
    // freopen("transmit.out","w",stdout);


    return 0;
}