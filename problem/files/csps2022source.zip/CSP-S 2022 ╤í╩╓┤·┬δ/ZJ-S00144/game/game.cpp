#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

#define fo(_var,_a,_b) for(int _var=_a;_var<=_b;_var++)
#define fr(_var,_a,_b) for(int _var=_a;_var>=_b;_var--)

const long long INF=1e18+1000;

ll n,m,q;
ll a[100010],b[100010];
ll l1,r1,l2,r2;

void solve()
{
    ll mina=INF,maxa=-INF,zeroa=0,maxfa=-INF,minza=INF;
    ll minb=INF,maxb=-INF,zerob=0,maxfb=-INF,minzb=INF;
    fo(i,l1,r1)
    {
        if(a[i]<0)
        {
            maxfa=max(maxfa,a[i]);
        }
        else if(a[i]>0)
        {
            minza=min(minza,a[i]);
        }
        else if(a[i]==0)
        {
            zeroa=1;
        }
        maxa=max(maxa,a[i]);
        mina=min(mina,a[i]);
    }
    fo(i,l2,r2)
    {
        if(b[i]<0)
        {
            maxfb=max(maxfb,b[i]);
        }
        else if(b[i]>0)
        {
            minzb=min(minzb,b[i]);
        }
        else if(b[i]==0)
        {
            zerob=1;
        }
        maxb=max(maxb,b[i]);
        minb=min(minb,b[i]);
    }
    if(mina<0&&maxa>0&&minb>=0)
    {
        printf("%lld\n",maxa*minb);
        return ;
    }
    if(mina<0&&maxa>0&&maxb<=0)
    {
        printf("%lld\n",mina*maxb);
        return ;
    }
    if(mina>=0&&minb>=0)
    {
        printf("%lld\n",maxa*minb);
        return ;
    }
    if(maxa<=0&&maxb<=0)
    {
        printf("%lld\n",mina*maxb);
        return ;
    }
    if(minb<0&&maxb>0&&zeroa)
    {
        printf("0\n");
        return ;
    }
    if(mina<0&&maxa>0&&minb<0&&maxb>0&&!zeroa)
    {
        printf("%lld\n",max(minza*minb,maxfa*maxb));
        return ;
    }
    if(maxa<0)
    {
        printf("%lld\n",maxa*maxb);
        return ;
    }
    if(mina>0)
    {
        printf("%lld\n",mina*minb);
        return ;
    }
    // printf("No Answer %lld %lld %lld %lld %lld %lld %lld %lld %lld %lld\n",mina,maxa,maxfa,minza,zeroa,minb,maxb,maxfb,minzb,zerob);
    return ;
}

int main()
{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    scanf("%lld%lld%lld",&n,&m,&q);
    fo(i,1,n)
    {
        scanf("%lld",&a[i]);
    }
    fo(i,1,m)
    {
        scanf("%lld",&b[i]);
    }
    fo(i,1,q)
    {
        scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
        solve();
    }
    return 0;
}