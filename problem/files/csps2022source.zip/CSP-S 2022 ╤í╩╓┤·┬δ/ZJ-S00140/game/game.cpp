#include <bits/stdc++.h>
#define MAXN 99999999999999999
using namespace std;
long long read(){
	long long aaa=0,sss=1;
	char ccc=getchar();
	while(!isdigit(ccc)){
		if(ccc=='-') sss=-sss;
		ccc=getchar();
	}
	while(isdigit(ccc)){
		aaa=aaa*10+ccc-'0';
		ccc=getchar();
	}
	return aaa*sss;
}
long long n,m,q,k1=-MAXN,k2=MAXN,ans1,ans2,sum;
long long a[100005][2],b[100005][2];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read();
	m=read();
	q=read();
	for(int i=1;i<=n;i++){
		a[i][1]=read();
		if(a[i][1]>=0) a[i][2]=a[i-1][2]+1;
		else a[i][2]=a[i-1][2]-1;
	}
	for(int i=1;i<=m;i++){
		b[i][1]=read();
		if(b[i][1]>=0) b[i][2]=b[i-1][2]+1;
		else b[i][2]=b[i-1][2]-1;
	}
	while(q--){
		int l1=read(),r1=read(),l2=read(),r2=read();
		k1=-MAXN,k2=MAXN;
		if(l1==r1){
			k1=a[l1][1];
			for(int i=l2;i<=r2;i++){
				k2=min(k2,b[i][1]);
			}
			cout<<k1*k2<<endl;
		}
		else if(l2==r2){
			k2=b[l2][1];
			for(int i=l1;i<=r1;i++){
				k1=max(k1,a[i][1]);
			}
			cout<<k1*k2<<endl;
		}
		else if((r1-l1+1==a[r1][2]-a[l1-1][2])||(r2-l2+1==b[r2][2]-b[l2-1][2])){
			for(int i=l2;i<=r2;i++){   
				k2=min(k2,b[i][1]);
			}
			for(int i=l1;i<=r1;i++){
				k1=max(k1,a[i][1]);
			}
			cout<<k1*k2<<endl;
		}
		else if((l1-r1-1==a[r1][2]-a[l1-1][2])||(l2-r2-1==b[r2][2]-b[l2-1][2])){
			for(int i=l2;i<=r2;i++){   
				k1=max(k1,b[i][1]);
			}
			for(int i=l1;i<=r1;i++){
				k2=min(k2,a[i][1]);
			}
			cout<<k1*k2<<endl;
		}
		else{
			for(int i=l2;i<=r2;i++){
				if(b[i][1])
				k1=max(k1,b[i][1]);
			}
			for(int i=l1;i<=r1;i++){
				k2=min(k2,abs(a[i][1]));
			}
			cout<<k1*k2<<endl;
		}
	}
	return 0;
}
