#include <bits/stdc++.h>
using namespace std;
int read(){
	int aaa=0,sss=1;
	char ccc=getchar();
	while(!isdigit(ccc)){
		if(ccc=='-') sss=-sss;
		ccc=getchar();
	}
	while(isdigit(ccc)){
		aaa=aaa*10+ccc-'0';
		ccc=getchar();
	}
	return aaa*sss;
}
int n,m,k,xx,yy,ans,sum,qwer,qwet,ceng;
int a[2505],f[2505][2505],q[2505];
int p[25005],symbol[2505];

bool song(int x,int y){
	if(k==0){
		if(f[x][y]==1) return 1;
	}
	if(x==y) return 0;
	memset(p,0,sizeof(p));
	memset(symbol,0,sizeof(symbol));
	int i=0;
	int l=1,r=1;
	p[1]=x;
	symbol[x]=1;
	qwer=0;
	qwet=0;
	ceng=1;
	while(i<=k&&l<=r){
		for(int qwe=1;qwe<=n;qwe++){
			if(symbol[qwe]==1) continue;
			if(f[p[l]][qwe]==1){
				r++;
				p[r]=qwe;
				qwet++;
				symbol[qwe]=1;
				if(qwe==y) return 1;
			}
		}
		l++;
		qwer++;
		if(qwer==ceng){
			qwer=0;
			ceng=qwet;
			qwet=0;
			i++;
		}
	}
	return 0;
}
void dfs(int x,int shu){
	if(shu==4&&song(x,1)){
		sum=max(sum,ans);
		return;
	}
	if(shu==5) return;
	q[x]=1;
	for(int i=1;i<=n;i++){
		if(q[i]==0&&song(x,i)){	
			ans+=a[i];
			dfs(i,shu+1);
			ans-=a[i];
		}
	}
	q[x]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read();
	m=read();
	k=read();
	for(int i=2;i<=n;i++) a[i]=read();
	for(int i=1;i<=m;i++){
		xx=read();
		yy=read();
		f[xx][yy]=1;
		f[yy][xx]=1;
	}
	dfs(1,0);
	cout<<sum<<endl;
	return 0;
}