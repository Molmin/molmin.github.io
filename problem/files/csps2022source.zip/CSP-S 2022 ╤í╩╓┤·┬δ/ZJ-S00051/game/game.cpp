#include<bits/stdc++.h>
using namespace std;
int n,m,q1;
long long a[1005],b[1005];
long long q[1005][1005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q1;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int j=1;j<=m;j++){
		scanf("%lld",&b[j]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			q[i][j]=a[i]*b[j];
		}
	}
	int l1,l2,r1,r2;
	
	for(int i=1;i<=q1;i++){
		cin>>l1>>r1;
		cin>>l2>>r2;
		long long ma=-1000000000000000000;
		for(int j=l1;j<=r1;j++){
			long long  mi=q[j][l2];
			for(int j1=l2;j1<=r2;j1++){
				if(mi>q[j][j1])mi=q[j][j1];
			}
			if(mi>ma)ma=mi;
		}
		
	printf("%lld\n",ma);
	}
	
	return 0;
}