#include<bits/stdc++.h>
using namespace std;
int n,m,q1;
int a[1005],b[1005];
int q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++){
		cin>>a[i];
	}
	cin>>q;
	for(int i=1;i<=q;i++)
	cout<<"YES";
	return 0;
}