#include <bits/stdc++.h>
using namespace std;
const int N = 1e3+5;
const int INF = 0x3f3f3f3f;
int val[N][N];
int a[N];
int b[N];
int n, m, q;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;++i) cin>>a[i];
	for(int j=1;j<=m;++j) cin>>b[j];
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			val[i][j]=a[i]*b[j];
		}
	}
	while(q--){
		int x1,x2,y1,y2;
		cin>>x1>>y1>>x2>>y2;
		int minn;
		int ans=INF*(-1);
		for(int i=x1;i<=y1;++i){
			minn=INF;
			for(int j=x2;j<=y2;++j){
				minn=min(minn,val[i][j]);
			}
			ans=max(ans,minn);
		}
		cout<<ans<<endl;
	}
}
