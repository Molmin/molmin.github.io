#include<bits/stdc++.h>
#include<vector>
using namespace std;
const int N = 2e3+5;
const long long INF = 0x3f3f3f3f3f3f3f3f;
int n, Q, K;
long long  val[N];
int d[N];
long long w[N][N];
bool vis[N];
vector<int > lj[N];
void dfs(int fa,int now,int tot) {
	if(tot==0) return;
	if(w[fa][now]==0) return ;
	lj[fa].push_back(now);
	w[fa][now]=0;
//	cout<<now<<endl;;
//	w[now][fa]=0;
	for(int i=0; i<d[now]; ++i) {
		if(w[fa][lj[now][i]]==INF) {
			dfs(fa,lj[now][i],tot-1);
		}
	}
}
void spfa(int s) {
	queue<int > q;
	q.push(s);
	bool flag=0;
	while(!q.empty()) {
		int now=q.front();
		q.pop();
		vis[now]=0;
		for(int i=0; i<lj[now].size(); ++i) {
			int t=lj[now][i];
			if(!flag||(w[s][t]>(w[s][now]+(now==s ? 0 : val[now])))) {
				w[s][t]=w[t][s]=w[s][now]+(now==s ? 0 : val[now]);
				if(!vis[t]) {
					vis[t]=1;
					q.push(t);
				}
			}
		}
		flag=1;
	}
}
void point20() {
	for(int i=1;i<=n;++i) d[i]=lj[i].size();
	for(int i=1; i<=n; ++i) {
		dfs(i,i,K+1);
	}
//	for(int i=1; i<=n; ++i) {
//		for(int j=1; j<=n; ++j) {
//			cout<<i<<" "<<j<<" "<<w[i][j]<<endl;
//		}
//	}
	while(Q--) {
		int s,t;
		cin>>s>>t;
		if(w[s][t]==INF)
			spfa(s);
		cout<<w[s][t]+val[s]+val[t]<<endl;
	}

}
int main() {
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	memset(w,0x3f, sizeof(w));
	cin>>n>>Q>>K;
	for(int i=1; i<=n; ++i) cin>>val[i];
	for(int i=2; i<=n; ++i) {
		int a,b;
		cin>>a>>b;
//		w[a][b]=0;
//		w[b][a]=0;
		lj[a].push_back(b);
		lj[b].push_back(a);
	}
	point20();
}
