#include<bits/stdc++.h>
#include<vector>
using namespace std;
const int N = 5e5+5;
int n, m, q;
struct node {
	int s,t;
} bug[N];
vector<int >lj[N];
bool vis[N];
int t[N];
bool mark[N];
int d[N];
bool check() {
//	cout<<1;
	for(int i=1; i<=n; ++i) {
		mark[i]=0;
		d[i]=0;
		t[i]=0;
	}
	for(int i=1; i<=m; ++i) {
		if(vis[i]) {
			if(t[bug[i].s])return 0;
			t[bug[i].s]=bug[i].t;
			d[bug[i].t]++;
		}
	}
	queue<int > q;
	for(int i=1; i<=n; ++i) {
		if(t[i]==0) return 0;
		if(d[i]==0) q.push(i),mark[i]=1;
	}
	if(q.empty()) return 1;
	while(!q.empty()) {
		int now=q.front();
		q.pop();
		if(!mark[t[now]]) {
			mark[t[now]]=1;
			q.push(t[now]);
		}
	}
	for(int i=1; i<=n; ++i) {
		if(!mark[i]) return 0;
	}
	return 1;
}
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=m; ++i) {
		vis[i]=1;
		int a,b;
		cin>>a>>b;
		bug[i].s=a;
		bug[i].t=b;
	}
	cin>>q;
	while(q--) {
		int t;
		cin>>t;
		if(t==1||t==3) {
			int u,v;
			cin>>u>>v;
			int id=0;
			for(int i=1; i<=m; ++i) {
				if(bug[i].s==u&&bug[i].t==v) {
					id=i;
					break;
				}
			}
			vis[id]=t/2;
		} else if(t==2||t==4) {
			int u;
			cin>>u;
			for(int i=1; i<=m; ++i) {
				if(bug[i].t==u) vis[i]=t/2-1;
			}
		}
		if(check()) {
			cout<<"YES"<<endl;
		} else cout<<"NO"<<endl;
	}
}//Ŀ�� mq

