#include<bits/stdc++.h>
using namespace std;
const int N = 3005;
int n, m,p;
int w[N][N];
int val[N];
void point1() {
	memset(w,0x3f,sizeof(w));
	for(int i=2; i<=n; ++i) cin>>val[i],w[i][i]=0;
	val[1]=0;
	w[1][1]=0;
	for(int i=1; i<=m; ++i) {
		int a,b;
		cin>>a>>b;
		w[a][b]=0;
//		w[i][i]=0;
		w[b][a]=0;
	}
	for(int k=1; k<=n; ++k) {
		for(int i=1; i<=n; ++i) {
			for(int j=1; j<=n; ++j) {
				w[i][j]=min(w[i][j],w[i][k]+w[k][j]+1);
			}
		}
	}
//	for(int i=1; i<=n; ++i) {
//		for(int j=1; j<=n; ++j) {
//			cout<<i<<" "<<j<<" "<<w[i][j]<<endl;
//		}
//	}
	int ans=0;
	for(int i=2; i<=n; ++i) {
		if(w[1][i]>p) continue;
		for(int j=2; j<=n; ++j) {
			if(j==i) continue;
			if(w[i][j]>p) continue;
			for(int k=2; k<=n; ++k) {
				if(k==i||k==j) continue;
				if(w[j][k]>p) continue;
				for(int l=2; l<=n; ++l) {
					if(l==i||l==j||l==k) continue;
					if(w[k][l]>p) continue;
					if(w[l][1]>p) continue;
					ans=max(ans,val[i]+val[j]+val[k]+val[l]);
				}
			}
		}
	}
	cout<<ans<<endl;
//	cout<<p;
	return ;
}
int ans;
bool vis[N];
vector<int > lj[N];
void dfs(int now,int t,int tot) {
	if(t==0) {
		if(now==1)
			ans=max(ans,tot);
		return;
	}
	for(int i=0; i<lj[now].size(); ++i) {
		if(vis[lj[now][i]]) continue;
		vis[lj[now][i]]=1;
		dfs(lj[now][i],t-1,tot+val[lj[now][i]]);
		vis[lj[now][i]]=0;
	}
}
void pointx() {
	for(int i=2; i<=n; ++i) cin>>val[i],w[i][i]=0;
	val[1]=0;
	for(int i=1; i<=m; ++i) {
		int a,b;
		cin>>a>>b;
		lj[a].push_back(b);
		lj[b].push_back(a);
	}
	dfs(1,5,0);
	cout<<ans;
};
int main() {
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>p;
	if(p==0) {
		pointx();
	} else if(n<=3000) {
		point1();
	}else{
		int a[N];
		for(int i=2;i<=n;++i){
			cin>>a[i];
		}
		sort(a+2,a+n+1);
		cout<<a[n]+a[n-1]+a[n-2]+a[n-3];
	}
	return 0;
}
