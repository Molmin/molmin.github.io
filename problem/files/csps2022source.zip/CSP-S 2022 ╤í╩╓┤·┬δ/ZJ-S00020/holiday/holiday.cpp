#include <bits/stdc++.h>
using namespace std;
long long n,m,k;
long long a[3000];
bool able[3000][3000];
vector<long long> gw[3000];
vector<long long> g[3000];
inline long long Max(long long a,long long b)
{
	if (a>=b) return a;
	else return b;
}
long long cnt[3000];
queue<long long> q;
inline void bfs(long long x,long long step)
{
	bool vis[3000];
	memset(vis,0,sizeof(vis));
	q.push(x);
	vis[x]=true;
	cnt[x]=-1;
	able[x][x]=true;
	while(!q.empty())
	{
		long long u=q.front();
		//cout << u << endl;
		q.pop();
		for (long long j=0;j<gw[u].size();++j)
		{
			long long v=gw[u][j];
			//cout << v << endl;
			if (vis[v]==false)
			{
				cnt[v]=cnt[u]+1;
				g[x].push_back(v);
				able[x][v]=able[v][x]=able[u][v]=able[v][u]=true;
				vis[v]=true;
				if (cnt[v]==step) continue;
				q.push(v);
			}
			else continue;
		}
	}
}
long long ans=-1;
bool vis[3000];
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld %lld %lld",&n,&m,&k);
	for (long long i=2;i<=n;++i)
	{
		scanf("%lld",&a[i]);
	}
	for (long long i=1;i<=m;++i)
	{
		long long u,v;
		scanf("%lld %lld",&u,&v);
		gw[u].push_back(v);
		gw[v].push_back(u);
	}
	for (long long i=1;i<=n;++i)
	{
		bfs(i,k);
	}
	memset(vis,0,sizeof(vis));
	vis[1]=true;
	for (long long i=0;i<g[1].size();++i)
	{
		long long u1=g[1][i];
		vis[u1]=true;
		for (long long j=0;j<g[u1].size();++j)
		{
			long long v1=g[u1][j];
			if (vis[v1]) continue;
			vis[v1]=true;
			for (long long k=0;k<g[1].size();++k)
			{
				long long u2=g[1][k];
				if (vis[u2]) continue;
				vis[u2]=true;
				for (long long l=0;l<g[u2].size();++l)
				{
					long long v2=g[u2][l];
					if (vis[v2]) continue;
					if (able[v1][v2])
						ans=max(ans,a[u1]+a[u2]+a[v1]+a[v2]);
				}
				vis[u2]=false;
			}
			vis[v1]=false;
		}
		vis[u1]=false;
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
