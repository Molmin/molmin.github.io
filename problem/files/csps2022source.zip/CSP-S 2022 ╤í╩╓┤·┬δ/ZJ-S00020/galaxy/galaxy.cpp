#include <bits/stdc++.h>
using namespace std;
long long n,m,q;
vector<long long> g[5050];
long long k[5050][5050];
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin >> n >> m;
	for (long long i=1;i<=m;i++)
	{
		long long u,v;
		scanf ("%d %d",&u,&v);
		g[u].push_back(v);
	}
	cin >> q;
	while(q--)
	{
		int t;
		cin >> t;
		if (t==1)
		{
			int u,v;
			cin >> u >> v;
		}
		else if (t==2)
		{
			int u;
			cin >> u;
		}
		else if (t==3)
		{
			int u,v;
			cin >> u >> v;
		}
		else if (t==4)
		{
			int u;
			cin >> u;
		}
	}
	
	return 0;
}
