#include <bits/stdc++.h>
using namespace std;
long long n,m,q;
long long a[1000010],b[1000010];
long long minn[1000010];
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin >> n >> m >> q;
	for (long long i=1;i<=n;i++) scanf("%lld",&a[i]);
	for (long long j=1;j<=m;j++) scanf("%lld",&b[j]);
	while(q--)
	{
		//cout << q << endl;
		long long l1,l2,r1,r2;
		scanf("%lld %lld %lld %lld",&l1,&r1,&l2,&r2);
		long long ans=-100000000000000000;
		for (long long i=l1;i<=r1;i++)
		{
			long long tmp=100000000000000000;
			for (long long j=l2;j<=r2;j++)
			{
				if (a[i]*b[j]<=tmp)
				{
					tmp=a[i]*b[j];
				}
			}
			//cout << tmp << endl;
			if (tmp>=ans)
			{
				ans=tmp;
			}
		}
		cout << ans << endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
