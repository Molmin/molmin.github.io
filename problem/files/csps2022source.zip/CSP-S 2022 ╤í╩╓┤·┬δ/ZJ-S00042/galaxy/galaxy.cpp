#include<bits/stdc++.h>
using namespace std;
int n,m,q,t[10001][10001]={0},u,v,s[10001][10001]={0},cz,d[50001]={0},jd[50001]={0},vis[50001]={0};
bool kg=true,kg1=false;
bool pd(int x)
{
	for (int i=1;i<=n;i++)
	{
		if (t[x][i]==1&&t[i][x]==1) kg1=true;
		else if (vis[i]==1&&t[x][i]==1) kg1=true;
		else if (t[x][i]==1)
		{
			vis[x]=1;
			pd(i);
		}
		if (kg1) return true;
	}
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&u,&v);
		t[u][v]=1;
		s[u][v]=1;
		d[u]++;
		jd[i]=1;
	}
	scanf("%d",&q);
	for (int i=1;i<=q;i++)
	{
		scanf("%d",&cz);
		if(cz==1)
		{
			scanf("%d%d",&u,&v);
			t[u][v]=0;
			d[u]--;
		}
		else if (cz==2)
		{
			scanf("%d",&u);
			for (int j=1;j<=n;j++) t[j][u]=0;
			jd[u]=0;
			d[u]=0;
		}
		else if (cz==3)
		{
			scanf("%d%d",&u,&v);
			t[u][v]=1;
			d[u]++;
		}
		else
		{
			scanf("%d",&u);
			for (int j=1;j<=n;j++)
			{
				if (s[j][u]==1)
				{
					t[j][u]=1;
					d[u]++;
				}
			}
			jd[u]=1;
		}
		kg=true;
		for (int j=1;j<=n;j++)
		{
			memset(vis,0,sizeof(vis));
			kg1=false;
			if (!pd(j))
			{
				kg=false;
				break;
			}
		}
		if (kg)
			for (int j=1;j<=n;j++)
				if (d[j]!=1) {kg=false;break;}
		if (kg) printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
