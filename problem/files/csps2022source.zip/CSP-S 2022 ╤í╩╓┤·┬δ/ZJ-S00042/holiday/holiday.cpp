#include<bits/stdc++.h>
using namespace std;
int n,m,k,v[2501],t[2501][2501]={0},way[2501]={0},sum=0,vis[2501]={0},ans=0;
int dfs(int x,int y,int z)
{
	if (z==4&&x==1)
	{
		ans=max(ans,sum);
		return 0;
	}
	for (int i=1;i<=way[x];i++)
	{
		if (y<=k&&t[x][i]==1)
		{
			if(vis[i]==0)
			{
				sum+=v[i];
				dfs(i,0,z+1);
				sum-=v[i];
			}
			dfs(i,y+1,z);
		}
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	v[1]=0;
	for (int i=2;i<=n;i++)
		scanf("%d",&v[i]);
	int x,y;
	for (int i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		t[x][y]=1;
		t[y][x]=1;
		way[x]++;
		way[y]++;
	}
	dfs(1,0,0);
	printf("%d",ans);
	return 0;
}
