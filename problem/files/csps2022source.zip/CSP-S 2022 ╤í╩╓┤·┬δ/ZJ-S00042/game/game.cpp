#include<bits/stdc++.h>
using namespace std;
int n,m,l1,r1,l2,r2,q,ans;
int a[10001],b[10001],c[10001][10001],miny;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i]);
	for (int i=1;i<=m;i++)
		scanf("%d",&b[i]);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			c[i][j]=a[i]*b[j];
	for (int i=1;i<=q;i++)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for (int j=l1;j<=r1;j++)
		{
			miny=c[j][l2];
			for (int x=l2;x<=r2;x++)
				miny=min(miny,c[j][x]);
			if (j==l1) ans=miny;
			else ans=max(ans,miny);
		}
		printf("%d\n",ans);
	}
	return 0;
}
