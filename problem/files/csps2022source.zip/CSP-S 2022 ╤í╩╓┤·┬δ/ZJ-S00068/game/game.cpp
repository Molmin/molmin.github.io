#include<bits/stdc++.h>
#define pb push_back
#define Fin(qwq) freopen(qwq, "r", stdin)
#define Fout(qwq) freopen(qwq, "w", stdout)
#define Fio(qwq) Fin(qwq".in"), Fout(qwq".out")
#define mid ((l + r) >> 1)
#define int long long
using namespace std;
const int maxn = 1e5 + 10, inf = 2e9;
struct Node{
	int MAX, MIN, pre, suf;
	Node(int ma = -inf, int mi = inf, int pr = -inf, int su = inf): MAX(ma), MIN(mi), pre(pr), suf(su){}
	Node operator + (const Node &t)const{
		return Node(max(MAX, t.MAX), min(MIN, t.MIN), max(pre, t.pre), min(suf, t.suf));
	}
};
struct SegmentTree{
#define lson (p << 1)
#define rson (p << 1 | 1)
	Node t[maxn << 2];
	Node init(int x){
		return Node(x, x, x <= 0 ? x : -inf, x >= 0 ? x : inf);
	}
	void pushup(int p){
		t[p] = t[lson] + t[rson];
	}
	void build(int l, int r, int p, int a[]){
		if(l == r) return t[p] = init(a[l]), void();
		build(l, mid, lson, a), build(mid + 1, r, rson, a), pushup(p);
	}
	Node query(int l, int r, int p, int ql, int qr){
		if(ql > qr || l > qr || r < ql) return Node();
		if(ql <= l && r <= qr) return t[p];
		return query(l, mid, lson, ql, qr) + query(mid + 1, r, rson, ql, qr);
	}
#undef lson
#undef rson
}ta, tb;
int n, m, q, a[maxn], b[maxn];
signed main(){
	Fio("game");
//Fin("test.in");
	scanf("%lld%lld%lld", &n, &m, &q);
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1; i <= m; i++) scanf("%lld", &b[i]);
	ta.build(1, n, 1, a), tb.build(1, m, 1, b);
	while(q--){
		int l1, l2, r1, r2, res;
		scanf("%lld%lld%lld%lld", &l1, &r1, &l2, &r2);
		Node qa = ta.query(1, n, 1, l1, r1), qb = tb.query(1, m, 1, l2, r2);
		if(qb.MAX <= 0){
			if(qa.MIN < 0) res = qa.MIN * qb.MAX;
			else res = qa.MIN * qb.MIN;
		}else if(qb.MIN >= 0){
			if(qa.MAX > 0) res = qa.MAX * qb.MIN;
			else res = qa.MAX * qb.MAX;
		}else res = max(qa.pre * qb.MAX, qa.suf * qb.MIN);
//		printf("%lld %lld %lld %lld - %lld %lld %lld %lld\n", qa.MAX, qa.MIN, qa.pre, qa.suf, qb.MAX, qb.MIN, qb.pre, qb.suf);
		printf("%lld\n", res);
	}
	return 0;
}

