#include<bits/stdc++.h>
#define pb push_back
#define int long long
#define Fin(qwq) freopen(qwq, "r", stdin)
#define Fout(qwq) freopen(qwq, "w", stdout)
#define Fio(qwq) Fin(qwq".in"), Fout(qwq".out")
using namespace std;
const int maxn = 2e5 + 10, inf = 1e18;
int n, k, q, a[maxn], f[maxn][20], sum[maxn], dep[maxn];
vector<int> edge[maxn];
int dp[maxn];
void dfs(int u){
	for(int i = 1; i < 20; i++) f[u][i] = f[f[u][i - 1]][i - 1];
	dep[u] = dep[f[u][0]] + 1, sum[u] = sum[f[u][0]] + a[u];
	for(int v : edge[u]) if(v != f[u][0]) f[v][0] = u, dfs(v);
}
int LCA(int x, int y){
	if(dep[x] < dep[y]) swap(x, y);
	int det = dep[x] - dep[y];
	for(int i = 0; i < 20; i++) if(det & (1ll << i)) x = f[x][i];
	if(x == y) return x;
	for(int i = 19; i >= 0; i--) if(f[x][i] != f[y][i]) x = f[x][i], y = f[y][i];
	return f[x][0];
}
using vec = basic_string<int>;
vec cur, l, r;
int work(){
//	cur = cur + 0ll;
	int len = cur.size();
//	for(int i = 0; i < len; i++) printf("%lld ", cur[i]);
//	puts("");
	for(int i = 0; i < len; i++) dp[i] = inf;
	dp[0] = cur[0];
	for(int i = 1; i < len; i++) for(int j = 1; j <= k; j++) if(i - j >= 0){
		dp[i] = min(dp[i], dp[i - j] + cur[i]);
	}
	return dp[len - 1];
}
void solve(int u, int lca, int v){
	cur.clear(), l.clear(), r.clear();
	for(int x = u; x != lca; x = f[x][0]) l = l + a[x];
	for(int x = v; x != lca; x = f[x][0]) r = a[x] + r;
	l = l + a[lca]; int ans = inf;
	for(int i = 0; i < k && lca; i++){
		cur = l + r;
		ans = min(ans, work());
		r = a[lca] + r, lca = f[lca][0], l = l + a[lca];
	}
	printf("%lld\n", ans);
}
signed main(){
	Fio("transmit");
	scanf("%lld%lld%lld", &n, &q, &k);
	for(int i = 1; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1, x, y; i < n; i++){
		scanf("%lld%lld", &x, &y);
		edge[x].pb(y), edge[y].pb(x);
	}
	dfs(1);
	while(q--){
		int x, y; scanf("%lld%lld", &x, &y);
		int lca = LCA(x, y);
		if(k == 1){printf("%lld\n", sum[x] + sum[y] - sum[lca] * 2 + a[lca]); continue;}
		solve(x, lca, y);
	}
	return 0;
}
