#include<bits/stdc++.h>
#define pb push_back
#define fi first
#define se second
#define ll long long
#define Fin(qwq) freopen(qwq, "r", stdin)
#define Fout(qwq) freopen(qwq, "w", stdout)
#define Fio(qwq) Fin(qwq".in"), Fout(qwq".out")
using namespace std;
const int maxn = 2510, inf = 1e9;
int n, m, k, dist[maxn][maxn];
vector<int> edge[maxn];
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
ll dp[maxn][3], a[maxn];
int pre[maxn][3];
void Dijkstra(int s){
	fill(dist[s] + 1, dist[s] + n + 1, inf);
	dist[s][s] = 0, q.push({0, s});
	while(!q.empty()){
		auto p = q.top(); q.pop();
		int u = p.se, dis = p.fi;
		if(dist[s][u] != dis) continue;
		for(int v : edge[u]) if(dist[s][v] > dis + 1){
			dist[s][v] = dis + 1, q.push({dist[s][v], v});
		}
	}
}
bool check(int x, int i, int y, int j){
	if(x == y || x == pre[y][j] || y == pre[x][i] || pre[x][i] == pre[y][j]) return 0;
	if(!pre[x][i] || !pre[y][j]) return 0;
//	printf("ok: %d %d %d %d\n", x, i, y, j);
	return 1;
}
int main(){
	Fio("holiday");
	scanf("%d%d%d", &n, &m, &k), k++;
	for(int i = 2; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1; i <= m; i++){
		int x, y; scanf("%d%d", &x, &y);
		edge[x].pb(y), edge[y].pb(x);
	}
	for(int i = 1; i <= n; i++) Dijkstra(i);
	for(int i = 2; i <= n; i++) for(int j = 2; j <= n; j++) if(j != i){
//		printf("%d -> %d: %d\n", i, j, dist[i][j]);
		if(dist[1][j] <= k && dist[j][i] <= k){
			ll res = a[j] + a[i];
			if(res >= dp[i][0]){ 
				dp[i][2] = dp[i][1], pre[i][2] = pre[i][1];
				dp[i][1] = dp[i][0], pre[i][1] = pre[i][0];
				dp[i][0] = res, pre[i][0] = j;
			}else if(res >= dp[i][1]){
				dp[i][2] = dp[i][1], pre[i][2] = pre[i][1];
				dp[i][1] = res, pre[i][1] = j;
			}else if(res >= dp[i][2]) dp[i][2] = res, pre[i][2] = j;
		}
	}
//	for(int i = 2; i <= n; i++) printf("%d: %lld %lld %lld\n", i, dp[i][0], dp[i][1], dp[i][2]);
	ll ans = 0;
	for(int i = 2; i <= n; i++) for(int j = 2; j <= n; j++) if(j != i){
		if(dist[i][j] <= k){
			ll res = 0;
			for(int x = 0; x < 3; x++) for(int y = 0; y < 3; y++) if(check(i, x, j, y)) res = max(res, dp[i][x] + dp[j][y]);
			ans = max(ans, res);
//			printf("%d %d - %lld\n", i, j, res);
		}
	}
	printf("%lld\n", ans);
	return 0;
}
