#include<bits/stdc++.h>
#define pb push_back
#define Fin(qwq) freopen(qwq, "r", stdin)
#define Fout(qwq) freopen(qwq, "w", stdout)
#define Fio(qwq) Fin(qwq".in"), Fout(qwq".out")
using namespace std;
const int maxn = 5e5 + 10;
int n, m, q, deg[maxn];
set<pair<int, int>> edge[maxn];
vector<pair<int, int>> era;
int main(){
	Fio("galaxy");
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= m; i++){
		int x, y; scanf("%d%d", &x, &y);
//		printf("%d %d\n", x, y);
		edge[y].insert((pair<int, int>){x, 1}), deg[x]++;
	}
//	for(int i = 1; i <= n; i++) for(auto p : edge[i]) printf("%d - %d\n", i, p.first);
	int err = 0;
	scanf("%d", &q);
	for(int i = 1; i <= n; i++) err += (deg[i] != 1);
	while(q--){
		int opt, x, y;
		scanf("%d%d", &opt, &x);
		if(opt == 1 || opt == 3) scanf("%d", &y);
		if(opt == 1){
			if(deg[x] == 1) err++;
			else if(deg[x] == 2) err--;
			deg[x]--;
			auto pos = edge[y].lower_bound((pair<int, int>){x, 0});
//			assert(pos != edge[y].end());
			pair<int, int> res = *pos;
			edge[y].erase(pos), res.second = 0, edge[y].insert(res);
		}else if(opt == 2){
			era.clear(); // assert(!edge[x].empty());
//			for(auto p : edge[x]) printf("+ %d\n", p.first);
			for(auto p : edge[x]) if(p.second){
				int v = p.first;
				if(deg[v] == 1) err++;
				else if(deg[v] == 2) err--;
				deg[v]--, era.pb(p);
//				printf("- %d\n", v);
			}
			for(auto p : era){
				edge[x].erase(p);
				edge[x].insert({p.first, p.second ^ 1});
			}
		}else if(opt == 3){
			if(deg[x] == 1) err++;
			else if(deg[x] == 0) err--;
			deg[x]++;
			auto pos = edge[y].lower_bound((pair<int, int>){x, 0});
			pair<int, int> res = *pos;
			edge[y].erase(pos), res.second = 1, edge[y].insert(res);
		}else if(opt == 4){
			era.clear();
			for(auto p : edge[x]) if(!p.second){
				int v = p.first;
				if(deg[v] == 1) err++;
				else if(deg[v] == 0) err--;
				deg[v]++, era.pb(p);
			}
			for(auto p : era){
				edge[x].erase(p);
				p.second ^= 1, edge[x].insert(p);
			}
		}
		puts(err ? "NO" : "YES");
	}
	return 0;
}

