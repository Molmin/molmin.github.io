#include<bits/stdc++.h>
#define N 500005
using namespace std;
int n,m,q,edgenum,head[N],to[N],nxt[N];
bool liv[N],vis[N],flag;
void addedge(int u,int v){
	nxt[++edgenum]=head[u];
	to[edgenum]=v;
	liv[edgenum]=1;
	head[u]=edgenum;
}
void dfs(int u){
	if(vis[u]){
		flag=1;
		return;
	}
	vis[u]=1;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(!liv[i])continue;
		dfs(v);
	}
}
bool Can(){
	for(int i=1;i<=n;i++){
		memset(vis,0,sizeof(vis));
		flag=0;
		dfs(i);
		int cnt=0;
		for(int j=head[i];j;j=nxt[j])
			cnt+=(liv[j]);
		if(cnt>1||!flag)return 0;
	}
	return 1;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		addedge(u,v);
	}
	scanf("%d",&q);
	while(q--){
		int op,u,v;
		scanf("%d%d",&op,&u);
		if(op==1){
			scanf("%d",&v);
			for(int i=head[u];i;i=nxt[i]){
				int vv=to[i];
				if(vv==v){
					liv[i]=0;
					break;
				}
			}
		}
		if(op==2){
			for(int j=1;j<=n;j++)
				for(int i=head[j];i;i=nxt[i])
					if(to[i]==u)liv[i]=0;
		}
		if(op==3){
			scanf("%d",&v);
			for(int i=head[u];i;i=nxt[i]){
				int vv=to[i];
				if(vv==v){
					liv[i]=1;
					break;
				}
			}
		}
		if(op==4){
			for(int j=1;j<=n;j++)
				for(int i=head[j];i;i=nxt[i])
					if(to[i]==u)liv[i]=1;
		}
		puts(Can()?"YES":"NO");
	}
	return 0;
}
