#include<bits/stdc++.h>
#define ull unsigned long long
#define ll long long
#define N 2505
#define M 10005
using namespace std;
bool vis[N];
ll n,m,k,sum[N],edgenum,head[M<<2],nxt[M<<2],to[M<<2];
ll dis[N][N];
ull ans,f[N][5];
bool vis2[N][4][N];
void addedge(ll u,ll v){
	nxt[++edgenum]=head[u];
	to[edgenum]=v;
	head[u]=edgenum;
}
void dfs(ll u,ll fa,ll cnt,ull s){
	if(cnt>4&&u!=1)return;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		if(v==fa)continue;
		if(cnt==4&&v==1){
			ans=max(ans,s);
			break;
		}
		dfs(v,u,cnt+1,s+sum[v]);
	}
}
void dijskra(int x){
	for(int i=1;i<=n;i++)
		dis[x][i]=1e9;
	dis[x][x]=0;
	priority_queue<pair<int,int> >q;
	q.push(make_pair(0,x));
	while(!q.empty()){
		int u=q.top().second;
		q.pop();
		if(vis[u])continue;
		vis[u]=1;
		for(int i=head[u];i;i=nxt[i]){
			int v=to[i];
			if(dis[x][v]>dis[x][u]+1){
				dis[x][v]=dis[x][u]+1;
				q.push(make_pair(-dis[x][v],v));
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&sum[i]);
	for(int i=1;i<=m;i++){
		ll u,v;
		scanf("%lld%lld",&u,&v);
		addedge(u,v);
		addedge(v,u);
	}
	if(k==0){
		dfs(1,-1,0,0);
		cout<<ans<<endl;
	}else{
		for(int i=1;i<=n;i++){
			memset(vis,0,sizeof(vis));
			dijskra(i);
		}
		/*
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++)
				cout<<dis[i][j]<<" ";
			puts("");
		}*/
		for(int i=2;i<=n;i++)
			if(min(dis[1][i],dis[i][1])<=k+1)f[i][0]=sum[i];
		/*for(int i=2;i<=n;i++){
			for(int j=2;j<=n;j++)
				if(i!=j&&dis[i][j]<=k+1){
					addedge(i,j);
					addedge(j,i);
				}
		}*/
		//memset(vis,0,sizeof(vis));
		//for(int i=1;i<=n;i++)
		//dfs2(1,-1);
		int cant1=-1,cant2=-1,cant3=-1;
		for(int i=0;i<=3;i++)
			for(int v=2;v<=n;v++){
				int uu=0;
				bool flag=0;
				for(int u=2;u<=n;u++){
					if(u==v)continue;
					if(dis[v][u]<=k+1){
						if(!vis2[u][i][v]&&f[v][i+1]<f[u][i]+sum[v]){
							if(f[u][i]>f[uu][i]){
								uu=u;
								flag=0;
								cant1=cant2=-1;
							}else if(f[u][i]==f[uu][i]){
								flag=1;
								cant1=u,cant2=uu;
							}
							//vis2[v][i+1][u]=1;
							//f[v][i+1]=f[u][i]+sum[v];
						}
					}
				}
				for(int ii=1;ii<=n;ii++)
					if(vis2[uu][i][ii])
						vis2[v][i+1][ii]=1;
				if(!flag){
					vis2[v][i+1][uu]=1;
					if(uu==cant1)
						vis2[v][i+1][cant2]=1;
					else if(uu==cant2)
						vis2[v][i+1][cant1]=1;
				}
				f[v][i+1]=f[uu][i]+sum[v];
			}
		for(int i=2;i<=n;i++)
			if(dis[i][1]<=k+1)ans=max(ans,f[i][3]);
		cout<<ans<<endl;
	}
	return 0;
}
/*
8 8 1
9 7 1 8 2 3 6
1 2
2 3
3 4
4 5
5 6
6 7
7 8
8 1
*/
