#include<bits/stdc++.h>
#define N 400005
using namespace std;
int n,q,k,edgenum,head[N],nxt[N],to[N],v[N];
void addedge(int u,int v){
	nxt[++edgenum]=head[u];
	to[edgenum]=v;
	head[u]=edgenum;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<n;i++){
		int u,vv;
		scanf("%d%d",&u,&vv);
		addedge(u,vv);
	}
	while(q--){
		int u,vv;
		cin>>u>>vv;
		printf("%d\n",v[u]+v[vv]);
	}
	return 0;
}
