#include<bits/stdc++.h>
#define ll long long
#define N 100005
using namespace std;
ll n,m,q,a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	while(q--){
		ll l1,l2,r1,r2;
		scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
		if(l1==r1){
			ll minn=10e9;
			for(int i=l2;i<=r2;i++)
				minn=min(minn,a[l1]*b[i]);
			printf("%lld\n",minn);
			continue;
		}
		if(l2==r2){
			ll minn=-10e9;
			for(int i=l1;i<=r1;i++)
				minn=max(minn,a[i]*b[l2]);
			printf("%lld\n",minn);
			continue;
		}
		ll maxx=-10e9;
		for(int i=l1;i<=r1;i++){
			ll minn=10e9;
			for(int j=l2;j<=r2;j++){
				ll c=a[i]*b[j];
				//cout<<c<<" ";
				minn=min(minn,c);
			}
			maxx=max(maxx,minn);
		}
		printf("%lld\n",maxx);
	}
	return 0;
}

