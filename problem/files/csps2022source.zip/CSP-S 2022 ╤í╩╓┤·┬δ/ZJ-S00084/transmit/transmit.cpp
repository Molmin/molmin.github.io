#include <bits/stdc++.h>
using namespace std;
long long w[200010];
struct edge {
	int to, nxt;
} e[400010];
int head[200010];
long long f[200010];
vector<int> v;
int cnt = 0;
inline void add(int x, int y) {
	e[++cnt] = {y, head[x]};
	head[x] = cnt;
}
bool dfs(int x, int d, int fa) {
	if(x == d) return 1;
	for(int i = head[x]; i; i = e[i].nxt) {
		int y = e[i].to;
		if(y == fa) continue;
		v.push_back(y);
		if(dfs(y, d, x)) return 1;
		v.pop_back();
	}
	return 0;
}
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	int n, q, k;
	cin >> n >> q >> k;
	for(int i = 1; i <= n; i++) scanf("%lld", &w[i]);
	for(int i = 1; i < n; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}
	while(q--) {
		int a, b;
		scanf("%d%d", &a, &b);

		v.clear();
		v.push_back(a);
		dfs(a, b, 0);
//		//v.push_back(b);
//		for(int x : v) cout << x << " " << w[x] << endl;
//		puts("");
		memset(f, 0x3f, (int)(v.size() + 10) * sizeof(long long));
		//for(int i = 2; i <= v.size(); i++) f[i] = 0x3f3f3f3f3f3f3f3f;
		f[1] = w[v[0]];
		for(int i = 2; i <= v.size(); i++) {
			for(int j = 1; j <= k; j++) {
				if(i - j >= 1) f[i] = min(f[i], f[i - j] + w[v[i - 1]]);
			}
		}
//		for(int i = 1; i <= v.size(); i++) cout << f[i] << " ";
//		//for(int i = 0; i <= v.size(); i++) cout << f[i] << " ";
//		puts("");
		printf("%lld\n", f[v.size()]);
	}




	return 0;

}

