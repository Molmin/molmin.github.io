#include <bits/stdc++.h>
using namespace std;
//int fa1[100010][20], fa2[100010][20], fb1[100010][20], fb2[100010][20];
int a[100010], b[100010];
long long f[1010][1010];
long long st[1010][1010][11];
int main(){
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	int n, m, q;
	cin >> n >> m >> q; 
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	for(int i = 1; i <= m; i++) scanf("%d", &b[i]);
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= m; j++){
			f[i][j] = a[i] * 1ll * b[j];
			st[i][j][0] = f[i][j];
		}
	}
	for(int k = 1; k <= n; k++){
		for(int j = 1; j <= 10; j++){
			for(int i = 1; i <= m; i++){
				st[k][i][j] = min(st[k][i][j - 1], st[k][i + (1 << j - 1)][j - 1]);
			}
		}
	}
	while(q--){
		int l1, r1, l2, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		long long ma = -0x7f7f7f7f7f7f7f7f;
		for(int i = l1; i <= r1; i++){
			int k = log2(r2 - l2 + 1);
			ma = max({ma, st[i][l2][k], st[i][r2 - (1 << k) + 1][k]});
		}
		cout << ma << endl;
	}
	return 0;

}

