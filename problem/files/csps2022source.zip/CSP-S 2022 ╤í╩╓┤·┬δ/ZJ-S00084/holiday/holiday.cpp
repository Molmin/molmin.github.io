#include <bits/stdc++.h>
using namespace std;
struct edge{
	int to, nxt;
}e[20010];
int d[2510][2510];
int head[2510];
long long a[2510], f[2510][7];
bool v[2510];
int cnt = 0;
priority_queue <pair<int, int>, vector<pair<int, int> >, greater<pair<int ,int> > > q;
inline void add(int x, int y){
	e[++cnt] = {y, head[x]};
	head[x] = cnt;
}
inline void dijkstra(int s){
	memset(v, 0, sizeof(v));
	d[s][s] = 0;
	q.push({0, s});
	while(q.size()){
		int x = q.top().second;
		q.pop();
		if(v[x]) continue;
		//cout << 1 << endl;
		v[x] = 1;
		for(int i = head[x]; i; i = e[i].nxt){
			int y = e[i].to;
			//cout << x << ' ' << y << d[s][x] << " " << d[s][y] << endl;
			if(d[s][x] + 1 < d[s][y]){
				d[s][y] = d[s][x] + 1;
				q.push({d[s][y], y});
			}
		}
	}
}
int main(){
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	int n, m, k;
	cin >> n >> m >> k;
	for(int i = 2; i <= n; i++) scanf("%lld", &a[i]);
	for(int i = 1, x, y; i <= m; i++){
		scanf("%d%d", &x, &y);
		add(x, y);
		add(y, x);
	}
	memset(d, 0x3f, sizeof(d));
	for(int i = 1; i <= n; i++) dijkstra(i);
//	for(int i = 1; i <= 4; i ++){
//		for(int j = 1; j <= n; j++){
//			cout << f[j][i] << " ";
//		}
//		puts("");
//	}
	for(int i = 2; i <= n; i++) if(d[1][i] <= k + 1) f[i][1] = max(f[i][1], a[i]);
	for(int l = 2; l <= 4; l++){
		for(int i = 2; i <= n; i++){
			for(int j = 2; j < i; j++){
				//if(j == i) continue;
				//if(l == 4 && d[1][i] > k + 1) continue;
				if(d[i][j] <= k + 1) f[i][l] = max(f[i][l], f[j][l - 1] + a[i]);
			}
		}
	}
	for(int i = 2; i <= n; i++) if(d[1][i] <= k + 1) f[1][5] = max(f[1][5], f[i][4]);
//	long long ma = 0;
//	for(int i = 1; i <= n; i++) ma = max(ma, f[i][4]);
//	memset(f, 0, sizeof(f));
//	for(int i = 1; i <= n; i++) if(d[1][i] <= k + 1) f[i][1] = max(f[i][1], a[i]);
//	for(int l = 2; l <= 4; l++){
//		for(int i = 1; i <= n; i++){
//			for(int j = i + 1; j <= n; j++){
//				//if(j == i) continue;
//				if(l == 4 && d[1][i] > k + 1) continue;
//				if(d[i][j] <= k + 1) f[i][l] = max(f[i][l], f[j][l - 1] + a[i]);
//			}
//		}
//	}
//	for(int i = 1; i <= n; i++) ma = max(ma, f[i][4]);
	
	cout << f[1][5] << endl;

	return 0; 

}

