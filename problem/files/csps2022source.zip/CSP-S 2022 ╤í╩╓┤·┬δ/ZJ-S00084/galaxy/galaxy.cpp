#include <bits/stdc++.h>
using namespace std;
map <pair<int ,int>, bool> mm;
int ind[500010], od[500010];
bool f[500010];
struct edge{
	int to, nxt;
}e[500010];
int head[500010];
int cnt = 0;
inline void add(int x, int y){
	e[++cnt] = {y, head[x]};
	head[x] = cnt;
}
int qAq;
int xAx;
int n, m;
inline void de(int x, int y){
	if(mm[{x, y}]){
		mm[{x, y}] = 0;
		od[x]--;
		if(od[x] == 1) qAq--;
		if(od[x] == 0) qAq++;
	//	m--;
	}
}
inline void ae(int x, int y){
	if(!mm[{x, y}]){
		mm[{x, y}] = 1;
		od[x]++;
		if(od[x] == 1) qAq--;
		if(od[x] == 2) qAq++;
		//m++;
	}
}
int main(){
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	cin >> n >> m;
	for(int i = 1; i <= m; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		add(y, x);
		mm[{x, y}] = 1;
		od[x]++;
		//ind[x]++;
	}
	for(int i = 1; i <= n; i++) if(od[i] != 1) ++qAq;
//	for(int i = 1; i <= n; i++) if(ind[x] != 1) ++ini;
	int q;
	cin >> q;
	while(q--){
		int op, x, y;
		scanf("%d", &op);
		if(op == 1){
			scanf("%d%d", &x, &y);
			de(x, y);
		}else if(op == 2){
			scanf("%d", &x);
			for(int i = head[x]; i; i = e[i].nxt) de(e[i].to, x);
		}else if(op == 3){
			scanf("%d%d", &x, &y);
			ae(x, y);
		}else if(op == 4){
			scanf("%d", &x);
			for(int i = head[x]; i; i = e[i].nxt) ae(e[i].to, x);// ae(x, e[i].to);
		}
		if(qAq == 0) puts("YES");
		else puts("NO");
	}
	
	return 0;

}

