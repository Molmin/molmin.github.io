#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int MAXN = 114514;
const ll inf = 1e18;

ll n,m,q,a[MAXN],b[MAXN];

int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&q);
	for(ll i = 1;i <= n;i++)
		scanf("%lld",&a[i]);
	for(ll j = 1;j <= m;j++)
		scanf("%lld",&b[j]);
	
	while(q--){
		int l1,l2,r1,r2;
		ll ans = 0,bmax = -inf,bmin = inf,bmax2 = inf,bmin2 = -inf;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		ans = -inf;
		for(int j = l2;j <= r2;j++){
			bmax = max(bmax,b[j]);
			bmin = b[j] >= 0 ? min(bmin,b[j]) : bmin;
			bmax2 = b[j] < 0 ? min(bmax2,b[j]) : bmax2;
			bmin2 = b[j] <= 0 ? max(bmin2,b[j]) : bmin2;
		}
//		printf("%lld %lld %lld %lld\n",bmax,bmin,bmax2,bmin2);
		for(int i = l1;i <= r1;i++){
			if(a[i] > 0){
				if(bmax2 == inf){
					ans = max(ans,a[i] * bmin);
				}
				else{
					ans = max(ans,a[i] * bmax2);
				}
			}
			else if(a[i] < 0){
				if(bmax < 0){
					ans = max(ans,a[i] * bmin2);
				}
				else{
					ans = max(ans,a[i] * bmax);
				}
			}
			else {
				ans = max(1ll * 0,ans);
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
