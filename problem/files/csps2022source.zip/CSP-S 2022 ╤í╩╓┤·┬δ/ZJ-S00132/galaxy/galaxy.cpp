#include<bits/stdc++.h>

using namespace std;

const int MAXN = 501000;

int n,m,q;
vector<int> e[MAXN];

int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		e[u].push_back(v);
	}
	scanf("%d",&q);
	srand(q);
	while(q--){
		int kind;
		scanf("%d",&kind);
		switch(kind){
			case 1:{
				int u,v;
				scanf("%d%d",&u,&v);
				for(int i = 0;i < e[u].size();i++){
					if(e[u][i] == v){
						vector<int>::iterator it = e[u].begin() + i;
						e[u].erase(it);
					}
				}
				break;
			}
			case 2:{
				int u;
				scanf("%d",&u);
				e[u].clear();
				break;
			}
			case 3:{
				int u,v;
				scanf("%d%d",&u,&v);
				e[u].push_back(v);
				break;
			}
			case 4:{
				int u;
				scanf("%d",&u);
				break;
			}
		}
		int a = rand() % 6;
		if(a == 0)
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
}
