#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int MAXN = 2505;

int n,m,k,d[MAXN][MAXN];
ll v[MAXN],ans;
vector<int> e[MAXN];
bool vis[MAXN];

void floyd(){
	for(int l = 1;l <= n;l++)
		for(int i = 1;i <= n;i++)
			for(int j = 1;j <= n;j++)
				d[i][j] = min(d[i][j],d[i][l] + d[l][j] + 1);
	return ;			
}

void dfs(int x,int step,ll sum){
	if(step == 4){
		bool flag = 0;
		for(auto i : e[x]){
			if(i == 1){
				flag = 1;
				break;
			}
		}
		if(flag){
			ans = max(ans,sum);
		}
	}
	else{
		for(auto i : e[x]){
			if(!vis[i]){
				vis[i] = 1;
				dfs(i,step + 1,sum + v[i]);
				vis[i] = 0;
			}
		}
	}
	return ;
}

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i = 2;i <= n;i++){
		scanf("%lld",&v[i]);
	}
	memset(d,0x3f,sizeof(d));
	for(int i = 1;i <= m;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		d[v][u] = d[u][v] = 0;
		if(k == 0){
			e[u].push_back(v);
			e[v].push_back(u);
		}
	}
	if(k == 0){
		vis[1] = 1;
		dfs(1,0,0);
		printf("%lld\n",ans);
		return 0;
	}
	floyd();
	for(int i = 1;i <= n;i++){
		for(int j = i + 1;j <= n;j++)
			if(d[i][j] <= k){
				e[i].push_back(j);
				e[j].push_back(i);
			}
	}
	vis[1] = 1;
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}
