#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

const int MAXN = 114514;
const ll inf = 1e18;

int n,q,k;
ll ans,v[MAXN];
vector<int> tree[MAXN];
bool vis[MAXN];

void dfs(int x,int step,ll sum,int ed){
	if(sum > ans){
		return ;
	}
	if(x == ed){
		if(step != 0){
			sum += v[ed];
		}
		ans = min(ans,sum);
	}
	else{
		for(auto i : tree[x]){
			if(!vis[i]){
				vis[i] = 1;
				dfs(i,0,1ll * sum + v[i],ed);
				if(step + 1 < k){
					vis[i] = 0;
					dfs(i,step + 1,sum,ed);
				}
				vis[i] = 0;
			}
		}
	}
	return ;
}

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i = 1;i <= n;i++){
		scanf("%lld",&v[i]);
	}
	for(int i = 1;i < n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		tree[u].push_back(v);
		tree[v].push_back(u);
	}
	while(q--){
		int st,ed;
		scanf("%d%d",&st,&ed);
		ans = inf;
		dfs(st,0,v[st],ed);
		printf("%lld\n",ans);
	}
	return 0;
}
