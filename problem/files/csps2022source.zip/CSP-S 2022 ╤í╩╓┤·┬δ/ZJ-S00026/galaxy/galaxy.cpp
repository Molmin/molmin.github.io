#include<bits/stdc++.h>
using namespace std;
const int N=1005;
int n,m,q;
bool M0[N][N],M[N][N],F[N];
bool check1(int p){
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(M[p][i]) cnt++;
		if(cnt>1) return 0;
	}
	return cnt==1;
}
bool check2(int p){
	if(F[p]) return 1;
	for(int i=1;i<=n;i++){
		F[p]=1;
		if(M[p][i]&&check2(i)) return 1;
		F[p]=0;
	}
	return 0;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1,u,v;i<=m;i++){
		scanf("%d%d",&u,&v);
		M0[u][v]=M[u][v]=1;
	}
	scanf("%d",&q);
	for(int i=1,t,u,v;i<=q;i++){
		scanf("%d",&t);
		if(t==1){
			scanf("%d%d",&u,&v);
			M[u][v]=0;
		}
		if(t==2){
			scanf("%d",&u);
			for(int j=1;j<=n;j++) M[j][u]=0;
		}
		if(t==3){
			scanf("%d%d",&u,&v);
			M[u][v]=1;
		}
		if(t==4){
			scanf("%d",&u);
			for(int j=1;j<=n;j++) M[j][u]=M0[j][u];
		}
		bool flag=1;
		memset(F,0,sizeof(F));
		for(int j=1;j<=n;j++){
			if(!check1(j)){flag=0;break;}
			if(!check2(j)){flag=0;break;}
		}
		printf(flag?"YES\n":"NO\n");
	}
	return 0;
}