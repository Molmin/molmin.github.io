#include<bits/stdc++.h>
using namespace std;
const int N=2505;
int n,m,k;
long long s[N],ans;
vector<int> V[N];
bool F0[N],F1[N],F2[N];
void init(int p,int step){
	if(step==3) return;
	int len=V[p].size();
	for(int i=0;i<len;i++){
		int np=V[p][i];
		init(np,step+1);
		F2[np]=1;
	}
}
void dfs(int p,int step,long long sum){
	int len=V[p].size();
	if(step==4){
		for(int i=0;i<len;i++){
			int np=V[p][i];
			if(np!=1&&!F1[np]&&F0[np]){
				sum+=s[np];
				if(sum>ans) ans=sum;
			}
		}
	}
	if(step==3){
		for(int i=0;i<len;i++){
			int np=V[p][i];
			if(np!=1&&!F1[np]&&F2[np]){
				F1[np]=1;
				dfs(np,step+1,sum+s[np]);
				F1[np]=0;
			}
		}
	}
	if(step<=2){		
		for(int i=0;i<len;i++){
			int np=V[p][i];
			if(np!=1&&!F1[np]){
				F1[np]=1;
				dfs(np,step+1,sum+s[np]);
				F1[np]=0;
			}
		}
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)
		scanf("%lld",&s[i]);
	for(int i=1,u,v,c=0;i<=m;i++){
		scanf("%d%d",&u,&v);
		V[u].push_back(v);
		V[v].push_back(u);
		if(u==1) F0[++c]=v;
		if(v==1) F0[++c]=u;
	}
	init(1,1);
	dfs(1,1,0);
	printf("%lld",ans);
	return 0;
}