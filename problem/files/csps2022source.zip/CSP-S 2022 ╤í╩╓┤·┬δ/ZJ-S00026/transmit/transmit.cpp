#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n,q,k,f[N],h[N],v[N];
vector<int> V[N];
void dfs(int p){
	int len=V[p].size();
	for(int i=0;i<len;i++){
		int np=V[p][i];
		if(np!=f[p]) h[np]=h[p]+1,f[np]=p,dfs(np);
	}
}
long long lca(int s,int t){
	long long sum=0;
	for(;h[s]<h[t];t=f[t]) sum+=v[t];
	for(;s!=t;s=f[s],t=f[t]) sum+=v[s]+v[t];
	return sum+v[s];
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++) scanf("%d",&v[i]);
	for(int i=1,s,t;i<n;i++){
		scanf("%d%d",&s,&t);
		V[s].push_back(t);
		V[t].push_back(s);
	}
	dfs(1);
	for(int i=1,s,t;i<=q;i++){
		scanf("%d%d",&s,&t);
		printf("%lld\n",h[s]<h[t]?lca(s,t):lca(t,s));
	}
	return 0;
}