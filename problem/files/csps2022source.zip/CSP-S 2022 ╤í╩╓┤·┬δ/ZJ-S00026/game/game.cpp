#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,m,q,l1,r1,l2,r2;
long long a[N],b[N];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++) scanf("%lld",&b[i]);
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long ans=-1e18;
		for(int i=l1;i<=r1;i++){
			long long minn=1e18;
			bool fl=1;
			for(int j=l2;j<=r2;j++){
				long long s=a[i]*b[j];
				if(s<minn) minn=s;
				if(s<ans){fl=0;break;}
			}
			if(fl&&minn>ans) ans=minn;
		}
		printf("%lld\n",ans);
	}
	return 0;
}