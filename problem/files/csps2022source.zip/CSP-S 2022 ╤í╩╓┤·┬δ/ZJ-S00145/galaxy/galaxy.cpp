#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
int n,m,q;
ull a[500005];
ull now0[500005],now1[500005];
int e0[500005],e1[500005];
vector<int> edge[500005];
ull seed;
ull getrand(){
	seed^=seed>>7;
	seed^=seed<<15;
	seed^=seed>>10;
	return seed;
}
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	srand(time(NULL));
	seed=rand();
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)a[i]=getrand();
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		edge[x].push_back(y);
		now1[y]+=a[x];e1[y]++;
	}
	scanf("%d",&q);
	int nowcnt=m;ull nowsum=0,oksum=0;
	for(int i=1;i<=n;i++)nowsum+=now1[i],oksum+=a[i];
	while(q--){
		int opt;scanf("%d",&opt);
		if(opt==1){
			int x,y;scanf("%d%d",&x,&y);
			nowcnt--;
			e0[y]++,e1[y]--;
			nowsum-=a[x];
			now0[y]+=a[x],now1[y]-=a[x];
		}else if(opt==2){
			int x;scanf("%d",&x);
			nowcnt-=e1[x];
			e0[x]+=e1[x],e1[x]=0;
			nowsum-=now1[x];
			now0[x]+=now1[x],now1[x]=0;
		}else if(opt==3){
			int x,y;scanf("%d%d",&x,&y);
			nowcnt++;
			e0[y]--,e1[y]++;
			nowsum+=a[x];
			now0[y]-=a[x],now1[y]+=a[x];
		}else if(opt==4){
			int x;scanf("%d",&x);
			nowcnt+=e0[x];
			e1[x]+=e0[x],e0[x]=0;
			nowsum+=now0[x];
			now1[x]+=now0[x],now0[x]=0;
		}
		if(nowcnt==n&&nowsum==oksum)puts("YES");
		else puts("NO");
	}
	return 0;
}