#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,k;
ll a[2505];
vector<int> edge[2505];
int dis[2505][2505],vis[2505];
queue<int> que;
set<pair<ll,int> >S[2505];
void BFS(int s){
	memset(dis[s],0x3f,sizeof(dis[s]));
	memset(vis,0,sizeof(vis));
	dis[s][s]=0;vis[s]=1;
	que.push(s);
	while(!que.empty()){
		int x=que.front();que.pop();
		for(int y:edge[x])if(!vis[y])vis[y]=1,dis[s][y]=dis[s][x]+1,que.push(y);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);k++;
	for(int i=2;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++){
		int x,y;scanf("%d%d",&x,&y);
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	for(int i=1;i<=n;i++)BFS(i);
	for(int i=2;i<=n;i++){
		for(int j=2;j<=n;j++)if(j!=i&&dis[1][j]<=k&&dis[j][i]<=k){
			if(S[i].size()<3)S[i].insert(make_pair(a[j],j));
			else{
				if(a[j]<=(*S[i].begin()).first)continue;
				S[i].erase(S[i].begin());
				S[i].insert(make_pair(a[j],j));
			}
		}
	}
	ll ans=0;
	for(int i=2;i<=n;i++)
		for(int j=2;j<=n;j++)if(i!=j&&dis[i][j]<=k){
			set<pair<ll,int> > sx=S[i],sy=S[j];
			for(auto it:sx)if(it.second==j){sx.erase(it);break;}
			for(auto it:sy)if(it.second==i){sy.erase(it);break;}
			if(sx.empty()||sy.empty())continue;
			ll res=0;
			auto ix=--sx.end(),iy=--sy.end();
			if((*ix).second==(*iy).second){
				if(sx.size()>1)res=max(res,(*--ix).first+(*iy).first);
				if(sy.size()>1)res=max(res,(*--iy).first+(*ix).first);
			}else res=(*ix).first+(*iy).first;
			ans=max(ans,res+a[i]+a[j]);
		}
	printf("%lld\n",ans);
	return 0;
}