#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,q,k;
ll a[200005];
vector<int> edge[200005];
int fa[200005][25],dep[200005];
void dfs(int x,int f){
	fa[x][0]=f;dep[x]=dep[f]+1;
	for(int i=1;i<=20;i++)fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int y:edge[x])if(y!=f)dfs(y,x);
}
int LCA(int x,int y){
	int k=20;
	if(dep[x]<dep[y])swap(x,y);
	while(dep[x]>dep[y]){
		if(dep[fa[x][k]]>=dep[y])x=fa[x][k];
		k--;
	}
	if(x==y)return x;
	k=20;
	while(k>=0){
		if(fa[x][k]!=fa[y][k])x=fa[x][k],y=fa[y][k];
		k--;
	}
	return fa[x][0];
}
namespace k_1{
	ll dis[200005];
	void dfs(int x,int f){
		dis[x]=dis[f]+a[x];
		for(int y:edge[x])if(y!=f)dfs(y,x);
	}
	void main(){
		dfs(1,0);
		while(q--){
			int x,y;scanf("%d%d",&x,&y);
			int lca=LCA(x,y);
			printf("%lld\n",dis[x]+dis[y]-dis[lca]-dis[fa[lca][0]]);
		}
	}
}
namespace n_200{
	ll dis[205][205];
	void main(){
		memset(dis,0x3f,sizeof(dis));
		for(int i=1;i<=n;i++)dis[i][i]=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)if(dep[i]+dep[j]-2*dep[LCA(i,j)]<=k)
				dis[i][j]=a[j],dis[j][i]=a[i];
		for(int p=1;p<=n;p++)
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++)
					dis[i][j]=min(dis[i][j],dis[i][p]+dis[p][j]);
		while(q--){
			int x,y;scanf("%d%d",&x,&y);
			printf("%lld\n",a[x]+dis[x][y]);
		}
	}
}
namespace k_2{
	struct Matrix{
		ll a[2][2];
	}val[200005][25];
	const Matrix operator *(const Matrix &x,const Matrix &y){
		Matrix res;memset(res.a,0x3f,sizeof(res.a));
		for(int i=0;i<2;i++)
			for(int j=0;j<2;j++)
				for(int p=0;p<2;p++)res.a[i][p]=min(res.a[i][p],x.a[i][j]+y.a[j][p]);
		return res;
	}
	Matrix jump(int x,int d){
		Matrix res;
		res.a[0][0]=res.a[1][1]=0;
		res.a[0][1]=res.a[1][0]=0x3f3f3f3f3f3f3f3fll;
		for(int i=20;i>=0;i--)if(d&(1<<i))res=res*val[x][i],x=fa[x][i];
		return res;
	}
	void main(){
		for(int i=1;i<=n;i++){
			val[i][0].a[0][0]=0x3f3f3f3f3f3f3f3fll;
			val[i][0].a[0][1]=0;
			val[i][0].a[1][0]=val[i][0].a[1][1]=a[i];
		}
		for(int j=1;j<=20;j++)
			for(int i=1;i<=n;i++)if(fa[i][j])val[i][j]=val[i][j-1]*val[fa[i][j-1]][j-1];
		while(q--){
			int x,y;scanf("%d%d",&x,&y);
			int lca=LCA(x,y);
			Matrix xx=jump(x,dep[x]-dep[lca]),yy=jump(y,dep[y]-dep[lca]);
			printf("%lld\n",min(xx.a[1][0]+yy.a[1][0],xx.a[1][1]+yy.a[1][1]+a[lca]));
		}
	}
}
namespace n_2000k_3{
	int pos[200005];
	ll b[200005],c[200005];int cnt;
	ll f[200005],g[200005],h[200005];
	void main(){
		while(q--){
			int x,y;scanf("%d%d",&x,&y);
			int lca=LCA(x,y);
			cnt=0;
			for(int i=x;i!=lca;i=fa[i][0])pos[++cnt]=i;
			pos[++cnt]=lca;
			cnt+=dep[y]-dep[lca];
			for(int i=y,j=cnt;i!=lca;i=fa[i][0],j--)pos[j]=i;
			pos[cnt+1]=0;
			for(int i=1;i<=cnt;i++){
				b[i]=a[pos[i]];c[i]=0x3f3f3f3f3f3f3f3fll;
				for(int j:edge[pos[i]])if(j!=pos[i-1]&&j!=pos[i+1])c[i]=min(c[i],a[j]);
			}
			f[1]=b[1],g[1]=0x3f3f3f3f3f3f3f3fll;
			for(int i=2;i<=cnt;i++){
				f[i]=min(f[i-1],g[i-1]);
				if(i>2)f[i]=min(f[i],min(f[i-2],g[i-2]));
				if(i>3)f[i]=min(f[i],f[i-3]);
				f[i]+=b[i];
				g[i]=min(f[i-1],g[i-1]);
				if(i>2)g[i]=min(g[i],f[i-2]);
				g[i]+=c[i];
			}
			printf("%lld\n",f[cnt]);
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<n;i++){
		int x,y;scanf("%d%d",&x,&y);
		edge[x].push_back(y);
		edge[y].push_back(x);
	}
	dfs(1,0);
	if(k==1)return k_1::main(),0;
	else if(n<=200)return n_200::main(),0;
	else if(k==2)return k_2::main(),0;
	else return n_2000k_3::main(),0;
	return 0;
}