#include<bits/stdc++.h>
using namespace std;
#define ll long long
int n,m,q;
ll a[100005],b[100005];
struct node{
	ll mx,mn;
};
const node operator +(const node &x,const node &y){
	return (node){max(x.mx,y.mx),min(x.mn,y.mn)};
}
struct SegT{
	node tree[400005];
	void build(int k,int l,int r){
		if(l==r){
			tree[k]=(node){(ll)-2e9,(ll)2e9};
			return;
		}
		int mid=l+r>>1;
		build(k*2,l,mid);
		build(k*2+1,mid+1,r);
		tree[k]=tree[k*2]+tree[k*2+1];
	}
	void change(int k,int l,int r,int x,ll y){
		if(l==r){
			tree[k]=(node){y,y};
			return;
		}
		int mid=l+r>>1;
		if(x<=mid)change(k*2,l,mid,x,y);
		else change(k*2+1,mid+1,r,x,y);
		tree[k]=tree[k*2]+tree[k*2+1];
	}
	node query(int k,int l,int r,int x,int y){
		if(l>=x&&r<=y)return tree[k];
		int mid=l+r>>1;
		if(y<=mid)return query(k*2,l,mid,x,y);
		else if(x>mid)return query(k*2+1,mid+1,r,x,y);
		else return query(k*2,l,mid,x,y)+query(k*2+1,mid+1,r,x,y);
	}
}Ta1,Ta2,Tb1,Tb2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	Ta1.build(1,1,n);Ta2.build(1,1,n);
	Tb1.build(1,1,m);Tb2.build(1,1,m);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		if(a[i]>=0)Ta1.change(1,1,n,i,a[i]);
		else Ta2.change(1,1,n,i,a[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld",&b[i]);
		if(b[i]>=0)Tb1.change(1,1,m,i,b[i]);
		else Tb2.change(1,1,m,i,b[i]);
	}
	while(q--){
		int l1,r1,l2,r2;scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		node a1=Ta1.query(1,1,n,l1,r1),a2=Ta2.query(1,1,n,l1,r1);
		node b1=Tb1.query(1,1,m,l2,r2),b2=Tb2.query(1,1,m,l2,r2);
		ll ans=-2e18;
		if(a1.mn==0)ans=0;
		if(a1.mx>0){
			if(b2.mn<0)ans=max(ans,a1.mn*b2.mn);
			else ans=max(ans,a1.mx*b1.mn);
		}
		if(a2.mn<0){
			if(b1.mx>0)ans=max(ans,a2.mx*b1.mx);
			else ans=max(ans,a2.mn*b2.mx);
		}
		printf("%lld\n",ans);
	}
	return 0;
}