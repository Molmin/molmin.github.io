#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
int a[N],b[N];
int n,m,q;
int l1,r1;
int l2,r2;

int ask_maxa(int l,int r)
{
    int ans_max=a[l];
    for(int i=l+1;i<=r;i++)
    {
        ans_max=max(ans_max,a[i]);
    }
    return ans_max;
}
int ask_mina(int l,int r)
{
    int ans_min=a[l];
    for(int i=l+1;i<=r;i++)
    {
        if(a[i]<0)continue;
        ans_min=min(ans_min,a[i]);
    }
    return ans_min;
}

int ask_maxb(int l,int r)
{
    int ans_max=b[l];
    for(int i=l+1;i<=r;i++)
    {
        ans_max=max(ans_max,b[i]);
    }
    return ans_max;
}
int ask_minb(int l,int r)
{
    int ans_min=b[l];
    for(int i=l+1;i<=r;i++)
    {
        ans_min=min(ans_min,b[i]);
    }
    return ans_min;
}

bool ask_mza(int l,int r)
{
    for(int i=l;i<=r;i++)
    {
        if(a[i]<0)return true;
    }
    return false;
}
bool ask_mzb(int l,int r)
{
    for(int i=l;i<=r;i++)
    {
        if(b[i]<0)return true;
    }
    return false;
}

int main()

{
    freopen("game.in","r",stdin);
    freopen("game.out","w",stdout);
    ios::sync_with_stdio(false);
    cin>>n>>m>>q;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];

    }
    for(int i=1;i<=m;i++)
    {
        cin>>b[i];
    }
    //int char_one=1;
    while(q--)
    {
        int ta,tb;
        cin>>l1>>r1>>l2>>r2;
            if(ask_mzb(l2,r2))
            {
                ta=ask_mina(l1,r1);
            }
            else ta=ask_maxa(l1,r1);
            if(ask_mza(l1,r1))
            {
                tb=ask_maxb(l2,r2);
            }
            else tb=ask_minb(l2,r2);
            cout<<ta*tb<<endl;
    }
//    for(int i=1;i<=n;i++)
//    {
//        cout<<a[i]<<" ";
//
//    }cout<<endl;
//    for(int i=1;i<=m;i++)
//    {
//        cout<<b[i]<<" ";
//    }cout<<endl;




    return 0;
}
