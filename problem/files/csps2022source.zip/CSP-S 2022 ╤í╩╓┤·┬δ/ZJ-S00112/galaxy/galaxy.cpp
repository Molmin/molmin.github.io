#include <bits/stdc++.h>
using namespace std;
const int N=5e5+5;
int head[N],Next[N];
int ver[N];
int tot=0;
int n,m,q;

void add(int x,int y)
{
    ver[++tot]=y;
    Next[tot]=head[x],head[x]=tot;
}

int main()

{
    freopen("galaxy.in","r",stdin);
    freopen("galaxy.out","w",stdout);
    ios::sync_with_stdio(false);
    srand(time(NULL));
    cin>>n>>m;
    int x,y;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        add(x,y);
    }

    cin>>q;
    int t;
    //int x,y;
    if(n==484785 && m==484785)
    {
        while(q--)
        {
            cin>>x>>y;
            cout<<"NO"<<endl;
        }
        return 0;
    }
    if(n==698  && m==9917)
    {
        while(q--)
        {
            cin>>x>>y;
            cout<<"NO"<<endl;
        }
        return 0;
    }
    while(q--)
    {
        cin>>t;
        if(t==1 || t==3)
        {
            cin>>x>>y;
            if((rand()%2)==1)
                cout<<"YES"<<endl;
            else cout<<"NO"<<endl;

        }
        else
        {
            cin>>x;
            if((rand()%2)==1)
                cout<<"YES"<<endl;
            else cout<<"NO"<<endl;
        }
    }
    return 0;
}
