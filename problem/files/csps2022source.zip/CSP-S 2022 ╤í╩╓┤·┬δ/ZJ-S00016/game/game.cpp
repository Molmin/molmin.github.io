#include<bits/stdc++.h>
#define ll long long
template <typename T> void read (T &x){
	T sign=1,sum=0;
	char c=getchar();
	while (!isdigit(c)){
		if (c=='-'){
			sign=-1;
		}
		c=getchar();
	}
	while (isdigit(c)){
		sum=(sum<<1)+(sum<<3)+c-'0';
		c=getchar();
	}
	x=sign*sum;
}
template <typename T> T max(T a,T b){
	return a>b?a:b;
}
template <typename T> T min(T a,T b){
	return a<b?a:b;
}
const ll inf=1e10+7;
const int N=1e6+50;
ll a[N],b[N];
int n,m;
int q;
const int Size=N<<1;
int roota,rootb;
struct Val{
	ll negmax,posmin,Max,Min;
};
struct Segment_Treea{
	int tot=0,lc[Size],rc[Size];
	Val node[Size];
	int add_node(){
		++tot;
		node[tot].negmax=-inf;
		node[tot].posmin=inf;
		node[tot].Max=-inf;
		node[tot].Min=inf;
		return tot;
	}
	Val merge(Val x,Val y){
		Val res;
		res.negmax=max(x.negmax,y.negmax);
		res.posmin=min(x.posmin,y.posmin);
		res.Max=max(x.Max,y.Max);
		res.Min=min(x.Min,y.Min);
		return res;
	}
	void update(int rt,ll k){
		if (k>=0){
			node[rt].posmin=k;
		}
		if (k<=0){
			node[rt].negmax=k;
		}
		node[rt].Max=k;
		node[rt].Min=k;
	}
	void push_up(int rt){
		node[rt].negmax=max(node[lc[rt]].negmax,node[rc[rt]].negmax);
		node[rt].posmin=min(node[lc[rt]].posmin,node[rc[rt]].posmin);
		node[rt].Max=max(node[lc[rt]].Max,node[rc[rt]].Max);
		node[rt].Min=min(node[lc[rt]].Min,node[rc[rt]].Min);
	}
	void build(int &rt,int l,int r){
		if (!rt){
			rt=add_node();		
		}
		if (l==r){
			update(rt,a[l]);
			return;
		}
		int mid=l+r>>1;
		build(lc[rt],l,mid);
		build(rc[rt],mid+1,r);
		push_up(rt);
	}
	Val query(int rt,int l,int r,int L,int R){
		if (L<=l&&r<=R){
			return node[rt];
		}
		Val res;
		res.negmax=-inf;
		res.posmin=inf;
		res.Max=-inf;
		res.Min=inf;
		int mid=l+r>>1;
		if (L<=mid){
			res=merge(res,query(lc[rt],l,mid,L,R));
		}
		if (mid+1<=R){
			res=merge(res,query(rc[rt],mid+1,r,L,R));
		}
		return res;
	}
}sgta;
struct Segment_Treb{
	int tot=0,lc[Size],rc[Size];
	Val node[Size];
	int add_node(){
		++tot;
		node[tot].negmax=-inf;
		node[tot].posmin=inf;
		node[tot].Max=-inf;
		node[tot].Min=inf;
		return tot;
	}
	Val merge(Val x,Val y){
		Val res;
		res.negmax=max(x.negmax,y.negmax);
		res.posmin=min(x.posmin,y.posmin);
		res.Max=max(x.Max,y.Max);
		res.Min=min(x.Min,y.Min);
		return res;
	}
	void update(int rt,ll k){
		if (k>=0){
			node[rt].posmin=k;
		}
		if (k<=0){
			node[rt].negmax=k;
		}
		node[rt].Max=k;
		node[rt].Min=k;
	}
	void push_up(int rt){
		node[rt].negmax=max(node[lc[rt]].negmax,node[rc[rt]].negmax);
		node[rt].posmin=min(node[lc[rt]].posmin,node[rc[rt]].posmin);
		node[rt].Max=max(node[lc[rt]].Max,node[rc[rt]].Max);
		node[rt].Min=min(node[lc[rt]].Min,node[rc[rt]].Min);
	}
	void build(int &rt,int l,int r){
		if (!rt){
			rt=add_node();		
		}
		if (l==r){
			update(rt,b[l]);
			return;
		}
		int mid=l+r>>1;
		build(lc[rt],l,mid);
		build(rc[rt],mid+1,r);
		push_up(rt);
	}
	Val query(int rt,int l,int r,int L,int R){
		if (L<=l&&r<=R){
			return node[rt];
		}
		Val res;
		res.negmax=-inf;
		res.posmin=inf;
		res.Max=-inf;
		res.Min=inf;
		int mid=l+r>>1;
		if (L<=mid){
			res=merge(res,query(lc[rt],l,mid,L,R));
		}
		if (mid+1<=R){
			res=merge(res,query(rc[rt],mid+1,r,L,R));
		}
		return res;
	}
}sgtb;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	read(n),read(m);
	read(q);
	for (int i=1;i<=n;++i){
		read(a[i]);
	}
	for (int j=1;j<=m;++j){
		read(b[j]);
	}
	sgta.build(roota,1,n);
	sgtb.build(rootb,1,m);
	for (int i=1;i<=q;++i){
		int l1,l2,r1,r2;
		read(l1),read(r1),read(l2),read(r2);
		Val A=sgta.query(roota,1,n,l1,r1);
		Val B=sgtb.query(rootb,1,m,l2,r2);
		ll res;
		if (B.Min>=0){
			if (A.Max<=0){
				res=A.Max*B.Max;
			}
			else{
				res=A.Max*B.Min;
			}
		}
		else{
			if (B.Max<=0){
				if (A.Min>=0){
					res=B.Min*A.Min;
					
				}
				else{	
					res=A.Min*B.Max;
				}
			}
			else{
				if (A.negmax==-inf){
					res=A.posmin*B.Min;
				}
				else{
					if (A.posmin==inf){
						res=A.negmax*B.Max;
					}
					else{	
						res=max(1ll*A.negmax*B.Max,1ll*A.posmin*B.Min);
					}
				}
			}			
		}
		printf("%lld\n",res);
	}
	return 0;
}
