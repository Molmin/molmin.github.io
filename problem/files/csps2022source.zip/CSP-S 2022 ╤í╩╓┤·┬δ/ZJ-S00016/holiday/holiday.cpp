#include<bits/stdc++.h>
#define ll long long
template <typename T> void read (T &x){
	T sign=1,sum=0;
	char c=getchar();
	while (!isdigit(c)){
		if (c=='-'){
			sign=-1;
		}
		c=getchar();
	}
	while (isdigit(c)){
		sum=(sum<<1)+(sum<<3)+c-'0';
		c=getchar();
	}
	x=sign*sum;
}
template<typename T> T max(T a,T b){
	return a>b?a:b;
}
const int inf=0x7fffffff;
const int N=2500+10;
const int M=2e4+10;
int n,k;
int m;
ll s[N];
int avi[N];
int asdf[N];
int dis[N][N];
ll f[4][N];
int pos[4][N];
int vis[N];
std::vector<int> to[N];
struct node{
	int id;
	ll s;
	bool operator < (node x) const{
		return s>x.s;
	}
};
std::vector<node> g[N];
struct Node{
	int id;
	int dist;
	bool operator < (Node x) const{
		return dist>x.dist;
	}
};
std::priority_queue<Node> q;
std::vector<int> e[N];
void dij(int s){
	for (int i=1;i<=n;++i){
		dis[s][i]=inf;
		vis[i]=0;
	}
	dis[s][s]=-1;
	q.push(Node{s,-1});
	while (!q.empty()){
		Node t=q.top();
		int u=t.id;
		q.pop();
		if (vis[u]){
			continue;
		}
		for (int i=0;i<e[u].size();++i){
			int v=e[u][i];
			if (dis[s][v]>dis[s][u]+1){
				dis[s][v]=dis[s][u]+1;
				q.push(Node{v,dis[s][v]});
			}
		}
		vis[u]=1;
	}
}
bool check(int a,int b,int c,int d){
	if (a==b){
		return 0;
	}
	if (b==c){
		return 0;
	}
	if (c==d){
		return 0;
	}
	if (d==a){
		return 0;
	}
	if (a==c){
		return 0;
	}
	if (b==d){
		return 0;
	}
	if (a==1){
		return 0;
	}
	if (b==1){
		return 0;
	}
	if (c==1){
		return 0;
	}
	if (d==1){
		return 0;
	}
	return 1;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	read(n),read(m),read(k);
	for (int i=2;i<=n;++i){
		read(s[i]);
		f[1][i]=f[2][i]=f[3][i]=-inf;
	}
	for (int i=1;i<=m;++i){
		int u,v;
		read(u),read(v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	for (int i=1;i<=n;++i){
		dij(i);
	}
	for (int i=1;i<=n;++i){
		for (int j=i+1;j<=n;++j){
			if (dis[i][j]<=k){
				to[i].push_back(j);
				to[j].push_back(i);
			}
		}
	}
	for (int i=0;i<to[1].size();++i){
		int v=to[1][i];
		asdf[v]=1;
		for (int j=0;j<to[v].size();++j){
				 avi[to[v][j]]=1;
		}
	}
	for (int i=2;i<=n;++i){
		for (int j=0;j<to[i].size();++j){
			int v=to[i][j];
			if (asdf[v]==1){
				g[i].push_back(node{v,s[v]});
			}
		}
	}
	for (int i=2;i<=n;++i){
		std::sort(g[i].begin(),g[i].end());
	}
	ll ans=0;
	for (int i=2;i<=n;++i){
		if (!avi[i]){
			continue;
		}
		for (int j=0;j<to[i].size();++j){
			int u=i,v=to[i][j];
			if (!avi[v]){
				continue;
			}
			for (int p=0;p<=3&&p<g[u].size();++p){
				if (!asdf[g[u][p].id]){
					continue;
				}
				for (int q=0;q<=3&&q<g[v].size();++q){
					int x=g[u][p].id,y=g[v][q].id;
					if (!asdf[y]){
						continue;
					}
					if (check(x,u,v,y)){
						ans=max(ans,s[u]+s[v]+s[x]+s[y]);
					}
				}
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
