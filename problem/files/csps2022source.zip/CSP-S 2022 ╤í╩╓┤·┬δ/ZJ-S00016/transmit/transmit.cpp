#include<bits/stdc++.h>
#define ll long long
template <typename T> void read (T &x){
	T sign=1,sum=0;
	char c=getchar();
	while (!isdigit(c)){
		if (c=='-'){
			sign=-1;
		}
		c=getchar();
	}
	while (isdigit(c)){
		sum=(sum<<1)+(sum<<3)+c-'0';
		c=getchar();
	}
	x=sign*sum;
}
template <typename T> T min(T a,T b){
	return a<b?a:b;
}
const int inf=0x7fffffff;
const int N=2e5+10;
const int K=40;
int n;
int k;
std::vector<int> e[N];
ll val[N];
ll dis[N];
int dep[N];
int f[N][K];
void dfs(int u,int fa){
	dep[u]=dep[fa]+1;
	dis[u]=dis[fa]+val[u];
	f[u][0]=fa;
	for (int i=0;i<e[u].size();++i){
		int v=e[u][i];
		if (v==fa){
			continue;
		}
		dfs(v,u);
	}
	for (int i=1;i<K;++i){
		f[u][i]=f[f[u][i-1]][i-1];
	}
}
int lca(int a,int b){
	if (dep[a]<dep[b]){
		std::swap(a,b);
	}
	for (int i=K-1;i>=0;--i){
		if (dep[f[a][i]]>=dep[b]){
			a=f[a][i];
		}
	}
	for (int i=K-1;i>=0;--i){
		if (f[a][i]!=f[b][i]){
			a=f[a][i];
			b=f[b][i];
		}
	}
	if (f[a][0]==0){
		return a;
	}
	return f[a][0];
}
ll g[N];
void up(int u,int top,int &ne_1,int &ne_2,int &ne_3){
	if (f[u][0]==top){
		ne_1=u;
	}
	if (f[u][1]==top){
		ne_2=u;
	}
	if (f[f[u][0]][1]==top){
		ne_3=u;
	}
	g[u]=inf;
	if (u==top){
		return;
	}
	up(f[u][0],top,ne_1,ne_2,ne_3);
}
int n_a,n_b,nn_a,nn_b,nnn_a,nnn_b;
void dfs2(int u,int top){
	if (u==top){
		return;
	}
	g[f[u][0]]=min(g[f[u][0]],g[u]+val[f[u][0]]);
	if (k>=2){
		g[f[u][1]]=min(g[f[u][1]],g[u]+val[f[u][1]]);
	}
	if (k==3){
		g[f[f[u][0]][1]]=min(g[f[f[u][0]][1]],g[u]+val[f[f[u][0]][1]]);
	}
	dfs2(f[u][0],top);
}
ll get_ans(int a,int b){
	int ff=lca(a,b);
	if (dep[a]+dep[b]-2*dep[ff]<=k){
		return val[a]+val[b];
	}
	up(a,ff,n_a,nn_a,nnn_a);
	up(b,ff,n_b,nn_b,nnn_b);
	g[a]=val[a],g[b]=val[b];
	dfs2(a,ff);
	dfs2(b,n_b);
	g[0]=inf;
	if (k==2){
		return min(g[ff]+min(g[n_b],g[nn_b]),g[n_a]+g[n_b]);
	}
	return min(g[ff]+min(min(g[n_b],g[nn_b]),g[nnn_b]),min(g[n_a]+min(g[n_b],g[nn_b]),g[nn_a]+g[n_b]));
}
int Q;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	read(n),read(Q),read(k);
	for (int i=1;i<=n;++i){
		read(val[i]);
	}
	for (int i=1;i<n;++i){
		int u,v;
		read(u),read(v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,0);
	if (k==1){
		for (int i=1;i<=Q;++i){
			int a,b;
			read(a),read(b);
			int l=lca(a,b);
			printf("%lld\n",dis[a]+dis[b]-2*dis[l]+val[l]);
		}		
	}
	else{
		for (int i=1;i<=Q;++i){
			int a,b;
			read(a),read(b);
			printf("%lld\n",get_ans(a,b));
		}
	}
	return 0;
}
