#include <bits/stdc++.h>

using namespace std;

int read() {
	int x=0, f=0; char c=getchar();
	while (!isdigit(c)) f|=c=='-', c=getchar();
	while (isdigit(c)) x=(x<<3)+(x<<1)+(c^48), c=getchar();
	return f ? -x : x;
}

const int N=1e5+10;
int n, m, q, a[N], b[N];

struct seg {
	int mn[N<<2], mx[N<<2];
	void init() {
		memset(mn, 127, sizeof mn);
		memset(mx, -127, sizeof mx);
	}
	void add(int p, int l, int r, int x, int v) {
		if (l==r) return mn[p]=mx[p]=v, void();
		int mid=l+r>>1;
		if (x<=mid) add(p<<1, l, mid, x, v);
		else add(p<<1|1, mid+1, r, x, v);
		mn[p]=min(mn[p<<1], mn[p<<1|1]);
		mx[p]=max(mx[p<<1], mx[p<<1|1]);
	}
	int askmin(int p, int l, int r, int L, int R) {
		if (L<=l && r<=R) return mn[p];
		int mid=l+r>>1, res=2e9;
		if (L<=mid) res=min(res, askmin(p<<1, l, mid, L, R));
		if (R>mid) res=min(res, askmin(p<<1|1, mid+1, r, L, R));
		return res;
	}
	int askmax(int p, int l, int r, int L, int R) {
		if (L<=l && r<=R) return mx[p];
		int mid=l+r>>1, res=-2e9;
		if (L<=mid) res=max(res, askmax(p<<1, l, mid, L, R));
		if (R>mid) res=max(res, askmax(p<<1|1, mid+1, r, L, R));
		return res;
	}
} t1, t2, t3;

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	n=read(), m=read(), q=read();
	t1.init(), t2.init(), t3.init();
	for (int i=1; i<=n; i++) {
		a[i]=read();
		if (a[i]>=0) t1.add(1, 1, n, i, a[i]);
		if (a[i]<=0) t2.add(1, 1, n, i, a[i]);
	}
	for (int i=1; i<=m; i++) {
		b[i]=read();
		t3.add(1, 1, m, i, b[i]);
	}
	while (q--) {
		int l1=read(), r1=read();
		int l2=read(), r2=read();
		int mx=t3.askmax(1, 1, m, l2, r2), mn=t3.askmin(1, 1, m, l2, r2);
		long long res1=-1e18, res2=-1e18;
		if (t1.askmax(1, 1, n, l1, r1)>=0) {
			if (mn>=0) res1=1ll*t1.askmax(1, 1, n, l1, r1)*mn;
			else res1=1ll*t1.askmin(1, 1, n, l1, r1)*mn;
		}
		if (t2.askmin(1, 1, n, l1, r1)<=0) {
			if (mx>=0) res2=1ll*t2.askmax(1, 1, n, l1, r1)*mx;
			else res2=1ll*t2.askmin(1, 1, n, l1, r1)*mx;
		}
		printf("%lld\n", max(res1, res2));
	}
	return 0;
}