#include <bits/stdc++.h>

using namespace std;

int read() {
	int x=0, f=0; char c=getchar();
	while (!isdigit(c)) f|=c=='-', c=getchar();
	while (isdigit(c)) x=(x<<3)+(x<<1)+(c^48), c=getchar();
	return f ? -x : x;
}

const int N=5e5+10;
int n, m, c[N], tot;
set<int> s1[N], s2[N];

void add(int x) {
	if (c[x]==1) tot--;
	c[x]++;
	if (c[x]==1) tot++;
}

void del(int x) {
	if (c[x]==1) tot--;
	c[x]--;
	if (c[x]==1) tot++;
}

int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	n=read(), m=read();
	for (int i=1; i<=m; i++) {
		int x=read(), y=read();
		s1[y].insert(x);
		s2[y].insert(x);
		add(x);
	}
	int q=read();
	while (q--) {
		int op=read();
		if (op==1) {
			int x=read(), y=read();
			s2[y].erase(x);
			del(x);
		}
		if (op==3) {
			int x=read(), y=read();
			s2[y].insert(x);
			add(x);
		}
		if (op==2) {
			int x=read();
			for (int i:s2[x]) del(i);
			s2[x].clear();
		}
		if (op==4) {
			int x=read();
			for (int i:s2[x]) del(i);
			s2[x].clear();
			for (int i:s1[x]) add(i), s2[x].insert(i);
		}
		if (tot==n) puts("YES");
		else puts("NO");
	}
	return 0;
}