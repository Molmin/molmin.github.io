#include <bits/stdc++.h>
#define int long long

using namespace std;

int read() {
	int x=0, f=0; char c=getchar();
	while (!isdigit(c)) f|=c=='-', c=getchar();
	while (isdigit(c)) x=(x<<3)+(x<<1)+(c^48), c=getchar();
	return f ? -x : x;
}

const int N=2e5+10;
int n, q, K, f[N][19], a[N], fa[N][19], dep[N];
vector<int> e[N];

void dfs(int x, int ff) {
	f[x][0]=a[x];
	fa[x][0]=ff;
	dep[x]=dep[ff]+1;
	for (int i=1; i<19; i++) {
		fa[x][i]=fa[fa[x][i-1]][i-1];
		f[x][i]=f[x][i-1]+f[fa[x][i-1]][i-1];
	}
	for (int y:e[x])
		if (y!=ff) dfs(y, x);
}

int cc(int x, int y) {
	int res=0;
	if (dep[x]<dep[y]) swap(x, y);
	for (int i=18; i>=0; i--)
		if (dep[fa[x][i]]>=dep[y]) res+=f[x][i], x=fa[x][i];
	if (x==y) return res+f[x][0];
	for (int i=18; i>=0; i--) {
		if (fa[x][i]!=fa[y][i]) {
			res+=f[x][i];
			res+=f[y][i];
			x=fa[x][i], y=fa[y][i];
		}
	}
	return res+=f[x][1]+f[y][1]-f[fa[x][0]][0];
}

signed main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	n=read(), q=read(), K=read();
	for (int i=1; i<=n; i++) a[i]=read();
	for (int i=1; i<n; i++) {
		int x=read(), y=read();
		e[x].push_back(y);
		e[y].push_back(x);
	}
	dfs(1, 0);
	while (q--) {
		int x=read(), y=read();
		printf("%lld\n", cc(x, y));
	}
	return 0;
}