#include <bits/stdc++.h>
#define int long long

using namespace std;

int read() {
	int x=0, f=0; char c=getchar();
	while (!isdigit(c)) f|=c=='-', c=getchar();
	while (isdigit(c)) x=(x<<3)+(x<<1)+(c^48), c=getchar();
	return f ? -x : x;
}

const int N=2510;
int n, m, k, g[N][N], val[N], ans, dis[N];
vector<int> e[N];

struct node {
	int v1=0, v2=0, v3=0;
	void insert(int x) {
		if (val[x]>val[v1]) v3=v2, v2=v1, v1=x;
		else if (val[x]>val[v2]) v3=v2, v2=x;
		else if (val[x]>val[v3]) v3=x;
	}
} w[N];

void merge(int x, int y, node a, node b) {
	int res=0;
	if (a.v1 && b.v1 && a.v1!=y && b.v1!=x && b.v1!=a.v1) res=max(res, val[a.v1]+val[b.v1]);
	if (a.v1 && b.v2 && a.v1!=y && b.v2!=x && b.v2!=a.v1) res=max(res, val[a.v1]+val[b.v2]);
	if (a.v1 && b.v3 && a.v1!=y && b.v3!=x && b.v3!=a.v1) res=max(res, val[a.v1]+val[b.v3]);
	if (a.v2 && b.v1 && a.v2!=y && b.v1!=x && b.v1!=a.v2) res=max(res, val[a.v2]+val[b.v1]);
	if (a.v2 && b.v2 && a.v2!=y && b.v2!=x && b.v2!=a.v2) res=max(res, val[a.v2]+val[b.v2]);
	if (a.v2 && b.v3 && a.v2!=y && b.v3!=x && b.v3!=a.v2) res=max(res, val[a.v2]+val[b.v3]);
	if (a.v3 && b.v1 && a.v3!=y && b.v1!=x && b.v1!=a.v3) res=max(res, val[a.v3]+val[b.v1]);
	if (a.v3 && b.v2 && a.v3!=y && b.v2!=x && b.v2!=a.v3) res=max(res, val[a.v3]+val[b.v2]);
	if (a.v3 && b.v3 && a.v3!=y && b.v3!=x && b.v3!=a.v3) res=max(res, val[a.v3]+val[b.v3]);
	ans=max(ans, res+val[x]+val[y]);
}

void bfs(int s) {
	queue<int> q;
	for (int i=1; i<=n; i++) dis[i]=-1;
	q.push(s), dis[s]=0;
	while (!q.empty()) {
		int x=q.front(); q.pop();
		if (dis[x]>k) continue;
		for (int y:e[x]) {
			if (!~dis[y]) {
				dis[y]=dis[x]+1;
				q.push(y);
			}
		}
	}
	for (int i=1; i<=n; i++) if (~dis[i]) g[s][i]=1;
}

signed main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	n=read(), m=read(), k=read();
	for (int i=2; i<=n; i++) val[i]=read();
	for (int i=1; i<=m; i++) {
		int x=read(), y=read();
		e[x].push_back(y);
		e[y].push_back(x);
	}
	for (int i=1; i<=n; i++) bfs(i);
	for (int i=2; i<=n; i++)
		for (int j=2; j<=n; j++)
			if (i!=j && g[1][j] && g[j][i]) w[i].insert(j);
	for (int i=2; i<=n; i++)
		for (int j=i+1; j<=n; j++)
			if (g[i][j]) merge(i, j, w[i], w[j]);
	printf("%lld\n", ans);
	return 0;
}