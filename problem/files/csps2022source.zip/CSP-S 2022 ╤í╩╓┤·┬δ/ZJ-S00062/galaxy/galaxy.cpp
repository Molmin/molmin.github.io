#include <iostream>
#include <cstdio>
#include <vector>

const int MaxN = 1e3 + 5;
int n, m, q;
bool edge[MaxN][MaxN], eeddggee[MaxN][MaxN], isa[MaxN];
int num[MaxN], nnuumm[MaxN];

bool find(int p)
{
	if(isa[p]) return true;
	else isa[p] = true;
	bool flag = false;
	for (int i = 1; i <= n; ++i)
		if (edge[p][i])
			flag |= find(i);
	return flag;
}

bool check()
{
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= n; ++j) isa[j] = false;
		if (num[i] != 1 || !find(i)) return false;
	}
	return true;
}

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i)
	{
		static int u, v;
		scanf("%d%d", &u, &v);
		eeddggee[u][v] = edge[u][v] = true;
		++num[u];
		++nnuumm[u];
	}
	scanf("%d", &q);
	for (int T = 1; T <= q; ++T)
	{
		int op;
		scanf("%d", &op);
		if (op == 1)
		{
			int u, v;
			scanf("%d%d", &u, &v);
			edge[u][v] = false;
			--num[u];
		}
		else if (op == 2)
		{
			int u;
			scanf("%d", &u);
			for (int v = 1; v <= n; ++v)
				if (edge[v][u])
				{
					edge[v][u] = false;
					--num[v];
				}
		}
		else if (op == 3)
		{
			int u, v;
			scanf("%d%d", &u, &v);
			edge[u][v] = true;
			++num[u];
		}
		else if (op == 4)
		{
			int u;
			scanf("%d", &u);
			for (int v = 1; v <= n; ++v)
				if (edge[v][u])
				{
					edge[v][u] = eeddggee[v][u];
					num[v] += eeddggee[v][u];
				}
		}
		if (check()) std::cout << "YES\n";
		else std::cout << "NO\n";
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
