#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>

const int MaxN = 2005;
int n, Q, k;
int v[MaxN];
long long f[MaxN];
std::vector<int> edge[MaxN];
bool isc[MaxN][MaxN], tmp[MaxN], isin[MaxN];

void dfs(int dis, int pos)
{
	tmp[pos] = true;
	if (dis == k) return;
	for (std::vector<int>::iterator it = edge[pos].begin(); it != edge[pos].end(); ++it)
		if (!tmp[*it])
		{
//			tmp[*it] = true;
			dfs(dis + 1, *it);
		}
}

//class Node
//{
//public:
//	int pos;
//	long long w;
//	Node(int ___pos = 0, ___w = 0ll)
//		: pos(___pos), w(___w) {}
//};

int main()
{
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	
	scanf("%d%d%d", &n, &Q, &k);
	for (int i = 1; i <= n; ++i) scanf("%d", v + i);
	for (int i = 1; i < n; ++i)
	{
		int a, b;
		scanf("%d%d", &a, &b);
		edge[a].push_back(b);
		edge[b].push_back(a);
	}
	for (int i = 1; i <= n; ++i)
	{
		for (int j = 1; j <= n; ++j) tmp[j] = false;
		dfs(0, i);
		for (int j = 1; j <= n; ++j) isc[i][j] = tmp[j];
		isc[i][i] = false;
	}
//	for (int i = 1; i <= n; ++i, putchar('\n'))
//		for (int j = 1; j <= n; ++j) std::cout << isc[i][j] << ' ';
	for (int T = 1; T <= Q; ++T)
	{
		int s, t;
		scanf("%d%d", &s, &t);
		for (int i = 1; i <= n; ++i) f[i] = 4e18;
		f[s] = v[s];
		std::queue<int> q;
		q.push(s);
		isin[s] = true;
		for (; !q.empty();)
		{
			int now = q.front();
			q.pop();
			isin[now] = false;
			for (int i = 1; i <= n; ++i)
				if (isc[now][i])
				{
					if (f[i] > f[now] + v[i])
					{
						f[i] = f[now] + v[i];
						if (!isin[i])
						{
							q.push(i);
							isin[i] = true;
						}
					}
				}
		}
		std::cout << f[t] << '\n';
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
