#include <iostream>
#include <cstdio>
#include <algorithm>

const int MaxN = 1e5 + 5, oo = 1e9 + 1;
int n, m, q;
int lgt[MaxN];
struct Node
{
	int value[MaxN];
	int nnum[MaxN], znum[MaxN], pnum[MaxN];
	int nmin[20][MaxN], nmax[20][MaxN], pmin[20][MaxN], pmax[20][MaxN];
	void init(const int &n)
	{
		for (int i = 1; i <= n; ++i)
			if (value[i] > 0)
			{
				nnum[i] = nnum[i - 1];
				znum[i] = znum[i - 1];
				pnum[i] = pnum[i - 1] + 1;
				nmin[0][i] = 0;
				nmax[0][i] = -oo;
				pmin[0][i] = value[i];
				pmax[0][i] = value[i];
			}
			else if (value[i] < 0)
			{
				nnum[i] = nnum[i - 1] + 1;
				znum[i] = znum[i - 1];
				pnum[i] = pnum[i - 1];
				nmin[0][i] = value[i];
				nmax[0][i] = value[i];
				pmin[0][i] = oo;
				pmax[0][i] = 0;
			}
			else
			{
				nnum[i] = nnum[i - 1];
				znum[i] = znum[i - 1] + 1;
				pnum[i] = pnum[i - 1];
				nmin[0][i] = 0;
				nmax[0][i] = -oo;
				pmin[0][i] = oo;
				pmax[0][i] = 0;
			}
		for (int block = 2, i = 1; block <= n; ++i, block *= 2)
			for (int j = 1; j + block - 1 <= n; ++j)
				{
					nmin[i][j] = std::min(nmin[i - 1][j], nmin[i - 1][j + (block >> 1)]);
					nmax[i][j] = std::max(nmax[i - 1][j], nmax[i - 1][j + (block >> 1)]);
					pmin[i][j] = std::min(pmin[i - 1][j], pmin[i - 1][j + (block >> 1)]);
					pmax[i][j] = std::max(pmax[i - 1][j], pmax[i - 1][j + (block >> 1)]);
				}
	}
	bool ishaven(const int &l, const int &r)
	{
		return nnum[r] > nnum[l - 1];
	}
	bool ishavez(const int &l, const int &r)
	{
		return znum[r] > znum[l - 1];
	}
	bool ishavep(const int &l, const int &r)
	{
		return pnum[r] > pnum[l - 1];
	}
	int Nmin(const int &l, const int &r)
	{
		return std::min(nmin[lgt[r - l + 1]][l], nmin[lgt[r - l + 1]][r - (1 << lgt[r - l + 1]) + 1]);
	}
	int Nmax(const int &l, const int &r)
	{
		return std::max(nmax[lgt[r - l + 1]][l], nmax[lgt[r - l + 1]][r - (1 << lgt[r - l + 1]) + 1]);
	}
	int Pmin(const int &l, const int &r)
	{
		return std::min(pmin[lgt[r - l + 1]][l], pmin[lgt[r - l + 1]][r - (1 << lgt[r - l + 1]) + 1]);
	}
	int Pmax(const int &l, const int &r)
	{
		return std::max(pmax[lgt[r - l + 1]][l], pmax[lgt[r - l + 1]][r - (1 << lgt[r - l + 1]) + 1]);
	}
}a, b;

int main()
{
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &q);
	for (int i = 1; i <= n; ++i) scanf("%d", a.value + i);
	for (int i = 1; i <= m; ++i) scanf("%d", b.value + i);
	lgt[1] = 0;
	if (n > m) for (int i = 2; i <= n; ++i) lgt[i] = lgt[i / 2] + 1;
	else for (int i = 2; i <= m; ++i) lgt[i] = lgt[i / 2] + 1;
	a.init(n);
	b.init(m);
	for (int T = 1; T <= q; ++T)
	{
		static int al, ar, bl, br;
		scanf("%d%d%d%d", &al, &ar, &bl, &br);
		if (a.ishavep(al, ar))
		{
			if (a.ishaven(al, ar))
			{
				if (b.ishavep(bl, br))
				{
					if (b.ishaven(bl, br))
					{
						if (a.ishavez(al, ar))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << std::max(1ll * a.Pmin(al, ar) * b.Nmin(bl, br), 1ll * a.Nmax(al, ar) * b.Pmax(bl, br));
							putchar('\n');
						}
					}
					else
					{
						if (b.ishavez(bl, br))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Pmax(al, ar) * b.Pmin(bl, br);
							putchar('\n');
						}
					}
				}
				else
				{
					if (b.ishaven(bl, br))
					{
						if (b.ishavez(bl, br))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Nmin(al, ar) * b.Nmax(bl, br);
							putchar('\n');
						}
					}
					else
					{
						std::cout << 0;
						putchar('\n');
					}
				}
			}
			else
			{
				if (b.ishavep(bl, br))
				{
					if (b.ishaven(bl, br))
					{
						if (a.ishavez(al, ar))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Pmin(al, ar) * b.Nmin(bl, br);
							putchar('\n');
						}
					}
					else
					{
						if (b.ishavez(bl, br))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Pmax(al, ar) * b.Pmin(bl, br);
							putchar('\n');
						}
					}
				}
				else
				{
					if (b.ishaven(bl, br))
					{
						if (a.ishavez(al, ar))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Pmin(al, ar) * b.Nmin(bl, br);
							putchar('\n');
						}
					}
					else
					{
						std::cout << 0;
						putchar('\n');
					}
				}
			}
		}
		else
		{
			if (a.ishaven(al, ar))
			{
				if (b.ishavep(bl, br))
				{
					if (b.ishaven(bl, br))
					{
						if (a.ishavez(al, ar))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Nmax(al, ar) * b.Pmax(bl, br);
							putchar('\n');
						}
					}
					else
					{
						if (a.ishavez(al, ar))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Nmax(al, ar) * b.Pmax(bl, br);
							putchar('\n');
						}
					}
				}
				else
				{
					if (b.ishaven(bl, br))
					{
						if (b.ishavez(bl, br))
						{
							std::cout << 0;
							putchar('\n');
						}
						else
						{
							std::cout << 1ll * a.Nmin(al, ar) * b.Nmax(bl, br);
							putchar('\n');
						}
					}
					else
					{
						std::cout << 0;
						putchar('\n');
					}
				}
			}
			else
			{
				std::cout << 0;
				putchar('\n');
			}
		}
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
