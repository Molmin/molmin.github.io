#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>

const int MaxN = 2505, MaxM = 10005, MaxK = 105;
const long long oo = 4e18 + 1;
int n, m, k;
long long s[MaxN], ans = -oo;
bool iscanarrive[MaxN][MaxN];
std::vector<int> v[MaxN];
class Node
{
public:
	int pos, numk;
	Node(int ___pos = 0, int ___numk = 0)
		: pos(___pos), numk(___numk) {}
};
class node
{
public:
	int midp;
	long long w;
	node(int ___midp = 0, long long ___w = -oo)
		: midp(___midp), w(___w) {}
}f[MaxN][3];


int main()
{
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1; i <= n; ++i) iscanarrive[i][i] = true;
	for (int i = 2; i <= n; ++i) scanf("%lld", s + i);
	for (int i = 1; i <= m; ++i)
	{
		static int x, y;
		scanf("%d%d", &x, &y);
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for (int u = 1; u <= n; ++u)
	{
		std::queue<Node> q;
		q.push(Node(u, -1));
		for (; !q.empty();)
		{
			Node now = q.front();
			q.pop();
			if (now.numk == k) continue;
			for (std::vector<int>::iterator it = v[now.pos].begin(); it != v[now.pos].end(); ++it)
				if (!iscanarrive[u][*it])
				{
					iscanarrive[u][*it] = true;
					q.push(Node(*it, now.numk + 1));
				}
		}
	}
	for (int i = 2; i <= n; ++i)
		for (int j = 2; j <= n; ++j)
			if ((i != j) && iscanarrive[i][j] && iscanarrive[1][i])
			{
				if (s[i] + s[j] > f[j][0].w)
				{
					f[j][2] = f[j][1];
					f[j][1] = f[j][0];
					f[j][0] = node(i, s[i] + s[j]);
				}
				else if (s[i] + s[j] > f[j][1].w)
				{
					f[j][2] = f[j][1];
					f[j][1] = node(i, s[i] + s[j]);
				}
				else if (s[i] + s[j] > f[j][2].w)
				{
					f[j][2] = node(i, s[i] + s[j]);
				}
			}
	for (int i = 2; i <= n; ++i)
		for (int j = 2; j <= n; ++j)
			if ((i != j) && iscanarrive[i][j] && f[i][0].w >= 0 && f[j][0].w >= 0)
			{
				if (f[i][0].midp != f[j][0].midp && f[i][0].midp != j && f[j][0].midp != i) ans = std::max(ans, f[i][0].w + f[j][0].w);
				else
				{
					if (f[i][1].midp != j && f[i][1].midp != f[j][0].midp && i != f[j][0].midp) ans = std::max(ans, f[i][1].w + f[j][0].w);
					if (f[i][2].midp != j && f[i][1].midp != f[j][0].midp && i != f[j][0].midp) ans = std::max(ans, f[i][2].w + f[j][0].w);
					if (f[j][1].midp != i && f[j][1].midp != f[i][0].midp && j != f[i][0].midp) ans = std::max(ans, f[j][1].w + f[i][0].w);
					if (f[j][2].midp != i && f[j][1].midp != f[i][0].midp && j != f[i][0].midp) ans = std::max(ans, f[j][2].w + f[i][0].w);
					if (f[i][1].midp != f[j][1].midp && f[i][1].midp != j && f[j][1].midp != i) ans = std::max(ans, f[j][1].w + f[i][1].w);
				}
			}
	std::cout << ans;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
