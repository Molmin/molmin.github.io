#include<bits/stdc++.h>//LCA
using namespace std;
int n,q,k,g,x,y,o;
vector<int> to[200005];//len,type
int dp[200005][22],deep[200005],v[200005];
bool vis[200005];
void dfs(int w,int h){
	vis[w]=1;
	int len=to[w].size();
	for(int i=0;i<len;i++){
		int y=to[w][i];
		if(vis[y])	continue;
		deep[y]=h+1;
		dfs(y,h+1);
		dp[y][0]=w;
	}
}
int LCA(int x,int y){
	if(deep[x]<deep[y])	swap(x,y);
	for(int k=20;k>=0;k--){
		if(dp[x][k]!=0&&deep[dp[x][k]]>=deep[y])	x=dp[x][k];
	}
	if(x==y)	return x;
	for(int k=20;k>=0;k--){
		if(dp[x][k]!=dp[y][k]){
			x=dp[x][k];
			y=dp[y][k];
		}
	}
	return dp[x][0];
}
void fs(int g,int xx,int yy){
	int num[2005]={0},q[2005]={0};
	num[1]=xx;
	while(xx!=g){
		num[++num[0]]=xx;
		xx=dp[xx][0];
	}
	num[++num[0]]=g;
	while(yy!=g){
		q[++q[0]]=yy;
		yy=dp[yy][0];
	}
	for(int i=1;i<=q[0];i++){
		num[num[0]+i]=q[q[0]-i+1];
	}
	num[0]+=q[0];
	long long st[5]={0};
	st[1]=v[num[1]];
	for(int i=2;i<=num[0];i++){
		long long minn=1e18;
		for(int u=1;u<=k;u++){
			if(i-u>0){
				if(st[(i-u+k)%k]+v[num[i]]<minn){
					minn=st[(i-u+k)%k]+v[num[i]];
				}
			}
		}
		st[i%k]=minn;
	}
	cout<<st[num[0]%k]<<endl;
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
		scanf("%d",&v[i]);
	}
	for(int i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		to[x].push_back(y);
		to[y].push_back(x);
	}
	dfs(1,1);
	for(int k=1;k<=20;k++){
		for(int i=1;i<=n;i++){
			dp[i][k]=dp[dp[i][k-1]][k-1];
		}
	}
	while(q--){
		scanf("%d%d",&x,&y);
		g=LCA(x,y);
		fs(g,x,y);
	}
	return 0;
} 
