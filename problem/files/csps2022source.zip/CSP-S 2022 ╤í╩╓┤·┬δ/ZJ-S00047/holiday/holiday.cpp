#include<bits/stdc++.h>//backpack problem
using namespace std;
struct E{
	long long to,len,point;
}a[2505][2505];
int n,m,k,dist[2505][2505],t,len[2505];
unsigned long long p[2505],maxn,res;
bool vis[2505];
bool cmp(E a,E b){
	return a.point>b.point;
}
void dfs(int w){
	if(t==4){
		for(int i=1;i<=len[w];i++){
			if(a[w][i].to==1&&a[w][i].len<=k+1&&w!=0){
				maxn=max(maxn,res);
				return ;
			}
		}
		return ;
	}
	vis[w]=1;
	for(int i=1;i<=len[w];i++){
		if(!vis[a[w][i].to]&&a[w][i].len<=k+1){
			res+=a[w][i].point;
			t++;
			dfs(a[w][i].to);
			res-=a[w][i].point;
			t--;
		}
	}
	vis[w]=0;
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		scanf("%lld",&p[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dist[i][j]=0x3f3f3f3f;
		}
	}
	while(m--){
		int x,y;
		scanf("%d%d",&x,&y);
		dist[x][y]=dist[y][x]=1;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int u=1;u<=n;u++){
				if(i==u||j==u||i==j)	continue;
				if(dist[i][j]>dist[i][u]+dist[u][j])	dist[i][j]=dist[i][u]+dist[u][j];
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(dist[i][j]==0x3f3f3f3f)	continue;
			a[i][++len[i]].len=dist[i][j];
			a[i][len[i]].to=j;
			a[i][len[i]].point=p[j];
		}
		sort(a[i]+1,a[i]+1+len[i],cmp);
	}
	dfs(1);
	cout<<maxn<<endl;
	return 0;
} 
