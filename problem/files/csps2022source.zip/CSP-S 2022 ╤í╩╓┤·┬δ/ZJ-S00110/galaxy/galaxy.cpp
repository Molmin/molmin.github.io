#include<bits/stdc++.h>
using namespace std;
int n,m,u,v,q;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%i%i",&n,&m);
	for (int i=1;i<=m;i++)
	cin>>u>>v;
	cin>>q;
	for (int i=1;i<=q;i++) cout<<"YES"<<endl;
	return 0;
}
