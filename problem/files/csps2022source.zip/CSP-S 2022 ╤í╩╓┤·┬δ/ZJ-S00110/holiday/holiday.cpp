#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long a[3000],ans;
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%i%i%i",&n,&m,&k);
	for (int i=2;i<=n;i++) scanf("%i",&a[i]);
	sort(a+1,a+1+n);
	ans=0;
	for (int i=n-3;i<=n;i++) ans+=a[i];
	printf("%i",ans);
}
