#include<bits/stdc++.h>
using namespace std;
int a[100100],b[100100],l1,l2,r1,r2,n,m,q;
long long ans;
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%i%i%i",&n,&m,&q);
	for (int i=1;i<=n;i++) scanf("%i",&a[i]);
	for (int i=1;i<=m;i++) scanf("%i",&b[i]);
	for (int i=1;i<=q;i++)
	  {
	  	  scanf("%i%i%i%i",&l1,&r1,&l2,&r2);
	  	  int m1,m2;
	  	  m1=-1000000000;m2=100000000;
	  	  for (int j=l1;j<=r1;j++) m1=max(a[j],m1);
	  	  for (int j=l2;j<=r2;j++) m2=min(b[j],m2);
	  	  ans=m1*m2;
	  	  printf("%lld",ans);
	  }
}
