#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define pb push_back
#define fi first
#define se second
const int N = 2505, M = 20005;
int n, m, k, ver[M], nxt[M], h[N], d[N], f[N][N], vis[N], tot;
multiset <pair <ll, int> > st[N];
ll a[N], dp[N][6], val[6], ans;
void add(int x, int y) {ver[++tot] = y, nxt[tot] = h[x], h[x] = tot;}
priority_queue <pair <int, int> > q;
void dijkstra(int s) {
	memset(d, 0x3f, sizeof(d));
	memset(vis, 0, sizeof(vis));
	d[s] = 0; q.push({0, s});
	while (q.size()) {
		int u = q.top().se; q.pop();
		if (vis[u]) continue;
		vis[u] = 1;
		if (d[u] - 1 > k) continue; 
		for (int i = h[u]; i; i = nxt[i]) {
			int v = ver[i];
			if (d[v] > d[u] + 1) {
				d[v] = d[u] + 1;
				if (d[v] - 1 <= k && !vis[v])
					q.push({-d[v], v});
			}
		}
	}
	for (int i = 1; i <= n; i++)
		if (d[i] - 1 <= k) f[s][i] = 1;
}
priority_queue <ll> pq[N];

int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 2; i <= n; i++)
		scanf("%lld", &a[i]);
	for (int i = 1, x, y; i <= m; i++) {
		scanf("%d%d", &x, &y);
		add(x, y), add(y, x);
	}
	for (int i = 1; i <= n; i++) dijkstra(i);
//	for (int i = 1; i <= n; i++) {
//		for (int j = i + 1; j <= n; j++)
//			if (f[i][j]) printf("%d -> %d\n", i, j);
//	}
	for (int i = 2; i <= n; i++) {
		for (int j = 2; j <= n; j++) if (i != j) {
			if (f[1][j] && f[i][j]) st[i].insert({a[j], j});
		}
	}
	int t1[5], t2[5], c1 = 0, c2 = 0;
	for (int i = 2; i <= n; i++) {
		for (int j = 2; j <= n; j++) if (i != j) {
			ll now = -2e18;
			if (!st[i].size() || !st[j].size()) continue;
			c1 = c2 = 0;
			auto it = --st[i].end();
			while (c1 <= 2) {
				t1[++c1] = it->se;
				if (it == st[i].begin()) break;
				it--;
			}
			it = --st[j].end();
			while (c2 <= 2) {
				t2[++c2] = it->se;
				if (it == st[j].begin()) break;
				it--;
			}
			for (int l = 1; l <= c1; l++)
				for (int p = 1; p <= c2; p++)
					if (t1[l] != j && t1[l] != t2[p] && t2[p] != i) {
//						if (i == 3 && j == 4) printf("wula %d %d\n", t1[l], t2[p]);
						now = max(now, a[t1[l]] + a[t2[p]]);
					}
			ans = max(ans, now + a[i] + a[j]);
		}
	}
	printf("%lld\n", ans);
	return 0;
}