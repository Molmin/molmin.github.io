#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 1e5 + 5, inf = 2e9;
int n, m, q, f[2][4][N][20], a[N][2], lg[N], c0[2][N];
void init() {
	for (int tp = 0; tp < 2; tp++) {
		int tt = tp ? m : n;
		for (int i = 1; i <= tt; i++) c0[tp][i] = c0[tp][i - 1] + (a[i][tp] == 0);
		for (int i = 1; i <= tt; i++) {
			if (a[i][tp] > 0) f[tp][0][i][0] = f[tp][2][i][0] = a[i][tp], 
				f[tp][1][i][0] = inf, f[tp][3][i][0] = -inf;
			else if (a[i][tp] < 0) f[tp][1][i][0] = f[tp][3][i][0] = a[i][tp], 
				f[tp][0][i][0] = inf, f[tp][2][i][0] = -inf;
			else f[tp][1][i][0] = f[tp][0][i][0] = inf, 
				f[tp][2][i][0] = f[tp][3][i][0] = -inf;
		}
		for (int j = 1; j < 18; j++)
			for (int i = 1; i + (1 << j) - 1 <= tt; i++) {
				f[tp][0][i][j] = min(f[tp][0][i][j - 1], f[tp][0][i + (1 << j - 1)][j - 1]);
				f[tp][1][i][j] = min(f[tp][1][i][j - 1], f[tp][1][i + (1 << j - 1)][j - 1]);
				f[tp][2][i][j] = max(f[tp][2][i][j - 1], f[tp][2][i + (1 << j - 1)][j - 1]);
				f[tp][3][i][j] = max(f[tp][3][i][j - 1], f[tp][3][i + (1 << j - 1)][j - 1]);
			}
	}
}
int ask(int tp, int l, int r, int op) {
	int k = lg[r - l + 1]; int ret;
	if (op <= 1) ret = min(f[tp][op][l][k], f[tp][op][r - (1 << k) + 1][k]);
	else ret = max(f[tp][op][l][k], f[tp][op][r - (1 << k) + 1][k]);
	return ret;
}

int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q); lg[0] = -1;
	for (int i = 1; i <= n; i++) scanf("%d", &a[i][0]);
	for (int i = 1; i <= m; i++) scanf("%d", &a[i][1]);
	for (int i = 1; i <= max(n, m); i++) lg[i] = lg[i >> 1] + 1;
	init();
	while (q--) {
		int l1, r1, l2, r2;
		scanf("%d%d%d%d", &l1, &r1, &l2, &r2);
		ll ans = -2e18;
		for (int i = 0; i < 4; i++) {
			ll now = 2e18;
			int t1 = ask(0, l1, r1, i), t2;
			if (abs(t1) == inf) continue;
			for (int j = 0; j < 4; j++) {
				t2 = ask(1, l2, r2, j);
				if (abs(t2) != inf) now = min(now, 1ll * t1 * t2);
			}
			if (c0[1][r2] - c0[1][l2 - 1]) now = min(now, 0ll);
			ans = max(ans, now);
		}
		if (c0[0][r1] - c0[0][l1 - 1]) ans = max(ans, 0ll);
		printf("%lld\n", ans);
	}
	return 0;
}