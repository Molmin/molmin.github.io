#include <bits/stdc++.h>
using namespace std;
#define pb push_back
using ll = long long;
const int N = 2e5 + 5;
vector <int> adj[N];
map <int, ll> mp[N];
int f[N][20], dep[N], n, q, m, a[N], lg[N];
ll dp[N][20];
void dfs(int u) {
	dep[u] = dep[f[u][0]] + 1;
	for (int i = 1; i <= 17; i++) f[u][i] = f[f[u][i - 1]][i - 1];
	for (auto v : adj[u]) if (v != f[u][0]) f[v][0] = u, dfs(v);
}
int LCA(int x, int y) {
	if (dep[x] < dep[y]) swap(x, y);
	for (int i = 17; i >= 0; i--)
		if (dep[f[x][i]] >= dep[y]) x = f[x][i];
	if (x == y) return x;
	for (int i = 17; i >= 0; i--)
		if (f[x][i] != f[y][i]) x = f[x][i], y = f[y][i];
	return f[x][0];
}
int jump(int x, int k) {
	for (int i = 17; i >= 0; i--)
		if (k >> i & 1) x = f[x][i];
	return x;
}
ll ask(int u, int v) {
	if (!u || !v) return (ll)2e18;
	if (u == v) return a[u];
	if (dep[u] < dep[v]) swap(u, v);
	if (m == 1) {
		ll res = 0;
		for (int i = 17; i >= 0; i--)
			if (dep[f[u][i]] >= dep[v]) {
				res += dp[u][i];
				u = f[u][i];
			}
		return res;
	} else if (m == 2) {
		if (mp[u].count(v)) return mp[u][v];
		ll res = 0; int i = lg[dep[u] - dep[v]], j = jump(u, (1 << i) - 1);
		if ((1 << i) == dep[u] - dep[v]) res = dp[u][i];
		else res = min(ask(u, f[u][i]) + ask(f[u][i], v) - a[f[u][i]],
			ask(u, j) + ask(f[f[j][0]][0], v));
		return mp[u][v] = res;
	} else {
		if (mp[u].count(v)) return mp[u][v];
		ll res = 0; int i = lg[dep[u] - dep[v]];
		if ((1 << i) == dep[u] - dep[v]) res = dp[u][i];
		else {
			int j = jump(u, (1 << i) - 1);
			res = min(ask(u, f[u][i]) + ask(f[u][i], v) - a[f[u][i]],
				ask(u, j) + ask(f[f[j][0]][0], v));
			res = min(res, ask(u, j) + ask(f[f[f[j][0]][0]][0], v));
			if ((1 << i) - 2 > 0) {
				int j2 = jump(u, (1 << i) - 2);
				res = min(res, ask(u, j2) + ask(f[f[j][0]][0], v));
			}
		}
		return mp[u][v] = res;
	}
}
void dfs1(int u) {
	for (int j = 0; j <= 17; j++) {
		int fa = u;
		for (int i = 1; i <= m; i++) if (i <= (1 << j)) {
			fa = f[fa][0]; if (!fa) break;
			dp[u][j] = min(dp[u][j], ask(fa, f[u][j]) + a[u]);
//			printf("fa = %d, f[u][j] = %d\n", fa, f[u][j]);
		}
	}
	for (auto v : adj[u]) if (v != f[u][0]) dfs1(v);
}

int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	memset(dp, 0x3f, sizeof(dp));
	scanf("%d%d%d", &n, &q, &m); lg[0] = -1;
	for (int i = 1; i <= n; i++) scanf("%d", &a[i]), lg[i] = lg[i >> 1] + 1;
	for (int i = 1, x, y; i < n; i++) {
		scanf("%d%d", &x, &y);
		adj[x].pb(y), adj[y].pb(x);
	}
	dfs(1), dfs1(1);
//	for (int i = 1; i <= n; i++) {
//		for (int j = 0; j <= 3; j++)
//			printf("dp[%d][%d] = %lld\n", i, j, dp[i][j]);
//	}
//	puts("***********");
	while (q--) {
		int x, y;
		scanf("%d%d", &x, &y);
		if (dep[x] < dep[y]) swap(x, y);
		int lca = LCA(x, y);
		int u = x, v = y;
//		printf("x = %d, val = %d\n", u, a[u]);
//		while (u != lca) u = f[u][0], printf("x = %d, val = %d\n", u, a[u]);
//		puts("");
//		printf("y = %d, val = %d\n", v, a[v]);
//		while (v != lca) v = f[v][0], printf("y = %d, val = %d\n", v, a[v]);
//		puts("");
		if (y == lca) printf("%lld\n", ask(x, lca));
		else {
			ll ans = 2e18;
//			printf("aa = %lld, %lld\n", ask(7, 4), ask(12, 8));
			for (int i = 0; i <= m; i++)
				for (int j = 0; j <= m; j++) {
					if (i + j > m) continue;
					if (dep[x] - dep[lca] < i || dep[y] - dep[lca] < j) continue;
					ans = min(ans, ask(x, jump(x, dep[x] - dep[lca] - i)) +
						ask(y, jump(y, dep[y] - dep[lca] - j)));
//					printf("now = %lld\n", ask(x, jump(x, dep[x] - dep[lca] - i)) +
//						ask(y, jump(y, dep[y] - dep[lca] - j)));
//					printf("%d -> %d, %d -> %d\n", x, jump(x, dep[x] - dep[lca] - i), 
//						y, jump(y, dep[y] - dep[lca] - j));
				}
			printf("%lld\n", ans);
		}
	}
	return 0;
}
/*
9 10 2
3 5 1 4 9 10 2 3 13
1 2
2 3
3 4
4 5
1 6
6 7
7 8
8 9

12 1 2
8 7 6 4 7 3 8 3 5 2 9 4
1 2
2 3
3 4
4 5
5 6
6 7
1 8
8 9
9 10
10 11
11 12
7 12
*/