#include<bits/stdc++.h>
using namespace std;
int n,m,T,edgenum;
long long a[10005],Max=0;
int vet[50005],nxt[50005],head[50005];
int vis[10005];
int g[2505][2505];
bool flag;
void add(int u,int v)
{
	vet[++edgenum]=v;
	nxt[edgenum]=head[u];
	head[u]=edgenum;
}
void pd(int u,int fa,int end,int num)
{
//	printf("%d %d %d %d\n",u,fa,end,num);
//	system("pause");
	if (flag==true) return;
    if (u==end&&(num-1)<=T) 
		{flag=true;return;}
	if (num>T) return;
	for (int e=head[u];e;e=nxt[e])
	{
		int v=vet[e];
		if (v==fa) continue;
		pd(v,u,end,num+1);
	}
}
void dfs(int u,int fa,int d,int sum,int last)
{
	if (d>4)
	{
		if (g[last][1]==1||g[1][last]==1) 
			if (sum>Max) Max=sum;
		return ;
	}
	for (int e=head[u];e;e=nxt[e])
	{
		int v=vet[e];
		if (v==fa||vis[v]) continue;
		vis[v]=1;
		dfs(v,u,d+1,sum+a[v],v);
		vis[v]=0;
	}
}
int main()
{
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int i,x,y,j,k,l,ii,jj,kk,ll;
	long long ans=0;
	scanf("%d%d%d",&n,&m,&T);
	for (i=1;i<n;i++) scanf("%lld",&a[i+1]);
	a[1]=0;
	for (i=1;i<=m;i++) 
	{
	  scanf("%d%d",&x,&y);
	  add(x,y);
	  add(y,x);
	  g[x][y]=g[y][x]=1;
	}
	if (n<=20)
	{
	  for (i=2;i<=n;i++)
	    for (j=2;j<=n;j++)
	      if (i!=j)
	        for (k=2;k<=n;k++)
	          if (j!=k&&i!=k)
	            for (l=2;l<=n;l++)
	              if (i!=l&&j!=l&&k!=l)
	              {
	              	flag=false;pd(1,0,i,0);if (!flag) continue;
	              	flag=false;pd(i,0,j,0);if (!flag) continue;
	              	flag=false;pd(j,0,k,0);if (!flag) continue;
	              	flag=false;pd(k,0,l,0);if (!flag) continue;
	              	flag=false;pd(l,0,1,0);if (!flag) continue;
	              	if (a[i]+a[j]+a[k]+a[l]>ans)
	              	{
	              		ans=a[i]+a[j]+a[k]+a[l];
					  }
				  }
		cout<<ans<<endl;
		//cout<<ii<<' '<<jj<<' '<<kk<<' '<<ll<<endl;
		return 0;
	}
	if (k==0)
	{
		memset(vis,0,sizeof(vis));
		dfs(1,0,1,0,0);
		cout<<Max;
		return 0;
	}
	return 0;
}
