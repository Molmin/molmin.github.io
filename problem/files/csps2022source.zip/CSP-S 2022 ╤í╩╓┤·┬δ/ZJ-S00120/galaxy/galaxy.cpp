#include<bits/stdc++.h>
using namespace std;
int n,m;
int now[1005][1005],g[1005][1005];
int vis[10005];
bool bo;
int out[500005];
void dfs(int u)
{
	if (bo==true) return;
	vis[u]=1;
	for (int v=1;v<=n;v++)
	{
		if (now[u][v]==0) continue;
		if (vis[v]==1) bo=true;
		dfs(v);
	}
}
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int i,x,y,op,q,j;
	scanf("%d%d",&n,&m);
	if (n<=1000)
	{
	for (i=1;i<=m;i++) 
	{
		scanf("%d%d",&x,&y);
		now[x][y]=g[x][y]=1;
	}
	scanf("%d",&q);
	while (q--)
	{
		scanf("%d",&op);
		if (op==1)
		{
			scanf("%d%d",&x,&y);
			now[x][y]=0;
		}else if (op==2)
		{
			scanf("%d",&x);
			for (i=1;i<=n;i++)
			  now[i][x]=0;
		}else if (op==3)
		{
			scanf("%d%d",&x,&y);
			now[x][y]=1;
		}
		else
		{
			scanf("%d",&x);
			for (i=1;i<=n;i++)
			  now[i][x]=g[i][x];
		}
		bool flag=true;
		for (i=1;i<=n;i++)
		{
			int t=0;
			for (j=1;j<=n;j++)
			{
			  if (now[i][j]==1) t++;
			  if (t>1) 
			  {
			  	flag=false;
			  	break;
			  }
			}
			if (flag==false) break;
		}
		if (flag==false) 
		{
			printf("NO\n");
			continue;
		}
		for (i=1;i<=n;i++)
		{
			bo=false;
			memset(vis,0,sizeof(vis));
			dfs(i);
			if (bo==false) break;
		}
		if (bo==false)
		{
			printf("NO\n");
			continue;
		}
		printf("YES\n");
	}
	  return 0;
	}
	for (i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		out[x]++;
	}
	scanf("%d",&q);
	while (q--)
	{
		scanf("%d%d%d",&op,&x,&y);
		if (op==1)
		{
			if (m==n+1)
			{
				if (out[x]==2) printf("YES\n");
				else printf("NO\n");
				out[x]--;
			}
			else
			  {out[x]--;printf("NO\n");}
		}
		else
		{
			if (m==n-1)
			{
				if (out[x]==0) printf("YES\n");
				else printf("NO\n");
				out[x]--;
			}
			else
			{
				out[x]++;
				printf("NO\n");
			}
		}
	}
	return 0;
}
