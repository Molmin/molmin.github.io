#include<bits/stdc++.h>
using namespace std;
long long a[100005],b[100005];
struct node
{
	long long d,x;
} Ma[500005],Mb[500005];
void builda(int k,int l,int r)
{
	if (l==r)
	{
		Ma[k].d=a[l];
		Ma[k].x=a[l];
		return;
	}
	int mid=l+r>>1;
	builda(k*2,l,mid);
	builda(k*2+1,mid+1,r);
	Ma[k].d=max(Ma[k*2].d,Ma[k*2+1].d);
	Ma[k].x=min(Ma[k*2].x,Ma[k*2+1].x);
}
void buildb(int k,int l,int r)
{
	if (l==r)
	{
		Mb[k].d=Mb[k].x=b[l];
		return;
	}
	int mid=l+r>>1;
	buildb(k*2,l,mid);
	buildb(k*2+1,mid+1,r);
	Mb[k].x=min(Mb[k*2].x,Mb[k*2+1].x);
	Mb[k].d=max(Mb[k*2].d,Mb[k*2+1].d);
}
long long qamax(int k,int l,int r,int x,int y)
{
	if (l>y||r<x) return -1e12;
	if (x<=l&&r<=y)
	{
		return Ma[k].d;
	}
	int mid=l+r>>1;
	return max(qamax(k*2,l,mid,x,y),qamax(k*2+1,mid+1,r,x,y));
}
long long qamin(int k,int l,int r,int x,int y)
{
	if (l>y||r<x) return 1e12;
	if (x<=l&&r<=y)
	{
		return Ma[k].x;
	}
	int mid=l+r>>1;
	return min(qamin(k*2,l,mid,x,y),qamin(k*2+1,mid+1,r,x,y));
}
long long qbmax(int k,int l,int r,int x,int y)
{
	if (l>y||r<x) return -1e12;
	if (x<=l&&r<=y)
	{
		return Mb[k].d;
	}
	int mid=l+r>>1;
	return max(qbmax(k*2,l,mid,x,y),qbmax(k*2+1,mid+1,r,x,y));
}
long long qbmin(int k,int l,int r,int x,int y)
{
	if (l>y||r<x) return 1e12;
	if (x<=l&&r<=y)
	{
		return Mb[k].x;
	}
	int mid=l+r>>1;
	return min(qbmin(k*2,l,mid,x,y),qbmin(k*2+1,mid+1,r,x,y));
}
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,i,l1,r1,l2,r2,j;
	scanf("%d%d%d",&n,&m,&q);
	for (i=1;i<=n;i++) scanf("%lld",&a[i]);
	for (i=1;i<=m;i++) scanf("%lld",&b[i]);
	if (n<=1000&&m<=1000)
	{
	while (q--)
	{
		bool aqf,aqz,bqf,bqz;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		aqf=true,aqz=true;bqf=true,bqz=true;
		for (i=l1;i<=r1;i++)
		{
			if (a[i]>=0) aqf=false;
			else aqz=false;
		}
		for (j=l2;j<=r2;j++)
		{
			if (b[j]>=0) bqf=false;
			else bqz=false;
		}
	//	cout<<aqz<<' '<<aqf<<' '<<bqz<<' '<<bqf<<endl;
		
		
		if (aqz==true&&bqz==true)
		{
			long long Mxa=-1e9,Mib=1e9;
			for (i=l1;i<=r1;i++) Mxa=max(Mxa,a[i]);
			for (j=l2;j<=r2;j++) Mib=min(Mib,b[j]);
			printf("%lld\n",Mxa*Mib);
			continue;
		}else
		if (aqz==true&&bqf==true)
		{
			long long Mia=1e9,Mib=1e9;
			for (i=l1;i<=r1;i++) Mia=min(Mia,a[i]);
			for (j=l2;j<=r2;j++) Mib=min(Mib,b[j]);
			printf("%lld\n",Mia*Mib);
			continue;
		}else
		if (aqz==true&&bqz==false&&bqf==false)
		{
			long long Mia=1e9,Mib=1e9;
			for (i=l1;i<=r1;i++) Mia=min(Mia,a[i]);
			for (j=l2;j<=r2;j++) Mib=min(Mib,b[j]);
			printf("%lld\n",Mia*Mib);
			continue;
		}else
		if (aqf==true&&bqz==true)
		{
			long long Mxa=-1e9,Mxb=-1e9;
			for (i=l1;i<=r1;i++) Mxa=max(Mxa,a[i]);
			for (j=l2;j<=r2;j++) Mxb=max(Mxb,b[j]);
			printf("%lld\n",Mxa*Mxb);
			continue;
		}else
		if (aqf==true&&bqf==true)
		{
			long long Mia=1e9,Mxb=-1e9;
			for (i=l1;i<=r1;i++) Mia=min(Mia,a[i]);
			for (j=l2;j<=r2;j++) Mxb=max(Mxb,b[j]);
			printf("%lld\n",Mia*Mxb);
			continue;
		}else
		if (aqf==true&&bqz==false&&bqf==false)
		{
			long long Mxa=-1e9,Mxb=-1e9;
			for (i=l1;i<=r1;i++) Mxa=max(Mxa,a[i]);
			for (j=l2;j<=r2;j++) Mxb=max(Mxb,b[j]);
			printf("%lld\n",Mxa*Mxb);
			continue;
		}else
		if (aqf==false&&aqz==false&&bqz==true)
		{
			long long Mxa=-1e9,Mib=1e9;
			for (i=l1;i<=r1;i++) Mxa=max(Mxa,a[i]);
			for (j=l2;j<=r2;j++) Mib=min(Mib,b[j]);
			printf("%lld\n",Mxa*Mib);
			continue;
		}else
		if (aqf==false&&aqz==false&&bqf==true)
		{
			long long Mia=1e9,Mxb=-1e9;
			for (i=l1;i<=r1;i++) Mia=min(Mia,a[i]);
			for (j=l2;j<=r2;j++) Mxb=max(Mxb,b[j]);
			printf("%lld\n",Mia*Mxb);
			continue;
		}else
		{
			long long fa=-1e9,zb=-1e9,za=1e9,fb=1e9;
			for (i=l1;i<=r1;i++) 
			{
			  if (a[i]<0&&a[i]>fa) fa=a[i]; 
			  if (a[i]>=0&&a[i]<za) za=a[i];
			}
			for (j=l2;j<=r2;j++)
			{
				if (b[j]>=0&&b[j]>zb) zb=b[j];
				if (b[j]<0&&b[j]<fb) fb=b[j];
			}
			printf("%lld\n",max(fa*zb,za*fb));
		}
	}
	return 0;
	}
	bool A=true,B=true;
	builda(1,1,n);
	buildb(1,1,m);
	for (i=1;i<=n;i++) if (a[i]<=0) A=false;
	for (i=1;i<=m;i++) if (b[i]<=0) B=false;
	if (A==true&&B==true)
	{
		while (q--)
		{
			scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
			printf("%lld\n",qamax(1,1,n,l1,r1)*qbmin(1,1,m,l2,r2));
		}
		return 0;
	}
	
	while (q--)
	{
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if (l1==r1)
		{
			if (a[l1]<0) printf("%lld\n",a[l1]*qbmax(1,1,m,l2,r2));
			else printf("%lld\n",a[l1]*qbmin(1,1,m,l2,r2));
		}
		else 
		{
			if (b[l2]<0) printf("%lld\n",b[l2]*qamin(1,1,n,l1,r1));
			else printf("%lld\n",b[l2]*qamax(1,1,n,l1,r1));
		}
	}
	return 0;
}
