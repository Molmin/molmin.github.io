#include<bits/stdc++.h>
#define ll long long
#define do double
using namespace std;
const int maxn=1e5+5;
int n,m,q;ll a[maxn],b[maxn];
ll fx[maxn][19],fn[maxn][19];
inline void ST_init(){
	int k=log2(m);
	for(int i=1;i<=m;++i)
		fx[i][0]=fn[i][0]=b[i];
	for(int j=1;j<=k;++j)
		for(int i=1;i+(1<<j)-1<=m;++i){
			fx[i][j]=max(fx[i][j-1],fx[i+(1<<(j-1))][j-1]);
			fn[i][j]=min(fn[i][j-1],fn[i+(1<<(j-1))][j-1]);
		}
}
inline ll query_max(int l,int r){
	int k=log2(r-l+1);
	return max(fx[l][k],fx[r-(1<<k)+1][k]);
}
inline ll query_min(int l,int r){
	int k=log2(r-l+1);
	return min(fn[l][k],fn[r-(1<<k)+1][k]);
}
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;++i)
		scanf("%lld",&b[i]);
	ST_init();
	while(q--){
		int l1,r1,l2,r2;ll ans=-1e18;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		for(int i=l1;i<=r1;++i){
			ll sum=0;
			if(a[i]>0)
				sum=1ll*query_min(l2,r2)*a[i];
			else if(a[i]<0)
				sum=1ll*query_max(l2,r2)*a[i];
			ans=max(ans,sum);
		}
		printf("%lld\n",ans);
	}
	return 0;
	unsigned int rp;
	while(1) rp++;
}
