#include<bits/stdc++.h>
#define ll long long
#define do double
using namespace std;
const int maxn=1e4+5,maxm=1e4+5;
struct Edge{
	int u,v;
}e[maxm];
struct edge{
	int v,next;
}E[maxm];int head[maxn],cnt;
inline void add(int u,int v){
	E[++cnt]=(edge){v,head[u]};
	head[u]=cnt;
}
int n,m,s[maxn][maxn];
bool f[maxm];
vector<int>st[maxn],en[maxn];
int in[maxn];
bool vis[maxn];
bool toposort(){
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;++i){
		in[i]=en[i].size();int o=in[i];
		for(int j=0;j<o;++j)
			if(f[en[i][j]])
				--in[i];
	}
	queue<int>q;int tp=0;
	for(int i=1;i<=n;++i)
		if(!in[i])
			q.push(i);
	while(!q.empty()){
		int u=q.front();q.pop();
		++tp;
		for(int i=head[u];i;i=E[i].next){
			int v=E[i].v;
			if(f[s[u][v]]||vis[v]) continue;
			vis[v]=1;
			if(--in[v]==0) q.push(v);
		}
	}
	return tp==n;
}
bool check(){
	bool p=toposort();
	if(p) return 0;
	for(int i=1;i<=n;++i){
		int siz=st[i].size();int kkk=0;
		for(int j=0;j<siz;++j)
			if(!f[st[i][j]])
				++kkk;
		if(kkk!=1) return 0;
	}
	return 1;
}
signed main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;++i){
		scanf("%d%d",&e[i].u,&e[i].v);
		st[e[i].u].push_back(i);
		en[e[i].v].push_back(i);
		s[e[i].u][e[i].v]=i;
		add(e[i].u,e[i].v);
	}
	int Q;scanf("%d",&Q);
	while(Q--){
		int op,u,v;scanf("%d%d",&op,&u);
		if(op==1){
			scanf("%d",&v);
			f[s[u][v]]=1;
		}
		if(op==2){
			int siz=en[u].size();
			for(int i=0;i<siz;++i)
				f[en[u][i]]=1;
		}
		if(op==3){
			scanf("%d",&v);
			f[s[u][v]]=0;
		}
		if(op==4){
			int siz=en[u].size();
			for(int i=0;i<siz;++i)
				f[en[u][i]]=0;
		}
		printf(check()?"YES\n":"NO\n");
	}
	return 0;
	unsigned int rp;
	while(1) rp++;
}
