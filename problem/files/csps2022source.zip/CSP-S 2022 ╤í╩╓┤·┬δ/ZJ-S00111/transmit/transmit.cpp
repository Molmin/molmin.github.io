#include<bits/stdc++.h>
#define ll long long
#define do double
using namespace std;
const int maxn=2e3+5;
struct edge{
	int v,next;
}e[maxn<<1];int head[maxn],cnt;
inline void add(int u,int v){
	e[++cnt]=(edge){v,head[u]};
	head[u]=cnt;
}
int n,q,K,a[maxn],sum,X,Y;
int dep[maxn],fa[maxn],siz[maxn],son[maxn],top[maxn];
int dis[maxn][maxn];
int dp[maxn];
void dfs1(int u,int f){
	siz[u]=1;
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].v;
		if(v==f) continue;
		fa[v]=u;dep[v]=dep[u]+1;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]])
			son[u]=v;
	}
}
void dfs2(int u){
	if(u==son[fa[u]])
		top[u]=top[fa[u]];
	else top[u]=u;
	for(int i=head[u];i;i=e[i].next){
		int v=e[i].v;
		if(v==fa[u]) continue;
		dfs2(v);
	}
}
int LCA(int u,int v){
	while(top[u]!=top[v]){
		if(dep[top[u]]>dep[top[v]])
			u=fa[top[u]];
		else
			v=fa[top[v]];
	}
	return dep[u]<dep[v]?u:v;
}
bool cmp(int x,int y){return dis[X][x]<dis[X][y];}
void dfs(int u,int v){
	memset(dp,0x3f,sizeof(dp));
	vector<int>k;int p;
	k.push_back(u);k.push_back(v);
	while(u!=v){
		if(dep[u]>dep[v]){
			u=fa[u];
			k.push_back(u);
		}
		else{
			v=fa[v];
			k.push_back(v);
		}
	}
	sort(k.begin(),k.end(),cmp);
	int siz=k.size();dp[X]=a[X];
	for(int i=0;i<siz;++i){
		if(K>=1&&i>=1)
			dp[k[i]]=min(dp[k[i]],dp[k[i-1]]+a[k[i]]);
		if(K>=2&&i>=2)
			dp[k[i]]=min(dp[k[i]],dp[k[i-2]]+a[k[i]]);
		if(K>=3&&i>=3)
			dp[k[i]]=min(dp[k[i]],dp[k[i-3]]+a[k[i]]);
	}
	printf("%d\n",dp[Y]);
}
signed main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&K);
	for(int i=1;i<=n;++i)
		scanf("%d",&a[i]);
	for(int i=1,u,v;i<n;++i){
		scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
	}
	dfs1(1,0);
	dfs2(1);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			if(i!=j)
				dis[i][j]=dep[i]+dep[j]-2*dep[LCA(i,j)];
	while(q--){
		int u,v;scanf("%d%d",&u,&v);
//		printf("%d\n",dis[u][v]);
		if(dis[u][v]<=K){
			printf("%d\n",a[u]+a[v]);
			continue;
		}
		else{
			X=u,Y=v;
			dfs(u,v);
		}
	}
	return 0;
	unsigned int rp;
	while(1) rp++;
}
