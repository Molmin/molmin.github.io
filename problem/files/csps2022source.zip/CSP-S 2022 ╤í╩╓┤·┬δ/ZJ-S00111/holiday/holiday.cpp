#include<bits/stdc++.h>
#define ll long long
#define do double
using namespace std;
const int maxn=2505,maxm=1e4+5;
int n,m;ll a[maxn],ans,K;
ll f[maxn][maxn];
struct edge{
	int v,next;
}e[maxm<<1];int head[maxn],cnt;
inline void add(int u,int v){
	e[++cnt]=(edge){v,head[u]};
	head[u]=cnt;
}
inline void work(){
	for(int i=2;i<=n;++i)
		scanf("%lld",&a[i]);
	while(m--){
		int u,v;scanf("%d%d",&u,&v);
		add(u,v);add(v,u);
		f[u][v]=f[v][u]=1ll;
	}
	for(int i=head[1];i;i=e[i].next)
		for(int j=head[e[i].v];j;j=e[j].next)if(e[j].v!=e[i].v)
			for(int p=head[e[j].v];p;p=e[p].next)if(e[p].v!=e[i].v&&e[p].v!=e[j].v)
				for(int q=head[e[p].v];q;q=e[q].next)if(e[q].v!=e[i].v&&e[q].v!=e[j].v&&e[q].v!=e[p].v)
					if(f[e[q].v][1])
						ans=max(ans,a[e[i].v]+a[e[j].v]+a[e[p].v]+a[e[q].v]);
	printf("%lld",ans);
}
signed main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&K);
	if(K==0){
		work();
		return 0;
	}
	for(int i=2;i<=n;++i)
		scanf("%lld",&a[i]);
	memset(f,0x3f,sizeof(f));
	for(int i=1;i<=n;++i)
		f[i][i]=0;
	while(m--){
		int u,v;
		scanf("%d%d",&u,&v);
		f[u][v]=f[v][u]=1ll;
	}
	for(int k=1;k<=n;++k)
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				f[i][j]=min(f[i][j],f[i][k]+f[k][j]);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			if(i!=j)
				--f[i][j];
	for(int i=2;i<=n;++i)if(f[1][i]<=K)
		for(int j=2;j<=n;++j)if(j!=i&&f[i][j]<=K)
			for(int p=2;p<=n;++p)if(p!=i&&p!=j&&f[j][p]<=K)
				for(int q=2;q<=n;++q)if(q!=i&&q!=j&&q!=p&&f[p][q]<=K)
					if(f[q][1]<=K)
						ans=max(ans,a[i]+a[j]+a[p]+a[q]);
	printf("%lld",ans);
	return 0;
	unsigned int rp;//unsigned int ��ֹ���
	while(1) rp++;
}
