#include<bits/stdc++.h>
using namespace std;
const int MOD=1e9;
int n,m,q;
int  a[10005],b[10005],c[10005][10005];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<=m;i++)scanf("%d",&b[i]);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	c[i][j]=(a[i]%MOD)*(b[j]%MOD);
	while(q--){
		int l1,r1,l2,r2,sum=1e5,ans=-1e5;
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		if(l1==r1){
			for(int i=1;i<=m;i++)
			sum=min(sum,c[l1][i]);
			ans=sum;
		}
		else if(l2==r2){
			for(int i=1;i<=n;i++)
			ans=max(ans,c[l2][i]);
		}
		else{
		for(int i=l1;i<=r1;i++){
			for(int j=l2;j<=r2;j++){
				sum=min(sum,c[i][j]);
			}
			ans=max(ans,sum)%MOD;
			sum=1e5;
		}	
		}
		printf("%d\n",ans);
	}
	return 0;
}