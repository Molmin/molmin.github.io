#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int v[2505],a[2050][2050],ans,sum=2,f[2050],i=2;
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=2;i<=n;i++)scanf("%d",&v[i]);
	for(int i=1;i<=m;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		a[x][y]=1;
	}
	printf("%d",f[1]);
	return 0;
}
