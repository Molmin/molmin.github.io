#include<bits/stdc++.h>
using namespace std;
int n,m,u[10000],v[10000],u1[10000],t,v1[10000],q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++)scanf("%d%d",&u[i],&v[i]);
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		scanf("%d",&t);
		if(t==4)printf("%d",&u1[i]);
		else printf("%d%d",&u1[i],&v1[i]);
	}
	printf("NO");
	return 0;
}
