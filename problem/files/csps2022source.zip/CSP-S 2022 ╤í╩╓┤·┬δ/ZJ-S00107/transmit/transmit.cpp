#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[2005],a[2005],b[2005],s[2005],t[2005];
bool c[2005][2005];
struct code{
	int v;
	int id;
}point[2005];
int dfs(int x,int y,int sum){
	for(int i=1;i<=n;i++){
		if(c[x][i]==1){
		sum++;
		if(i==y)return sum;
		else{
		dfs(i,y,sum);
		}
		}
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=1;i<=n;i++){
	scanf("%d",&point[i].v);
	point[i].id=i;
	}
	for(int i=1;i<n;i++){
	scanf("%d%d",&a[i],&b[i]);
	c[a[i]][b[i]]=1;
	}
	for(int i=1;i<=q;i++)scanf("%d%d",&s[i],&t[i]);
	for(int i=1;i<=q;i++){
	printf("%d\n",dfs(s[i],t[i],0));	
	}
	return 0;
}
