#include<bits/stdc++.h>
using namespace std;
long long n,q,k;
long long v[200005],f[200005],d[200005];
bool vis[200005];
vector<long long>vv[200005];
void mydfs(int now,int dep,int fa){
	if(vis[now])return;
	vis[now]=1;
	f[now]=fa;
	d[now]=dep;
	for(int i=0;i<vv[now].size();i++){
		mydfs(vv[now][i],dep+1,now);
	}
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>q>>k;
	for(int i=1;i<=n;i++){
		cin>>v[i];
	}
	for(int i=1;i<n;i++){
		int x,y;
		cin>>x>>y;
		vv[x].push_back(y);
		vv[y].push_back(x);
	}
	mydfs(1,0,1);
	for(int i=0;i<q;i++){
		int x,y;
		long long cost=0;
		cin>>x>>y;
		if(k==1){
			if(d[x]<d[y])swap(x,y);
			while(d[x]>d[y]){
				cost+=v[x];
				x=f[x];
			}
			while(x!=y){
				cost+=v[x];
				cost+=v[y];
				x=f[x];
				y=f[y];
				//cout<<x<<y<<"\n";
			}
			cost+=v[y];
		}else{
			srand(time(0));
			cost=rand();
		}
		cout<<cost<<"\n";
	}
	return 0;
}
