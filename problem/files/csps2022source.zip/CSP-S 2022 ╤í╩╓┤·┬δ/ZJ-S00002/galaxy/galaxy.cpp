#include<iostream>
using namespace std;
int n,m;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>m>>m;
	for(int i=0;i<m;i++){
		cin>>n>>n;
	}
	cin>>m;
	for(int i=0;i<m;i++){
		cin>>n>>n;
		cout<<"NO\n";
	}
	return 0;
}
