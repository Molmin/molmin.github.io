#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a[100005],b[100005],stb[2][100005][20];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=m;i++){
		cin>>b[i];
	}
	for(int i=m;i>=1;i--){
		stb[0][i][0]=stb[1][i][0]=b[i];
		for(int j=1,x=1;j<20;j++,x<<=1){
			if(x+i>m)x=m-i;
			stb[0][i][j]=min(stb[0][i][j-1],stb[0][i+x][j-1]);
			stb[1][i][j]=max(stb[1][i][j-1],stb[1][i+x][j-1]);
			//cout<<i<<" "<<j<<" ";
			//cout<<stb[1][i][j-1]<<" "<<stb[1][i+x][j-1]<<"\n";
		}
	}
	for(int i=1;i<=q;i++){
		int l1,r1,l2,r2;
		cin>>l1>>r1>>l2>>r2;
		long long maxx=-1000000000000000001;
		for(int i=l1;i<=r1;i++){
			long long minn=b[r2],minnn=b[r2];
			int temp=l2;
			for(int k=17,x=131072;k>=0;k--,(x>>=1)){
				if(temp+x<=r2){
					minn=min(minn,stb[0][temp][k]);
					minnn=max(minnn,stb[1][temp][k]);
					temp+=x;
				}
			}
			maxx=max(maxx,(a[i]>=0?minn:minnn)*a[i]);
		}
		cout<<maxx<<"\n";
	}
	return 0;
}
