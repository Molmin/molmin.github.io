#include<bits/stdc++.h>
using namespace std;
long long n,m,k,a[2505],ans=-1;
vector<long long>v[2505];
bool vis[2505];
void mydfs(long long now,long long cost,long long d){
	if(vis[now])return;
	vis[now]=1;
	if(d==4&&ans<cost){
		for(int i=0;i<v[now].size();i++){
		 	if(v[now][i]==1){
		 		ans=cost;
		 		return;
			 }
		}
	}
	for(int i=0;i<v[now].size();i++){
		 mydfs(v[now][i],cost+a[v[now][i]],d+1);
	}
}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	for(int i=2;i<=n;i++){
		cin>>a[i];
	}
	for(int i=0;i<m;i++){
		int x,y;
		cin>>x>>y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	if(k==0){
		mydfs(1,0,0);
		cout<<ans;
	}else{
		srand(time(0));
		cout<<rand();
	}
	return 0;
}
