#include<bits./stdc++.h>
#define int long long
using namespace std;
int s[300][300],a[120000],b[120000];
signed main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	int n,m,q,l1,l2,r1,r2;
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)scanf("%lld",&b[i]);
	if(n>=200||m>=200){		/******				********/
		int minn,maxx;
		for(int p=1;p<=q;p++){
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			if(l1==r1){
				minn=1e18;
				for(int i=l2;i<=r2;i++)minn=min(minn,a[l1]*b[i]);
				printf("%lld",minn);
			}
			else if(l2==r2){
				maxx=-1e18;
				for(int i=l2;i<=r2;i++)maxx=max(maxx,a[i]*b[l2]);
				printf("%lld",maxx);
			}
			else {
				return 0;
			}
		}
	}
	else {
		for(int i=1;i<=n;i++){
			for(int j=1;j<=m;j++){
				s[i][j]=a[i]*b[j];
			}
		}
		for(int p=1;p<=q;p++){
			scanf("%lld%lld%lld%lld",&l1,&r1,&l2,&r2);
			int minn,minmax=-1e18;
			for(int i=l1;i<=r1;i++){
				minn=1e18;
				for(int j=l2;j<=r2;j++)minn=min(minn,s[i][j]);
				minmax=max(minmax,minn);
			}
			printf("%lld\n",minmax);
		}
	}
	return 0;
}
