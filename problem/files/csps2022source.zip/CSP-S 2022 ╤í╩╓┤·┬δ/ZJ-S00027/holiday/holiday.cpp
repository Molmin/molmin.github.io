#include<bits./stdc++.h>
#define int long long
using namespace std;
struct node{
	int to,nxt;
}s[200020];
int head[3000],w[3000],cnt;
void ad(int u,int v){
	s[++cnt].to=v;
	s[cnt].nxt=head[u];
	head[u]=cnt;
}
int vis[3000],q[300000];
int dis[3000][3000],f[3000][3000];
int maxx[3000][8];
void rol(int n,int x,int num,int roll){
	if(roll>=3){
		maxx[n][6]=maxx[n][4];
		maxx[n][5]=maxx[n][3];
		maxx[n][4]=maxx[n][2];
		maxx[n][3]=maxx[n][1];
		maxx[n][2]=x;
		maxx[n][1]=num;
		return ;
	}
	if(roll>=2){
		maxx[n][6]=maxx[n][4];
		maxx[n][5]=maxx[n][3];
		maxx[n][4]=x;
		maxx[n][3]=num;
		return ;
	}
	maxx[n][6]=x;
	maxx[n][5]=num;
	return ;
}
signed main(){
	//freopen("holiday2.in","r",stdin);
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	int n,m,K,u,v;
	cin>>n>>m>>K;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)dis[i][j]=1000000;
		dis[i][i]=-1;
	}
	for(int i=2;i<=n;i++){
		scanf("%lld",&w[i]);
	}
	for(int i=1;i<=m;i++){
		scanf("%lld%lld",&u,&v);
		ad(u,v);ad(v,u);
	}
	int l=0,r=0,now;
	for(int i=1;i<=n;i++){
		q[++r]=i;
		for(int j=1;j<=n;j++)vis[j]=0;
		while(l<r){
			now=q[++l];++vis[now];
			for(int j=head[now];j;j=s[j].nxt){
				v=s[j].to;
				if(vis[v])continue;
				q[++r]=v;
				dis[i][v]=min(dis[i][now]+1,dis[i][v]);
			}
		}
	}
	for(int i=2;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(dis[i][j]>K)continue;
			if(dis[1][i]<=K)f[i][j]=w[i]+w[j];
			if(dis[1][j]<=K)f[j][i]=w[i]+w[j];
		}
	}
	for(int i=2;i<=n;i++){//max_value_of_point
		for(int j=2;j<=n;j++){
			if(f[i][j]>maxx[j][2]) rol(j,f[i][j],i,3);
			else if(f[i][j]>maxx[j][4])rol(j,f[i][j],i,2);
			else if(f[i][j]>maxx[j][6])rol(j,f[i][j],i,1);
		}
	}
	int ans=0;
	/*
	for(int i=1;i<=n;i++){
		cout<<i<<":\n";
		cout<<maxx[i][1]<<" "<<maxx[i][2]<<endl;
		cout<<maxx[i][3]<<" "<<maxx[i][4]<<endl;
		cout<<maxx[i][5]<<" "<<maxx[i][6]<<endl;
		cout<<endl;
	}*/
	for(int i=1;i<=n;i++){
		for(int k=1;k<=3;k++){
			for(int j=i+1;j<=n;j++){
				for(int z=1;z<=3;z++){
					if(dis[i][j]<=K&&i!=j&&i!=maxx[j][z*2-1]&&j!=maxx[i][k*2-1]&&maxx[i][k*2-1]!=maxx[j][z*2-1])
						ans=max(ans,maxx[i][k*2]+maxx[j][z*2]);
				}
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}