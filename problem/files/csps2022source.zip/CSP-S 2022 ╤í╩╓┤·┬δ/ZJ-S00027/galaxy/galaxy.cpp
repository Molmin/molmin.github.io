#include<bits./stdc++.h>
using namespace std;
int s[1200][1200],vis[1200],now[1200];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m,q,u,v,t,cnt;
	cin>>n>>m;
	if(n>1000&&m>1000)return 0;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		s[u][v]=1;++s[u][0];++s[1145][v];s[u][1145]+=v;
	}
	cin>>q;
	int fl;
	for(int p=1;p<=q;p++){
		cnt=0;
		for(int i=0;i<=1199;i++)vis[i]=now[i]=0;
		cin>>t;
		if(t==1){
			cin>>u>>v;
			s[u][v]=-1;--s[u][0];--s[1145][v];s[u][1145]-=v;
		}
		else if(t==2){
			cin>>v;
			for(int i=1;i<=n;i++){
				if(s[i][v]==1){
					s[i][v]=-1;--s[i][0];--s[1145][v];s[i][1145]-=v;
				}
			}
		}
		else if(t==3){
			cin>>u>>v;
			s[u][v]=1;++s[u][0];++s[1145][v];s[u][1145]+=v;
		}
		else if(t==4){
			cin>>v;
			for(int i=1;i<=n;i++){
				if(s[i][v]==-1){
					s[i][v]=1;++s[i][0];++s[1145][v];s[i][1145]+=v;
				}
			}
		}
		fl=1;
		for(int i=1;i<=n;i++){
			if(s[i][0]!=1){
				printf("NO\n");fl=-1;break;
			}
			if(!s[1145][i]){
				now[++cnt]=i;
			}
		}
		if(fl==-1)continue;
		if(cnt==0){
			printf("YES\n");
			continue;
		}
		int now2;
		for(int i=1;i<=cnt;i++){
			now2=now[i];
			while(!vis[now2]){
				vis[now2]=1;
				now2=s[now2][1145];
			}
		}	
		if(fl==-1)continue;
		fl=1;
		for(int i=1;i<=n;i++)if(!vis[i])fl=0;
		if(fl)printf("YES\n");
		else printf("NO\n");
	}
	return 0;
}
