//k=1 subtask
#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mkp make_pair
#define fi first
#define se second
#define ls(x) ((x)<<1)
#define rs(x) ((x)<<1|1)
const int N = 2e5 + 10, M = 20, lim = 18;
int n, q, k, dep[N], val[N]; ll sum[N], g[N];
int e, to[N << 1], nxt[N << 1], hd[N];
int f[N][M];
vector<int>A, B; 
void add(int u, int v) { to[++e] = v; nxt[e] = hd[u]; hd[u] = e; }
void dfs(int u, int fa) {
	//cout<<u<<" "<<fa<<endl;
	dep[u] = dep[fa] + 1;
	sum[u] = sum[fa] + val[u];
	f[u][0] = fa;
	for(int i = 1; i <= lim; i++) f[u][i] = f[f[u][i - 1]][i - 1];
	for(int i = hd[u]; i; i = nxt[i]) {
		int v = to[i]; if(v == fa) continue;
		dfs(v, u);
	}
}
int getlca(int x, int y) {
	if(dep[x] < dep[y]) swap(x, y);
	for(int i = lim; i >= 0; i--)
		if(dep[f[x][i]] >= dep[y]) x = f[x][i];
	if(x == y) return x;
	for(int i = lim; i >= 0; i--)
		if(f[x][i] != f[y][i]) x = f[x][i], y = f[y][i];
	return f[x][0];
}
ll solve() {
	if(!A.size()) return 0;
	g[0] = val[A[0]];
	for(int i = 1; i < A.size(); i++) {
		g[i] = 1e18;
		for(int j = max(i - k, 0); j < i; j++)
			g[i] = min(g[i], g[j] + val[A[i]]);
	}
	return g[A.size() - 1];
}
int main() {
	freopen("transmit.in", "r", stdin);
	freopen("transmit.out", "w", stdout);
	scanf("%d%d%d", &n, &q, &k);
	for(int i = 1; i <= n; i++)
		scanf("%d", &val[i]);
	for(int i = 1, u, v; i < n; i++)
		scanf("%d%d", &u, &v), add(u, v), add(v, u);
	dfs(1, 0);
//	cout<<"???"<<endl;
	while(q--) {
		int x, y;
		scanf("%d%d", &x, &y);
		int t = getlca(x, y);
		if(k == 1) printf("%lld\n", sum[x] + sum[y] - sum[t] - sum[f[t][0]]);
		else {
			A.clear(); B.clear();
			while(x != t) A.push_back(x), x = f[x][0];
			A.push_back(t);
			while(y != t) B.push_back(y), y = f[y][0];
			reverse(B.begin(), B.end());
			for(int i = 0; i < B.size(); i++) A.push_back(B[i]);
			printf("%lld\n", solve());
		}
	}
	return 0;
}
/*
背景很像THUSC2022D2那题啊。。什么午夜梦回。。还有1h能打啥暴力呢。啸了。
=1的直接lca一手就好了。特殊性质考虑树形dp即可。很有道理，写的完吗。。

7 3 1
1 2 3 4 5 6 7
1 2
1 3
2 4
2 5
3 6
3 7
4 7
5 6
1 2


*/