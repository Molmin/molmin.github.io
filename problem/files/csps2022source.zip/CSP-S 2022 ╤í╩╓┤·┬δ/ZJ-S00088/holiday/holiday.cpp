#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mkp make_pair
#define fi first
#define se second
#define ls(x) ((x)<<1)
#define rs(x) ((x)<<1|1)
const int N = 2510, xM = 10010, M = N * N;//???
int n, m, k;
int x[M], y[M];
ll val[N]; bool mp[N][N];
int e, to[xM << 1], nxt[xM << 1], hd[N];
void add(int u, int v) { to[++e] = v; nxt[e] = hd[u]; hd[u] = e; }
void bfs(int bg) {
	queue<pair<int, int> >q; q.push(mkp(bg, 0)); mp[bg][bg] = 1;
	while(!q.empty()) {
		int u = q.front().fi, st = q.front().se; q.pop();
		if(st <= k) {
			for(int i = hd[u]; i; i = nxt[i]) {
				int v = to[i]; if(mp[bg][v]) continue;
				mp[bg][v] = 1; q.push(mkp(v, st + 1));
			}
		}
	}
}
bool check(int a, int b, int c, int d) { return mp[1][a] && mp[a][b] && mp[b][c] && mp[c][d] && mp[d][1]; }
void solve() {
	ll ans = 0;
	for(int i = 1; i <= m; i++)
		for(int j = 1; j <= m; j++) {
			if(x[i] == x[j] || x[i] == y[j] || y[i] == x[j] || y[i] == y[j]) continue;
			
			if(check(x[i], y[i], x[j], y[j]) || check(x[i], y[i], y[j], x[j]) || check(y[i], x[i], x[j], y[j]) || check(y[i], x[i], y[j], x[j]))
				ans = max(ans, val[x[i]] + val[y[i]] + val[x[j]] + val[y[j]]);
		}
	printf("%lld\n", ans);
	return;
}
int main() {
	freopen("holiday.in", "r", stdin);
	freopen("holiday.out", "w", stdout);
	memset(mp, 0, sizeof(mp));
	scanf("%d%d%d", &n, &m, &k);
	for(int i = 2; i <= n; i++) scanf("%lld", &val[i]);
	for(int i = 1, u, v; i <= m; i++) {
		scanf("%d%d", &u, &v); add(u, v), add(v, u);
	}
	for(int i = 1; i <= n; i++) bfs(i);
	m = 0;
	for(int i = 2; i <= n; i++)
		for(int j = i + 1; j <= n; j++) {
			if(mp[i][j]) {
				x[++m] = i, y[m] = j;
			}
		}
	solve();
	return 0;
}