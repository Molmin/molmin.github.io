#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mkp make_pair
#define fi first
#define se second
#define ls(x) ((x)<<1)
#define rs(x) ((x)<<1|1)
const int N = 5e5 + 10;
int n, m, ot[N], cnt;
set<int>s[N];
vector<int>pre[N];
int main() {
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1, u, v; i <= m; i++) {
		scanf("%d%d", &u, &v), pre[v].push_back(u);
		if(ot[u] == 1) cnt--; ot[u]++; if(ot[u] == 1) cnt++;
		s[v].insert(u);
	}
//	int cas = 0;
	int q; scanf("%d", &q);
	while(q--) {
		int op, u, v;
		scanf("%d", &op);
		if(op == 1) {
			scanf("%d%d", &u, &v);
			if(ot[u] == 1) cnt--; ot[u]--; if(ot[u] == 1) cnt++; 
			s[v].erase(u);
		} else if(op == 2) {
			scanf("%d", &u);
			set<int>::iterator it;
			for(it = s[u].begin(); it != s[u].end(); it++) {
				if(ot[*it] == 1) cnt--; ot[*it]--; if(ot[*it] == 1) cnt++; 
			}
			s[u].clear();
		} else if(op == 3) {
			scanf("%d%d", &u, &v);
			if(ot[u] == 1) cnt--; ot[u]++; if(ot[u] == 1) cnt++;
			s[v].insert(u);
		} else {
			scanf("%d", &u);
			for(int i = 0; i < pre[u].size(); i++) {
				if(s[u].find(pre[u][i]) != s[u].end()) continue;
				if(ot[pre[u][i]] == 1) cnt--; ot[pre[u][i]]++; if(ot[pre[u][i]] == 1) cnt++; 
				s[u].insert(pre[u][i]);
			}
		}
//		cout<<++cas<<"ot: ";
//		for(int i = 1; i <= n; i++)
//			cout<<ot[i]<<" ";
//		cout<<endl;
		if(cnt == n) puts("YES");
		else puts("NO");
	}
	return 0;
}
/*
考虑你每个点就一条出边，这个图肯定很特殊，先check出边数量，符合出边数量其实这图就一定合法了吧？
*/