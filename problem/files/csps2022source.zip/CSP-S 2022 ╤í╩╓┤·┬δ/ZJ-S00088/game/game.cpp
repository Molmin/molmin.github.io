#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mkp make_pair
#define fi first
#define se second
#define ls(x) ((x)<<1)
#define rs(x) ((x)<<1|1)
const int N = 1e5 + 10, M = 20, inf = 0x3f3f3f3f;
const int lim = 17;
int n, m, q, Log[N], a[N], b[N], tmp[N];
int sum[N];
struct findmax {
	int st[N][M], sj;
	void init(int t) {
		sj = t;
		for(int j = 0; j <= lim; j++)
			for(int i = 1; i <= sj; i++)
				st[i][j] = -inf;
		for(int i = 1; i <= sj; i++)
			st[i][0] = tmp[i];
		for(int j = 1; j <= lim; j++)
			for(int i = 1; i + (1 << j) - 1 <= sj; i++)
				st[i][j] = max(st[i][j - 1], st[i + (1 << (j - 1))][j - 1]);
		return;
	}
	int query(int x, int y) {
		int t = Log[y - x + 1];
		return max(st[x][t], st[y - (1 << t) + 1][t]);
	}
}Afx, Azx, Bx;
struct findmin {
	int st[N][M], sj;
	void init(int t) {
		sj = t;
		for(int j = 0; j <= lim; j++)
			for(int i = 1; i <= sj; i++)
				st[i][j] = inf;
		for(int i = 1; i <= sj; i++)
			st[i][0] = tmp[i];
		for(int j = 1; j <= lim; j++)
			for(int i = 1; i + (1 << j) - 1 <= sj; i++)
				st[i][j] = min(st[i][j - 1], st[i + (1 << (j - 1))][j - 1]);
		return;
	}
	int query(int x, int y) {
		int t = Log[y - x + 1];
		return min(st[x][t], st[y - (1 << t) + 1][t]);
	}
}Azn, Afn, Bn;
ll calc(int a, int b, int c, int d) {
	ll ret = -1e18;
	//cout<<Az.query(a, b)<<" "<<Bn.query(c, d)<<endl;
	int t, aaa;
	aaa = Bn.query(c, d);
	t = Azx.query(a, b); if(t != inf && t != -inf) ret = max(ret, 1ll * t * aaa);
	t = Azn.query(a, b); if(t != inf && t != -inf) ret = max(ret, 1ll * t * aaa);
	
	aaa = Bx.query(c, d);
	t = Afx.query(a, b); if(t != inf && t != -inf) ret = max(ret, 1ll * t * aaa);
	t = Afn.query(a, b); if(t != inf && t != -inf) ret = max(ret, 1ll * t * aaa);
	if(sum[b] - sum[a - 1] > 0) ret = max(ret, 0ll);
	return ret;
}
int main() {
	freopen("game.in", "r", stdin);
	freopen("game.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &q);
	Log[1] = 0; for(int i = 2; i <= max(n, m); i++) Log[i] = Log[i >> 1] + 1;
	for(int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		sum[i] = sum[i - 1] + (a[i] == 0);
	}
	for(int i = 1; i <= n; i++) tmp[i] = ((a[i] < 0) ? a[i] : -inf); Afx.init(n); 
	for(int i = 1; i <= n; i++) tmp[i] = ((a[i] < 0) ? a[i] : inf); Afn.init(n);
	for(int i = 1; i <= n; i++) tmp[i] = ((a[i] > 0) ? a[i] : inf); Azn.init(n);
	for(int i = 1; i <= n; i++) tmp[i] = ((a[i] > 0) ? a[i] : -inf); Azx.init(n); 
	
	for(int i = 1; i <= m; i++) scanf("%d", &b[i]), tmp[i] = b[i]; Bx.init(m); Bn.init(m);
	while(q--) {
		int a, b, c, d;
		scanf("%d%d%d%d", &a, &b, &c, &d);
		printf("%lld\n", calc(a, b, c, d));
	}
	return 0;
}
//A维护2ST表分别维护区间最小正数和区间最大负数再一个前缀和维护区间0个数，BST表维护区间最大数和区间最小数，
//直接写个维护区间最小数和最大数的ST表结构体得了。。