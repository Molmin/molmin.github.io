#include<iostream>
#include<cstdio>
using namespace std;
int n,m,k,ans;
int map[3000];
bool vis[3000][3000];
bool home[3000];
void dfs(int x,int t,int cnt,int trip,int tf){
	if(t<0) return ;
	if(trip==4 && home[x]) ans=max(cnt,ans);
	else if(trip==4) return ;
	for(int i=1;i<=n;i++){
		if(vis[x][i]){
			vis[x][i]=0;
			dfs(i,tf,cnt+map[i],trip+1,tf);
			dfs(i,t-1,cnt,trip,tf);
		}
	}
}
int main(){
	memset(vis,0,sizeof(vis));
	memset(map,0,sizeof(map));
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	int x,y;
	for(int i=2;i<=n;i++)
		scanf("%d",&map[i]);
	for(int i=1;i<=m;i++){
		scanf("%d%d",&x,&y);
		vis[x][y]=vis[y][x]=1;
	}
	for(int i=1;i<=n;i++)
		if(vis[1][i]) home[i]=1;
	for(int i=1;i<=k;i++)
		for(int j=2;j<=n;j++)
			for(int k=2;j<=n;k++)
				if((home[k]&&vis[j][k])||home[j]){
					home[j]=1;
					break;
				}
			
	dfs(1,k,0,0,k);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
}