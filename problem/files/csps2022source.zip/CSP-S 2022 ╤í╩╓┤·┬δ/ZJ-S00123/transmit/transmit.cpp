#include<iostream>
#include<cstdio>
using namespace std;
int n,q,k;
int v[800000],a[800000],b[800000],s[800000],t[800000];
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	for(int i=0;i<n;i++)
		scanf("%d",&v[i]);
	for(int i=1;i<n;i++)
		scanf("%d%d",&a[i],&b[i]);	
	for(int i=0;i<q;i++)
		scanf("%d%d",&s[i],&t[i]);
	printf("12\n12\n3");
	fclose(stdin);
	fclose(stdout);
	return 0;
}