#include<iostream>
#include<cstdio>
using namespace std;
int n,m,q;
long long a[100099],b[100099];
int l1,l2,r1,r2;
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	scanf("%d%d%d",&n,&m,&q);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<=m;i++)
		scanf("%lld",&b[i]);
	while(q--){
		scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
		long long x=-0x3ffffff,y=0x3ffffff;
		for(int i=l1;i<=r1;i++){
			for(int j=l2;j<=r2;j++)
				y=min((a[i]*b[j]),y);
			x=max(y,x);
		}
		printf("%lld\n",x);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}