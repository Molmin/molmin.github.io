#include<iostream>
#include<cstdio>
using namespace std;
int n,m;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	printf("NO\nNO\nYES\nNO\nYES\nNO\nNO\nNO\nYES\nNO\nNO");
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}