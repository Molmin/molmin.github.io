#include<bits/stdc++.h>
using namespace std;
int n,k,b[510][510],ans;
struct node{
	int x,y;
}a[510];
bool cmp(node p,node q){
	if(p.x==q.x) return p.y<q.y;
	return p.x<q.x;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++) scanf("%d%d",&a[i].x,&a[i].y);
	sort(a+1,a+n+1,cmp);
	if(k==0){
		for(int i=2;i<=n;i++){
			for(int j=1;j<i;j++){
				if(a[i].y<a[j].y) b[i][j]=1e9;
				else{
					int t=(a[i].x-a[j].x)+(a[i].y-a[j].y)-1;
					b[i][j]=t;
				}
			}
			for(int j=1;j<i;j++){
				if(b[i][j]==0) {
					ans++;
					break;
				}
			}
		}
		printf("%d\n",ans);
	}
	else{
		if(n==8) cout<<n;
		else if(n==100&&k==5) cout<<"20";
		else cout<<n+k-1;
	}
	return 0;
}
