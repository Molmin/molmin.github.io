#include<bits/stdc++.h>
using namespace std;
char s[1000010];
int x,y,st,sd,ans,a,b;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s+1);
	for(int i=1;s[i];i++){
		if(s[i]=='(') ans++;
		else if(s[i]=='&'){
			a++;
			if(s[i-1]=='0') x++;
			st=1;
		}
		else if(s[i]=='|'){
			b++;
			if(s[i-1]=='1') y++;
			sd=1;
		}
	}
	if(st==0){
		cout<<"1"<<endl;
		cout<<"0"<<' '<<b-ans<<endl;
	}
	else if(sd==0){
		cout<<"0"<<endl;
		cout<<a-ans<<' '<<"0"<<endl;
	}
	else{
		cout<<"0"<<endl;
		cout<<x<<' '<<y<<endl;
	}
	return 0;
}
