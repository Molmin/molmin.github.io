#include<bits/stdc++.h>
using namespace std;
long long a,b,INf=1e9;
long long pp(long long a,long long b){
	long long res=1;
	while(b){
		if(b&1) res=res*a;
		if(res>INf) return -1;
		a=(long long)a*a;
		if(b>1){
			if(a>INf) return -1;
		}
		b>>=1;
	}
	return res;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	printf("%lld\n",pp(a,b));
	return 0;
}
