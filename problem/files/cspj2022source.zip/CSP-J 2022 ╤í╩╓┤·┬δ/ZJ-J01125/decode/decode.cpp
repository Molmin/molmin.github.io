#include<bits/stdc++.h>
using namespace std;
const int N=10000010;
int k,a[N];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	while(k--){
		long long n;
		int e,d;
		scanf("%lld%d%d",&n,&e,&d);
		memset(a,0,sizeof(a));
		int cnt=0;
		for(int i=1;i<=sqrt(n);i++){
			if(n%i==0) a[++cnt]=i;
		}
		bool flag=0;
		for(int i=1;i<=cnt;i++){
			if((a[i]-1)*(n/a[i]-1)+1==e*d){
				printf("%d %d\n",a[i],n/a[i]);
				flag=1;
				break;
			}
		}
		if(!flag) puts("NO");
	}
	return 0;
}
