#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll read(){
	ll x=0,f=1; char c=getchar();
	while(c!='-'&&(c<'0'||c>'9')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=(x<<1)+(x<<3)+c-'0',c=getchar();
	return x*f;
}
int k;
ll n,e,d,p,q,m;
ll l,r,mid;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=(int)read();
	while(k--){
		n=read(); e=read(); d=read();
		m=n-e*d+2;
		l=1; r=m/2;
		while(l<r){
			mid=l+r>>1;
			if(mid*(m-mid)==n) {l=mid; break;}
			if(mid*(m-mid)<n) l=mid+1;
			else r=mid-1;
		}
		if(l*(m-l)==n) printf("%lld %lld\n",l,m-l);
		else printf("NO\n");
	}
	return 0;
}
