#include<bits/stdc++.h>
using namespace std;
char s[1000005];
int op[1000005];
int n;
int ands=0;
int ors=0;
int f(int l,int r){
	if(l==r) return s[l]-'0';
	int id=0,k,sum=0;
	bool flg;
	for(int i=r;i>=l;i--){
		if(op[i]==3&&sum==0) {id=i; break;}
		if(abs(op[i])==1) sum+=op[i];
	}
	if(id){
		flg=0; sum=0;
		for(int i=l;i<=id-1;i++){
			if(sum==0&&i!=l) {flg=1; break;}
			if(abs(op[i])==1) sum+=op[i];
		}
		k=((op[l]==1&&!flg)?1:0);
		if(f(l+k,id-k-1)==1){
			ors++;
			return 1;
		}
		flg=0; sum=0;
		for(int i=id+1;i<=r;i++){
			if(sum==0&&i!=id+1) {flg=1; break;}
			if(abs(op[i])==1) sum+=op[i];
		}
		k=((op[r]==-1&&!flg)?1:0);
		return f(id+k+1,r-k);
	}
	else{
		id=sum=0;
		for(int i=r;i>=l;i--){
			if(op[i]==2&&sum==0) {id=i; break;}
			if(abs(op[i])==1) sum+=op[i];
		}
		if(!id) return f(l+1,r-1);
		flg=0; sum=0;
		for(int i=l;i<=id-1;i++){
			if(sum==0&&i!=l) {flg=1; break;}
			if(abs(op[i])==1) sum+=op[i];
		}
		k=((op[l]==1&&!flg)?1:0);
		if(f(l+k,id-k-1)==0){
			ands++;
			return 0;
		}
		flg=0; sum=0;
		for(int i=id+1;i<=r;i++){
			if(sum==0&&i!=id+1) {flg=1; break;}
			if(abs(op[i])==1) sum+=op[i];
		}
		k=((op[r]==-1&&!flg)?1:0);
		return f(id+k+1,r-k);
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s+1);
	n=strlen(s+1);
	for(int i=1;i<=n;i++){
		if(s[i]=='&') op[i]=2;
		if(s[i]=='|') op[i]=3;
		if(s[i]=='(') op[i]=1;
		if(s[i]==')') op[i]=-1;
	}
	printf("%d\n",f(1,n));
	printf("%d %d",ands,ors);
	return 0;
}
