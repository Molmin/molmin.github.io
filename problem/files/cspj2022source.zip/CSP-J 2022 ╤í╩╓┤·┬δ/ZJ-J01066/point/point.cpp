#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0,f=1; char c=getchar();
	while(c!='-'&&(c<'0'||c>'9')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=(x<<1)+(x<<3)+c-'0',c=getchar();
	return x*f;
}
int n,k;
struct Point{
	int x,y;
	Point(int x=0,int y=0): x(x),y(y) {};
}p[505];
bool cmp(Point x,Point y){
	if(x.x!=y.x) return x.x<y.x;
	return x.y<y.y;
}
int dp[505][105];
int ans=0;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	n=read(); k=read();
	for(int i=1,x,y;i<=n;i++){
		x=read(); y=read();
		p[i]=Point(x,y);
	}
	sort(p+1,p+n+1,cmp);
	for(int i=0;i<=k;i++) dp[1][i]=i+1;
	for(int i=2,dc;i<=n;i++){
		for(int j=1;j<i;j++){
			if(p[i].y<p[j].y) continue;
			dc=p[i].x+p[i].y-p[j].x-p[j].y-1;
			for(int l=0;l<=k;l++){
				if(l+dc>k) break;
				dp[i][l+dc]=max(dp[i][l+dc],dp[j][l]+dc);
			}
		}
		for(int j=0;j<=k;j++){
			dp[i][j]=max(dp[i][j],j)+1;
			ans=max(ans,dp[i][j]);
		}
	}
	printf("%d",ans);
	return 0;
}
