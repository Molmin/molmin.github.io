#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll read(){
	ll x=0,f=1; char c=getchar();
	while(c!='-'&&(c<'0'||c>'9')) c=getchar();
	if(c=='-') f=-1,c=getchar();
	while(c>='0'&&c<='9') x=(x<<1)+(x<<3)+c-'0',c=getchar();
	return x*f;
}
ll a,b;
bool flag=1;
ll qpow(ll d,ll c){
	ll res=1;
	while(c){
		if(c&1) res=res*d;
		d*=d; c>>=1;
		if(res>1000000000) return -1;
	}
	return res;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read(); b=read();
	printf("%lld",qpow(a,b));
	return 0;
}
