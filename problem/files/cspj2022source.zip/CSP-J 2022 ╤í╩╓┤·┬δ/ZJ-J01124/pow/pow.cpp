#include <bits/stdc++.h>
#define int long long
using namespace std;
const int MAX=1e9;
int qpow(int a,int b)
{
	int rt=1;
	for(;b;b>>=1)
	{
		if(b&1) rt*=a;
		if(rt>MAX||a>MAX)
		{
			rt=-1;
			break;
		}
		a*=a;
	}
	return rt;
}
signed main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	scanf("%lld%lld",&a,&b);
	printf("%lld",qpow(a,b));
	return 0;
}