#include <bits/stdc++.h>
#define int long long
using namespace std;
int calc(int flag,int x,int y)
{
	if(x*x-4*y>=0&&sqrt(x*x-4*y)*sqrt(x*x-4*y)==x*x-4*y)
	{
		if(flag==1)
		return (x+sqrt(x*x-4*y))/2;
		else return (x-sqrt(x*x-4*y))/2;
	}
	else return -1;
}
signed main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;scanf("%lld",&k);
	while(k--)
	{
		int n,d,e,p,q,x=0,y=0;
		scanf("%lld%lld%lld",&n,&d,&e);
		y=n;
		x=-(e*d-n-2);
		int ans1=calc(1,x,y),ans2=calc(0,x,y);
		if(ans1==-1||ans2==-1||ans1*ans2!=n||(ans1-1)*(ans2-1)+1!=e*d)
		{
			printf("NO\n");
		}
		else
		{
			if(ans1>ans2) swap(ans1,ans2);
			printf("%lld %lld\n",ans1,ans2);
		}
	}
	return 0;
}
