#include <bits/stdc++.h>
using namespace std;
struct point{
	int x,y;
}a[505];
int dp[205][205][105],mx,ans,n,k;
map<pair<int,int>,bool> ck;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&a[i].x,&a[i].y);
		dp[a[i].x][a[i].y][0]=1;
		ck[make_pair(a[i].x,a[i].y)]=1;
		mx=max(mx,max(a[i].x,a[i].y));
	}
	for(int i=1;i<=200;i++)
	{
		for(int j=1;j<=200;j++)
		{
			for(int q=0;q<=k;q++)
			{
				if(dp[i][j][q]!=0)
				{
					ans=max(ans,dp[i][j][q]);
					if(ck[make_pair(i,j+1)])
						dp[i][j+1][q]=max(dp[i][j+1][q],dp[i][j][q]+1);
					else if(q+1<=k)
						dp[i][j+1][q+1]=max(dp[i][j+1][q+1],dp[i][j][q]+1);
					if(ck[make_pair(i+1,j)])
						dp[i+1][j][q]=max(dp[i+1][j][q],dp[i][j][q]+1);
					else if(q+1<=k)
						dp[i+1][j][q+1]=max(dp[i+1][j][q+1],dp[i][j][q]+1);
				}
			}

		}
	}
	printf("%d",ans);
	return 0;
}
