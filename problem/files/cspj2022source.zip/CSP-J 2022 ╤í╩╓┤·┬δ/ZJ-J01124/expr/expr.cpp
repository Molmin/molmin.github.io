#include <bits/stdc++.h>
using namespace std;
int kh[1000005];
string s;
int last=-1,ans1=0,ans2=0;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.size()==3)
	{
		int ans=-1;
		for(int i=0;i<s.length();i++)
		{
			if(s[i]=='|') 
			{
				if(s[i-1]=='1') ans2++;
				ans=(s[i-1]-'0')|(s[i+1]-'0');
			}
			else if(s[i]=='&') 
			{
				if(s[i-1]=='0') ans1++;
				ans=(s[i-1]-'0')|(s[i+1]-'0');
			}
		}
		if(ans==-1)
		{
			for(int i=0;i<s.length();i++)
			{
				if(s[i]=='0'||s[i]=='1') 
					ans=s[i]-'0';
			}
		}
		printf("%d\n%d %d\n",ans,ans1,ans2);
	}
	else
	{
		memset(kh,-1,sizeof kh);
		stack<int> S;
		for(int i=0;i<s.length();i++)
		{
			if(s[i]=='(')
				S.push(i);
			else if(s[i]==')')
			{
				kh[i]=S.top();
				kh[S.top()]=i;
				S.pop();
			}
		}
		int type=0;
		for(int i=0;i<s.length();i++)
		{
			if(s[i]=='|') type=1;
			else if(s[i]=='&') type=0;
		}
		if(type)
		{
			int ans=0;
			int i;
			for(i=0;i<s.length();i++)
			{
				if(s[i]=='1') ans=1;
				if(s[i]=='1'&&s[i+1]=='|')
				{
					ans2++;
					break;
				}
			}
			i+=2;
			for(;i<s.length();i++)
			{
				if(s[i]=='(') i=kh[i];
				else if(s[i]=='|') ans2++;
			}
			cout<<ans<<'\n'<<0<<' '<<ans2;
		}
		else
		{
			int ans=1;
			int i;
			for(i=0;i<s.length();i++)
			{
				if(s[i]=='0') ans=0;
				if(s[i]=='0'&&s[i+1]=='&')
				{
					ans1++;
					break;
				}
			}
			i+=2;
			for(;i<s.length();i++)
			{
				if(s[i]=='(') i=kh[i];
				else if(s[i]=='&') ans1++;
			}
			cout<<ans<<'\n'<<ans1<<' '<<0;
		}
	}
	return 0;
}

