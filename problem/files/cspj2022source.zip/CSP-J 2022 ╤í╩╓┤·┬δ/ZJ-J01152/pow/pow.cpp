#include<bits/stdc++.h>
using namespace std;
long long a,b,ans=1;
long long x=1000000000;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1){
		cout<<1<<endl;
		return 0;
	}
	for(int i=1;i<=b;i++){
		ans*=a;
		if(ans>x){
			cout<<-1<<endl;
			return 0;
		}
	}
	cout<<ans;
	return 0;
}
