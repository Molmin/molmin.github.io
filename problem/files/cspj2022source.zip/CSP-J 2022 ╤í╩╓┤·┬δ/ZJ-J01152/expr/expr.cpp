#include<bits/stdc++.h>
using namespace std;
string s;
long long l,x,y,a[100001],b[100001],aa=0,bb=0;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	l=s.size();
	if(l==3){
		if(s=="(1)"){
		    cout<<"1"<<endl;
		    cout<<"0 0"<<endl;
		}
		if(s=="(0)"){
			cout<<"0"<<endl;
		    cout<<"0 0"<<endl;
		}
		if(s=="1&1"){
			cout<<"1"<<endl;
		    cout<<"1 0"<<endl;
		}
		if(s=="0&0"){
			cout<<"0"<<endl;
		    cout<<"1 0"<<endl;
		}
		if(s=="1&0"){
			cout<<"0"<<endl;
		    cout<<"1 0"<<endl;
		}
		if(s=="0&1"){
			cout<<"0"<<endl;
		    cout<<"1 0"<<endl;
		}
		if(s=="1|1"){
			cout<<"1"<<endl;
		    cout<<"0 1"<<endl;
		}
		if(s=="0|0"){
			cout<<"0"<<endl;
	    cout<<"0 1"<<endl;
		}
		if(s=="0|1"){
			cout<<"1"<<endl;
		    cout<<"0 1"<<endl;
		}
		if(s=="1|0"){
			cout<<"1"<<endl;
		    cout<<"0 1"<<endl;
		}
	}
	else{
		for(int i=0;i<=l;i++){
			if(s[i]=='&'){
				x++;
				aa++;
				a[aa]=1;
			}
			if(s[i]=='|'){
				y++;
				aa++;
				a[aa]=2;
			}
			if(s[i]>='0'&&s[i]<='9'){
				bb++;
				b[bb]=int(s[i]-'0');
			}
		}
		for(int i=1;i<=aa;i++){
			if(a[i]==1){
				if(b[i]==0||b[i+1]==0){
					b[i+1]=0;
				}
				else{
					b[i+1]=1;
				}
			}
			else{
				if(b[i]==0&&b[i+1]==0){
					b[i+1]=0;
				}
				else{
					b[i+1]=1;
				}
			}
		}
		cout<<b[bb]<<endl;
		cout<<x<<" "<<y<<endl;
	}
	return 0;
}
