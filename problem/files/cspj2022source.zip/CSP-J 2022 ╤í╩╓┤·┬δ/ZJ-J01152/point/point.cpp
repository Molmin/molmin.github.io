#include<bits/stdc++.h>
using namespace std;
int n,k,x[501],y[501],maxn=0,xxx=0,yyy=0;
//map <int,bool> p;
bool p[101][101]={0},b[101][101];
void dfs(int xx,int yy,int ans,int m)
{
	if(xx==0||yy==0){
		
		return;
	}
	if(b[xx][yy]==1){
		return;
	}
	if(p[xx][yy-1]==0){
		if(m>=1){
			dfs(xx,yy-1,ans+1,m-1);
			b[xx][yy]=1;
		}
		else{
			maxn=max(maxn,ans);
			return;
		}
	}
	else{
		dfs(xx,yy-1,ans+1,m);
		b[xx][yy]=1;
	}
	if(p[xx][yy+1]==0){
		if(m>=1){
			dfs(xx,yy+1,ans+1,m-1);
			b[xx][yy]=1;
		}
		else{
			maxn=max(maxn,ans);
			return;
		}
	}
	else{
		dfs(xx,yy+1,ans+1,m);
		b[xx][yy]=1;
	}
	if(p[xx-1][yy]==0){
		if(m>=1){
			dfs(xx-1,yy,ans+1,m-1);
			b[xx][yy]=1;
		}
		else{
			maxn=max(maxn,ans);
			return;
		}
	}
	else{
		dfs(xx-1,yy,ans+1,m);
		b[xx][yy]=1;
	}
	if(p[xx+1][yy]==0){
		if(m>=1){
			dfs(xx+1,yy,ans+1,m-1);
			b[xx][yy]=1;
		}
		else{
			maxn=max(maxn,ans);
			return;
		}
	}
	else{
		dfs(xx+1,yy,ans+1,m);
		b[xx][yy]=1;
	}
}
int main()
{
	ios::sync_with_stdio(false);
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
		p[x[i]][y[i]]=1;
	}
	for(int i=1;i<=n;i++){
		dfs(x[i],y[i],1,k);
		b[1][1]=1;
	}
	cout<<maxn;
}
/*
8 2
3 1
3 2
3 3
3 6
1 2
2 2
5 5
5 3
*/
