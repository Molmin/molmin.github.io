#include<bits/stdc++.h>
using namespace std;
long long k,n,d,e;
long long x,l,r,ans;
bool t=0;
int main()
{
	ios::sync_with_stdio(false);
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		map <int,bool> p;
		t=0;
		cin>>n>>d>>e;
		x=n-d*e+2;
		l=1;
		r=x;
		while(l<r){
			ans=(l+r)/2;
			if(ans*(x-ans)==n){
				cout<<min(ans,x-ans)<<" "<<max(ans,x-ans)<<endl;
				t=1;
				break;
			}
			if(ans*(x-ans)>n){
				if(p[ans*(x-ans)]==1){
					break;
				}
				p[ans*(x-ans)]=1;
				r=ans;
			}
			if(ans*(x-ans)<n){
				if(p[ans*(x-ans)]==1){
					break;
				}
				p[ans*(x-ans)]=1;
				l=ans;
			}
			
		}
		if(!t){
		    cout<<"NO"<<endl;	
		}		
	}
}
/*
10
770 77 5
633 1 211
545 1 499
683 3 227
858 3 257
723 37 13
572 26 11
867 17 17
829 3 263
528 4 109
*/
