#include <bits/stdc++.h>
using namespace std;
long long k;
long long n,e,d;
long long a,b;
long long m;
void f(long long t)
{
	for(long long i=1;i*i<=t;i++)
	{
		long long j=t/i;
		if((i*i+j*j)==(m-(2*n)))
		{
			a=i;
			b=j;
			return ;
		}
	}
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(long long i=1;i<=k;i++)
	{
		a=b=0;
		cin>>n>>d>>e;
		m=n-e*d+2;
		m*=m;
		f(n);
		if(a==0&&b==0)
		{
			cout<<"NO"<<endl;
		}	
		else
		{
			cout<<a<<" "<<b<<'\n';
		}
	}
	return 0;
}
