#include <bits/stdc++.h>
using namespace std;
string s;

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	cout<<0<<endl<<0<<" "<<0;
	return 0;
}
