#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream fin("point.in");
ofstream fout("point.out");
int n,k;
int x[505],y[505];
int mp[10000][10000];
struct node
{
	int x,y;
}po[505];
bool cmp(node a,node b)
{
	return a.x<b.x;
}
int find(int x,int y)
{
	for(int i=1;i<=n;i++)
	{
		if(po[i].x==x+1&&po[i].y==y)
		{
			return 1;
		}
		if(po[i].x==x&&po[i].y+1==y)
		{
			return 2;
		}
	}
	return 3;
}
int dfs(int x,int y,int k,int ans)
{		
	int a,b,c,d;
	int flag=find(x,y);
	if(flag==1)
	{
		a=dfs(x+1,y,k,++ans);
	}
	if(flag==2)
	{
		b=dfs(x,y+1,k,++ans);
	}	
	if(flag==3&&k>0)
	{
		c=dfs(x+1,y,--k,++ans);
		d=dfs(x,y+1,--k,++ans);
	}
	if(k==0)
	{	
	/*	a=max(a,b);
		c=max(c,d);
		ans=max(a,ans);*/
		return ans;
	}
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>po[i].x>>po[i].y;
	}
	sort(po+1,po+1+n,cmp);
	int ans[505];	
	for(int i=1;i<=n;i++)
	{
		ans[i]=dfs(po[i].x,po[i].y,k,1);
	}
	int ma=-0xfFFF;
	for(int i=1;i<=n;i++)
	{
		if(ans[i]>ma)
			ma=ans[i];
	}
	cout<<ma;
	return 0;
}
