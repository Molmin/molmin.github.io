#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a=0,b=0;
	cin>>a>>b;
	cout<<a<<" "<<b<<endl;
	if(a!=1&&b>1e9)
	{
		cout<<-1;
		return 0;
	}
	int sum=1;
	for(int i=1;i<=b;i++)
	{
		sum*=a;
		if(sum>1e9)
		{
			cout<<-1;
			return 0;
		}
	}
	if(sum>=1&&sum<=1e9)
		cout<<sum;
	return 0;
}
