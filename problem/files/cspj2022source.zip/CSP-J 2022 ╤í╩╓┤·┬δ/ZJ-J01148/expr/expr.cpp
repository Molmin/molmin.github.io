#include<bits/stdc++.h>
using namespace std;
long long l,n,m,s;
char a;
int main()
{
	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	l=s.size();
	if(l<=3)
	{
		if(s[0]>='0'&&s[0]<='9'&&s[2]>='0'&&s[0]<='9')
		{
			n=s[0]-'0';
			m=s[2]-'0';
			if(s[1]=='|')
			{
				cout<<(n|m);
			}
			else if(s[1]=='&')
			{
				cout<<(n&m);
			}
			cout<<endl<<0<<' '<<0;
			return 0;
		}
		else if(s[1]>='0'&&s[1]<='9')
		{
			cout<<(s[1]-'0')<<endl<<0<<' '<<0;
			return 0;
		}
	}
	else if(l<=5)
	{
		
	}
	
	return 0;
}
/*







*/
