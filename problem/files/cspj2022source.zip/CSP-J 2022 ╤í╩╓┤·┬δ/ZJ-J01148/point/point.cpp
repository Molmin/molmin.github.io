#include<bits/stdc++.h>
using namespace std;
long long n,k,sum,f;
long long sy[700][700],a[1000],b[1000];
struct pointjoy
{
	long long x;
	long long y;	
};


int endx,endy,stx,sty;

int dx[]={0,1};
int dy[]={1,0};
void dfs(long long x,long long y,long long sp,long long stx1,long long sty1)
{
	f=0;
	for(int i=0;i<2;i++)
	{
		int tx=x+dx[i];
		int ty=y+dy[i];
		if(sy[tx][ty]==1)
		{
			dfs(tx,ty,sp+1,stx1,sty1);
			f=1;
		}
	}
	if(f==0)
	{
		if(sp>sum)
		{
			sum=sp;
			stx=stx1;
			sty=sty1;
			endx=x;
			endy=y;
		}
		//sum=max(sum,sp);
		return ;
	}
}

/*
---------------
*/

void F1()
{
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]>>b[i];
		sy[a[i]][b[i]]=1;
	}
	for(int i=1;i<=n;i++)
	{
		dfs(a[i],b[i],1,a[i],b[i]);
	}
	
	cout<<sum;
}

void F2()
{
	for(int i=1;i<=n;i++)
	{
		cin>>a[i]>>b[i];
		sy[a[i]][b[i]]=1;
	}
	for(int i=1;i<=n;i++)
	{
		dfs(a[i],b[i],1,a[i],b[i]);
	}
	sum+=k;
	
	
	
	cout<<sum;	
}

/*



*/

int main()
{
	
	pointjoy joy[1009];
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	if(n<=10)
	{
		if(k==0)
		F1();
		else
		F2();
	}
	if(k==0)
	{
		F1();
	}
	
	return 0;
}



/*
for(int i=1;i<=n;i++)
	{
		cin>>joy[i].x>>joy[i].y;
		sy[]
	}
cout<<endl<<"		"<<stx<<" "<<sty<<" "<<endx<<" "<<endy<<" ";
-----------
9 0
1 1
1 2
1 3
2 1
2 2
2 3
3 1
3 2
3 3
----------
8 0
3 1
3 2
3 3
3 6
1 2
2 2
5 5
5 3
-----------








	1	2	3	4	5	6	7	8	9	
----------------------------------------
1	x	o	x	x

2	x	o	x	x

3	o	o	o	o

4	x	x	x	x

5

6



	1	2	3	4	5	6	7	8	9	
----------------------------------------
1	o	x	o	o	o	o

2	o	x	o	o	o	o

3	x	x	x	o	o	x

4	o	o	o	o	o	o	

5	o	o	x	o	x	o

6





*/














