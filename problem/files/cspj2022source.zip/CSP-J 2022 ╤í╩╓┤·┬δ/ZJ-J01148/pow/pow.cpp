#include<bits/stdc++.h>
using namespace std;
long long a,b,p;
int main()
{
	
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	p=1;
	for(int i=1;i<=b;i++)
	{
		p*=a;
		if(p>1000000000)
		{
			cout<<-1;
			return 0;
		}
	}
	cout<<p;
	
	return 0;
}
/*


1000000000



*/
