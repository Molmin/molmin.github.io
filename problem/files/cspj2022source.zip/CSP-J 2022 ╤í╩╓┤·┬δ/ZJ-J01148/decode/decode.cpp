#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d;
long long m,n1,ed,f;
long long p1[100005],q1[100005];
void F1()
{
	for(int i=1;i<=k;i++)
	{
		f=m=0;
		cin>>n>>e>>d;
		m=n-e*d+2;
		for(long long q=1;q<=m;q++)
		{
			if(n%q!=0)
			{
				continue;
			}
			if(f==1)
			break;
			for(long long p=1;p<=q;p++)
			{
				if(p+q>m)
				{
					break;
				}
				n1=q*p;
				ed=(p-1)*(q-1)+1;
				if(n1==n&&ed==e*d)
				{
					p1[i]=p;
					q1[i]=q;
					//cout<<p<<' '<<q<<endl;
					f=1;
					break;
				}
			}	
	    } 
		if(f==0)
		{
			p1[i]=-1;
			q1[i]=-1;
		}     
	}
	for(int i=1;i<=k;i++)
	{
		if(p1[i]!=-1&&q1[i]!=-1)
		{
			cout<<p1[i]<<" "<<q1[i]<<endl;	
		}	
		else
		cout<<"NO"<<endl;
	}
}



int main()
{
	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	F1();
	                    
	return 0;
}

/*

10
770 77 5
633 1 211
545 1 499
683 3 227
858 3 257
723 37 13
572 26 11
867 17 17
829 3 263
528 4 109















*/


    
