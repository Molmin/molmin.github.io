#include <bits/stdc++.h>
#include <stdio.h>
#include <cmath>
using namespace std;

int k;
long long n,e,d;





long long findp(long long paq,long long pmq){
    if((paq)%2==0){
        long long pow=paq*paq/4;
        long long t2=pow-pmq;
        if(t2<0)return -1;
        long long t=int(sqrt(t2));
        if(t*t!=t2){
            return -1;
        }
        return paq/2-t;
    }
    if((paq)%2==1){
        long long pow=(paq/2)*(paq/2+1);
        long long t2=pow-pmq;
        if(t2<0)return -1;
        long long t=int(sqrt(t2));
        if(t*t+t!=t2){
            return -1;
        }
        return (paq+1)/2-t-1;
    }
}



int main(){
    cin>>k;
    for(int i=0;i<k;i++){
        cin>>n>>e>>d;
        long long paq= n-e*d+2;
        long long pmq= n;
        long long p=findp(paq,pmq);
        if(p==-1){
            cout<<"NO"<<endl;
            continue;
        }
        long long q=paq-p;
        cout<<p<<' '<<q<<endl;
    }
}
