#include <bits/stdc++.h>

using namespace std;
long long n,k,b[2][500];

long long run(long long x,long long y,long long ki,long long ni){
    long long get=ni;
    for(int i=0;i<n;i++){
        if(b[1][i]>y and b[0][i]>x and b[1][i]-y+b[0][i]-x<=k+1){
            get=max(get,run(b[0][x],b[1][x],k-(b[1][i]-y+b[0][i]-x)+1,ni+1));
        }
    }
    return get;
}

int main(){
    cin>>n>>k;
    int get=0;
    for(int i=0;i<n;i++){
        cin>>b[0][i]>>b[1][i];
    }
    for(int i=0;i<n;i++){
        get=max(run(b[0][i],b[1][i],k,0),get);
    }
    cout<<get+k;
}
