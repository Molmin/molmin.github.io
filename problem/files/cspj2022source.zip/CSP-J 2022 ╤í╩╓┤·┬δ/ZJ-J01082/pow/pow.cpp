#include <bits/stdc++.h>

using namespace std;

long long n,m;
long long ans;

int main(){
    cin>>n>>m;
    ans=1;
    if(n==0){cout<<0;return 0;}
    if(n==1){cout<<1;return 0;}
    for(int i=0;i<m;i++){
        ans*=n;
        if(ans>1000000000){
            cout<<-1;
            return 0;
        }
    }
    cout<<ans;
    return 0;
}
