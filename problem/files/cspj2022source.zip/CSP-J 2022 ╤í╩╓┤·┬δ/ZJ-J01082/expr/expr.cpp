#include <stdio.h>
#include <bits/stdc++.h>
#include <cstring>
using namespace std;
int cutor,cutand;

char s[1000000];
struct point
{
    int value=NULL;
    point* left=NULL;
    point* right=NULL;
    int known=0;
    int op=NULL;
};
int build(int left,int right,point* father)
{
    int cl=0;
    int ctr=1;
    if (right-left==1 and s[left]=='0')
    {
        father->value=0;
        father->known=1;
        return 0;
    }
    if (right-left==1 and s[left]=='1')
    {
        father->value=1;
        father->known=1;
        return 1;
    }
    cl=0;
    for(int i=left; i<right-1; i++)
    {
        if(s[i]=='(')
        {
            cl-=1;
        }
        if(s[i]==')')
        {
            cl+=1;
        }
        if(cl==0)
        {
            ctr=0;
            break;

        }
    }
    if(ctr)
    {
        return build(left+1,right-1,father);
    }
    point* lson=new point;
    point* rson=new point;
    father->left=lson;
    father->right=rson;
    int done=0;
    cl=0;

    for(int i=right-1; i>left-1; i--)
    {
        if(s[i]=='(')
        {
            cl-=1;
        }
        if(s[i]==')')
        {
            cl+=1;
        }
        if(cl==0 and s[i]=='|')
        {
            father->op=1;
            build(left,i,lson);
            build(i+1,right,rson);
            return 1;
        }
    }
    cl=0;
    for(int i=right-1; i>left-1; i--)
    {
        if(s[i]==')')
        {
            cl+=1;
        }
        if(s[i]=='(')
        {
            cl-=1;
        }
        if(cl==0 and s[i]=='&')
        {
            father->op=0;
            build(left,i,lson);
            build(i+1,right,rson);
            return 0;
        }
    }
}

int run(point* now)
{
    if(now->known)return now->value;
    if(now->op==0)
    {
        if(!run(now->left))
        {
            cutand+=1;
            return 0;
        }
        if(!run(now->right))
        {
            return 0;
        }
        return 1;
    }
    if(now->op==1)
    {
        if(run(now->left))
        {
            cutor+=1;
            return 1;
        }
        if(run(now->right))
        {
            return 1;
        }
        return 0;
    }
}

int main()
{
    scanf("%s",&s);
    point* start=new point;
    int i=0;
    while(s[i]!=0)
    {
        i++;
    }
    build(0,i,start);
    int k=run(start);
    cout<<k<<endl<<cutand<<' '<<cutor<<endl;
}
