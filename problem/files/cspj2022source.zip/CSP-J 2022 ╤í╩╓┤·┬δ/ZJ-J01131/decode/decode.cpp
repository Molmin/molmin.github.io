#include<bits/stdc++.h>
using namespace std;
long long k,m,n,t,w,e,d,mid;
bool flag;
long long read()
{
	char ch=getchar();long long ans=0,t=1;
	while (ch<'0'||ch>'9'){if (ch=='-') t=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){ans=ans*10+ch-'0';ch=getchar();}
	return ans*t;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	for (int i=1;i<=k;i++)
	{
		n=read();e=read();d=read();
		m=n-e*d+2;
		t=1;w=m/2;flag=false;
		while (t<=w)
		{
			mid=(t+w)/2;
			if (mid*(m-mid)==n) 
			{
				printf("%lld %lld\n",mid,m-mid);
				flag=true;break;
			}
			else if (mid*(m-mid)>n) w=mid-1;
			else t=mid+1;
		}
		if (flag==false) printf("NO\n");
	}
	return 0;
}