#include<bits/stdc++.h>
using namespace std;
char s[1000010];
int land,lor,l;
int jisuan(int be,int ed)
{
	int t=1,w=0,i,nnp,ii,iii,sum1,sum2,iiii,sum,beg;
	bool flag;
	if (s[be]=='0') sum=0,nnp=be;
	else if (s[be]=='1') sum=1,nnp=be;
	else if (s[be]=='(') 
	{
		t=1,w=0,nnp=be;
		while (t>w)
		{
			nnp++;
			if (s[nnp]==')') w++;
			if (s[nnp]=='(') t++;
		}
		sum=jisuan(be+1,nnp-1);
	}
	for (i=nnp+1;i<=ed;i++)
	if (s[i]=='&')
		{
			i++;
			if (sum==0) 
			{
				
				if (s[i]=='(')
				{
					t=1,w=0;
					while (t>w)
					{
						i++;
						if (s[i]==')') w++;
						if (s[i]=='(') t++;
					}
				}
				land++;
			}
			else
			{
				if (s[i]=='(')
				{
					t=1,w=0;beg=i+1;
					while (t>w)
					{
						i++;
						if (s[i]==')') w++;
						if (s[i]=='(') t++;
					}
					sum=sum&jisuan(beg,i-1);
				} 	
				else{if (s[i]=='0') sum=0;else sum=1;}
			}
		}
		else if (s[i]=='|') 
		{
			ii=i;
			t=0;w=0;
			while (ii<l)
			{
				ii++;
				if (s[ii]=='(') t++;
				if (s[ii]==')') w++;
				if (t==w&&(s[ii]=='|'||s[ii]=='&')){if (s[ii]=='|')flag=true;else flag=false;break;	}	
			}
			if (flag==false&&ii>=l) flag=true;
			if (flag)
			{
				i++;
				if (sum==1) 
				{
					if (s[i]=='(')
					{
						t=1,w=0;
						while (t>w)
						{
							i++;
							if (s[i]==')') w++;
							if (s[i]=='(') t++;
						}
					}
					lor++;
				}
				else
				{
					if (s[i]=='(')
					{
						t=1,w=0;beg=i+1;
						while (t>w)
						{
							i++;
							if (s[i]==')') w++;
							if (s[i]=='(') t++;
						}
						sum1=jisuan(beg,i-1);
					}
					else {
						if (s[i]=='1') sum1=1;
						else sum1=0;
					}
					sum=sum|sum1;
				}
			}
			else
			{
				ii++;
				if (ii=='(')
				{
					t=1,w=0;beg=ii+1;
					while (t>w)
					{
						ii++;
						if (s[ii]==')') w++;
						if (s[ii]=='(') t++;
					}
					sum1=jisuan(beg,ii-1);iiii=ii;
				}
				else 
				{
					if (s[ii]=='0') sum1=0;else sum1=1;iiii=ii;
				}
				iii=i+1;
				if (iii=='(')
				{
					t=1,w=0;beg=iii+1;
					while (t>w)
					{
						iii++;
						if (s[iii]==')') w++;
						if (s[iii]=='(') t++;
					}
					sum2=jisuan(beg,iii-1);
				}
				else 
				{
					
					if (s[iii]=='0') sum2=0;else sum2=1;
				}
				if (sum==1) lor++;
				else if (sum2==0) land++;
				sum=sum|(sum1&sum2);i=iiii;
			}
		}
		return sum;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s);
	l=strlen(s);
	printf("%d\n",jisuan(0,l-1));
	printf("%d %d\n",land,lor);
	return 0;	
}

