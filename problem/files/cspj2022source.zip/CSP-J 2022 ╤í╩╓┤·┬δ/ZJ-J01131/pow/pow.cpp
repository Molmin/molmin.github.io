#include<bits/stdc++.h>
using namespace std;
long long a,b,sum;
long long read()
{
	char ch=getchar();long long ans=0,t=1;
	while (ch<'0'||ch>'9'){if (ch=='-') t=-1;ch=getchar();}
	while (ch>='0'&&ch<='9'){ans=ans*10+ch-'0';ch=getchar();}
	return ans*t;
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read();b=read();
	if (a==1) printf("1\n");
	else
	{
		sum=a;b=b-1;
		while (b>0)
		{
			sum=sum*a;
			b--;
			if (sum>1000000000)
			{
				printf("-1\n");
				return 0;
			}
		}
		printf("%lld\n",sum);
	}
	return 0;
}