#include<bits/stdc++.h>
using namespace std;
int l,i,ans1,ans2;char a[1000010];
void q(int x,int y){
	int i,j,f=1;
	for(i=y;i>=x;i--)
		if(a[i]==')') f=0;
		else if(((a[i]=='1'||a[i]=='0')&&f)||(a[i]=='('&&!f)){
			for(j=l;j>=i;j--) a[j+1]=a[j];
			a[i]='(';l++;
	for(i=1;i<=l;i++) cout<<a[i];cout<<"\n";return ;
		}
}
void h(int x,int y){
	int i,j,f=1;
	for(i=x;i<=y;i++)
		if(a[i]=='(') f=0;
		else if(((a[i]=='1'||a[i]=='0')&&f)||(a[i]==')'&&!f)){
			for(j=l;j>i;j--) a[j+1]=a[j];
			a[i+1]=')';l++;
	for(i=1;i<=l;i++) cout<<a[i];cout<<"\n";return ;
		}
}
int dg(int x,int y){
	int i;
	if(x+2==y&&a[x]=='('&&a[y]==')') return a[x+1]-48;
	if(x+2==y&&a[x+1]=='&'){
		if(a[x]=='0') ans1++;
		return (a[x]-48)&&(a[y]-48);
	}
	if(x+2==y&&a[x+1]=='|'){
		if(a[x]=='1') ans2++;
		return (a[x]-48)||(a[y]-48);
	}
	for(i=x;i<=y;i++)
		if((a[i]=='|'||a[i]=='&')&&a[i-1]==')'&&a[i+1]=='('){
			x=dg(x+1,y-2);y=dg(x+2,y-1);
			if(a[i]=='&'){
				if(!x) ans1++;
				return x||y;
			}
			else{
				if(x) ans2++;
				return x&&y;
			}
		}
	return 0;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a+1;l=strlen(a+1);
	if(l==3){
		if(a[2]=='&')
			if(a[1]=='0') cout<<"0\n1 0";
			else cout<<((a[1]-48)&&(a[3]-48))<<"\n0 0";
		else
			if(a[1]=='1') cout<<"1\n0 1";
			else cout<<((a[1]-48)||(a[3]-48))<<"\n0 0";
	}
	else if(l==5){
		int f;
		if(a[2]=='|')
			if(a[1]=='1') ans2++,f=1;
			else f=a[1]||a[3];
		else
			if(a[1]=='0') ans1++,f=0;
			else f=a[1]&&a[3];
		if(a[4]=='|')
			if(f==1) cout<<"1\n"<<ans1+1<<' '<<ans2;
			else cout<<a[5]-48<<"\n"<<ans1<<" "<<ans2;
		else
			if(f==0) cout<<"0\n"<<ans1<<' '<<ans2+1;
			else cout<<a[5]-48<<"\n"<<ans1<<" "<<ans2;
	} 
	else{
		for(i=1;i<=l;i++)
			if(a[i]=='&'&&(a[i-2]!='('||a[i+2]!=')'))
				q(1,i-1),h(i+1,l),i++;
		for(i=1;i<=l;i++)
			if(a[i]=='|'&&(a[i-2]!='('||a[i+2]!=')'))
				q(1,i-1),h(i+1,l),i++;
		for(i=1;i<=l;i++) cout<<a[i];cout<<"\n";
		cout<<dg(1,l)<<'\n'<<ans1<<' '<<ans2;
	}
	return 0;
}
