#include<bits/stdc++.h>
using namespace std;
long long n,m;
long long q(long long n,long long m){
	if(m==1) return n;
	long long ans;
	if(m%2==0) ans=q(n,m/2)*q(n,m/2);
	else ans=q(n,m/2)*q(n,m/2+1);
	if(ans>1e9){cout<<-1;exit(0);}
	return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>n>>m;cout<<q(n,m);
	return 0;
}
