#include<bits/stdc++.h>
using namespace std;
int n,k,i,j,x,y,ma,f[1010][1010],e[1010][1010];
void dfs(int x,int y,int s,int sum){
	e[x][y]=1;ma=max(ma,sum);
	if(x>1&&!e[x-1][y]&&f[x-1][y]) dfs(x-1,y,s,sum+1);
	if(y>1&&!e[x][y-1]&&f[x][y-1]) dfs(x,y-1,s,sum+1);
	if(x<1000&&!e[x+1][y]&&f[x+1][y]) dfs(x+1,y,s,sum+1);
	if(y<1000&&!e[x][y+1]&&f[x][y+1]) dfs(x,y+1,s,sum+1);
	if(x>1&&!e[x-1][y]&&!f[x-1][y]&&s) dfs(x-1,y,s-1,sum+1);
	if(y>1&&!e[x][y-1]&&!f[x][y-1]&&s) dfs(x,y-1,s-1,sum+1);
	if(x<1000&&!e[x+1][y]&&!f[x+1][y]&&s) dfs(x+1,y,s-1,sum+1);
	if(y<1000&&!e[x][y+1]&&!f[x][y+1]&&s) dfs(x,y+1,s-1,sum+1);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(i=1;i<=n;i++){
		scanf("%d%d",&x,&y);
		if(x<=1000&&y<=1000) f[x][y]=1;
	}
	for(i=1;i<=1000;i++)
		for(j=1;j<=1000;j++)
			if(!e[i][j]&&f[i][j]) dfs(i,j,k,1);
	cout<<ma;
	return 0;
}
