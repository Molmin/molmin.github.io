#include<bits/stdc++.h>
using namespace std;
int T;bool f;
long long n,d,e,m,k,i,x,y;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>T;
	while(T--){
		scanf("%lld%lld%lld",&n,&d,&e);m=d*e;k=n-m+2;
		x=sqrt(n);y=k/2;f=1;
		if(x<=y){
			for(i=1;i<=x;i++)
				if(n%i==0)
					if(i+(n/i)==k){
						f=0;printf("%lld %lld\n",i,n/i);break;
					}
		}
		else{
			for(i=1;i<=y;i++)
				if(i*(k-i)==n){
					f=0;printf("%lld %lld\n",i,n/i);break;
				}
		}
		if(f) printf("NO\n");
	}
	return 0;
}
