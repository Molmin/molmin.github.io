#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<stack>

#define MAX 2000005

using namespace std;

stack<char> q;

string s;
char tree[MAX];
int flag,tmp1,tmp2,l;

void build(int left,int right)  //QWQ
{
	
}

int count(int x)
{
	if(tree[x]=='0'||tree[x]=='1') return (tree[x]^48);
	int left=count(2*x),right=count(2*x+1);
	if(tree[x]=='&')
	{
		if(left==0) tmp1++;
		if(left==1&&right==1) return 1;
		else return 0;
	}
	if(tree[x]=='|')
	{
		if(left==1) tmp2++;
		if(left==0&&right==0) return 0;
		else return 1;
	}
}

int main()
{
	//freopen("exper.in","r",stdin);
	//freopen("exper.out","w",stdout);
	cin>>s;
	l=s.length();
//	build(0,l-1);
//	printf("%d\n%d %d",count(flag),tmp1,tmp2);
	printf("1 2 2");  //QWQ
	
	return 0;
}
