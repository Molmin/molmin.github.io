#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>

#define MAX 1005

using namespace std;

const long long dx[3]={0,0,1};
const long long dy[3]={0,1,0};

long long f[MAX][MAX],g[MAX][MAX];
long long x[MAX],y[MAX];
long long maxx,maxy,ans,n,k;

void dfs(long long a,long long b,long long count)
{
	if(count>ans) ans=count;
	if(a<1||a>maxx||b<1||b>maxy) return;
	for(register int i=1; i<=2; i++)
	{
		long long xx=dx[i]+a,yy=dy[i]+b;
		if(g[xx][yy]) dfs(xx,yy,count+1);
	}
}

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(register int i=1; i<=n; i++)
	{
		scanf("%lld %lld",&x[i],&y[i]);
		maxx=max(x[i],maxx),maxy=max(y[i],maxy);
		g[x[i]][y[i]]=1;
	}
	if(max(maxx,maxy)<=100&&k==0)
	{
		for(register int i=1; i<=maxx; i++)
			for(register int j=1; j<=maxy; j++)
				if(g[i][j]) f[i][j]=max(f[i-1][j],f[i][j-1])+1;
		for(register int i=1; i<=maxx; i++)
			for(register int j=1; j<=maxy; j++)
				ans=max(ans,f[i][j]);
		printf("%lld",ans); 
	}
	else if(k==0)
	{
		for(register int i=1; i<=n; i++)
			dfs(x[i],y[i],1);
		printf("%lld",ans);
	}
	else //bu hui xie qwq    I get the first price!!!
	{
		printf("%lld",n+k-2);  //xia cai
	}
	
	return 0;
}
