#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>

using namespace std;

long double n,d,e;
long long k;

inline long long read()
{
	register long long x=0,f=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		f|=ch=='-';
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return f?-x:x;
}

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	while(k--)
	{
		cin>>n>>d>>e;
		long double c=n-e*d+2;
		long double deta=c*c-4*n;
		if(deta<0||c<=0) printf("NO\n");
		else
		{
			deta=sqrt(deta);
			long double p=(c-deta)/2,q=(c+deta)/2;
			if(p<1||q<1)
			{
				printf("NO\n");
				continue;
			}
			if(int(p)!=p||int(q)!=q) 
			{
				printf("NO\n");
				continue;
			}
			cout<<int(p)<<" "<<int(q)<<endl;
		}
	}
	
	return 0;
}
