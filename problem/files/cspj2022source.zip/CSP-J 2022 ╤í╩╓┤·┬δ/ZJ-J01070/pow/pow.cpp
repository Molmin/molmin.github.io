#include<iostream>
#include<cstring>
#include<cstdio>

using namespace std;

const long long INF=1000000000;
long long a,b;

long long qpow()
{
	long long res=1;
	while(b)
	{
		if(b&1)
		{
			res*=a;
			if(res>INF) return -1;
		}
		a*=a,b>>=1;
	}
	return res;
}

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if(a==1)
	{
		printf("1");
		return 0;
	}
	printf("%lld",qpow());
	
	return 0;
}
