#include <bits/stdc++.h>
#define MAXN 1000010
using namespace std;

struct node{
	char c;
	int left,right;
};

node tree[MAXN];
int nidx = 1;
int findNext(string s,int sidx);
void bulidTree(string s,int idx);
int gans(int idx);
int andcot,orcot;

int main(){
	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	
	ios::sync_with_stdio(false);
	string s;
	cin >> s;
	
	bulidTree(s,1);
	
	
	//for(int i = 1;i <= s.size();i++){
	//	cout << tree[i].c;
	//}
	
	
	//cout << endl;
	cout << gans(1) << endl << andcot << " " << orcot;
	
	return 0;
}

int findNext(string s,int sidx){
	int tmp = 0;
	for(int i = sidx + 1;i <= s.size();i++){
		if(s[i] == '(') tmp++;
		else if(s[i] == ')'){
			if(tmp) tmp--;
			else return i;
		}
	}
	return -1;
}

void bulidTree(string s,int idx){
	if(s.size() == 1){
		//cout << idx;
		tree[idx].c = s[0];
		return;
	}
	int sizee = s.size();
	if(s[0] == '(' && findNext(s,0) == sizee - 1){
		for(int i = 0;i < sizee - 2;i++){
			s[i] = s[i + 1];
		}
		sizee -= 2;
	}
	int tmp = 0,endidx = -1;
	bool isand = true;
	for(int i = 0;i <= sizee;i++){
		if(s[i] == '(') tmp++;
		else if(s[i] == ')') tmp--;
		else if(s[i] == '&' && tmp == 0 && isand)
			endidx = i;
		else if(s[i] == '|' && tmp == 0){
			endidx = i;isand = false;
		}
	}
	if(endidx == -1) return;
	tree[idx].c = s[endidx];
	string ls = "",rs = "";
	for(int j = 0;j < endidx;j++)
		ls += s[j];
	for(int j = endidx + 1;j < sizee;j++)
		rs += s[j];
	tree[idx].left = nidx + 1;
	bulidTree(ls,++nidx);
	tree[idx].right = nidx + 1;
	//cout << endidx << " " << ls << " " << rs << " " << idx << " " << s[endidx] << endl;
	bulidTree(rs,++nidx);
}

int gans(int idx){
	//cout << idx << " " << tree[idx].c << " " << tree[idx].left << " " << tree[idx].right << endl;
	if(tree[idx].c == '&'){
		int first = gans(tree[idx].left);
		if(first == 0){
			andcot++;
			return 0;
		}
		else return (first & gans(tree[idx].right));
	}else if(tree[idx].c == '|'){
		int first = gans(tree[idx].left);
		if(first == 1){
			orcot++;
			return 1;
		}
		else return (first | gans(tree[idx].right));
	}else return tree[idx].c - '0';
}