#include <bits/stdc++.h>
using namespace std;

int main(){
	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	int k;
	cin >> k;
	
	for(int i = 0;i < k;i++){
		long long n,d,e;
		scanf("%lld%lld%lld",&n,&d,&e);
		//cout << n << " " << d << " " << e << endl;
		long long ans = n - e * d + 2;
		long long j;
		for(j = 1;j <= sqrt(n);j++){
			if(n % j == 0){
				if(j + (n / j) == ans){
					cout << j << " " << ans - j << endl;
					break;
	
				}
			}
		}
		if(j > sqrt(n)) cout << "NO" << endl;
	}
	
	return 0;
}