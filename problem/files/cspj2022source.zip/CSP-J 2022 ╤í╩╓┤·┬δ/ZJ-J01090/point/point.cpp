#include<bits/stdc++.h>
using namespace std;
int ans,f[10000][10000],k,n;
void dfs(int x,int y,int t){
	ans=max(ans,t);
	if(f[x+1][y]==1){
		dfs(x+1,y,t+1);
	}
	if(f[x+1][y]==0&&k>0){
		k--;
		dfs(x+1,y,t+1);
		k++;
	}
	if(f[x][y+1]==1){
		dfs(x,y+1,t+1);
	}
	if(f[x][y+1]==0&&k>0){
		k--;
		dfs(x,y+1,t+1);
		k++;
	}
}
int main(){
    int i,a[501],b[501];
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(i=1;i<=n;i++){
		cin>>a[i]>>b[i];
		f[a[i]][b[i]]=1;
	}
	for(i=1;i<=n;i++){
		dfs(a[i],b[i],1);
	}
	cout<<ans;
	return 0;
}
