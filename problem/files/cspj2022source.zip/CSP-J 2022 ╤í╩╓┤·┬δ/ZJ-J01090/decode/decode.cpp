#include<bits/stdc++.h>
using namespace std;
long long n,m;
int j,i,k,d,e,f;
int main(){
	freopen("decode.in","r",stdin);  
	freopen("decode.out","w",stdout);
	cin>>k;
	for(i=1;i<=k;i++){
		cin>>n>>d>>e;
		m=n-e*d+2;
		f=0;
		for(j=1;j*j<=n&&j*2<=m;j++){
			if(j*(m-j)==n) {
				cout<<j<<" "<<m-j<<endl;
		    	f=1;
		    	break;
			}
		}
		if(f==0) cout<<"NO";
	}
	return 0;
}
