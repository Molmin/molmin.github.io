#include<bits/stdc++.h>
using namespace std;
long long ans;
int a,b,i,m=1000000000;
int main(){
//	freopen("pow.in","r",stdin);
//	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1){
		cout<<1;
		return 0;
	}
	if((b>32&&a>=2)){
		cout<<"-1";
		return 0;
	}
	ans=1;
	for(i=1;i<=b;i++){
		ans=ans*a;
		if(ans>m){
			cout<<"-1";
			return 0;
		} 
	}
	cout<<ans;
}
