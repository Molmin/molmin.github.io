#include<bits/stdc++.h>
using namespace std;
string s;
int n,i,ans1,ans2,k;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	n=s.size();
	while(n!=1){
		i=0;
		while(s[i]!='&'&&i<n){
			i++;
		}
		if(i==n){
			break;
		}
		if(s[i-1]=='0'){
			ans1++;
		}
		else{
			if(s[i+1]=='0'){
				s[i-1]='0';
			}
		}
		for(  ;i+2<n;i++){
			s[i]=s[i+2];
		}
		n=n-2;
	}
	while(n!=1){
		i=0;
		while(s[i]!='|'&&i<n){
			i++;
		}
		if(i==n){
			break;
		}
		if(s[i-1]=='1'){
			ans2++;
		}
		else{
			if(s[i+1]=='1'){
				s[i-1]='1';
			}
		}
		for(  ;i+2<n;i++){
			s[i]=s[i+2];
		}
		n=n-2;
	}
	cout<<s[0]<<endl;
	cout<<ans1<<" "<<ans2;
	return 0;
}
