#include <cstdio>
#include <cmath>
using namespace std;
typedef long long ll;
void init(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
}
ll ni,ei,di,qi,pi;
ll mi,delta;
int main(){
	init();
	
	int k;
	scanf("%d",&k);
	bool boolen;
	while (k){
		k--;
		scanf("%lld%lld%lld",&ni,&ei,&di);
		mi=ni-ei*di+2;
		delta=mi*mi-4*ni;
		if (delta<0){
			printf("NO\n");
			continue;
		}
		pi=(mi-sqrt(delta))/2;
		qi=mi-pi;
		if (pi*qi==ni){
			printf("%lld %lld\n",pi,qi);
		}else{
			printf("NO\n");
		}
	}
	return 0;
}