#include <cstdio>
using namespace std;
typedef long long ll;
ll a,b;
void init(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
}
int main(){
	init();
	
	scanf("%lld%lld",&a,&b);
	ll x=1;
	if (a==1){
		printf("1\n");
	}else{
		for (ll i=0; i<b; i++){
			x*=a;
			if (x>2147483647){
				x=-1;
				break;
			}
		}
		printf("%lld\n",x);
	}
	return 0;
}