#include <cstdio>
using namespace std;
int n,k;
int cx[505],cy[505],cb[505];
const int px[4]={0,1,0,-1},py[4]={1,0,-1,0};
void init(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
}
int abs(const int a){
	if (a>=0){
		return a;
	}else{
		return -a;
	}
}
int max(const int a,const int b){
	return a>b?a:b;
}

int dfs(int nx,int ny,int len,int ap){
	int ans=len;
	for (int i=1; i<=n; i++){
		if (!cb[i]&&((abs(cx[i]-nx)==1&&cy[i]==ny)||(abs(cy[i]-ny)==1&&cx[i]==nx))){
			cb[i]=1;
			ans=max(ans,dfs(cx[i],cy[i],len+1,ap));
			cb[i]=0;
		}
	}
	for (int i=1; i<=n&&ap>0; i++){
		int tx=nx+px[i];
		int ty=nx+py[i];
		ans=max(ans,dfs(tx,ty,len+1,ap-1));
	}
	return ans;
}
int main(){
	init();
	
	scanf("%d%d",&n,&k);
	for (int i=1; i<=n; i++){
		scanf("%d%d",cx+i,cy+i);
		cb[i]=0;
	}
	int ans=0;
	for (int i=1; i<=n; i++){
		ans=max(ans,dfs(cx[i],cy[i],0,k));
	}
	printf("%d\n",ans);
}