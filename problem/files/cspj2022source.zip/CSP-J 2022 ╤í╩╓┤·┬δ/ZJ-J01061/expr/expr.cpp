#include <cstdio>
#include <stack>
#include <cstring>
using namespace std;
void init(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
}
char str[1000005];
stack<int> sn;
stack<char> se;
int cnt_and,cnt_or;
int main(){
	init();
	
	scanf("%s",str+1);
	str[0]='(';
	int size=strlen(str);
	str[size]=')';
	size++;
	for (int i=0; i<size; i++){
		if (str[i]=='0'||str[i]=='1'){
			sn.push(str[i]-'0');
		}else{
			switch(str[i]){
				case '&':{
					if (sn.top()==0){
						cnt_and++;
						i++;
						if (str[i]=='('){
							int cnt_left=1;
							i++;
							while (cnt_left!=0){
								if (str[i]=='('){
									cnt_left++;
								}else if (str[i]==')'){
									cnt_left--;
								}
								i++;
							}
							i--;
						}
					}else{
						se.push(str[i]);	
					}
					break;
				}
				case '|':{
					while (se.top()=='&'){
						int a,b;
						a=sn.top();
						sn.pop();
						b=sn.top();
						sn.pop();
						sn.push(a&b);
						se.pop();
					}
					if (sn.top()==1){
						cnt_or++;
						i++;
						if (str[i]=='('){
							int cnt_left=1;
							i++;
							while (cnt_left!=0){
								if (str[i]=='('){
									cnt_left++;
								}else if (str[i]==')'){
									cnt_left--;
								}
								i++;
							}
							i--;
						}
						while (str[i+1]=='&'){
							i+=2;
							if (str[i]=='('){
								int cnt_left=1;
								i++;
								while (cnt_left!=0){
									if (str[i]=='('){
										cnt_left++;
									}else if (str[i]==')'){
										cnt_left--;
									}
									i++;
								}
								i--;
							}
						}
					}else{
						se.push(str[i]);
					}
					break;
				}
				case '(':{
					se.push(str[i]);
					break;
				}
				case ')':{
					while (se.top()!='('){
						int a,b;
						a=sn.top();
						sn.pop();
						b=sn.top();
						sn.pop();
						if (se.top()=='&'){
							sn.push(a&b);
						}else{
							sn.push(a|b);
						}
						
						se.pop();
					}
					se.pop();
					break;
				}
			}
		}
	}
	printf("%d\n%d %d\n",sn.top(),cnt_and,cnt_or);
	return 0;          
}