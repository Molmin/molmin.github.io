#include <iostream>
#include <cmath>
using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin >> a >> b;
	if(pow(a,b) <= 1e9)
	{
		long long res = pow(a,b);
		cout << res;
	}
	else	cout << -1;
	return 0;
}