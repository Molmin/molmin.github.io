#include <iostream>
using namespace std;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	while(k--)
	{
		int n,d,e;
		bool flag = false;
		cin >> n >> d >> e;
		int s = n - e*d + 2;
		for(int p = 1;p <= n;p++)
		{
			int q = s - p;
			if(p * q == n)
			{
				cout << p << " " << q << endl;
				flag = true;
				break;
			}
		}
		if(flag == false)
			cout << "NO";
	}
	return 0;
}