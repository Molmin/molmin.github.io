#include <iostream>
#include <string.h>
#include <stack>
using namespace std;

string ex;
int cnt1,cnt2,ans;

void fill(int loc,char num)
{
	int t = loc-1;
	char tc = ex[t];
	for(;ex[t] == tc;t--)	ex[t] = num;
	t = loc+1;
	tc = ex[t];
	for(;ex[t] == tc;t++)	ex[t] = num;
}

void calc(int l,int r)
{
	for(int i = l;i <= r;i++)
	{
		if(ex[i] == '&')
		{
			int op1 = ex[i-1] - '0';
			int op2 = ex[i+1] - '0';
			if(op1 == 0)	cnt1++;
			ex[i] = (op1 & op2) + '0';
			fill(i,ex[i]);
		}
	}
	for(int i = l;i <= r;i++)
	{
		if(ex[i] == '|')
		{
			int op1 = ex[i-1] - '0';
			int op2 = ex[i+1] - '0';
			if(op1 == 1)	cnt2++;
			ex[i] = (op1 | op2) + '0';
			fill(i,ex[i]);
		}
	}
}


int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin >> ex;
	int n = ex.length();
	int kl = 0,kr = 0;
	for(;kl < n;kl++)
	{
		if(ex[kl] == '(')
		{
			bool flag = 0;
			for(kr = kl+1;kr < n;kr++)
			{
				if(ex[kr] == ')' && flag == 0)
				{
					calc(kl+1,kr-1);
					ex[kl] = ex[kl+1];
					ex[kr] = ex[kr-1];
					flag = 1;
				}
			}
		}
	}
	calc(0,n-1);
	cout << ex[0] << endl << cnt1 << " " << cnt2;
	//cout << 1 << endl << 1 << " " << 2;
}