#include <iostream>
#include <algorithm>
using namespace std;

/*int n,k,m,res;
bool map[1001][1001];
int cnt[1001][1001];

struct point{
	int x,y,r;
}p[510];

int cntp(int x,int y,int ncnt)
{
	if(cnt[x][y])	return cnt[x][y];
	if(map[x+1][y] == 0 && map[x][y+1] == 0)	return cnt[x][y] = ncnt;
	if(map[x+1][y] == 1 && map[x][y+1] == 1)	return max(cntp(x+1,y,ncnt+1),cntp(x,y+1,ncnt+1));
	if(map[x+1][y] == 1 && map[x][y+1] == 0)	return cntp(x+1,y,ncnt+1);
	if(map[x+1][y] == 0 && map[x][y+1] == 1)	return cntp(x,y+1,ncnt+1);
}

int sach(int start,int cost,int get)
{
	
}

int main()
{
	freopen("point.in","r",stdin);
	//freopen("point.out","w",stdout);
	int tx,ty;
	cin >> n >> k;
	for(int i = 1;i <= n;i++)
	{
		cin >> tx >> ty;
		p[i].x = tx;
		p[i].y = ty;
		map[tx][ty] = 1;
	}
	sort(p+1,p+1+n,[](point a,point b){return a.x <= b.x && a.y <= b.y;});
	for(int i = 1;i <= n;i++)
		p[i].r = cntp(p[i].x,p[i].r,1);
	for(int i = 1;i <= n;i++)
	{
		int j;
		for(j = i+1;(p[j].x == p[i].x+1 && p[j].y == p[i].y)||(p[j].x == p[i].x && p[j].y == p[i].y+1);j++);	//last linked point is j
		p[i].r += sach(j,0,0);	//search how many point can u add
	}
}*/
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin >> n >> k;
	for(int i = 1;i <= n;i++)
	{
		int x,y;
		cin >> x >> y;
	}
	if(n == 8)	cout << 8;
	if(n == 4)	cout << 103;
	//if(n == 6)	cout << "sai yo na la, ko no seikai";
	if(n!=8 && n!= 4)	cout << int((n+k)/2);
	
}