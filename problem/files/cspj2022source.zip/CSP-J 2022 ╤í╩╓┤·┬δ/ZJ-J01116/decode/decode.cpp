#include<bits/stdc++.h>
using namespace std;
int T;
long long find(long long H,long long J){
    long long MP = H / 2;
    long long L = 1,R = MP,mid;
    while(L <= R){
        mid = (L+R) >> 1;
        long double link = J*1.0/mid-1e-6;
        if(link< H-mid){
            R = mid-1;
        }else{
            L = mid+1;
        }
    }
    return L;
}
int main(){
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> T;
    while(T--){
        long long N,D,E;
        cin >>N >> D >> E;
        long long HPQ = N-(E*D)+2;
        long long P = find(HPQ,N);
        long long Q = HPQ - P;
        if(P*Q == N)cout << P <<" "<< Q<<"\n";
        else cout <<"NO\n";
    }
    return 0;
}
