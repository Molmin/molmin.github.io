#include<bits/stdc++.h>
using namespace std;
char str[1000010];
struct wz{
    int f = -1,ls = -1,rs = -1,ans = -1;
}w[1000010];
int find(int x){
    if(w[x].f == -1)return x;
    else return find(w[x].f);
}
int ans,A,B;
int main(){
    freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >> str;
    if(strlen(str) == 3){
        if(str[1] == '|'){
            if(str[0] == '1'){
                cout << 1 <<"\n"<<0 <<" "<< 1;
            }else{
                if(str[2] == '1'){
                    cout << 1 <<"\n"<<0 <<" "<< 0;
                }else{
                    cout << 0 <<"\n"<<0 <<" "<< 0;
                }
            }
        }else if(str[1] == '&'){
            if(str[0] == '0'){
                cout << 0 <<"\n"<<1 <<" "<< 0;
            }else{
                if(str[2] == '1'){
                    cout << 1 <<"\n"<<0 <<" "<< 0;
                }else{
                    cout << 0 <<"\n"<<0 <<" "<< 0;
                }
            }
        }
    }else{
        for(int i = 0;i < strlen(str);++i){
            if(str[i] == '0')w[i].ans = 0;
            if(str[i] == '1')w[i].ans = 1;
            if(str[i] == '&'){
                int f = find(i-1);
                int ansl = w[f].ans;
                w[f].f = i;
                w[i].ls = f;
                int ansr = w[i+1].ans;
                w[i+1].f = i;
                w[i].rs = i+1;
                if(ansl == 0){
                    ++A;
                    w[i].ans = 0;
                }else{
                    w[i].ans = ansl&ansr;
                }
            }
        }
        for(int i = 0;i < strlen(str);++i){
            if(str[i] == '|'){
                int f = find(i-1);
                int ansl = w[f].ans;
                w[f].f = i;
                w[i].ls = f;
                int f2 = find(i+1);
                int ansr = w[f2].ans;
                w[f2].f = i;
                w[i].rs = f2;
                if(ansl == 1){
                    ++B;
                    w[i].ans = 1;
                }else{
                    w[i].ans = ansl|ansr;
                }
            }
        }
        int ansn = 0;
        for(int i = 0;i < strlen(str);++i){
            if(w[i].f == -1){
                ansn = w[i].ans;
            }
        }
        cout << ansn <<"\n"<<A <<" "<<B<<"\n";
    }
    return 0;
}
