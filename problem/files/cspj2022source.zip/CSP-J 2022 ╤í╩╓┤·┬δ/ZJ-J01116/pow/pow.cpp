#include<bits/stdc++.h>
using namespace std;
long long A,B,C;
int main(){
    freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
    ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
    cin >>A >> B;
    if(A == 1){
        cout << 1;
        return 0;
    }
    C = A;
    for(int i = 2;i <= B;++i){
        C *= A;
        if(C > 1e9){
            cout << -1;
            return 0;
        }
    }
    cout << C;
    return 0;
}
