#include<bits/stdc++.h>
#define ll long long
#define N 1000000000
using namespace std;
ll mod_pow(ll x,ll n){
	ll res=1;
	while(n>0){
		if(n&1) res=res*x;
		if(res>N||x>N) return -1;
		x=x*x;
		n>>=1;
	}
	return res;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	cout<<mod_pow(a,b);
	return 0;
}