#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	long long n,e,d,m;
	while(k--){
		cin>>n>>e>>d;
		m=n-e*d+2;
		long long l=1,r=m/2;
		while(l<r){
			long long mid=(l+r+1)>>1;
			if(mid*(m-mid)<=n) l=mid;
			else r=mid-1;
		}
		if(l*(m-l)!=n) cout<<"NO"<<endl;
		else cout<<l<<" "<<m-l<<endl;
	}
	return 0;
}