#include<bits/stdc++.h>
using namespace std;
int s1,s2;
int js(string a,int x){
	int l=a.length();
	for(int i=0;i<l;i++){
		if(a[i]=='('){
			string a1=a;
			int j=-1,q=i;
			while(a[i]!=')'){
				i++;j++;
				a1[j]=a[i];
			}
			a1[j]='\0';
			a[q]=js(a1,x+1)+'0';
			a.erase(q+1,i-q);
			cout<<a<<endl;
			l=a.length();
			i=q;
		}
	}
	for(int i=0;i<l;i++){
		if(a[i]=='&'){
			a[i-1]=((a[i-1]-'0')&(a[i+1]-'0'))+'0';
			a.erase(i,2);
			l=a.length();
			if(x==1&&a[i-1]=='0') s1++;
		}
	}
	for(int i=0;i<l;i++){
		if(a[i]=='|'){
			a[i-1]=((a[i-1]-'0')|(a[i+1]-'0'))+'0';
			a.erase(i,2);
			l=a.length();
			if(x==1&&a[i-1]=='1') s2++;
		}
	}
	return int(a[0]-'0');
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	cout<<(int)js(s,1)<<endl;
	cout<<s1<<" "<<s2;
	return 0;
}