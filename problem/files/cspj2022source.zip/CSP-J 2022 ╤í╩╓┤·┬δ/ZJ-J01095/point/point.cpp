#include<bits/stdc++.h>
using namespace std;
int n,m,a[130][130][130],x,y,Max;
int main(){
freopen("point.in","r",stdin);freopen("point.out","w",stdout);
cin>>n>>m;for(int i=1;i<=n;i++){cin>>x>>y;a[x][y][0]=1;}
for(int i=1;i<=129;i++)for(int j=1;j<=129;j++)
for(int k=0;k<=m;k++){
if(k==0)a[i][j][0]=a[i][j][0]?max(a[i-1][j][0],a[i][j-1][0])+1:0;
else if(a[i][j][0])a[i][j][k]=max(a[i-1][j][k],a[i][j-1][k])+1;
else a[i][j][k]=max(a[i-1][j][k-1],a[i][j-1][k-1])+1;
Max=max(Max,a[i][j][k]);
}cout<<Max;
return 0;
}