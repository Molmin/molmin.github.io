#include<bits/stdc++.h>
using namespace std;
long long a,b,x=1;
int main(){
	freopen("pow.in","r",stdin);freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1)cout<<1;
	else{
		for(int i=1;i<=b;i++){
			x*=a;if(x>1000000000){cout<<-1;return 0;}
		}
		cout<<x;
	}return 0;
}