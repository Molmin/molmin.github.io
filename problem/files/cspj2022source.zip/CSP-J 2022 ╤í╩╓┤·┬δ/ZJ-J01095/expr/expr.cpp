#include<bits/stdc++.h>
using namespace std;
int ct1,ct2,l;string s;
int dfs(int &p){
int a=1,fh=0,Ans=0;
while(s[p]!=')'){
if(s[p]=='0'||s[p]=='1')if(fh==1)a=s[p]-'0';else a&=s[p]-'0';
if(s[p]=='(')a&=dfs(++p);
if((Ans==1||a==1)&&s[p+1]=='|')ct2++;
if(a==0&&s[p+1]=='&'){
ct1++;while(s[p]!='|'&&s[p]!=')'){if(s[p]=='(')while(s[p]!=')')p++;p++;}
}if(s[p]=='|')fh=1,Ans|=a,a=1;if(s[p]=='&')fh=0;
p++;
}++p;return Ans;
}
int main(){
freopen("expr.in","r",stdin);freopen("expr.out","w",stdout);
cin>>s;s+=')';
cout<<dfs(l)<<endl<<ct1<<" "<<ct2;
return 0;
}