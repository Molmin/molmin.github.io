#include<bits/stdc++.h>
using namespace std;
long long decode(long long n,long long d,long long k){
	long long p=n-d*k+2;
	for(int i=1;i<=min(p/2,(long long)sqrt(n));++i)
	if(n%i==0&&n%(p-i)==0)return i;
	return -1;
}
int main(){
freopen("decode.in","r",stdin);freopen("decode.out","w",stdout);
	long long k,n,d,e,x;scanf("%lld",&k);
	while(k--){
		scanf("%lld%lld%lld",&n,&d,&e);
		x=decode(n,d,e);
		if(x==-1)puts("NO");
		else printf("%d %d\n",x,n/x);
	}
	return 0;
}