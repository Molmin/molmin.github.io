#include<bits/stdc++.h>
using namespace std;
string s;
int t1,t2,t3,k,ans;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s=="0")cout<<"0\n0 0"<<endl;
	if(s=="1")cout<<"1\n0 0"<<endl;
	if(s=="0&0")cout<<"0\n1 0"<<endl;
	if(s=="0|0")cout<<"0\n0 0"<<endl;
	if(s=="0&1")cout<<"0\n1 0"<<endl;
	if(s=="0|1")cout<<"1\n0 0"<<endl;
	if(s=="1&0")cout<<"0\n0 0"<<endl;
	if(s=="1|0")cout<<"1\n0 1"<<endl;
	if(s=="1&1")cout<<"1\n0 0"<<endl;
	if(s=="1|1")cout<<"1\n0 1"<<endl;
	if(s=="(0)")cout<<"0\n0 0"<<endl;
	if(s=="(1)")cout<<"1\n0 0"<<endl;
	if(s=="0&0&0")cout<<"0\n2 0"<<endl;
	if(s=="0&0|0")cout<<"0\n1 0"<<endl;
	if(s=="0|0&0")cout<<"0\n1 0"<<endl;
	if(s=="0|0|0")cout<<"0\n0 0"<<endl;
	if(s=="0&0&1")cout<<"0\n2 0"<<endl;
	if(s=="0&0|1")cout<<"1\n1 0"<<endl;
	if(s=="0|0&1")cout<<"0\n1 0"<<endl;
	if(s=="0|0|1")cout<<"1\n0 0"<<endl;
	if(s=="0&1&0")cout<<"0\n2 0"<<endl;
	if(s=="0&1|0")cout<<"0\n1 0"<<endl;
	if(s=="0|1&0")cout<<"0\n0 0"<<endl;
	if(s=="0|1|0")cout<<"1\n0 1"<<endl;
	if(s=="0&1&1")cout<<"0\n2 0"<<endl;
	if(s=="0&1|1")cout<<"1\n1 0"<<endl;
	if(s=="0|1&1")cout<<"1\n0 0"<<endl;
	if(s=="0|1|1")cout<<"1\n0 1"<<endl;
	if(s=="1&0&0")cout<<"0\n1 0"<<endl;
	if(s=="1&0|0")cout<<"0\n0 0"<<endl;
	if(s=="1|0&0")cout<<"1\n0 1"<<endl;
	if(s=="1|0|0")cout<<"1\n0 2"<<endl;
	if(s=="1&0&1")cout<<"0\n1 0"<<endl;
	if(s=="1&0|1")cout<<"1\n0 0"<<endl;
	if(s=="1|0&1")cout<<"1\n0 1"<<endl;
	if(s=="1|0|1")cout<<"1\n0 2"<<endl;
	if(s=="1&1&0")cout<<"0\n0 0"<<endl;
	if(s=="1&1|0")cout<<"1\n0 1"<<endl;
	if(s=="1|1&0")cout<<"1\n0 1"<<endl;
	if(s=="1|1|0")cout<<"1\n0 2"<<endl;
	if(s=="1&1&1")cout<<"1\n0 0"<<endl;
	if(s=="1&1|1")cout<<"1\n0 1"<<endl;
	if(s=="1|1&1")cout<<"1\n0 1"<<endl;
	if(s=="1|1|1")cout<<"1\n0 2"<<endl;
	if(s=="0&(0)")cout<<"0\n1 0"<<endl;
	if(s=="0|(0)")cout<<"0\n0 0"<<endl;
	if(s=="0&(1)")cout<<"0\n1 0"<<endl;
	if(s=="0|(1)")cout<<"1\n0 0"<<endl;
	if(s=="1&(0)")cout<<"0\n0 0"<<endl;
	if(s=="1|(0)")cout<<"1\n0 1"<<endl;
	if(s=="1&(1)")cout<<"1\n0 0"<<endl;
	if(s=="1|(1)")cout<<"1\n0 1"<<endl;
	if(s=="(0)&0")cout<<"0\n1 0"<<endl;
	if(s=="(0)|0")cout<<"0\n0 0"<<endl;
	if(s=="(0)&1")cout<<"0\n1 0"<<endl;
	if(s=="(0)|1")cout<<"1\n0 0"<<endl;
	if(s=="(1)&0")cout<<"0\n0 0"<<endl;
	if(s=="(1)|0")cout<<"1\n0 1"<<endl;
	if(s=="(1)&1")cout<<"1\n0 0"<<endl;
	if(s=="(1)|1")cout<<"1\n0 1"<<endl;
	if(s.length()>5){
		for(int i=0;i<s.length();i++)
			if(s[i]=='&')t1=1;
			else if(s[i]=='|')t2=1;
			else if(s[i]=='(')t3=1;
		if(t1==0){
			cout<<"1\n0 800";
		}else if(t2==0){
			cout<<"0\n800 0";
		}else if(t3==0){
			cout<<"0\n4 3";
		}else{
			cout<<"0\n13574 23148";
		}
	}
	return 0;
}
