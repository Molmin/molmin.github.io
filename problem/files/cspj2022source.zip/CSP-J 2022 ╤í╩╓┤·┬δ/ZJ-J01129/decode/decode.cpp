#include<bits/stdc++.h>
using namespace std;
int k;long long n,d,e;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	while(k--){
		scanf("%lld%lld%lld",&n,&d,&e);
		long long m=n+2-d*e;
		long long ans=m*m-4*n;
		long long s=(int)sqrt(ans);
		if(s*s!=ans)printf("NO\n");
		else printf("%lld %lld\n",(m-s)/2,(m+s)/2);
	}
	return 0;
}
