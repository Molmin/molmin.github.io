#include<bits/stdc++.h>
using namespace std;
int f[3005][3005],Maxx,Maxy,Max,n,t,a[3005][3005],x[505],y[505];
void dfs(int k,int ans,int sum,int minx,int miny){
	if(ans>t)return;
	if(k>n){
		Max=max(Max,sum);
		return;
	}
	if(x[k]>=minx&&y[k]>=miny)
		if(sum>0)dfs(k+1,ans+x[k]-minx+y[k]-miny-1,sum+1,x[k],y[k]);
		else dfs(k+1,ans,sum+1,x[k],y[k]);
	dfs(k+1,ans,sum,minx,miny);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>t;
	for(int i=1;i<=n;i++){
		int b,c;
		cin>>b>>c;
		a[b][c]=1;
		x[i]=b;
		y[i]=c;
		Maxx=max(Maxx,b);
		Maxy=max(Maxy,c);	
	}
	if(Maxx<=3000&&Maxy<=3000&&t==0){
		for(int i=1;i<=Maxx;i++)
			for(int j=1;j<=Maxy;j++)
				if(a[i][j]==1)f[i][j]=max(f[i-1][j],f[i][j-1])+1;
		for(int i=1;i<=Maxx;i++)
			for(int j=1;j<=Maxy;j++)
				Max=max(Max,f[i][j]);
		cout<<Max;
		return 0;
	}
	if(n<=10){
		for(int i=1;i<n;i++)
			for(int j=i+1;j<=n;j++)
				if(x[i]>x[j]||x[i]==x[j]&&y[i]>y[j]){
					swap(x[i],x[j]);
					swap(y[i],y[j]);
				}
		dfs(1,0,0,0,0);
		cout<<Max+t;
		return 0;
	}
	cout<<100+t<<endl;
	return 0;
}
