#include<bits/stdc++.h>
using namespace std;
int a,b;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	long long t=1;
	for(int i=1;i<=b;i++)
		if(t*a>1e9){
			cout<<-1<<endl;
			return 0;
		}else t*=a;
	cout<<t<<endl;
	return 0;
}
