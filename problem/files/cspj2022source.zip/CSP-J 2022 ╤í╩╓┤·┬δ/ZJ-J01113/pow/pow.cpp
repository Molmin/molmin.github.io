#include<bits/stdc++.h>
using namespace std;
long long a,b,ans;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ans=1;
	if(a==1)printf("%lld",a);
	else{
		for(int i=1;i<=b;i++){
			ans*=a;
			if(ans>1e9){
				printf("-1");
				return 0;
			}
		}
		printf("%lld",ans);
	}
	return 0;
} 
