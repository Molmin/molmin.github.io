#include<bits/stdc++.h>
using namespace std;
long long n,d,e,s,l,r,mid;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	scanf("%d",&k);
	for(int i=1;i<=k;i++){
		bool flag=0;
		scanf("%lld%lld%lld",&n,&d,&e);
		s=n+2-d*e;
		l=1,r=sqrt(n);
		while(l<=r){
			mid=(l+r)>>1;
			//printf("%lld\n",mid);
			long double op=mid+(long double)n/(long double)mid;
			//printf("%f\n",op);
			if(op==s){
				flag=1;
				printf("%lld %lld\n",mid,n/mid);
				break;
			}
			if(op<s){
				r=mid-1;
			}
			if(op>s){
				l=mid+1;
			}
		}
		if(!flag){
			printf("NO\n");
		}
	}
	return 0;
} 
