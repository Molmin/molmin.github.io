#include <bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 1e6+5;
string s;
stack<int> now;
int sz,an[maxn];
struct node{
	int val,cnt0,cnt1;
};
node dfs(int l,int r){
	int i;
	node last;
	if(s[l] == '('){
		last = dfs(l+1,an[l]-1);
		i = an[l]+1;
	}
	else{
		last = {s[l]-'0',0,0};
		i = l+1;
	}
	while(i <= r){
		char type = s[i++];
		if(type == '&'){
			node nxt;
			if(s[i] == '('){
				nxt = dfs(i+1,an[i]-1);
				i = an[i]+1;
			}
			else{
				nxt = {s[i]-'0',0,0};
				i = i+1;
			}
			if(last.val == 0)  last.cnt0++;
			else{
				last.val = last.val&nxt.val;
				last.cnt0 += nxt.cnt0;
				last.cnt1 += nxt.cnt1;
			}
		}
		else{
			int ed;
			if(s[i] == '(')  ed = an[i]+1;
			else  ed = i+1;
			while(ed <= r && s[ed] == '&'){
				if(s[ed+1] == '(')  ed = an[ed+1]+1;
				else  ed = ed+2;
			}
			node nxt = dfs(i,ed-1);
			if(last.val == 1)  last.cnt1++;
			else{
				last.val = last.val|nxt.val;
				last.cnt0 += nxt.cnt0;
				last.cnt1 += nxt.cnt1;
			}
			i = ed;
		}
	}
//	cout << l << " " << r << " " << last.val << " " << last.cnt0 << " " << last.cnt1 << endl; 
	return last;
}
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin >> s;
	sz = s.size();
	for(int i = 0;i < sz;i++){
		if(s[i] == '(')  now.push(i);
		if(s[i] == ')'){
			an[now.top()] = i;
			now.pop();
		}
	}
	node ans = dfs(0,sz-1);
	printf("%lld\n%lld %lld",ans.val,ans.cnt0,ans.cnt1);
	return 0;
}
