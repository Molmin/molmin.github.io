#include <bits/stdc++.h>
using namespace std;
#define int long long
int k,n,e,d,x,y;
signed main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	while(k--){
		scanf("%lld%lld%lld",&n,&e,&d);
		x = n-e*d+2; //x = p+q,y = q-p
		if(x*x-4*n < 0)   printf("NO\n");
		else{
			y = sqrt(x*x-4*n);
			if(y*y != x*x-4*n || (x+y)%2 != 0 || x-y < 0)  printf("NO\n");
			else   printf("%lld %lld\n",(x-y)/2,(x+y)/2);
		}
	}
}
