#include <bits/stdc++.h>
using namespace std;
#define int long long
int n,k,dp[505][105] = {},ans = 0;
struct node{
	int x,y;
	bool operator < (node aa) const{
		if(x == aa.x)  return y < aa.y;
		return x < aa.x;
	}
} poi[505];
signed main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(int i = 1;i <= n;i++){
		scanf("%lld%lld",&poi[i].x,&poi[i].y);
	}
	sort(poi+1,poi+n+1);
	for(int i = n;i >= 1;i--){
		for(int o = 0;o <= k;o++){
			dp[i][o] = o+1;
		}
		for(int j = i+1;j <= n;j++){
			if(poi[j].y < poi[i].y)   continue;
			int cha = poi[j].x+poi[j].y-poi[i].x-poi[i].y-1;
			for(int o = 0;o <= k-cha;o++){
				dp[i][o+cha] = max(dp[i][o+cha],dp[j][o]+cha+1);
			}
		}
	}
	for(int i = 1;i <= n;i++){
		for(int j = 0;j <= k;j++){
			ans = max(ans,dp[i][j]);
		}
	}
	printf("%lld",ans);
}
