#include <bits/stdc++.h>
using namespace std;
#define int long long
int a,b,now = 1;
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if(a == 1)  printf("1");
	else{
		for(int i = 1;i <= b;i++){
			now *= a;
			if(now > 1e9){
				printf("-1");
				return 0;
			}
		}
		printf("%lld",now);
	}
	return 0;
}
