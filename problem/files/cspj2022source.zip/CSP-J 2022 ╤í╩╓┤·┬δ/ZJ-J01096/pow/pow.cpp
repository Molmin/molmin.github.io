#include<bits/stdc++.h>
using namespace std;

long long num;
long long a,b;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	cin>>a>>b;
	
	if(b>=30){
		cout<<-1;
		return 0;
	}
	
	num=1;
	for(int i=1;i<=b;i++){
		num*=a;
		if(num>pow(10,9)){
			cout<<-1;
			return 0;
		}
	}
	
	cout<<num;
	return 0;
}
