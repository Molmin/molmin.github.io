#include<bits/stdc++.h>
#include<queue>
using namespace std;
queue<int> f,s;
int k;
bool flag;
long long n,m,e,d;
int main() {
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	
	scanf("%d",&k);
	
	for(int i=1; i<=k; i++) {
		//��������
		scanf("%lld%lld%lld",&n,&e,&d);	
		//����m��ֵ
		m=n-e*d+2;
		//��ʼ��flag��ֵ
		flag=1;		

		for(int j=1; j<=m-j; j++) {
			if(j*(m-j)==n) {
				flag=0;
				f.push(j);
				s.push(m-j);
				break;
			}
		}
		
		if(flag) {
			f.push(-1);
			s.push(-1);
		}

	}
	for(int i=1; i<=k; i++) {
		if(f.front()==-1) {
			printf("NO");
			f.pop();
			s.pop();
		} else {
			printf("%d %d",f.front(),s.front());
			f.pop();
			s.pop();
		}
		if(!f.empty()){
			printf("\n");
		}
	}
	return 0;
}
