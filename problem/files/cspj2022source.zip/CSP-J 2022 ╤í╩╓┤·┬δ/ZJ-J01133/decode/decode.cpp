#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,t,m;
bool f;
long long check()
{
	f=false;
	for(register int j=1;j<=m/2;j++)
	{
		if(j*(m-j)==n)
		{
			f=true;
			return j;
			break;
		}
	}
	if(!f) return 0;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(register int i=1;i<=k;i++)
	{
		scanf("%d%d%d",&n,&e,&d);
		m=n-e*d+2;
		if(m<0)
		{
			cout<<"NO"<<endl;
			continue;
		}
		t=check();
		if(t!=0) printf("%d ",t),cout<<n/t,cout<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}