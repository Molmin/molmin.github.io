#include<bits/stdc++.h>
using namespace std;
int n,k,ans=1;
struct stc{
	int x,y;
}qwq[501];
bool cmp(stc a,stc b)
{
	if(a.x==b.x) return a.y<b.y;
	else return a.x<b.x;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&qwq[i].x,&qwq[i].y);
	}
	sort(qwq+1,qwq+n+1,cmp);
	for(int i=2;i<=n;i++)
	{
		if((qwq[i].x-1==qwq[i-1].x&&qwq[i].y==qwq[i-1].y)||(qwq[i].x==qwq[i-1].x&&qwq[i].y-1==qwq[i-1].y)) ans++;
		else
		{
			for(int j=i;j<=n;j++)
			{
				if((qwq[j].x-1==qwq[i-1].x&&qwq[j].y==qwq[i-1].y)||(qwq[j].x==qwq[i-1].x&&qwq[j].y-1==qwq[i-1].y))
				{
					ans++;
					break;
					i=j+1;
				}
				else if((qwq[j].x-k==qwq[i-1].x&&qwq[j].y==qwq[i-1].y)||(qwq[j].x==qwq[i-1].x&&qwq[j].y-k==qwq[i-1].y))
				{
					ans+=k;
					break;
					i=j+1;
				}
			}
		}	
	}
	cout<<ans-1;
	return 0;
}