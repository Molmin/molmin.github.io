#include<bits/stdc++.h>
using namespace std;
#define MOD 1000000000
long long a,b,ans=1,t;
bool f;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	ios::sync_with_stdio(false);
	cin>>a>>b;
	f=true;
	for(register long long i=1;i<=b;i++)
	{
		ans*=a;
		t=ans%MOD;
		if(t!=ans) 
		{
			f=false;
			cout<<"-1";
			break;
		}
	}
	if(f) cout<<ans;
	return 0;
}