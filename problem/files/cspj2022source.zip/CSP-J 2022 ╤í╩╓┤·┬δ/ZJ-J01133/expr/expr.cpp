#include<bits/stdc++.h>
using namespace std;
string a;
int aa,bb,ans;
bool f,f2,f4;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	f=false,f2=false,f4=false;
	if(a[0]=='(') f=true;
	if(!f)
	{
		if(a[1]=='&'||a[3]=='&')
		{
			if(a[1]=='&')
			{
				f2=true;
				if(a[0]=='0') aa++,a[2]='0',ans=0;
				else
				{
					if(a[2]=='0') ans=0;
					else a[2]='1',ans=1;
				}
			}
			if(a[3]=='&')
			{
				f4=true;
				if(a[2]=='0') aa++,ans=0;
				else
				{
					if(a[4]=='0') a[2]='0',ans=0;
					else a[2]='1',ans=1;
				}
			}
		}
		else
		{
			if(!f2)
			{
				if(a[0]=='1') bb++,a[2]=='1',ans=1;
				else if(a[2]=='1') ans=1;
				else ans=0,a[2]='0';
			}
			if(!f4)
			{
				if(a[2]=='1') bb++,ans=1;
				else if(a[4]=='1') ans=1;
				else ans=0;
			}
		}
	}
	else
	{
		if(a[2]=='&')
		{
			if(a[1]=='0') aa++,ans=0;
			else if(a[3]=='0') ans=0;
			else ans=1;
		}
		else
		{
			if(a[1]=='1') bb++,ans=1;
			else if(a[3]=='1') ans=1;
			else ans=0;
		}
	}
	cout<<ans<<endl;
	cout<<aa<<" "<<bb;
	return 0;
}