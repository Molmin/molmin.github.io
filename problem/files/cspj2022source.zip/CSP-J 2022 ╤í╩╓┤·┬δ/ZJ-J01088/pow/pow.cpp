#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	unsigned long long a,b;
	cin>>a>>b;
	int p=a;
	for(int i=1;i<b;i++){
		a*=p;
		if(a>pow(10,9)){
			cout<<"-1";
			return 0;
		}
	}
	cout<<a;
	return 0;
}