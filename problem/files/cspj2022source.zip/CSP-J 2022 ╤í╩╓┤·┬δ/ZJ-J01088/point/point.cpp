#include<bits/stdc++.h>
using namespace std;
int p[101][101];
int bj[101][101];
int ans;
void dfs(int x,int y,int ls) {
	if(x>100)
		return;
	if(y>100)
		return;
	if(p[x][y]!=1||bj[x][y])
		return;
	bj[x][y]=1;
	ls++;
	dfs(x+1,y,ls);
	dfs(x,y+1,ls);
	dfs(x-1,y,ls);
	dfs(x,y-1,ls);
	if(ls>ans)
		ans=ls;
	return;
}
int main() {
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	for(int i=1; i<=n; i++) {
		int a,b;
		cin>>a>>b;
		p[a][b]=1;
	}
	for(int i=1; i<=100; i++)
		for(int j=1; j<=100; j++)
			dfs(i,j,0);
	cout<<ans+k;
	return 0;
}