#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string str;
	cin>>str;
	if(str=="0")
		cout<<"0\n0 0";
	if(str=="1")
		cout<<"1\n0 0";
	if(str=="0|1")
		cout<<"1\n0 0";
	if(str=="1|0")
		cout<<"1\n0 1";
	if(str=="0|0")
		cout<<"0\n0 0";
	if(str=="1|1")
		cout<<"1\n0 1";
	if(str=="0&1")
		cout<<"0\n1 0";
	if(str=="1&0")
		cout<<"0\n0 0";
	if(str=="0&0")
		cout<<"0\n1 0";
	if(str=="1&1")
		cout<<"1\n0 1";
}