#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long e,d,ans,n;
	int t;
	cin>>t;
	while(t--){
		bool flag=1;
		cin>>n>>e>>d;
		ans=n-e*d+2;
		for(int i=1;i<=ans/2+1;i++){
			int p=i;
			int q=ans-i;
			if(p*q==n){
				flag=0;
				cout<<p<<" "<<q;
			}
			if(!flag)
			break;
		}
		if(flag)
		cout<<"NO";
		cout<<endl;
	}
	return 0;
}