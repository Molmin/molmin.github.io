#include<bits/stdc++.h>
using namespace std;
const int m=1000000000;
long long a,b,ans;
void ss(){
	long long t=1;
	while(b){
		if(a>m){
			printf("-1");
			exit(0);
		}
		if(b&1){
			if(1ll*t*a>m){
				printf("-1");
				exit(0);
			}
			t=1ll*t*a;
		}
		b>>=1;
		if(b)a=1ll*a*a;
		//printf("%lld %lld %lld\n",a,b,t);
	}
	ans=1ll*t;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ss();
	printf("%lld",ans);
	fclose(stdin);
    fclose(stdout);
	return 0;
}
