#include<bits/stdc++.h>
using namespace std;
char s[1000005];
int n,f[1000005],t[1000005],cnt,k[1000005],a1,a2;
int dfs(int l,int r){
	cnt=0;
	for(int i=l;i<=r;i++){
		if(s[i]=='('){
			cnt++;
			for(int j=i+1;j<=r;j++){
				if(s[j]==')'){
					t[i]=j;
					k[i]=dfs(i+1,j-1);k[j]=k[i];//if(s[j+1]=='|'&&k[j]==1)a2++;
					//if(s[j+1]=='&'&&k[j]==0)a1++;
				}
			}
		}
	}
	if(!cnt){
		int ans=0;
		for(int i=l;i<=r;i++){
			if(s[i]=='1'||s[i]=='0')k[i]=s[i]-'0';
		}
		for(int i=l;i<=r;i++){
			if(s[i]=='&'){
				a1++;
				ans=k[i-1]=k[i+1]=min(k[i-1],k[i+1]);
				i++;
			}
			else{
				if(s[i]=='(')i=t[i]-1;
			}
		}
		for(int i=l;i<=r;i++){
			if(s[i]=='|'){
				a2++;
				ans=k[i-1]=k[i+1]=max(k[i-1],k[i+1]);
			    i++;
			}
			else{
				if(s[i]=='(')i=t[i]-1;
			}
		}
		k[l-1]=ans;k[r+1]=ans;
		return ans;
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s+1);
	n=strlen(s+1);
	s[0]='(';
	s[n+1]=')';
	n++;
	printf("%d\n%d %d",dfs(0,n),a1/3*2,a2/3*2);
	fclose(stdin);
    fclose(stdout);
	return 0;
}
