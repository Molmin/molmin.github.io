#include<bits/stdc++.h>
using namespace std;
int k,ok;
long long a,b,c,m;
int ss(){
	long long l=1,r=m/2;
	while(l<=r){
		long long mid=(l+r)/2;
		if(1ll*mid*(m-mid)==a){
			return mid;
		}
		if(1ll*mid*(m-mid)<a){
			l=mid+1;
		}
		else r=mid-1;
	}
	if(1ll*l*(m-l)==a){
		return l;
	}
	return 0;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int i=1;i<=k;i++){
		scanf("%lld%lld%lld",&a,&b,&c);ok=0;
		m=a-1ll*b*c+2;
		/*for(int j=1;j<=(a/j);j++){
			if(1ll*j*(m-j)==a){
				ok=1;
				if(((j-1)*(m-j-1)+1)==1ll*b*c){
					printf("%lld %lld\n",j,m-j);
				}
				else{
					printf("NO\n");
				}
				break;
			}
		}
		if(!ok)printf("NO\n");*/
		long long x=ss();//cout<<x;
		//long long m1=min(x,a/x),m2=a/m1;
		if(!x){
			printf("NO\n");continue;
		}
		if((1ll*(x-1)*(m-x-1)+1)==1ll*b*c){
			printf("%lld %lld\n",x,1ll*a/x);
		}else{
			printf("NO\n");
		}
	}
	fclose(stdin);
    fclose(stdout);
	return 0;
}
