#include<bits/stdc++.h>
using namespace std;
int n,k,a[1000005],b[1000005],f[1005][1005],v[1000000],ans;
int d[4][2]={1,0,0,1,-1,0,0,-1};
void dfs(int x,int y,int step){
	ans=max(ans,step);
	//cout<<x<<" "<<y<<" "<<step<<endl;
	for(int i=0;i<4;i++){
		int fx=x+d[i][0];
		int fy=x+d[i][1];
		if(!f[fx][fy]||v[f[fx][fy]])continue;
		v[f[fx][fy]]=1;
		dfs(fx,fy,step+1);
		v[f[fx][fy]]=0;
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d %d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a[i],&b[i]);
		if(a[i]<=1004&&b[i]<=1004)f[a[i]][b[i]]=i;
	}
	if(k==0){
		for(int i=1;i<=n;i++){
			memset(v,0,sizeof(v));
			v[i]=1;
			dfs(a[i],b[i],1);
		}
		printf("%d",ans);
		return 0;
    }
    printf("%d",k+n/2);
    fclose(stdin);
    fclose(stdout);
    return 0;
}
