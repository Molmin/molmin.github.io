#include<cstdio>
long long a,b;
long long ans;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if(a == 1)
	{
		printf("1");
		return 0;
	}
	long long i,j;
	i = 1;
	long long dq = a;
	while(dq<=1000000000ll&&i<=b)
	{
		if(i==b)
		{
			ans = dq;
		}
		dq *= a;
		i++;
	}
	if(i==b)
	{
		ans = dq;
	}
	if(b >= i)
	{
		printf("-1");
	} 
	else
	{
		printf("%lld",ans);
	}
	return 0;
}
//41 days from Germany to France
