#include<cstdio>
#include<cmath>
using namespace std;
long long t;
long long n,e,d;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld%lld%lld",&n,&e,&d);
		long long b = e*d;
		long long sm = n-b+2;
		if(sm*sm-4ll*n<0)
		{
			printf("NO\n");
		}
		else
		{
			long long x,y;
			x = (sm-(long long)(sqrt(sm*sm-4*n)))/2;
			y = (sm+(long long)(sqrt(sm*sm-4*n)))/2;
			if(x<=0||y<=0||b!=(x-1)*(y-1)+1||n!=x*y)
			{
				printf("NO\n");
			}
			else
			{
				printf("%lld %lld\n",x,y);
			}
		}
	}
	return 0;
}
