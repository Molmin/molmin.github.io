#include<cstdio>
#include<iostream>
#include<string>
#include<algorithm>
#include<cstring>
#include<stack>
using namespace std;
string s;
int l;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int i,j;
	cin>>s;
	l = s.length();
	if(l<=3)
	{
		if(s == "0")
		printf("0\n0 0");
		else if(s == "1")
		printf("1\n0 0");
		else if(s=="(1)")
		printf("1\n0 0");
		else if(s=="(0)")
		printf("0\n0 0");
		else if(s=="1&1")
		printf("1\n0 0");
		else if(s=="1&0")
		printf("0\n0 0");
		else if(s=="0&1")
		printf("0\n1 0");
		else if(s=="0&0")
		printf("0\n1 0");
		else if(s=="1|1")
		printf("1\n0 1");
		else if(s=="0|1")
		printf("1\n0 0");
		else if(s=="1|0")
		printf("1\n0 1");
		else if(s=="0|0")
		printf("0\n0 0");
		else
		printf("0\n0 0");
		return 0;
	}
	printf("1\n1 2");
	return 0;
}
// abandon
