#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
const int INF = 11451419;
int n;
int k;
int dp[601][201];

struct node
{
	int x,y;
} point[601];
bool cmp(node x,node y)
{
	if(x.x == y.x)
	{
		return x.y<y.y;
	}
	return x.x<y.x;
}
int ans = -INF;
int walm(int x,int y);
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int i,j,l;
	for(i=1;i<=500;i++)
	{
		for(j=1;j<=100;j++)
		{
			dp[i][j] = -INF;
		}
	}
	scanf("%d%d",&n,&k);
	for(i=1;i<=n;i++)
	{
		scanf("%d%d",&point[i].x,&point[i].y);
	}
	sort(point+1,point+1+n,cmp);
	for(i=n;i>=1;i--)
	{
		dp[i][0] = 1;
		for(j=i+1;j<=n;j++)
		{
			if(point[j].x>=point[i].x&&point[j].y>=point[i].y)
			{
				int wazrzt = walm(i,j);
				for(l=0;l<=k-wazrzt;l++)
				{
					if(dp[j][l] != -INF)
					{
						dp[i][l+wazrzt] = max(dp[i][l+wazrzt],dp[j][l]+1);
					}
				}
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		for(j=0;j<=k;j++)
		{
			ans = max(dp[i][j],ans);
		}
	}
	printf("%d",ans+k);
	return 0;
}
int walm(int x,int y)
{
	return abs(point[x].x - point[y].x) + abs(point[x].y - point[y].y) - 1;
}
