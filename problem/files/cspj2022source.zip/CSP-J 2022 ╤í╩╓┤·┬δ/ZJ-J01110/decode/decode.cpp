#include<cstdio>
int main(void){
    freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
    long long n,e,d;
    int k;
    scanf("%d",&k);
    while (k--){
        scanf("%lld%lld%lld",&n,&e,&d);
        long long q=1,p=1;
        bool flag=1;
        if (e*d>=n)
        {
            printf("NO\n");
            continue;
        }
        if (n>250000000000000000)
        {
            printf("NO\n");
            continue;
        }

        for (p=1;p<=500000000&&p*p<=n;p++)
        {
            if (n%p)
            {
                continue;
            }
            q=n/p;
            if (e*d==(q-1)*(p-1)+1)
            {
                printf("%lld %lld",p,q);
                flag=0;
                break;
            }
        }
        if(flag){
            printf("NO");
        }
        if (k)
        {
            printf("\n");
        }

    }
    fclose(stdout);
    fclose(stdin);
    return 0;
}
