#include<cstdio>
#include<cstring>
int or_d,and_d;
char s[1000001];
int Getv(int sta,int e){
    int lastand=e+1,lastor=e+1,i;
    for (i=e;i>=sta;i--)
    {
        if (s[i]=='&'&&lastand==e+1)
        {
            lastand=i;
        }
        if (s[i]=='|'&&lastor==e+1)
        {
            lastor=i;
        }
        if (s[i]==')')
        {
            int co=1;
            while (co)
            {
                i--;
                if (s[i]=='(')
                {
                    co--;
                }
                if (s[i]==')')
                {
                    co++;
                }

            }
        }
    }
    if (lastor!=e+1)
    {
        int v1=Getv(sta,lastor-1);
        if (v1)
        {
            or_d++;
            return 1;
        }
        else{
            v1=Getv(lastor+1,e);
            return v1;
        }
    }
    else if (lastand!=e+1)
    {
        int v1=Getv(sta,lastand-1);
        if (v1)
        {
            v1=Getv(lastand+1,e);
            return v1;
        }
        else{
            and_d++;
            return 0;
        }
    }
    else if(s[sta]=='('){
        return Getv(sta+1,e-1);
    }
    else{
        return s[sta]-'0';
    }
}
int main(void){
    freopen("expr.in","r",stdin);
    freopen("expr.out","w",stdout);
    gets(s);
    printf("%d\n",Getv(0,strlen(s)-1));
    printf("%d %d",and_d,or_d);
    fclose(stdout);
    fclose(stdin);
    return 0;
}
