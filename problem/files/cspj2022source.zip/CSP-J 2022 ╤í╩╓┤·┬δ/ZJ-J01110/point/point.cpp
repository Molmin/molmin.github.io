#include<cstdio>
#include<cstring>
struct Point{
    int x,y;
} Ds[501];
int N,K;
int X,Y;
int Dp[701][701][101];
int Dfs(int x,int y,int k){//
    if (Dp[x-X][y-Y][k]!=-1)
    {
        return Dp[x-X][y-Y][k];
    }

    int ans=0,upf=1,leftf=1;
    for (size_t i = 1; i <=N; i++)
    {
        if (Ds[i].x==x&&Ds[i].y==y+1)
        {
            int a=Dfs(x,y+1,k)+1;
            upf=0;
            if (a>ans)
            {
                ans=a;
            }

        }
        if (Ds[i].y==y&&Ds[i].x==x+1)
        {
            int a=Dfs(x+1,y,k)+1;
            leftf=0;
            if (a>ans)
            {
                ans=a;
            }

        }
    }
    if (upf&&k)
    {
        int a=Dfs(x,y+1,k-1)+1;
        if (a>ans)
        {
            ans=a;
        }
    }
    if (leftf&&k)
    {
        int a=Dfs(x+1,y,k-1)+1;
        if (a>ans)
        {
            ans=a;
        }

    }
    return Dp[x-X][y-Y][k]=ans;
}
int main(void){
    freopen("point.in","r",stdin);
    freopen("point.out","w",stdout);
    scanf("%d%d",&N,&K);
    for (size_t i = 1; i <= N; i++)
    {
        scanf("%d%d",&Ds[i].x,&Ds[i].y);
    }
    int ans=0;
    for (size_t i = 1; i <=N; i++)
    {
        memset(Dp,-1,sizeof(Dp));
        X=Ds[i].x,Y=Ds[i].y;
        int a=Dfs(Ds[i].x,Ds[i].y,K)+1;
        if (a>ans)
        {
            ans=a;
        }

    }
    printf("%d\n",ans);
    fclose(stdout);
    fclose(stdin);
    return 0;
}
