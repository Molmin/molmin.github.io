#include<cstdio>
int main(void){
    freopen("pow.in","r",stdin);
    freopen("pow.out","w",stdout);
    long long a,b;
    bool flag=1;
    scanf("%lld%lld",&a,&b);
    long long ans=1;
    if(a==1){
        printf("1\n");
        return 0;
    }
    for (size_t i = 0; i < b; i++){
        ans*=a;
        if (ans>0x7fffffff){
            printf("-1\n");
            flag=0;
            break;
        }
    }
    if(flag){
        printf("%lld\n",ans);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}