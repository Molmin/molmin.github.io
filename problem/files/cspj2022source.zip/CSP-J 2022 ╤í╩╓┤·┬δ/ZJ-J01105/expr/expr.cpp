#include<bits/stdc++.h>
using namespace std;
string a;
int s1,s2,s3;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
 	cin>>a;
	if(a[1]=='&') 
	{
		cout<<int(a[0]-'0')&&int(a[2]-'0');	
		if(a[0]=='0') cout<<"\n1 0";
		else cout<<"\n0 0";
		return 0;
	}
	if(a[1]=='|')
	{
		cout<<int(a[0]-'0')||int(a[2]-'0');
		if(a[0]=='1') cout<<"\n0 1";
		else cout<<"\n0 0";
		return 0;
	}
 	for(int i=0;i<a.size();++i)
 	  if(a[i]=='|') ++s1;
 	  else ++s2;
 	if(s1==0)
 	{
 		int s1=0,s2=0,s3=0;
 		for(int i=0;i<a.size();++i)
 		  if(a[i]=='1') ++s1;
 		  else if(a[i]=='0') ++s2;
 		  else ++s3;
 		if(s2==0) cout<<"0\n";
 		else cout<<"1\n";
 		cout<<s3<<" "<<0;
	}
	else
	{
		int s1=0,s2=0,s3=0;
 		for(int i=0;i<a.size();++i)
 		  if(a[i]=='1') ++s1;
 		  else if(a[i]=='0') ++s2;
 		  else ++s3;
 		if(s1==0) cout<<"0\n";
 		else cout<<"1\n";
 		cout<<0<<" "<<s3;
	}
	return 0;
}