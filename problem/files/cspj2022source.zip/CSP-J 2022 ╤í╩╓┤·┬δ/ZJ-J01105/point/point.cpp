#include<bits/stdc++.h>
using namespace std;
int n,k,d[510];
struct node{
	int a,b;
}c[510];
bool cmp(node x,node y)
{
	return x.a<y.a||x.a==y.a&&x.b<y.b;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;++i)
	  cin>>c[i].a>>c[i].b;
	sort(c+1,c+n+1,cmp);
	cout<<n+k;
	return 0;
}