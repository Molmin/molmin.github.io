#include<bits/stdc++.h>
using namespace std;
int k;
long long n,x,y,m;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--)
	{
		scanf("%lld%lld%lld",&n,&x,&y);
		m=x*y-2;
		bool p=0;
		long long l=1,r=sqrt(n);
		long long mid=(l+r)/2;
		while(l<=r)
		{
			long long a=n/mid;
			if(a*mid==n)
			{
				if(n-a-mid==m) 
				{
					printf("%lld %lld\n",mid,a);	
					p=1;
					break;
				}
			}
			if(n-a-mid<=m) l=mid+1;
			else r=mid-1;
			mid=(l+r)/2;
		}
		if(p==0) printf("NO\n");
	}
	return 0;
}