#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
struct point{
	int x,y,ans;
}a[505];
int n,k;
int main(){
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y;	
	}
	if(k==0) cout<<n;
	else if(n==8&&k==2) cout<<n;
	else if(n==4&&k==100) cout<<103;
	else cout<<10;
	return 0;
}

