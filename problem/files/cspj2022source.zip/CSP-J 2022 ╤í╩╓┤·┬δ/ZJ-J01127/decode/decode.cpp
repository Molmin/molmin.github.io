#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
// n=a,e=b,d=c
long long a,b,c,sum,lt,rt,mid;
int main(){
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	int k;
	cin>>k;
	for(int i=1; i<=k;i++){
		cin>>a>>b>>c;
		sum = a+2-b*c;
		lt = 1; rt = sqrt(a);
		bool flag = 0;
		while(lt<=rt){
			mid = (lt+rt) >>1;
			double op = mid+(long double)a/(long double)mid;
			if(op==sum){
				flag=1;
				cout<<mid<<" "<<a/mid<<endl;
				break;
			}
			if(op<sum){
				rt = mid-1;
			}
			if(op>sum){
				lt = mid+1;
			}
			
		}
		if(!flag) cout<<"NO"<<endl;
	}
	return 0;
} 
