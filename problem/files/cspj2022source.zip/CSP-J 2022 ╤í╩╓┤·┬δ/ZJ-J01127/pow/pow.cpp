#include<bits/stdc++.h>
#include<cstdio>
using namespace std;

int main(){
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	long long a,b;
	cin>>a>>b;
	long long ret = 1;
	if(a==1) cout<<a;
	else{
		for(int i=1; i<=b; i++){
			ret*=a;
			if(ret>1e9){
				cout<<"-1";
				return 0;
			}
		}
	}
	cout<<ret;
	return 0;
}

