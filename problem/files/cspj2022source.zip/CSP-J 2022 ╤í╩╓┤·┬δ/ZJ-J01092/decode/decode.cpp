#include<bits/stdc++.h>
#define int long long
using  namespace  std;
bool  flag=false;
int  k,n,d,e,a,b,c;
signed  main( ){
	freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	while(k--){
		scanf("%lld%lld%lld",&n,&d,&e);
		if(d*e>n){
			printf("NO\n");
		}
		else if(d*e==n){
			if(n==1){
				printf("1 1\n");
			}
			else{
				printf("NO\n");
			}
		}
		else{
			a=-1;
			b=n-d*e+2;
			c=-n;
			if(((long long)min((-b-sqrt(b*b-4*a*c))/(a*2),(-b+sqrt(b*b-4*a*c))/(a*2)))/1==min((-b-sqrt(b*b-4*a*c))/(a*2),(-b+sqrt(b*b-4*a*c))/(a*2))&&min((-b-sqrt(b*b-4*a*c))/(a*2),(-b+sqrt(b*b-4*a*c))/(a*2))>0){
				cout<<(long long)min((-b-sqrt(b*b-4*a*c))/(a*2),(-b+sqrt(b*b-4*a*c))/(a*2))<<" "<<(long long)max((-b-sqrt(b*b-4*a*c))/(a*2),(-b+sqrt(b*b-4*a*c))/(a*2))<<'\n';
			}
			else{
				printf("NO\n");
			}
		}
	}
	return  0;
}