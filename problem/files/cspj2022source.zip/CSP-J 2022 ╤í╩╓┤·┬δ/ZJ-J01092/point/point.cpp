#include<bits/stdc++.h>
using  namespace  std;
int  n,k,l,r,ans;
long long  d[1001][1001];
struct  dian{
	int x,y;
};
dian  point[1001];
bool  cmp1(dian a,dian b){
	if(a.x==b.x)
	    return  a.y<b.y;
	return  a.x<b.x;
}
int  dis(dian a,dian b){
	return  (abs(a.x-b.x)+abs(a.y-b.y)-1);
}
int  main( ){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++)
        scanf("%d%d",&point[i].x,&point[i].y);
    sort(point+1,point+n+1,cmp1);
    l=1,r=1;
    while(l<=r&&r<=n){
    	r++;
    	k=k-dis(point[r-1],point[r]);
    	while(k<0){
    		l++;
    		k=k+dis(point[l-1],point[l]);
    		ans=max(ans,r-l+1);
		}
	}
	printf("%d",ans);
	return  0;
}