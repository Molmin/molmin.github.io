#include<bits/stdc++.h>
using  namespace  std;
long long  a,b;
long long  ans;
int  main( ){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ans=a;
	for(int i=2;i<=b;i++){
		ans=ans*a;
		if(ans>1e9){
			printf("-1");
			return  0;
		}
	}
	printf("%lld",ans);
	return  0;
}