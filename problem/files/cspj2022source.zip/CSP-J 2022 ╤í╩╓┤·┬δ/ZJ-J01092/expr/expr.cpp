#include<bits/stdc++.h>
using  namespace  std;
int  ydl,hdl;
string  s;
bool  noww;
stack<bool> st;
void  calc(int l,bool noww){
	if(l==s.size()-1)
	    return  ;
		if(s[l]=='0'&&s[l+1]=='&'){
			if(s[l+2]!=40){
				noww=0;
				ydl++;
				l=l+3;
				calc(l,noww);
			}
			else{
				noww=0;
				ydl++;
				int  mo=1,j=l+3;
				for(;j<s.size();j++){
					if(s[j]==41)
					    mo--;
					if(s[j]==40)
					    mo++;
					if(mo==0)
					    break;
				}
				l=j+1;
				calc(l,noww);
			}
		}
		if(s[l]=='1'&&s[l+1]=='|'){
			if(s[l+2]!=40){
				noww=1;
				hdl++;
				l=l+3;
				calc(l,noww);
			}
			else{
				noww=1;
				hdl++;
				int  mo=1,j=l+3;
				for(;j<s.size();j++){
					if(s[j]==41)
					    mo--;
					if(s[j]==40)
					    mo++;
					if(mo==0)
					    break;
				}
				l=j+1;
				calc(l,noww);
			}
		}
}
int  main( ){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s[0]!=40)
	    noww=s[0]-'0';
	else
	    noww=s[1]-'0';
	if(s[0]=='0'&&s[1]=='|'){
		cout<<s[2]<<'\n'<<0<<" "<<0;
	    return  0;
	}
	if(s[0]=='1'&&s[1]=='&'){
		cout<<s[2]<<'\n'<<0<<" "<<0;
	    return  0;
	}
	if(s.size()==3&&s[0]==40){
		cout<<s[1]<<'\n'<<0<<" "<<0;
	    return  0;
	}
	calc(0,noww);
	cout<<noww<<'\n'<<ydl<<" "<<hdl;
	return  0;
}