#include<bits/stdc++.h>
using namespace std;
long long n,m,ans=1;

int main(){
freopen("pow.in","r",stdin);
freopen("pow.out","w",stdout);
cin>>n>>m;
if (n==1) {cout<<1;return 0;}
for (int i=1;i<=m;i++){
ans*=n;
if (ans>1000000000){cout<<-1;return 0;}
}
cout<<ans;
return 0;
}
