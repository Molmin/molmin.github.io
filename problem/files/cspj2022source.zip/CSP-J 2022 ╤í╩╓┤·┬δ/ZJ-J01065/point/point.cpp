#include<bits/stdc++.h>
using namespace std;
long long n,m,z,x,y,dp[505],ans;
struct xxx{
long long x,y;
} a[505];

bool cmp(xxx a,xxx b){
if (a.x==b.x) return a.y<b.y;
else return a.x<b.x;
}

int main(){
freopen("point.in","r",stdin);
freopen("point.out","w",stdout);
cin>>n>>m;
for (int i=1;i<=n;i++) cin>>a[i].x>>a[i].y,dp[i]=1;
sort(a+1,a+1+n,cmp);
for (int i=1;i<=n;i++){
for (int j=1;j<=i-1;j++)
if ((a[j].x==a[i].x&&a[j].y==a[i].y-1)||(a[j].x==a[i].x-1&&a[j].y==a[i].y)) dp[i]=max(dp[i],dp[j]+1);
if (dp[i]>ans) ans=dp[i];
}
cout<<ans;
return 0;
}
