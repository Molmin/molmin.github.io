#include<bits/stdc++.h>
using namespace std;
long long n,m,d,e,ansp,T;

long long erfen(long long a,long long b){
long long l=1,r=b/2,mid=0,ans=0;
while (l<=r){
mid=(l+r)/2;
if (mid*(b-mid)<a) l=mid+1;
else ans=mid,r=mid-1;
}
return ans;
}

int main(){
freopen("decode.in","r",stdin);
freopen("decode.out","w",stdout);
cin>>T;
while (T--){
cin>>n>>d>>e;
m=n-e*d+2;
ansp=erfen(n,m);
if (ansp==0) cout<<"NO"<<endl;
else if (n%ansp==0&&ansp+n/ansp==m) cout<<ansp<<" "<<n/ansp<<endl;
else cout<<"NO"<<endl;
}
return 0;
}
