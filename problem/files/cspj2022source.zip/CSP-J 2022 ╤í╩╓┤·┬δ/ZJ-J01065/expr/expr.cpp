#include<bits/stdc++.h>
using namespace std;
long long n,m,d,e,ans,aans,oans,l,o;
string s;

int dfs(int x) {
//	cout<<l<<endl;
	long long sum=1,op=1,kh=0;
	if (s[l]=='&') {
		while (l<s.size()) {
			l++;
//			cout<<s[l]<<endl;
			if (s[l]=='(') {
				sum=sum&(dfs(x));
			}  else if (s[l]=='&') {
		    	break;
			} else if (s[l]=='|') {
				break;
			} else if (s[l]=='1') {
				if (op==0) sum=sum|1;
				else sum=sum&1;
			} else if (s[l]=='0') {
				if (op==0) sum=sum|0;
				else sum=sum&0;
			} else if (s[l]==')') break;
		}
//		cout<<sum<<endl;
	} else if (s[l]=='|') {
		while (l<s.size()) {
			l++;
			if (s[l]=='(') {
				if (op==1) sum=sum&(dfs(x));
				else sum=sum|(dfs(x));
			}   else if (s[l]=='&') {
			    break;
			} else if (s[l]=='|') {
		   	break;
			} else if (s[l]=='1') {
				if (s[l+1]!='&'){
				if (op==0) sum=sum|1;
				else sum=sum&1;
			} else {
				l++;
				if (op==0) sum=sum|(1&dfs(x));
				else sum=sum&(1&dfs(x));
			}
			} else if (s[l]=='0') {
					if (s[l+1]!='&'){
				if (op==0) sum=sum|0;
				else sum=sum&0;
			} else {
				l++;
				aans+=x;
				if (op==0) sum=sum|0,dfs(x);
				else sum=sum&0,dfs(x);
			}
			} else if (s[l]==')') {
			    break;
			}
		}
	} else if (s[l]=='(') {
		while (l<s.size()) {
			l++;
//			cout<<l<<' '<<sum<<endl;
			if (s[l]=='(') {
				if (op==1) sum=sum&(dfs(x));
				else sum=sum|(dfs(x));
			} else if (s[l]=='&') {
				if (sum==0) aans+=x,dfs(0);
				else sum=sum&(dfs(x));
			} else if (s[l]=='|') {
				if (sum==1) oans+=x,dfs(0);
				else sum=sum|(dfs(x));
			} else if (s[l]=='1') {
				if (op==0) sum=sum|1;
				else sum=sum&1;
			} else if (s[l]=='0') {
				if (op==0) sum=sum|0;
				else sum=sum&0;
			} else if (s[l]==')'){
			break;
			}
		}
	}
	return sum;
}

int main() {
freopen("expr.in","r",stdin);
freopen("expr.out","w",stdout);
	cin>>s;
	l=-1;
	o=1;
	ans=1;
	while (l==-1||l<s.size()) {
		l++;
//		cout<<s[l]<<endl;
		if (s[l]=='&') {
			if (ans==0) aans++,dfs(0);
			else ans=(ans&(dfs(1)));
		} else if (s[l]=='|') {
			if (ans==1) oans++,dfs(0);
			else ans=(ans|(dfs(1)));
		} else if (s[l]=='(') {
			if (o==1) ans=ans&(dfs(1));
			else ans=ans|(dfs(1));
		} else if (s[l]=='0') {
			ans=0;
		} else if (s[l]=='1') {
			ans=1;
		}
//		cout<<l<<' '<<ans<<endl;
	}
	cout<<ans<<endl<<aans<<' '<<oans;
	return 0;
}
