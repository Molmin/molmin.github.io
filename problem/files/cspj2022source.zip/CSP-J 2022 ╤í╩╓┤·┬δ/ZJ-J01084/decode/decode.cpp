#include <bits/stdc++.h>
using namespace std;
long long n, e, d;
int T;
inline __int128 sqqqrt(__int128 x) {
	__int128 r = 2e18, l = 0, ans = 0, mid;
	while (l <= r) {
		mid = l + r >> 1;
		if (mid * mid == x)
			return mid;
		else if (mid * mid > x) r = mid - 1;
		else l = mid + 1;
	}
	return -1;
}
void write(__int128 x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
void dowrite(__int128 a, __int128 b) {
	if (a > b) swap(a, b);
	write(a), putchar(' '), write(b), putchar('\n');
}
int main() {
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	cin >> T;
	while (T--) {
		scanf("%lld %lld %lld", &n, &e, &d);
		__int128 m = (__int128)e * d, x = n - m + 2, y = n, delta, ansa, ansb;
		if (x * x < 4 * y) {
			puts("NO");
			continue;
		}
		delta = sqqqrt(x * x - 4 * y);
//		 write(delta);
		if (delta == -1) {
			puts("NO");
			continue;
		}
		ansa = x - delta, ansb = x + delta;
		if (ansa > 0 && (ansa % 2 == 0) && !(n % (ansa / 2))) {
			ansa /= 2;
			dowrite(ansa, n / ansa);
		} else if (ansb > 0 && (ansb % 2 == 0) && !(n % (ansb / 2))) {
			ansb /= 2;
			dowrite(ansb, n / ansb);
		} else
			puts("NO");
	}
	return 0;
}
/*
1
1000000000000000000 999999998000000002 1
*/