#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
char str[N];
int shd, sho, n, nxt[N];
int st[N], top;
bool solve(int l, int r);
bool solve3(int l, int r) {
//	cout << "solve3::" << l << ' ' << r << endl;
	while (l < r && str[l] == '(' && nxt[l] == r) ++l, --r;
	if (l == r) return (str[l] - '0');
	return solve(l, r);
}
bool solve2(int l, int r) {
//	cout << "solve2::" << l << ' ' << r << endl;
	bool flag = 0;
	while (l < r && str[l] == '(' && nxt[l] == r) ++l, --r, flag = 1;
	if (flag) return solve(l, r);
	int pre = l - 1;
	int ans = 1;
	for (int i = l; i <= r; i++) {
		if (str[i] == '(') {
			i = nxt[i];
			continue;
		}
		if (str[i] == '&') {
			if (!ans) ++shd;
			else ans &= solve3(pre + 1, i - 1), pre = i;
		}
	}
	if (!ans) ++shd;
	else ans &= solve3(pre + 1, r);
	return ans;
}
bool solve(int l, int r) {
//	cout << "solve::" << l << ' ' << r << endl;
	while (l < r && str[l] == '(' && nxt[l] == r) ++l, --r;
	int pre = l - 1;
	int ans = 0;
	for (int i = l; i <= r; i++) {
		if (str[i] == '(') {
			i = nxt[i];
			continue;
		}
		if (str[i] == '|') {
			if (ans) 
				++sho;
			else
				ans |= solve2(pre + 1, i - 1), pre = i;
			if (l == 1 && r == 9) cout << ans << endl;
		}
	}
	if (ans) ++sho;
	else ans |= solve2(pre + 1, r);
	return ans;
}
int main() {
	freopen("expr.in", "r", stdin), freopen("expr.out", "w", stdout);
	scanf("%s", str + 1), n = strlen(str + 1);
	for (int i = 1; i <= n; i++) {
		if (str[i] == '(')
			st[++top] = i;
		else if (str[i] == ')')
			nxt[st[top--]] = i;
	}
	cout << solve(1, n) << endl;
	cout << shd << ' ' << sho;
	return 0;
}
//0&(1|0)|(1|1|1&0)
//(1&(0&0|1))
//(0&1|1)|1

