#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10;
inline long long qpw(long long a, long long b) {
	long long ans = 1;
	while (b) {
		if (a > 1000000000) return -1;
		if (b & 1) {
			ans = ans * a;
			if (ans > 1000000000) return -1;
		}
		a = a * a, b >>= 1;
	}
	return ans;
}
int main() {
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	long long a, b;
	cin >> a >> b;
	cout << qpw(a, b);
	return 0;
}