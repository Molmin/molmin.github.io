// CSP-J2022 rp++
#include<bits/stdc++.h>
#define N 510
#define ll long long
using namespace std;
ll n,k,m;
struct node
{
	ll x,y;
}a[N];
bool cmp(node a,node b){return a.x==b.x?a.y<b.y:a.x<b.x;}
ll dis(node a,node b){return abs(a.x-b.x)+abs(a.y-b.y);}
namespace sub1
{
	ll ans=0;
	bool v[N];
	void dfs(ll id,ll s,ll t)
	{
		v[id]=1;
		bool f=0;
		for(int i=1;i<=n;i++)	
			if(dis(a[i],a[id])-1==0&&!v[i]&&a[id].x<=a[i].x&&a[id].y<=a[i].y)
			{
				dfs(i,s-dis(a[i],a[id])+1,t+1);
				f=1;
			}
		if(!f)
		{
			ans=max(ans,t);
			return;
		}
	}
	void solve()
	{
		for(int i=1;i<=n;i++)
		{
			memset(v,0,sizeof(v));
			dfs(i,k,1);
		}
		cout<<ans;
	}
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	sort(a+1,a+1+n,cmp);
	if(k==0)sub1::solve();
	return 0;
}