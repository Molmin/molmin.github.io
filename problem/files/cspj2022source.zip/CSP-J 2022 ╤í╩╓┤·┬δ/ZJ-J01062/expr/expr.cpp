// CSP-J2022 rp++
#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll n,ans,ra,ro;
stack<ll>st;
ll calc(ll l,ll r)
{
//	cout<<l<<' '<<r<<'\n';	
	ll t=0;
	if(l==r)return s[l]-'0';
	if(s[l]=='('&&s[r]==')')
	{
		bool f=0;
		for(int i=l;i<r;i++)
		{
			if(s[i]=='(')t++;
			if(s[i]==')')t--;
			if((s[i]=='|'||s[i]=='&')&&!t)
			{
				f=1;
				break;
			}
		}
		if(!f)l++,r--;
	}
	
	ll cnt=0;t=0;
	for(int i=l;i<=r;i++)
	{
		if(s[i]=='(')t++;
		if(s[i]==')')t--;
		if(s[i]=='|'&&!t)
			cnt++;
	}
	if(cnt<=1)
	{
		for(int i=l;i<=r;i++)
		{
			if(s[i]=='(')t++;
			if(s[i]==')')t--;
			if(s[i]=='|'&&!t)
			{
				ll a=calc(l,i-1);
				if(a==1)
				{
					ro++;
					return 1;
				}
				ll b=calc(i+1,r);
				return a|b;
			}
		}
	}
	else
	{
		for(int i=l;i<=r;i++)
		{
			if(s[i]=='(')t++;
			if(s[i]==')')t--;
			if(s[i]=='|'&&!t)
			{
				ll k=i+1;
				while(s[k]!='|'||t)
				{
					if(s[k]=='(')t++;
					if(s[k]==')')t--;
					k++;
				}
				ll a=calc(l,k-1);
				if(a==1)
				{
					ro++;
					return 1;
				}
				ll b=calc(k+1,r);
				return a|b;
			}
		}
	}
	
	t=0;cnt=0;
	for(int i=l;i<=r;i++)
	{
		if(s[i]=='(')t++;
		if(s[i]==')')t--;
		if(s[i]=='&'&&!t)
			cnt++;
	}
	if(cnt<=1)
	{
		for(int i=l;i<=r;i++)
		{
			if(s[i]=='(')t++;
			if(s[i]==')')t--;
			if(s[i]=='&'&&!t)
			{
				ll a=calc(l,i-1);
				if(a==0)
				{
					ra++;
					return 0;
				}
				ll b=calc(i+1,r);
				return a&b;
			}
		}
	}
	else
	{
		for(int i=l;i<=r;i++)
		{
			if(s[i]=='(')t++;
			if(s[i]==')')t--;
			if(s[i]=='&'&&!t)
			{
				ll k=i+1;
				while(s[k]!='&'||t)
				{
					if(s[k]=='(')t++;
					if(s[k]==')')t--;
					k++;
				}
				ll a=calc(l,k-1);
				if(a==0)
				{
					ra++;
					return 0;
				}
				ll b=calc(k+1,r);
				return a&b;
			}
		}
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>s;
	n=s.length();
	cout<<calc(0,n-1)<<'\n'<<ra<<' '<<ro;
	return 0;
}