// CSP-J2022 rp++
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	ll t;cin>>t;
	while(t--)
	{
		ll n,d,e;
		cin>>n>>d>>e;
		ll m=n-d*e+2;
		ll delta=m*m-4*n;
		if(delta<0)		
			cout<<"NO\n";
		else
		{
			ll t=sqrt(delta);
			if(t*t!=delta)cout<<"NO\n";
			else
			{
				ll p=(m-t)/2,q=(m+t)/2;
				if(m%2!=t%2)cout<<"NO\n";
				else if(p<=0||q<=0)cout<<"NO\n";
				else cout<<p<<' '<<q<<'\n';
			}
		}
	}
	return 0;
}