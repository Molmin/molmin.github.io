#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	ll a,b;cin>>a>>b;
	if(a==1)
	{
		cout<<"1";
		return 0;
	}
	ll res=1;bool f=0;
	for(int i=1;i<=b;i++)
	{
		res*=a;
		if(res>1e9)
		{
			cout<<-1;
			f=1;
			break;
		}
	}
	if(!f)cout<<res;
	return 0;
}