#include<bits/stdc++.h>
using namespace std;
long long a,b,t=1;
bool p=true;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if (a>b) swap(a,b);
	if (a==1||b==1)
	  {
	  	cout<<1;
	  	return 0;
	  }
	for (int i=1;i<=a;i++)
	{
		if (t*b>1000000000){
			cout<<-1;
			return 0;
		}
		else t*=b;
	}
	cout<<t;
}