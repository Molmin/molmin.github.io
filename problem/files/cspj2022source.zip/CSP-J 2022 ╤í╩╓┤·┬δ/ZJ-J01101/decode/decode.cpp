#include<bits/stdc++.h>
using namespace std;
int T;
long long t,n,x,y;
void check()
{
	long long p=(t-sqrt(t*t-4*n))/2,q=(t+sqrt(t*t-4*n))/2;
	if (p>q) swap(p,q);
	if (p+q==t&&p*q==n){
		cout<<p<<' '<<q<<endl;
		return;
	}
	cout<<"NO"<<endl;
	return;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>T;
	while (T--)
	{
		cin>>n>>x>>y;
		t=abs(x*y-n)+2;
		check();
	}
}