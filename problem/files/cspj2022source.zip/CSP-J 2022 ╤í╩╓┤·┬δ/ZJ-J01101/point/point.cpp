#include<bits/stdc++.h>
using namespace std;
struct node{
	int x,y;
}a[510];
int n,m,f[5010][5010],maxx,maxy,maxt;
void dfs(int x,int y,int num)
{
	if (x>maxx||y>maxy) 
	{
		maxt=max(maxt,num);
		return;
	}
	if (f[x+1][y]==1) dfs(x+1,y,num+1);
	if (f[x][y+1]==1) dfs(x,y+1,num+1);
	maxt=max(maxt,num);
	return;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) 
	{
		cin>>a[i].x>>a[i].y;
		f[a[i].x][a[i].y]=1;
		maxx=max(maxx,a[i].x),maxy=max(maxy,a[i].y);
	}
	for (int i=1;i<=n;i++)
		dfs(a[i].x,a[i].y,1);
	cout<<maxt;
}