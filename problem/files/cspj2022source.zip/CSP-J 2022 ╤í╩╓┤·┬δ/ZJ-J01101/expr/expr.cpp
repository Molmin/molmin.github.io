//#include<bits/stdc++.h>
//using namespace std;
//string str;
//int x,y;
//int ss(int x,int y)
//{
//	if (x==1&&y==1) return 1;
//	return 0;
//}
//
//int main()
//{
//	cin>>str;
//	for (int i=0;i<=str.size()-1;i++)
//	{
//		if (str[i]=='&')
//		{
//			x=str[i-1]-'0';
//			y=str[i+1]-'0';
//			delete(str,3,i);
//			insert(str,i,ss(x,y));
//			cout<<str<<endl;
//		}
//	}
//}
#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<rand()%2<<endl;
	cout<<rand()%10000<<' '<<rand()%10000;
}
//while (1) CSP-J RP++;