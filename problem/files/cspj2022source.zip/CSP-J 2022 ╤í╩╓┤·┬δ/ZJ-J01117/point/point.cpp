#include <bits/stdc++.h>
int n,k;
int x[505],y[505];
int dp[505][505];
int f[505][505];
int ans;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x[i],&y[i]);
		f[x[i]][y[i]]=1;
	}
	for(int i=1;i<=n;i++){
			int tmp=k;
			int u=x[i],v=y[i];
			int l=1;//jia de
			while(tmp>=0&&l<=tmp){
				if(f[u+l][v]==1||f[u][v+l]==1){
					tmp-=l-1;
					dp[x[i]][y[i]]++;
					if(f[u+l][v]==1) u+=l;
					else v+=l;
					l=1;
				}else{
					l++;
				}
			}
	}
	for(int i=1;i<=n;i++){
		if(dp[x[i]][y[i]]>ans) ans=dp[x[i]][y[i]];
	}
	printf("%d\n",ans*2);
	return 0;
}
