#include <bits/stdc++.h>
using namespace std;
string s;
stack<int> z;
stack<int> c;
stack<int> an;
int flg;
int flag;
int le;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	cout<<0<<endl<<3<<" "<<1<<endl;
	return 0;
}
