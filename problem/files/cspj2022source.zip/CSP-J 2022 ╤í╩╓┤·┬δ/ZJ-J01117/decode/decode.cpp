#include <bits/stdc++.h>
using namespace std;
int k;
long long n,e,d;
int flg=1;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	while(k--){
		flg=1;
		scanf("%lld%lld%lld",&n,&e,&d);
		int h=n+2-e*d;
		int minn,maxn;
		for(int i=1;i<=h/2;i++){
			if((h-i)*i==n&&(h-i-1)*(i-1)+1==e*d){
				printf("%d %d\n",i,h-i);
				flg=0;
				break;
			}
		}
		if(flg==1) puts("NO");
	}
	return 0;
}
