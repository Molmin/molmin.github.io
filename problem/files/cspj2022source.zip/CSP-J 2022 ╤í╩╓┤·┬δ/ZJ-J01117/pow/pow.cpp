#include <bits/stdc++.h>
using namespace std;
int a,b;
int c=1000000000;
long long ans;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%d%d",&a,&b);
	ans=pow(a,b);
	if(ans>c||ans<0) printf("-1\n");
	else printf("%d\n",ans);
	return 0;
}
