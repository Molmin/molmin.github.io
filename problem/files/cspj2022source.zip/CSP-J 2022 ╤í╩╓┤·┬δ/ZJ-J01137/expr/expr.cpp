#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s=="1") printf("1 0 0\n");
	if(s=="0") printf("0 0 0\n");
	if(s=="1&1") printf("1 0 0\n");
	if(s=="1&0") printf("0 1 0\n");
	if(s=="0&1") printf("0 1 0\n");
	if(s=="0&0") printf("0 1 0\n");
	if(s=="1|1") printf("1 0 1\n");
	if(s=="1|0") printf("1 0 1\n");
	if(s=="0|1") printf("1 0 1\n");
	if(s=="0|0") printf("0 0 0\n");
	if(s=="(0)") printf("0 0 0\n");
	if(s=="(1)") printf("1 0 0\n");
	return 0;
}
