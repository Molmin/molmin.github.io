#include<bits/stdc++.h>
using namespace std;
int n,k,i,j,ma,f[510][110],p,l;
struct node{
	int x,y;
}a[510];
bool cmp(node a,node b){
	return a.x<b.x||a.x==b.x&&a.y<b.y;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(i=1;i<=n;i++) scanf("%d%d",&a[i].x,&a[i].y);
	sort(a+1,a+1+n,cmp);
	for(i=1;i<=n;i++)
		for(j=0;j<=k;j++) f[i][j]=j+1;
	ma=k+1;
	for(i=2;i<=n;i++){
		for(j=1;j<i;j++)
			if(a[i].y>=a[j].y){
				l=a[i].x-a[j].x+a[i].y-a[j].y-1;
				for(p=l;p<=k;p++)
					f[i][p]=max(f[i][p],f[j][p-l]+1+l),ma=max(ma,f[i][p]);
			}
	}
	printf("%d\n",ma);
	return 0;
}
