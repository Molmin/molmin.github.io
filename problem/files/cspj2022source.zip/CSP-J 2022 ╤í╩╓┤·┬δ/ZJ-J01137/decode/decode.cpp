#include<bits/stdc++.h>
using namespace std;
long long T,n,d,e,p,qq;
double q1,q2,l,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld%lld%lld",&n,&d,&e);
		if((e*d-n-2)*(e*d-n-2)-4*n<0){printf("NO\n");continue;}
		l=sqrt((e*d-n-2)*(e*d-n-2)-4*n);
		q1=1.0*(n+2-e*d+l)/2;q2=1.0*(n+2-e*d-l)/2;q=q1;
		if(floor(q)==q){
			qq=floor(q);
			p=n/qq;if(p>qq) swap(p,qq);
			printf("%lld %lld\n",p,qq);
		}
		else printf("NO\n");
	}
	return 0;
}
