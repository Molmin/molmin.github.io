#include<bits/stdc++.h>
using namespace std;
long long a,b,x,i;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if(a==1) printf("1\n");
	else{
		x=a;
		for(i=2;i<=b;i++){
			x=x*a;
			if(x>1000000000){printf("-1\n");return 0;} 
		}
		printf("%lld\n",x);
	}
	return 0;
}
