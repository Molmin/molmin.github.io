#include<bits/stdc++.h>
using namespace std;
map<long long,int>dp;
int n,k,maxn;
long long x[501],y[501];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
		dp[x[i]*1000000000+y[i]]=1;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			long long tmp=x[j]*1000000000+y[j];
			dp[tmp]=max(dp[tmp-1e9]+1,dp[tmp]);
			dp[tmp]=max(dp[tmp-1]+1,dp[tmp]);
			maxn=max(maxn,dp[tmp]);
		}
	}
	cout<<maxn;
	
	return 0;
}

