#include<bits/stdc++.h>
using namespace std;
bool fl=0;
long long maxn=1e9;
long long fspow(long long a,long long b){
	long long ans;
	if(b==0)return 1;
	if(b%2==0)ans=fspow(a*a,b/2);
	else ans=a*fspow(a,b-1);
	if(ans>maxn||a>maxn)fl=1;
	if(fl)return 0;
	return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	long long x=fspow(a,b);
	if(fl)cout<<-1;
	else cout<<x;
	return 0;
}

