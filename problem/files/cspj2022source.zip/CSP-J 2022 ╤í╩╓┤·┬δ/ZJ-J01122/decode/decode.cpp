#include<bits/stdc++.h>
using namespace std;
int q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>q;
	while(q--){
		long long n,e,d,f=0;
		scanf("%lld%lld%lld",&n,&e,&d);
		long long l=0,tmp=n-e*d+2,r=tmp+1;
		while(l+1<r){
			long long mid=(l+r)/2;
			if(tmp<mid||(tmp-mid)*mid>n)r=mid;
			else if((tmp-mid)*mid<n)l=mid;
			else {
				f=1;
				printf("%lld %lld\n",mid,tmp-mid);
				break;
			}
		}
		if(!f)printf("NO\n");
		
	}
	return 0;
}

