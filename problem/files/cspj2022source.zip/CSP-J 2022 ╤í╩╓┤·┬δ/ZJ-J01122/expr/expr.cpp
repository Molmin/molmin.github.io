#include<bits/stdc++.h>
using namespace std;
stack<int> num,num1;
stack<char> b,c;
int ans1,ans2,l1,l2,l3;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	cin>>a;
	for(int i=0;i<a.size();i++){
		if(a[i]=='|')l1++;
		else if(a[i]=='&')l2++;
		else if(a[i]=='(')l3++;
	}
	if(l1==0){
		bool f=1;
		for(int i=0;i<a.size();i++){
			if(a[i]=='0'&&i+1<a.size()&&a[i+1]=='&'){
			f=0;
			while(i+1<a.size()&&a[i+1]=='&'){
				if(i+2<a.size()&&a[i+2]=='('){
					int cnt=1;
					i=i+3;
					while(cnt&&i<a.size()){
						if(a[i]==')')cnt--;
						else if(a[i]=='(')cnt++;
						i++;
					}
				}
				else i+=2;
				ans1++;
			}
			i--;
			}
		}
		cout<<f<<endl<<ans1<<" "<<ans2;
	}
	if(l2==0){
		bool f=0;
		for(int i=0;i<a.size();i++){
			if(a[i]=='1'&&i+1<a.size()&&a[i+1]=='|'){
			f=1;
			while(i+1<a.size()&&a[i+1]=='|'){
				if(i+2<a.size()&&a[i+2]=='('){
					int cnt=1;
					i=i+3;
					while(cnt&&i<a.size()){
						if(a[i]==')')cnt--;
						else if(a[i]=='(')cnt++;
						i++;
					}
				}
				else i+=2;
				ans2++;
			}
			i--;
			}
		}
		cout<<f<<endl<<ans1<<" "<<ans2;
	}
	return 0;
}

