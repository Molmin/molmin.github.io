#include<bits/stdc++.h>
using namespace std;

int x[505],y[505];
int edge[505][505];
int ans = 0;

void longest(int i,int dep)
{
	if(edge[i][0] == 0)
	{
		ans = max(ans,dep);
		return;
	}
	for(int j = 1;j <= edge[i][0];j++)
		longest(edge[i][j],dep + 1);
}

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin >> n >> k;
	for(int i = 1;i <= n;i++)
		cin >> x[i] >> y[i];
	for(int i = 1;i <= n;i++)
		for(int j = i + 1;j <= n;j++)
			if(x[i] - x[j] == 1 && y[i] == y[j] || y[i] - y[j] == 1 && x[i] == x[j])
				edge[j][++edge[j][0]] = i;
			else if(x[j] - x[i] == 1 && y[j] == y[i] || y[j] - y[i] == 1 && x[j] == x[i])
				edge[i][++edge[i][0]] = j;
	for(int i = 1;i <= n;i++)
		longest(i,1);
	cout << ans + k;	
}
