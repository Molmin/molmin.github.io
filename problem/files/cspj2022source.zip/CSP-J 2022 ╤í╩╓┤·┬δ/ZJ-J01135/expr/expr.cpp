#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin >> s;
	bool res;
	int ands = 0,ors = 0;
	if(s.size() == 1)
	{
		cout << s[0] << endl << 0 << " " << 0;
		exit(0);
	}
	else if(s.size() == 3)
	{
		if(s[1] == '|')
		{
			if(s[0] == '1')
				ors++;
			cout << ((s[0] - '0') | (s[2] - '0'))<< endl << ands << " " << ors;		
		}
		if(s[1] == '&')
		{
			if(s[0] == '0')
				ands++;
			cout << ((s[0] - '0') & (s[2] - '0'))<< endl << ands << " " << ors;		
		}
	}
	else
	{
		for(int i = 0;i < s.size();i++)
			if(s[i] == '&')
			{
				if(s[i - 1] == '0')
					ands++;
				s[i + 1] = ((s[i - 1] - '0') & (s[i + 1] - '0')) + '0';
				s[i - 1] = s[i] = '!';
			}
		int i = 0;
		while(s[i] == '!')
			i++;
		bool pre = s[i] - '0';
		for(;i < s.size();i++)
		{
			if(s[i] == '|')
			{
				if(pre == 1)
					ors++;
				while(s[i++] == '!');
				pre = pre | (s[i] - '0');
			}
		}
		cout << pre << endl << ands << " " << ors;
	}
}
