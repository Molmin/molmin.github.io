#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin >> a >> b;
	int c = pow(a,b);
	if(c <= 0 || c > 1000000000)
		cout << -1;
	else
		cout << c;
}
