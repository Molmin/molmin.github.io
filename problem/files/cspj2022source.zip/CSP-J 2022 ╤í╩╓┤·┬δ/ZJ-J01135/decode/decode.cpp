#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	for(int i = 1;i <= k;i++)
	{
		long long n,e,d;
		cin >> n >> e >> d;
		long long ji = n;
		long long he = 2 + n - e * d;
		long long cha = sqrt(he * he - 4 * ji);
		if(cha == sqrt(he * he - 4 * ji))
		{
			if((he - cha) % 2 == 0 && he > cha && (he + cha) % 2 == 0)
				cout << (he - cha) / 2 << " " << (he + cha) / 2 << endl;
			else
				cout << "NO" << endl;
		}
		else
			cout << "NO" << endl;
	}
}
