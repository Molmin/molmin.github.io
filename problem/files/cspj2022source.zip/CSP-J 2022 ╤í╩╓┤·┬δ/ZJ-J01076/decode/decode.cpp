#include<bits/stdc++.h>
using namespace std;
int k;
void calu(long long x,long long y){
	long long delta = x*x-4*y;
	if(delta < 0){
		printf("NO\n");
		return;
	}
	if(sqrt(delta)!=(int)(sqrt(delta)) ){
		printf("NO\n");
		return;
	}
	double p = (x*1.0-sqrt(delta))/2;
	double q = (x*1.0+sqrt(delta))/2;
	if(p != int(p)){
		printf("NO\n");
		return;
	}
	int u = int(p);
	int v = int(q);
	printf("%d %d\n",u,v);
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int i = 1;i <= k;i++){
		long long n,m,d,e;
		scanf("%lld%lld%lld",&n,&e,&d);
		m = n-e*d+2;
		calu(m,n);
	}
	return 0;
	
}