#include<bits/stdc++.h>
using namespace std;
int n,T,f[501][501];
struct Point{
	int x,y,s;
}p[501];

bool cmp(Point A,Point B){
	return A.s<B.s;
}
int ans = 0;
void dfs(int l,int r){
	if(r <= l)return;
	if(p[r].s-p[l].s+1-f[l][r] > T){
		dfs(l+1,r);
		dfs(l,r-1);
	}
	else{
		ans = max(ans,T+f[l][r] );
	}
}

bool iscon(int i,int j){
	if(p[i].x == p[j].x && abs(p[i].y-p[j].y) == 1)return true;
	if(p[i].y == p[j].y && abs(p[i].x-p[j].x) == 1)return true;
	if(f[i][j] == abs(p[i].s-p[j].s)+1)return true;
	return false;
}

void kdy_0(){
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			if(i == j)continue;
			if(iscon(i,j)){
				f[i][j] = f[j][i] = 2;
			}
			
		}
	}
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			if(i == j)continue;
			for(int k = 1;k <= n;k++){
				if((p[i].x-p[k].x)*(p[k].x - p[j].x) >= 0 && (p[i].y-p[k].y)*(p[k].y - p[j].y) >= 0 && iscon(i,k) && iscon(k,j)){
					f[i][j] = max(f[i][j],f[i][k]+f[k][j]-1);
				}
			}
			f[j][i] = f[i][j];
		}
	}
	
	int max_f = 0;
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			max_f = max(max_f,f[i][j]);
		}
	}
	cout << max_f;
}

int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&T);
	for(int i = 1;i <= n;i++){
		scanf("%d%d",&p[i].x,&p[i].y);
		p[i].s = p[i].x+p[i].y;
	}
	sort(p+1,p+n+1,cmp);
	
	if(T == 0){
		kdy_0();
		return 0;
	}
	
	
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			if(i == j)continue;
			if(p[i].x == p[j].x && abs(p[i].y-p[j].y) == 1){
				f[i][j] = f[j][i] = 2;
			}
			if(p[i].y == p[j].y && abs(p[i].x-p[j].x) == 1){
				f[i][j] = f[j][i] = 2;
			}
			bool flag = 0;
			for(int k = 1;k <= n;k++){
				if(k == i || k == j)continue;
				if((p[i].x-p[k].x)*(p[k].x - p[j].x) >= 0 && (p[i].y-p[k].y)*(p[k].y - p[j].y) >= 0){
					flag = 1;
					break;
				}
			}
			if(!flag){
				f[i][j] = f[j][i] = 2;
			}
		}
	}
	for(int i = 1;i <= n;i++){
		for(int j = 1;j <= n;j++){
			if(i == j)continue;
			for(int k = 1;k <= n;k++){
				if((p[i].x-p[k].x)*(p[k].x - p[j].x) >= 0 && (p[i].y-p[k].y)*(p[k].y - p[j].y) >= 0){
					f[i][j] = max(f[i][j],f[i][k]+f[k][j]-1);
				}
			}
			f[j][i] = f[i][j];
		}
	}
//	int max_f = 0;
//	for(int i = 1;i <= n;i++){
//		for(int j = 1;j <= n;j++){
//			max_f = max(max_f,f[i][j]);
//		}
//	}
//	//cout << max_f+T;
	dfs(1,n);
	cout << ans;
	return 0;
	
}