#include<bits/stdc++.h>
using namespace std;
unsigned long long a,b;
int pow(unsigned long long x,unsigned long long b){
	unsigned long long ans = 1;
	while(b > 0){
		if(b&1)ans *= x;
		b /= 2;
		x = x*x;
		if(ans > 1e9)return -1;
	}
	return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin >> a >> b;
	if(a == 1){
		cout << 1;
		return 0;
	}
	if(a > 1 && b > 40){
		cout << -1;
		return 0;
	}
	cout << pow(a,b);
	return 0;
	
}