#include<bits/stdc++.h>
using namespace std;
string s;
int len;
void del(int x1,int x2,string s1){
	string sss = s;
	int l1 = s1.length()-1;
	for(int i = x1,j = 0;i <= l1+x1,j <= l1;i++,j++){
		s[i] = s1[j];
	}
	for(int i = x2+1,j = l1+x1+1;i <= len;i++,j++){
		s[i] = sss[j];
	}
}
//4123890
//445890
int main(){
//	freopen("expr.in","r",stdin);
//	freopen("expr.out","w",stdout);
	getline(cin,s);
	len = s.length()-1;
	cout << del(1,3,"45");
	return 0;
	
}