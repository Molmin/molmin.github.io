#include<bits/stdc++.h>
#define int long long
using namespace std;
int F;
int k,n,p,q;
void read(int &x){
	x=0;F=1;
	char c=getchar();
	while (!isdigit(c) && c!='-')c=getchar();
	if (c=='-')F=0,c=getchar();
	while (isdigit(c))x=(x<<3)+(x<<1)+c-48,c=getchar();
	if (!F)x=-x;
}
signed main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	read(k);
	for (int i=1;i<=k;i++){
		read(n);read(p);read(q);
		//n=x*y,p*q=(x-1)*(y-1)+1
		p*=q;
		q=0;
		n=n-p+2;//n->x+y
		p+=n-2;//p->xy
		bool flag=true;
		if (n*n-4*p<0)flag=false;
		else{
			int x=(int)floor(sqrt(n*n-4*p));
			//y=n-x;
			//(n-x)x=p;
			//x*x-n*x+p=0
			//x=|n(+-)sqrt(n*n-4*p)|
			if (x*x!=n*n-4*p)flag=false;
			else{
				int P=abs((-n+x)/2);
				int Q=p/P;
				if (P*Q!=p || P+Q!=n){
					P=abs((-n-x)/2);
					Q=p/P;
				}
				if (P*Q!=p || P+Q!=n)flag=false;
				else if (P<=0 || Q<=0)flag=false;
				else printf("%lld %lld\n",P,Q);
			}
		}
		if (!flag)printf("NO\n");
	}
	return 0;
}
