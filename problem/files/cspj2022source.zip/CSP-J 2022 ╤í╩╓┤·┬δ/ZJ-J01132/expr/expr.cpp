#include<bits/stdc++.h>
#define int long long
using namespace std;
int F,ans1,ans2;
string s;
char s2[2000005];
vector<int> v1[2000005],v2[2000005];
queue<int> q;
void read(int &x){
	x=0;F=1;
	char c=getchar();
	while (!isdigit(c) && c!='-')c=getchar();
	if (c=='-')F=0,c=getchar();
	while (isdigit(c))x=(x<<3)+(x<<1)+c-48,c=getchar();
	if (!F)x=-x;
}

int fi1(int x,int y,int k){
	int l=1,r=v1[k].size(),bao=0;
	while (l<=r){
		int mid=(l+r)>>1;
		if (v1[k][mid-1]<=y){
			l=mid+1;
			bao=mid;
		}else{
			r=mid-1;
		}
	}
	if (bao==0)return 0;
	if(v1[k][bao-1]>=x)return bao;
	return 0;
}

int fi2(int x,int y,int k){
	int l=1,r=v2[k].size(),bao=0;
	while (l<=r){
		int mid=(l+r)>>1;
		if (v2[k][mid-1]<=y){
			l=mid+1;
			bao=mid;
		}else{
			r=mid-1;
		}
	}
	if (bao==0)return 0;
	if(v2[k][bao-1]>=x)return bao;
	return 0;
}

bool dfs(int l,int r,int k){
	int f1=-1,f2=-1;
	if (fi1(l,r,k)==0 && fi2(l,r,k)==0 && s[l]=='(' && s[r]==')')k++,l++,r--;
	if (fi1(l,r,k)!=0)f1=v1[k][fi1(l,r,k)-1];
	if (fi2(l,r,k)!=0)f2=v2[k][fi2(l,r,k)-1];
	if (f2==-1 && f1==-1){//not have '&' or '|' only a number and some->()
		if (s[l]=='1')return 1;
		return 0;
	}
	if (f1!=-1){//have '|'
		bool f=dfs(l,f1-1,k);
		if (f==1){//duan'lu->2
			ans2++;return 1;
		}else return dfs(f1+1,r,k);
	}else{//only have '&'
		bool f=dfs(l,f2-1,k);
		if (f==0){//duan'lu->1
			ans1++;return 0;
		}else return dfs(f2+1,r,k);
	}
}

signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",&s2);
	s=s2;
	int len=0;
	for (int i=0;i<s.length();i++){
		if (s[i]=='(')q.push(i),len++;
		if (s[i]==')')q.pop(),len--;
		if (s[i]=='&'){v2[len].push_back(i);}
		if (s[i]=='|'){v1[len].push_back(i);}
	}
	if (dfs(0,s.length()-1,0))printf("1\n");
	else printf("0\n");
	printf("%lld %lld",ans1,ans2);
	return 0;
}