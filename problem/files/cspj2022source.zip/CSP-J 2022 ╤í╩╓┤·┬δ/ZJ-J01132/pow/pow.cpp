#include<bits/stdc++.h>
#define int long long
using namespace std;
int F;
int a,b;
void read(int &x){
	x=0;F=1;
	char c=getchar();
	while (!isdigit(c) && c!='-')c=getchar();
	if (c=='-')F=0,c=getchar();
	while (isdigit(c))x=(x<<3)+(x<<1)+c-48,c=getchar();
	if (!F)x=-x;
}
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	read(a);read(b);
	if (a==1){
		printf("1");
	}else{
		int s=1;bool flag=true;
		for (int i=1;i<=b;i++){//min(b,loga(n))+1->max:32
			s*=a;
			if (s>1e9){
				puts("-1");
				flag=false;
				break;
			}
		}
		if (flag)printf("%lld\n",s);
	}
	return 0;
}