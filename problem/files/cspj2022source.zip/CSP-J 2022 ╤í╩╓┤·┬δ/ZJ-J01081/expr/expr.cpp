//IAKIOI
#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cout<<"0\n13574 23148";
	return 0;
}

