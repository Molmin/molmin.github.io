//IAKIOI
#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	scanf("%lld%lld",&a,&b);
	if(log(10e9)/log(a)<b){
		cout<<-1<<endl;
	}else{
		cout<<(long long)pow(a,b)<<endl;
	}
	return 0;
}

