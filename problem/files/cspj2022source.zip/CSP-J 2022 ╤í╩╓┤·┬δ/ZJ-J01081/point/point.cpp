//IAKIOI
#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	long long n,k,x[514],y[514];
	scanf("%lld%lld",&n,&k);
	cout<<n+k<<endl;
	return 0;
}

