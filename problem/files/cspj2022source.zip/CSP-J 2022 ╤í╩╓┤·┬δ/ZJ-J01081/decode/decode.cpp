//IAKIOI
#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	scanf("%d",&k);
	for(int i=1;i<=k;i++){
		long long n,e,d,m;
		double ans;
		scanf("%lld%lld%lld",&n,&e,&d);
		m=n-e*d+2;
		ans=(m+sqrt(m*m-4*n))/2.0;
		if(ans==(int)ans){
			cout<<(int)(n/ans)<<" "<<(int)ans<<endl;
		}else{
			printf("NO\n");
		}
	}
	return 0;
}

