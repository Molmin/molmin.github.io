#include<bits/stdc++.h>
using namespace std;
int k;
long long n[100005],e[100005],d[100005];
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for (int i=1;i<=k;i++)
	{
		scanf("%lld%lld%lld",&n[i],&d[i],&e[i]);
		long long p=(sqrt((n[i]-e[i]*d[i]+2)*(n[i]-e[i]*d[i]+2)-4*n[i])+(n[i]-e[i]*d[i]+2))/2;
		long long q=n[i]/p;
		if (p*q!=n[i]||(p-1)*(q-1)+1!=e[i]*d[i]) printf("NO\n");
		else if (p<q) printf("%lld %lld\n",p,q);
		else printf("%lld %lld\n",q,p);
	}
	return 0;
}