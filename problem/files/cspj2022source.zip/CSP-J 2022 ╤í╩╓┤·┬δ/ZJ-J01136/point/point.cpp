#include<bits/stdc++.h>
using namespace std;
int n,k,a[505],b[505];
int main()
{
	//freopen("point.in","r",stdin);
	//freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for (int i=1;i<=n;i++) scanf("%d",&a[i]);
	for (int i=1;i<=k;i++) scanf("%d",&b[i]);
	for (int i=1;i<=k;i++)
	{
		
	}
	return 0;
}