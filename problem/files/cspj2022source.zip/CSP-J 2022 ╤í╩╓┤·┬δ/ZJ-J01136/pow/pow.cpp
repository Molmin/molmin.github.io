#include<bits/stdc++.h>
using namespace std;
long long a,b,ans;
bool flag=0;
long long ksm(long long x,long long y)
{
	if (y==2) return x*x;
	if (y==1) return x;
	if (y%2==0) {
		long long t=ksm(x,y/2);
		if (t*t>10e9) {
			flag=1;
			return 0;
		}
		else return t*t;
	}
	else{
		long long t=ksm(x,y/2);
		if (t*t*x>10e9) {
			flag=1;
			return 0;
		}
		else return t*t*x;
	}
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ans=ksm(a,b);
	if (flag) printf("%d",-1);
	else printf("%lld",ans);
	return 0;
}