#include<bits/stdc++.h>
using namespace std;
struct node{
	char w;
	int id;
};
string s;
int x,y,cnt,flag,ans;
stack<char> c;
stack<node> b;
stack<int> a;
void f(int k)
{
	if (k==flag) return;
	while (k<flag)
	{
		node tt;
		node t1;
		t1.w=b.top().w;
		t1.id=b.top().id;
		b.pop();
		node t2;
		t2.w=b.top().w;
		t2.id=b.top().id;
		b.pop();
		if (c.top()=='|'){
			if (t2.w==1) y++;
			tt.id=t1.id+1;
			tt.w=t1.w|t2.w;
			b.push(tt);
			c.pop();
		}
		else{
			if (t2.w==0) x++;
			tt.id=t1.id+1;
			tt.w=t1.w&t2.w;
			b.push(tt);
			c.pop();
		}
		k=tt.id;
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	string t=s;
	int tp;
	for (int i=0;i<t.length();i++)
	{
		tp=0;
		bool tf=1;
		if (t[i]=='&') {
				s.insert(i-2+cnt,i-1+cnt,'(');
				cnt++;
				s.insert(i+2+cnt,i+3+cnt,')');
			
		}
	}
	s='('+s+')';
	for (int i=0;i<s.length();i++)
	{
		if (s[i]=='0') {
			node tt;
			tt.w=0;
			tt.id=i;
			b.push(tt);
		}
		else if (s[i]=='1') {
			node tt;
			tt.w=1;
			tt.id=i;
			b.push(tt);
		}
		if (s[i]=='|') c.push('|');
		else if (s[i]=='&') c.push('&');
		if (s[i]=='(') a.push(i);
		if (s[i]==')') {
			flag=i;
			f(a.top());
			a.pop();
		}
	}
	printf("%d\n%d %d",b.top().w,x,y);
	return 0;
}