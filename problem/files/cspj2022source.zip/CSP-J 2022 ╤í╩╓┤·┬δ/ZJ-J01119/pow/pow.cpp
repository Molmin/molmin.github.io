#include<bits/stdc++.h>
using namespace std;
#define int long long
int x,y,ans;
bool flag=0;
int poww(int a,int b){
	if(flag)return 0;
	if(a>1e9){
		flag=1;
		return 0;
	}
	if(b==1)return a;
	int s=0;
	if(b%2==0)s=poww(a*a,b/2);
	else s=poww(a*a,b/2)*a;
	if(s>1e9){
		flag=1;
		return 0;
	}
	return s;
}
signed main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>x>>y;
	ans=poww(x,y);
	if(flag)cout<<-1<<endl;
	else cout<<ans<<endl;
	return 0;
}
/*
a^b=(a*a)^(b/2)
*/