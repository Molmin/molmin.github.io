#include<bits/stdc++.h>
using namespace std;
const int N=2e6+10;
int n,ansa,anso;
char c[N];
string s0;
int cn[N];
stack<int> st;
bool dfs(int l,int r){
	if(c[l]=='('&&c[r]==')'&&cn[l]==r)l++,r--;
	//cout<<"                       "<<l<<" "<<r<<"\n";
	if(l==r){
		if(c[l]=='1'){
			bool t=1;
			//cout<<l<<" "<<r<<"  "<<t<<" \n";
			return t;
		}
		else if(c[l]=='0'){
			bool t=0;
			//cout<<l<<" "<<r<<"  "<<t<<" \n";
			return t;
		}
	}
	int cnt=0,k=0;
	for(int i=r;i>=l;i--){
		if(cnt==0&&c[i]=='|'){
			k=i;break;
		}
		if(c[i]==')')cnt++;
		if(c[i]=='(')cnt--;
	}
	if(k!=0){
		bool ls=dfs(l,k-1);
		if(ls==1){
			anso++;
			bool t=1;
			//cout<<l<<" "<<r<<"  "<<t<<" \n";
			return t;
		}else {
			bool t=dfs(k+1,r);
			//cout<<l<<" "<<r<<"  "<<t<<" \n";
			return t;
		}
	}
	cnt=0;k=0;
	for(int i=r;i>=l;i--){
		if(cnt==0&&c[i]=='&'){
			k=i;break;
		}
		if(c[i]==')')cnt++;
		if(c[i]=='(')cnt--;
	}
	bool ls=dfs(l,k-1);
	if(ls==0){
		ansa++;
		bool t=0;
		//cout<<l<<" "<<r<<"  "<<t<<" \n";
		return t;
	}else {
		bool t=dfs(k+1,r);
		//cout<<l<<" "<<r<<"  "<<t<<" \n";
		return t;
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s0;
	int l0=s0.size();
	bool o1=1,o2=1,o3=1;
	for(int i=0;i<l0;i++){
		c[i+1]=s0[i];
		if(c[i+1]=='&')o1=0;
		if(c[i+1]=='|')o2=0;
		if(c[i+1]=='('||c[i+1]==')')o3=0;
	}
	n=l0;
	if(o1){//quan dou shi |
		for(int i=1;i<=n;i++){
			if(c[i]=='1'){
				//cout<<"CCC\n";
				cout<<1<<"\n";
				cout<<0<<" ";
				int j=i+1;
				bool bol=1;
				while(j<=n)if(c[j]!=')'){bol=0;break;}
				if(bol){
					cout<<0<<"\n";
				}else cout<<1<<"\n";
				return 0;
			}
		}
		//cout<<"AAA\n";
		cout<<0<<"\n";
		cout<<0<<" "<<0<<"\n";
		return 0;
	}
	if(o2){//quan dou shi &
		for(int i=1;i<=n;i++){
			if(c[i]=='0'){
				cout<<0<<"\n";
				int j=i+1;
				bool bol=1;
				while(j<=n)if(c[j]!=')'){bol=0;break;}
				if(bol){
					cout<<0<<" "<<0<<"\n";
				}else cout<<1<<" "<<0<<"\n";
				return 0;
			}
		}
		//cout<<"BBB\n";
		cout<<1<<"\n";
		cout<<0<<" "<<0<<"\n";
		return 0;
	}
	for(int i=1;i<=n;i++){
		if(c[i]=='(')st.push(i);
		if(c[i]==')'){
			cn[st.top()]=i;
			st.pop();
		}
	}
	bool ans=dfs(1,n);
	cout<<ans<<"\n";
	cout<<ansa<<" "<<anso<<"\n";
	return 0;
}













