#include<bits/stdc++.h>
using namespace std;
#define int long long
int t;
int n,e,d;
signed main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>t;
	while(t--){
		scanf("%lld%lld%lld",&n,&e,&d);
		int m=n-e*d+2;
		bool o=0;
		if(t>1e3&&n>1e9){
			if((m/2)*(m/2)==n){
				cout<<m/2<<" "<<m/2<<endl;
				continue;
			}else {
				cout<<"NO\n";
				continue;
			}
		}
		
		for(int i=1;i*i<=n;i++){
			if(n%i==0){
				int p=min(i,n/i);
				int q=max(i,n/i);
				if(p+q==m){
					cout<<p<<" "<<q<<endl;o=1;
					break;
				}
			}
		}
		if(!o){
			cout<<"NO\n";
		}
	}
	return 0;
}
