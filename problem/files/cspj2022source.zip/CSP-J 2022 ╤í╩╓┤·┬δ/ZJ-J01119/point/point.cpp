#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,k,ans;
int f[510][110];
struct T{
	int x,y;
}a[510];
bool cmp(T a,T b){
	if(a.x!=b.x)return a.x<b.x;
	return a.y<b.y;
}
int hanshu(int i,int j){
	return abs(a[i].x-a[j].x)+abs(a[i].y-a[j].y);
}
signed main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;i++){
		f[i][0]=1;
		for(int j=1;j<i;j++){
			for(int l=0;l<=k;l++){
				if(a[i].y>=a[j].y){
					int t=hanshu(i,j)-1;
					if(l>=t){
						f[i][l]=max(f[i][l],f[j][l-t]+1);
					}
				}
				ans=max(ans,f[i][l]);
				//cout<<f[i][l]<<" ";
			}
		}
		//cout<<endl;
	}
	ans+=k;
	cout<<ans<<endl;
	return 0;
}
