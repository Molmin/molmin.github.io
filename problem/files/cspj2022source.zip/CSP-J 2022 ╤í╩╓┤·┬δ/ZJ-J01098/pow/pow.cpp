#include<bits/stdc++.h>
using namespace std;
int a,b;
long long sum=1;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	for(int i=1;i<=b;i++){
		sum*=a;
		if(sum>1e9){
			cout<<-1;
			return 0;
		}
	}
	cout<<sum;
	return 0;
}