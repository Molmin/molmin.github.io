#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int k;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++){
		ll n,d,e;
		cin>>n>>d>>e;
		ll tmp=n-e*d+2;//p+q=tmp,p*q=n
		ll z=tmp;
		tmp=1ll*tmp*tmp;
		tmp=tmp-4ll*n;
		ll x=sqrt(tmp);
		if(x*x==tmp){
			int p=(z+x)/2;
			int q=(z-x)/2;
			if(p>=1&&q>=1){
				if(p>q)swap(p,q);
				cout<<p<<" "<<q<<endl;
			}
			else cout<<"NO"<<endl;
		}
		else cout<<"NO"<<endl;
	}
	return 0;
}