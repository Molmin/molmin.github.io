#include<bits/stdc++.h>
using namespace std;
int n,k,sum,tot,ex,ey,f[2][2]= {1,0,0,1},mx,my,ans;
struct P {
	int x,y;
} a[505];
bool cmp(P a,P b) {
	if(a.x==b.x)return a.y<b.y;
	else if(a.y==b.y)return a.x<b.x;
	else return a.x<b.x&&a.y<b.y;
}
bool mark[105][105];
void dfs(int x,int y,int cnt1,int cnt2) {
	if(x==ex&&y==ey&&cnt2<=k) {
		sum=cnt1;
		tot=cnt2;
		return;
	}
	for(int i=0; i<2; i++) {
		int xx=x+f[i][0],yy=y+f[i][1];
		if(xx<1||xx>mx||yy<1||yy>my)continue;
		if(mark[xx][yy]) {
			dfs(xx,yy,cnt1+1,cnt2);
		} else dfs(xx,yy,cnt1+1,cnt2+1);
	}
}
int dfs2(int x,int y,int cnt1) {
	if(x==ex&&y==ey) {
		return cnt1;
	}
	mark[x][y]=0;
	for(int i=0; i<2; i++) {
		int xx=x+f[i][0],yy=y+f[i][1];
		if(xx<1||xx>mx||yy<1||yy>my)continue;
		if(mark[xx][yy]) {
			mark[xx][yy]=0;
			return dfs2(xx,yy,cnt1+1);
		} else return cnt1;
	}
}
int main() {
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1; i<=n; i++)cin>>a[i].x>>a[i].y,mx=max(a[i].x,mx),my=max(a[i].y,my),mark[a[i].y][a[i].x]=1;
	sort(a+1,a+n+1,cmp);
	if(k==0) {
		for(int i=1; i<=my; i++) {
			for(int j=1; j<=mx; j++) {
				if(mark[i][j]) {
					ans=max(ans,dfs2(i,j,1));
				}
			}
		}
		cout<<ans;
	} else {
		for(int i=1; i<=n; i++) {
			for(int j=i+1; j<=n; j++) {
				if(a[i].x>a[j].x||a[i].y>a[j].y)continue;
				tot=sum=0;
				ex=a[j].x,ey=a[j].y;
				dfs(a[i].x,a[i].y,1,0);
				ans=max(ans,sum);
			}
		}
		cout<<ans;
	}

	return 0;
}