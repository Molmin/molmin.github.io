#include<bits/stdc++.h>
using namespace std;
string s;
stack<char> fh;
stack<int> num;
int cnt1,cnt2;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int len=s.size();
	for(int i=0;i<len;i++){
		if(s[i]=='0'||s[i]=='1')num.push(s[i]-'0');
		else if(s[i]=='('||s[i]=='&'||s[i]=='|')fh.push(s[i]);
		else if(s[i]==')'){
			while(!num.empty()&&!fh.empty()){
				char ch=fh.top();fh.pop();
				if(ch=='(')break;
				int a=num.top();num.pop();
				int b=num.top();num.pop();
				if(ch=='&'){
					if(b==0)cnt1++;
					num.push(a&b);
				}
				else if(ch=='|'){
					if(b==1)cnt2++;
					num.push(a|b);
				}
			}
		}
	}
	cout<<num.top()<<endl;
	cout<<cnt1<<" "<<cnt2<<endl;
	return 0;
}