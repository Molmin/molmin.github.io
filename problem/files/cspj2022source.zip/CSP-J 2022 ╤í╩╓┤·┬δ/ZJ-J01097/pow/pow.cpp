#include<bits/stdc++.h>
#define int long long 
using namespace std;
int a,b;
int res=1;
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1){
		cout<<a;
		return 0;
	}
	for(int i=0;i<b;i++){
		res*=a;
		if(res>1000000000) {
			cout<<-1;
			return 0;
		}
	}
	cout<<res;
	return 0;
}
