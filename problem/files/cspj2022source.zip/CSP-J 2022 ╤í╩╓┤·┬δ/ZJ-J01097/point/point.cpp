#include<bits/stdc++.h>
using namespace std;
int n,k;
struct node {
	int x,y;
} a[505],b[505],c[505],d[505];
int idx1,idx2;
bool cmp(node a,node b) {
	if(a.x!=b.x) return a.x<b.x;
	else return a.y<b.y;
}
bool cmp1(node a,node b) {
	if(a.y!=b.y) return a.y<b.y;
	else return a.x<b.x;
}
int res;
int main() {
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	std::ios::sync_with_stdio(false);
	cin>>n>>k;
	for(int i=1; i<=n; i++) {
		cin>>a[i].x>>a[i].y;
		b[i].x=a[i].x;
		b[i].y=a[i].y;
	}
	sort(a+1,a+1+n,cmp);
	sort(b+1,b+1+n,cmp1);
	int tmp1=0,tmp2=0;
	for(int i=1;i<n;i++){
		if((a[i].x+1==a[i+1].x&&a[i].y==a[i+1].y)||(a[i].x==a[i+1].x&&a[i].y+1==a[i+1].y)){
			tmp1++;
		}
		else{
			res=max(res,tmp1);
			tmp1=0;
		}
		if((b[i].x+1==b[i+1].x&&b[i].y==b[i+1].y)||(b[i].x==b[i+1].x&&b[i].y+1==b[i+1].y)){
			tmp2++;
		}
		else{
			res=max(res,tmp2);
			tmp2=0;
		}
	}
	cout<<res+1;
	return 0;
}
