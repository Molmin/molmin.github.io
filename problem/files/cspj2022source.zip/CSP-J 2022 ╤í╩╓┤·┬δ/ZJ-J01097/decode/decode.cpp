#include<bits/stdc++.h>
#define int long long
using namespace std;
int k;
int num1,num2;
signed main() {
	std::ios::sync_with_stdio(false);
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--) {
		int n,d,e;
		cin>>n>>d>>e;
		int a=d*e;
		int sum=n-a+2;
		num1=0;
		num2=sum;
		bool my_ok=false;
		while(num2>=num1) {
			num1++;
			num2--;
			if(num1*num2>n) {
				break;
			}
			for(int i=8; i>=0; i--) {
				int abc=1;
				for(int j=0; j<i; j++) {
					abc*=10;
				}
				while((num1+abc)*(num2-abc)<n&&(num1+abc)<(num2-abc)) {
					num1+=abc;
					num2-=abc;
				}
			}
			if(num1*num2==n) {
				my_ok=true;
				break;
			}
		}
		if(my_ok) {
			cout<<num1<<' '<<num2<<"\n";
		} else {
			cout<<"NO"<<"\n";
		}
	}
	return 0;
}
