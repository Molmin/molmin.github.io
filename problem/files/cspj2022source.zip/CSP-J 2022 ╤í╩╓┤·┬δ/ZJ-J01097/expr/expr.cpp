#include<iostream>
using namespace std;
string s;
int res,res1,res2;
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	if(s.length()==3) {
		if(s[1]=='|') {
			if(s[0]=='1') {
				cout<<1<<endl<<0<<' '<<1;
				return 0;
			}
			if(s[2]=='1') {
				cout<<1<<endl<<0<<' '<<0;
				return 0;
			}
			if(s[2]=='0') {
				cout<<0<<endl<<0<<' '<<0;
				return 0;
			}
		}
		if(s[1]=='&') {
			if(s[0]=='0') {
				cout<<0<<endl<<1<<' '<<0;
				return 0;
			}
			if(s[2]=='1') {
				cout<<1<<endl<<0<<' '<<0;
				return 0;
			}
			if(s[2]=='0') {
				cout<<0<<endl<<0<<' '<<0;
				return 0;
			}
		}
	}
	else{
		cout<<1<<endl<<1<<' '<<0;
	}


	return 0;
}
