#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e9;
int t;
long long _pow(long long n, long long m)
{
	if (n > maxn)
	{
		cout << -1;
		// cout << time(0)-t;
		exit(0);
	}
	if (m == 1)
	{
		return n;
	}
	if (m == 0)
	{
		return 1;
	}
	if (m % 2 == 0)
	{
		long long x = _pow(n, m >> 1);
		if (x > 31650)
		{
			cout << -1;
			// cout << time(0)-t;
			exit(0);
		}
		return x * x;
	}
	else
	{
		long long x = _pow(n, m >> 1);
		if (x > 31650)
		{
			cout << -1;
			// cout << time(0)-t;
			exit(0);
		}
		return x * x * n;
	}
}
int main()
{
	ios::sync_with_stdio(0);
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	cout << _pow(n, m) << endl;
	return 0;
}