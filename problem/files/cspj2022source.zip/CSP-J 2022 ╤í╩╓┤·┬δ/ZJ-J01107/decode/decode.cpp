#include <bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(0);
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	long long K;
	cin >> K;
	while (K--)
	{
		long long n, e, d;
		cin >> n >> e >> d;
		/*
		ed=(p-1)(q-1)+1
		ed=pq-q-p+2
		n=pq
		k=n-e*d+2
		k=q+p
		*/
		long long k = n - e * d + 2;
		/*
		n=pq
		k=p+q
		p=k-q
		n=(k-q)-q
		n=kq-qq
		qq-kq+n=0
		*/
		d = k * k - 4 * n;
		if (d < 0)
		{
			cout << "NO" << endl;
			continue;
		}
		double x1 = (k - sqrt(k * k - 4 * n)) / 2;
		double x2 = (k + sqrt(k * k - 4 * n)) / 2;
		long long x3 = x1;
		long long x4 = x2;
		if ((abs(x1 - x3) < 0.00001) && (abs(x2 - x4) < 0.00001))
		{
			cout << x3 << " " << x4 << endl;
		}
		else
		{
			cout << "NO" << endl;
		}
	}
	return 0;
}