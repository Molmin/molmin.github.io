#include <bits/stdc++.h>
using namespace std;
int ans;
int n, k;
struct point
{
	int x, y;
};
point a[505];
int top = 0;
struct node
{
	int x, y, w;
};
bool cmp(point A, point B)
{
	if (A.x != B.y)
	{
		return A.x < B.y;
	}
	return A.y < B.y;
}
void dfs(point now, int nk, int anss)
{
	if (nk < 0)
	{
		return;
	}
	node tmp[505];
	ans = max(ans, anss + nk);
	int ttop = 0;
	for (int i = 1; i <= n; ++i)
	{
		if (a[i].x == now.x && a[i].y == now.y)
		{
			continue;
		}
		if (a[i].x >= now.x && a[i].y >= now.y)
		{
			tmp[++ttop] = (node){a[i].x, a[i].y, (a[i].x - now.x) + (a[i].y - now.y)};
		}
	}
	if (ttop + nk + anss <= ans)
	{
		return;
	}
	for (int i = 1; i <= ttop; ++i)
	{
		dfs((point){tmp[i].x, tmp[i].y}, nk - tmp[i].w + 1, anss + tmp[i].w);
	}
}
int main()
{
	ios::sync_with_stdio(0);
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	cin >> n >> k;
	for (int i = 1; i <= n; ++i)
	{
		int x, y;
		cin >> x >> y;
		a[++top] = (point){x, y};
	}
	sort(a + 1, a + top + 1, cmp);
	for (int i = 1; i <= n; ++i)
	{
		dfs(a[i], k, 1);
	}
	cout << ans;
	return 0;
}