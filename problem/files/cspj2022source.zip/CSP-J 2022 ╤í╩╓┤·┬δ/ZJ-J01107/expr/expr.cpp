#include <bits/stdc++.h>
using namespace std;
string str;
int ans1, ans2;
int fun(int l, int r)
{
	// cout << l<<" "<<r<<endl;
	if (r == l)
	{
		return str[l] - '0';
	}
	int pos = -1;
	char posc = '&';
	int flag = 0;
	for (int i = l; i <= r; ++i)
	{
		if (str[i] == '(')
		{
			++flag;
			continue;
		}
		if (str[i] == ')')
		{
			--flag;
			continue;
		}
		if (flag)
		{
			continue;
		}
		if (str[i] == '|')
		{
			pos = i;
			posc = '|';
		}
		if (str[i] == '&')
		{
			if (posc == '&')
			{
				pos = i;
				posc = '&';
			}
		}
	}
	if (pos == -1)
	{
		return fun(l + 1, r - 1);
	}
	int lc = fun(l, pos - 1);
	if (lc == 0 && posc == '&')
	{
		++ans1;
		return 0;
	}
	if (lc == 1 && posc == '|')
	{
		++ans2;
		return 1;
	}
	int rc = fun(pos + 1, r);
	if (posc == '&')
	{
		return lc && rc;
	}
	else
	{
		return lc || rc;
	}
}
int main()
{
	ios::sync_with_stdio(0);
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	cin >> str;
	cout << fun(0, str.length() - 1) << endl;
	cout << ans1 << " " << ans2;
	return 0;
}