#include<bits/stdc++.h>
using namespace std;
struct po
{
	int x,y,id;
}a[501];
struct po1
{
	int x,y,id;
}b[501];
int n,k,dp[501][2],h[501],l[501],ans;
bool cmp(po c,po d)
{
	if(c.x==d.x)
	  return c.y<d.y;
	return c.x<d.x;
}
bool cmp1(po c,po d)
{
	if(c.y==d.y)
	  return c.x<d.x;
	return c.y<d.y;
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;++i)
	{
		cin>>a[i].x>>a[i].y,a[i].id=i;
		dp[i][0]=1;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=n;++i)
	  h[a[i].id]=i;
	sort(a+1,a+1+n,cmp1);
	for(int i=1;i<=n;++i)
	  l[a[i].id]=i;
	for(int i=1;i<=n;++i)
	{
		int idd=a[i].id;
		for(int j=1;j<i;++j)
		  if(h[a[j].id]<=h[idd]&&l[a[j].id]<=l[idd])
		  {
		  	int jdd=a[j].id;
		  	int l=dp[jdd][1]+(a[i].x-a[j].x+a[i].y-a[j].y-1);
		  	if(dp[jdd][0]+1>dp[idd][0]&&l<=k)
		  	{
		  		dp[idd][0]=dp[jdd][0]+1;
		  		dp[idd][1]=l;
			}
		  }
	}
	for(int i=1;i<=n;++i)
	  ans=max(dp[i][0]+k,ans);
	cout<<ans;
	return 0;
}
