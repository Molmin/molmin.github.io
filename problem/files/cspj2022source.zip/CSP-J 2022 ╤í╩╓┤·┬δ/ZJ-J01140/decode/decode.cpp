#include<bits/stdc++.h>
using namespace std;
long long k,a,b,c,d,e,l=1;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k)
	{
		--k;
		cin>>a>>b>>c;
		d=a-b*c+2;
		e=d*d-4*a;
		if(sqrt(e)*sqrt(e)!=e)
		{
			cout<<"NO"<<'\n';
			continue;
		}
		e=sqrt(e);
		if(e>=d||(e+d)%2==1)
		{
			cout<<"NO"<<'\n';
			continue;
		}
		cout<<(d-e)/2<<" "<<(d+e)/2<<'\n';
	}
	return 0;
}
