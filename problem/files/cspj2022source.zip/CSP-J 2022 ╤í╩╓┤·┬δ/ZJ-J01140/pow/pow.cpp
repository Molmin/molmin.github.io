#include<bits/stdc++.h>
using namespace std;
long long a,b,l=1;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	while(l<=1e9&&b)
	{
		l*=a;
		--b;
	}
	if(b==0)
	  cout<<l;else
	  cout<<-1;
	return 0;
}
