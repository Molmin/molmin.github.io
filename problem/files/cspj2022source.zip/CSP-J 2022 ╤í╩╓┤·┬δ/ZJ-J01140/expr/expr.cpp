#include<bits/stdc++.h>
using namespace std;
struct ys
{
	char c;
	int d,w;
}a[1000005];
string s;
int n,l,tot,tot1,ls[1000005],rs[1000005],ll[1000005],rr[1000005],tree[1000005],ans1,ans2;
bool k[1000005],z[1000005];
bool cmp(ys x,ys y)
{
	if(x.d==y.d)
	{
		if(x.c==y.c)
		  return x.w>y.w;
		if(x.c=='|')
		  return 1;else
		  return 0;
	}
	return x.d<y.d;
}
void build(int id,int h,int t)
{
	int lll=tot1;
	tree[++tot1]=id,ll[tot1]=h,rr[tot1]=t;
	for(int i=id;i<=tot;++i)
	  if(a[i].w>=h&&a[i].w<a[id].w)
	  {
	  	ls[lll]=tot1+1;
	  	build(i,h,a[id].w-1);
	  	break;
	  }
	for(int i=id;i<=tot;++i)
	  if(a[i].w>a[id].w&&a[i].w<=t)
	  {
	  	rs[lll]=tot1+1;
	  	build(i,a[id].w+1,t);
	  	break;
	  }
}
void cx(int id)
{
	int idd=tree[id];
	if(!ls[id]&&!rs[id])
	{
	  	if(a[idd].c=='&')
	  	{
	  		if(s[a[idd].w-1]=='0'||s[a[idd].w+1]=='0')
	  		  z[id]=0;else
	  		  z[id]=1;
		}
		if(a[idd].c=='|')
	  	{
	  		if(s[a[idd].w-1]=='1'||s[a[idd].w+1]=='1')
	  		  z[id]=1;else
	  		  z[id]=0;
		}
		return;
	}
	int lz,rz;
	if(!ls[id])
	  lz=s[a[idd].w-1]-'0';else
	  cx(ls[id]);
	if(!rs[id])
	  rz=s[a[idd].w+1]-'0';else
	  cx(rs[id]);
	if(a[idd].c=='&')
	  z[id]=lz&rz;else
	  z[id]=lz|rz;
}
void find(int id)
{
	int idd=tree[id];
	if(a[id].c=='&'&&z[id]==0)
	{
			if(ls[id])
		  	{
		  		find(ls[id]);
		  		if(z[ls[id]]!=0)
		  		{
		  			if(rs[id])
		  		    find(rs[id]);
				}else
		  		++ans1;
			}else
			if(s[a[id].w-1]=='1')
			{
				if(rs[id])
			  	  find(rs[id]);
			}else
			  ++ans1;
	  	return;
	}
	if(a[id].c=='|'&&z[id]==1)
	{
			if(ls[id])
		  	{
		  		find(ls[id]);
		  		if(z[ls[id]]!=1)
		  		{
		  			if(rs[id])
		  			  find(rs[id]);
				}else
				++ans2;
			}else
			if(s[a[id].w-1]=='0')
			{
				if(rs[id])
			  find(rs[id]);
			}else
			  ++ans2;
	  	return;
	}
	if(ls[id])
	  find(ls[id]);
	if(rs[id])
	  find(rs[id]);
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	n=s.size();
	for(int i=0;i<n;++i)
	{
		if(s[i]=='(')
		  ++l;
		if(s[i]==')')
		  --l;
		if(s[i]=='|'||s[i]=='&')
		  a[++tot].c=s[i],a[tot].d=l,a[tot].w=i;
	}
	sort(a+1,a+1+tot,cmp);
	build(1,0,n-1);
	cx(1);
	cout<<z[1]<<'\n';
	find(1);
	cout<<ans1<<" "<<ans2<<'\n';
	return 0;
}
