#include <bits/stdc++.h>
using namespace std;
struct node {
	int x, y;
} a[505];
bool cmp(node xx, node yy) {
	return (xx.x == yy.x ? xx.y < yy.y : xx.x < yy.x);
}
bool mapp[1005][1005];
int dfs(int x, int y, int lastx, int lasty, int k, int len) {
	if (k == 0 && lastx != -1 || lasty != -1) {
		int now = 0;
		if (!mapp[x + 1][y] && (x + 1 != lastx || y != lasty)) now++;
		if (!mapp[x - 1][y] && (x - 1 != lastx || y != lasty)) now++;
		if (!mapp[x][y + 1] && (x != lastx || y + 1 != lasty)) now++;
		if (!mapp[x][y - 1] && (x != lastx || y - 1 != lasty)) now++;
		if (now >= 3) {
			return len;
		}
	}
	if (mapp[x + 1][y] && (x + 1 != lastx || y != lasty)) return dfs(x + 1, y, x, y, k, len + 1));
	if (mapp[x - 1][y] && (x - 1 != lastx || y != lasty)) return dfs(x - 1, y, x, y, k, len + 1));
	if (mapp[x][y + 1] && (x != lastx || y + 1 != lasty)) return dfs(x, y + 1, x, y, k, len + 1));
	if (mapp[x][y - 1] && (x != lastx || y - 1 != lasty)) return dfs(x, y - 1, x, y, k, len + 1));
	if (k > 0) {
		if (!mapp[x + 1][y] && (x + 1 != lastx || y != lasty)) return dfs(x + 1, y, x, y, k - 1, len + 1);
		if (!mapp[x - 1][y] && (x - 1 != lastx || y != lasty)) return dfs(x - 1, y, x, y, k - 1, len + 1);
		if (!mapp[x][y + 1] && (x != lastx || y + 1 != lasty)) return dfs(x, y + 1, x, y, k - 1, len + 1);
		if (!mapp[x][y - 1] && (x != lastx || y - 1 != lasty)) return dfs(x, y - 1, x, y, k - 1, len + 1);
	}
	return len;
}
int main() {
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	int n, k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i].x >> a[i].y;
		mapp[a[i].x][a[i].y] = 1;
	}
	sort(a + 1, a + n + 1, cmp);
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		ans = max(ans, dfs(a[i].x, a[i].y, -1, -1, k, 1)); 
	}
	cout << ans;
	return 0;
}
