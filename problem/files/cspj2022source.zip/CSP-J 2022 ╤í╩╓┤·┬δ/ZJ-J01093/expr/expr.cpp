#include <bits/stdc++.h>
using namespace std;
//�ѿ��ˣ�����Ŀ������ 
int main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	string s;
	cin >> s;
	if (s.size() <= 5) {
		if (s.size() == 1) {
			if (s[0] == '0') cout << "0\n0 0";
			else cout << "1\n0 0";
		}
		if (s.size() == 3) {
			if (s[0] == '0') {
				if (s[1] == '|') {
					if (s[2] == '1') cout << "1\n0 1";
					else cout << "0\n0 0";
				} else cout << "0\n1 0";
			} else {
				if (s[1] == '|') cout << "1\n0 1";
				else {
					if (s[2] == '0') cout << "0\n1 0";
					else cout << "1\n0 0";
				}
			}
		}
		if (s.size() == 5) {
			if (s == "(0&1)" || s == "(1&0)" || s == "(0&0)" || s == "0|0&1" || s == "0|0&0" || s == "0&0|0" || s == "0&1|0" || s == "0|1&0" || s == "1&0|0") cout << "0\n1 0";
			if (s == "0|1&1" || s == "0&1|1" || s == "1&0|1" || s == "1|1&0" || s == "1|0&1" || s == "0&0|1" || s == "1|0&0" || s == "1&1|1" || s == "1&1|0") cout << "1\n0 1";
			if (s == "(0|1)" || s == "(1|0)" || s == "(1|1)" || s == "0|0|1" || s == "1&1|1" || s == "1|1&1") cout << "1\n0 1";
			if (s == "0|1|1" || s == "1|1|0" || s == "1|0|1" || s == "1|0|0" || s == "0|1|0" || s == "0|0|0" || s == "1|1|1") cout << "1\n0 2";
			if (s == "0&1&1" || s == "1&0&1" || s == "0&0&1" || s == "0&0&0" || s == "1&0&0" || s == "0&1&0") cout << "0\n2 0";
			if (s == "(0|0)") cout << "0\n0 0";
			if (s == "1&1&1" || s == "(1&1)") cout << "1\n0 0";
		}
		return 0;
	}
	bool flag1 = 0, flag2 = 0;
	for (int i = 0; i < s.size(); i++) {
		if (s[i] == '|') flag1 = 1;
		if (s[i] == '&') flag2 = 1;
	}
	vector<char> v;
	for (int i = 0; i < s.size(); i++) {
		if (s[i] != '(' && s[i] != ')') v.push_back(s[i]);
	}
	if (flag1 == 0) {
		bool is_prime = 1;
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == '0') is_prime = 0;
		}
		int ans = 0;
		for (int i = 0; i < v.size(); i++) {
			if (v[i] == '&') {
				if (v[i - 1] == '0' || v[i + 1] == '0') ans++;
			}
		}
		cout << (is_prime ? 1 : 0) << endl << ans << " 0";
	} else if (flag2 == 0) {
		bool is_prime = 0;
		for (int i = 0; i < s.size(); i++) {
			if (s[i] == '1') is_prime = 1;
		}
		int ans = 0;
		for (int i = 0; i < v.size(); i++) {
			if (v[i] == '|') {
				if (v[i - 1] == '1' || v[i + 1] == '1') ans++;
			}
		}
		cout << (is_prime ? 1 : 0) << endl << "0 " << ans;
	} else {
		cout << 0 << endl << 2 << 3;
	}
	return 0;
}
