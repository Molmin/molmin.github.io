#include <bits/stdc++.h>
using namespace std;
const long long maxx = 1e9;
long long x, y, ans = 1;
int main() {
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	cin >> x >> y;
	while (y) {
		if (y % 2 == 1) ans *= x;
		if (ans > maxx || x > maxx) {
			cout << -1;
			return 0;
		}
		y /= 2;
		x = x * x;
	}
	if (ans > maxx || x > maxx) cout << -1;
	else cout << ans;
	return 0;
}
