#include <bits/stdc++.h>
using namespace std;
const long long maxx = 1e9;
int main() {
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	long long k, n, e, d;
	cin >> k;
	while(k--) {
		cin >> n >> e >> d;
		
		long long f = e * d, cnt = 0;
		bool flag = 1;
		if (n == sqrt(n) * sqrt(n)) {
			if (f == (sqrt(n) - 1) * sqrt(n - 1) + 1) {
				cout << sqrt(n) << " " << sqrt(n) << endl;
				continue;
			}
		}
		if (n > 1e17) {
			cout << "NO" << endl;
			continue;
		}
		for (long long i = sqrt(n); i > 0; i--) {
			if (i + (n / i) > maxx) {
				break;
			}
			if (n % i == 0) {
				if (f == n - i - (n / i) + 2) {
					flag = 0;
					cout << min(i, n / i) << " " << max(i, n / i) << endl;
					break;
				}
			}
		}
		if (flag) cout << "NO" << endl;
	}
}
