#include <bits/stdc++.h>
#define ll long long 
using namespace std;
ll x,y;
void fre_open(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
}
inline ll read(){
	ll ans=0,t=1;char c;
	for (c=getchar();c<'0'||c>'9';c=getchar())if (c=='-')t=-1;
	for (;c>='0'&&c<='9';c=getchar())ans=ans*10+c-48;
	return ans*t;
}
void write(ll x){if (x>9)write(x/10);putchar(x%10+48);}
void readln(){
	x=read();y=read(); 
	return;
}
void work(){
	if (x==1)putchar(49);
	else{
		for (ll xx=x,i=2;i<=y;i++){
			x*=xx;
			if (x>1e9){printf("-1");return;}
		}
		write(x);
	}
	return;
}
int main(){
	fre_open();
	readln();
	work();	
	return 0;
}
