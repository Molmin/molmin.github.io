#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n,d,e;
void fre_open(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
}
inline ll read(){
	ll ans=0,t=1;char c;
	for (c=getchar();c<'0'||c>'9';c=getchar())if (c=='-')t=-1;
	for (;c>='0'&&c<='9';c=getchar())ans=ans*10+c-48;
	return ans*t;
}
void write(ll x){if (x>9)write(x/10);putchar(x%10+48);}
inline void readln(){
	n=read();d=read();e=read();
	return;
}
void work(){
	ll b,t,c,tt;
	for (int T=read();T;T--){
		readln();
		b=-(n+2-d*e);
		c=n;
		t=b*b-4*c;
		if (t>=0){
			tt=sqrt(t);
			if (tt*tt==t&&-b-tt>0&&(-b-tt)%2==0){
				write((-b-tt)/2);
				putchar(32);
				write((-b+tt)/2);
				putchar(10);
			}else printf("NO\n");
		}else printf("NO\n");
	}
	return;
}
int main(){
	fre_open();
	work();	
	return 0;
}
