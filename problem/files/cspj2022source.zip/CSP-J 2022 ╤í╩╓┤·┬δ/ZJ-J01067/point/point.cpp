#include <bits/stdc++.h>
using namespace std;
const int e[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int n,m,f[1010][1010],d1[1010],d2[1010],maxx,maxy;
struct node{
	int x,y;
}a[1010];
void fre_open(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
}
inline int read(){
	int ans=0,t=1;char c;
	for (c=getchar();c<'0'||c>'9';c=getchar())if (c=='-')t=-1;
	for (;c>='0'&&c<='9';c=getchar())ans=ans*10+c-48;
	return ans*t;
}
void write(int x){if (x>9)write(x/10);putchar(x%10+48);}
void readln(){
	n=read();m=read();
	for (int i=1;i<=n;i++)a[i].x=read(),a[i].y=read(),f[a[i].x][a[i].y]=1;
	for (int i=1;i<=n;i++)maxx=max(maxx,a[i].x);
	for (int i=1;i<=n;i++)maxy=max(maxy,a[i].y);
	return;
}
void dfs1(int x,int y,int chance,int sum){
	if (chance<0)return;
	if (x==maxx||y==maxx){
		for (int i=chance;i>=0;i--)d1[i]=max(d1[i],sum+chance-i);
		return;
	}
	d1[chance]=max(d1[chance],sum);
	int xx,yy;
	for (int i=0;i<2;i++){
		xx=x+e[i][0];
		yy=y+e[i][1];
		if (xx<=maxx+1&&yy<=maxy+1)dfs1(xx,yy,chance+f[xx][yy]-1,sum+1);
	}
}
void dfs2(int x,int y,int chance,int sum){
	if (chance<0)return;
	int xx,yy;
	if (x==0||y==0){
		for (int i=chance;i>=0;i--)d2[i]=max(d2[i],sum+chance-i);
		return;
	}
	d2[chance]=max(d2[chance],sum);
	for (int i=2;i<4;i++){
		xx=x+e[i][0];
		yy=y+e[i][1];
		if (xx>=0&&yy>=0)dfs2(xx,yy,chance+f[xx][yy]-1,sum+1);
	}
}
void work(){
	int ans=0,maxans=0;
	for (int i=1;i<=n;i++){
		memset(d1,0,sizeof(d1));
		memset(d2,0,sizeof(d2));
		dfs1(a[i].x,a[i].y,m,1);
		dfs2(a[i].x,a[i].y,m,1);
		for (int i=0;i<=m;i++)
			ans=max(ans,d1[i]+d2[m-i]);
		maxans=max(maxans,ans-1);
	}
	write(maxans);
	return;
}
int main(){
	fre_open();
	readln();
	work();	
	return 0;
}
