#include <bits/stdc++.h>
using namespace std;
char s[1500010];
struct char_type{
	int ans_num,or_num;
}p[1500010];
int kuo[1500010],cnt;
void fre_open(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
}
void readln(){
	scanf("%s",s);
	return;
}
int kuo_do(int l,int r){
	int ls=l,ll,rr;
	for(int i=l;i<r;i++){
		if (s[i]=='&'){
			ls--;
			ll=s[ls]-48;
			rr=s[i+1]-48;
			s[ls]=(ll&rr)+48;
			p[i]=(char_type){0,0};i++;
			if (ll==0)p[ls].ans_num++;
			else{
			p[ls].ans_num+=p[i].ans_num;
			p[ls].or_num+=p[i].or_num;				
			}

			ls++;
		}else{
			s[ls]=s[i];
			p[ls++]=p[i];
		}
			if (ls-1!=i)p[i]=(char_type){0,0};
	}
	int ls1=l;
	for (int i=l;i<ls;i++){
		if (s[i]=='|'){
			ls1--;
			ll=s[ls1]-48;
			rr=s[i+1]-48;
			s[ls1]=(ll|rr)+48;
			p[i]=(char_type){0,0};i++;
			if (ll==1)p[ls1].or_num++;
			else{
			p[ls1].ans_num+=p[i].ans_num;
			p[ls1].or_num+=p[i].or_num;
			}
			ls1++;
		}else{
			s[ls1]=s[i];
			p[ls1++]=p[i];
		}
			if (ls1-1!=i)p[i]=(char_type){0,0};
	}
	return ls1;
}
void work(){
	int ls=strlen(s);int ls1=0,kuost;
	for (int i=0;i<ls;i++){
		if (s[i]=='(')kuo[++cnt]=ls1;
		else if (s[i]==')'){
			kuost=kuo[cnt--];
			ls1=kuo_do(kuost,ls1);
		}else s[ls1++]=s[i];
	}
//	for (int i=0;i<ls1;i++)printf("%c",s[i]);
	ls=0;int ll,rr;
	for (int i=0;i<ls1;i++){
		if (s[i]=='&'){
			ls--;
			ll=s[ls]-48;
			rr=s[i+1]-48;
			s[ls]=(ll&rr)+48;
			p[i]=(char_type){0,0};i++;
			if (ll==0)p[ls].ans_num++;
			else{
				p[ls].ans_num+=p[i].ans_num;
				p[ls].or_num+=p[i].or_num;
			}
			ls++;
		}else{
			s[ls]=s[i];
			p[ls++]=p[i];
		}
			if (ls-1!=i)p[i]=(char_type){0,0};
	}
	ls1=0;
	for (int i=0;i<ls;i++){
		if (s[i]=='|'){
			ls1--;
			ll=s[ls1]-48;
			rr=s[i+1]-48;
			s[ls1]=(ll|rr)+48;
			p[i]=(char_type){0,0};i++;
			if (ll==1)p[ls1].or_num++;
			else{
				p[ls1].ans_num+=p[i].ans_num;
				p[ls1].or_num+=p[i].or_num;				
			}
			ls1++;
		}else{
			s[ls1]=s[i];
			p[ls1++]=p[i];
		}
			if (ls1-1!=i)p[i]=(char_type){0,0};
	}
	printf("%c\n",s[0]);
	printf("%d %d",p[0].ans_num,p[0].or_num);
	return;
}
int main(){
	fre_open();
	readln();
	work();	
	return 0;
}
