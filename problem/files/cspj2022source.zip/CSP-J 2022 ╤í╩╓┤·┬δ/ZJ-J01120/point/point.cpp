#include<bits/stdc++.h>
using namespace std;
const int dx[]={0,1,0},dy[]={0,0,1};
int n,k;
struct pts{
	int x,y,ps,sum;
};
int f[105][105],vis[105][105];
int maxn=0,maxx=0,maxy=0;
void bfs(int x,int y,int ps){
	queue<pts> q;
	q.push({x,y,ps,1});
	while(q.size()){
		int qx=q.front().x,qy=q.front().y,qps=q.front().ps,qsum=q.front().sum;
		if(qx==maxx&&qy==maxy){
			maxn=maxn<qsum+qps?qsum+qps:maxn;
		}
		for(register int i=1;i<=2;i++){
			int nx=qx+dx[i],ny=qy+dy[i];
			if(nx>=1&&nx<=maxx+1&&ny>=1&&ny<=maxy+1){
				if(f[nx][ny]){
					q.push({nx,ny,qps,qsum+1});
				}else{
					if(qps==0){
						maxn=maxn<qsum?qsum:maxn;
					}else{
						q.push({nx,ny,qps-1,qsum+1});
					}
				}
			}
		}
		q.pop();
	}
}
int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	int x,y;
	for(register int i=1;i<=n;i++){
		cin>>x>>y;
		f[x][y]=1;
		maxx=maxx<x?x:maxx;
		maxy=maxy<y?y:maxy;
	}
	for(register int i=1;i<=maxx;i++){
		for(register int j=1;j<=maxy;j++){
			if(f[i][j])bfs(i,j,k);
		}
	}
	cout<<maxn;
	return 0;
}
