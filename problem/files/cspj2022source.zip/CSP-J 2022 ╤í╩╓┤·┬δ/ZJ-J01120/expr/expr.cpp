#include<bits/stdc++.h>
using namespace std;
stack<char> st,st2;
struct data{
	char con;
	int l;
};
stack<data> stch;
string s;
int cntand=0,cntor=0,L=0;
int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	int n=s.length();
	for(register int i=0;i<n;i++){
		if(s[i]>='0'&&s[i]<='1'){
			st.push(s[i]);
		}else if(s[i]=='('){
			L++;
		}else if(s[i]==')'){
			L--;
			while(stch.size()&&stch.top().l>=L){
				st.push(stch.top().con);
				stch.pop();
			}
		}else{
			stch.push({s[i],L});
		}
	}
	while(stch.size()){
		st.push(stch.top().con);
		stch.pop();
	}
	while(st.size()){
		st2.push(st.top());
		st.pop();
	}
	while(st2.size()){
		char tp=st2.top();
		st2.pop();
		if(tp>='0'&&tp<='1'){
			st.push(tp);
		}else if(tp=='&'){
			int x=st.top()-'0';st.pop();
			int y=st.top()-'0';st.pop();
			if(y==0){
				cntand++;
				st.push('0');
			}else st.push((char)('0'+(x&y)));
		}else{
			int x=st.top()-'0';st.pop();
			int y=st.top()-'0';st.pop();
			if(y==1){
				cntor++;
				st.push('1');
			}else st.push((char)('0'+(x|y)));
		}
	}
	printf("%c\n",st.top());
	printf("%d %d",cntand,cntor);
	return 0;
}
