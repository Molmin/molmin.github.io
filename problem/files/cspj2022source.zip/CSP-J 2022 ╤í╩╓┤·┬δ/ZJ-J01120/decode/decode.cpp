#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ULL;
int k,n,e,d,p;
ULL ed,x,y;
int main(){
	cin.tie(0);
	ios::sync_with_stdio(false);
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		cin>>n>>e>>d;
		ed=e*d;
		y=n-ed+2;
		x=n;
		if(y*y-4*x<0){
			printf("NO\n");
			continue;
		}
		double bp1,bq1,bp2,bq2;
		bp1=(y+sqrt(y*y-4*x))/2;
		bq1=x/bp1;
		if(bp1>=0&&bq1>=0&&fabs(bp1-(ULL)bp1)<=0.000001){
			if(bp1>bq1)swap(bp1,bq1);
			printf("%d %d\n",(ULL)bp1,(ULL)bq1);
			continue;
		}
		bp2=(y-sqrt(y*y-4*x))/2;
		bq2=x/bp2;
		if(bp2>=0&&bq2>=0&&fabs(bp2-(ULL)bp2)<=0.000001){
			if(bp2>bq2)swap(bp2,bq2);
			printf("%d %d\n",(ULL)bp2,(ULL)bp2);
			continue;
		}
		printf("NO\n");
	}
	return 0;
}
