#include<bits/stdc++.h>
using namespace std;

const int N=505,K=105;

struct node{
	int x,y;
}g[N];

int n,k,dis,f[N][K],ans;

inline char gc()
{
	return getchar();
}

template<typename T>
inline void read(T *x)
{
	(*x)=0;
	int f=1;
	char ch=gc();
	for(;!isdigit(ch);ch=gc())
		f|=-(ch=='-');
	for(;isdigit(ch);ch=gc())
		(*x)=(*x)*10+(ch&15);
	(*x)*=f;
}

bool cmp(node X,node Y)
{
	return (X.x<Y.x)||(X.x==Y.x&&X.y<Y.y);
}

//#define LOCAL

int main()
{
#ifndef LOCAL
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
#endif
	read(&n);
	read(&k);
	for(int i=1;i<=n;i++){
		read(&g[i].x);
		read(&g[i].y);
	}
	sort(g+1,g+n+1,cmp);
	for(int i=1;i<=n;i++)
	for(int j=0;j<=k;j++)
		f[i][j]=j+1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<i;j++)if(g[j].y<=g[i].y){
			dis=g[i].x-g[j].x+g[i].y-g[j].y-1;
			for(int o=dis;o<=k;o++)
				f[i][o]=max(f[i][o],f[j][o-dis]+dis+1);
		}
	}
	for(int i=1;i<=n;i++)
	for(int j=0;j<=k;j++)
		ans=max(ans,f[i][j]);
	printf("%d",ans);
#ifndef LOCAL
	fclose(stdin);
	fclose(stdout);
#endif
	return 0;
}
