#include<bits/stdc++.h>
using namespace std;

typedef double DB;
typedef long long LL;

LL n,d,e,sum,ans1,ans2,k;
DB cha,p,q;
bool pd;

inline char gc()
{
	return getchar();
}

template<typename T>
inline void read(T *x)
{
	(*x)=0;
	int f=1;
	char ch=gc();
	for(;!isdigit(ch);ch=gc())
		f|=-(ch=='-');
	for(;isdigit(ch);ch=gc())
		(*x)=(*x)*10+(ch&15);
	(*x)*=f;
}

bool isnum(DB x)
{
	return (x-(DB)floor(x)==0);
}

//#define LOCAL

int main()
{
#ifndef LOCAL
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
#endif
	read(&k);
	while(k--){
		pd=1;
		read(&n);
		read(&d);
		read(&e);
		sum=n-e*d+2;
		if(sum*sum-4*n>=0){
			cha=sqrt(sum*sum-4*n);
			if(isnum(cha)){
				q=(cha+sum)/2.0;
				p=(sum-cha)/2.0;
				if(!isnum(q)||q<=0||!isnum(p)||p<=0)
					pd=0;
			}else
				pd=0;
		}else
			pd=0;
		ans1=p;
		ans2=q;
		if(pd)
			printf("%lld %lld\n",ans1,ans2);
		else
			printf("NO\n");
	}
#ifndef LOCAL
	fclose(stdin);
	fclose(stdout);
#endif
	return 0;
}
