#include<bits/stdc++.h>
using namespace std;

typedef long long LL;

const LL INF=1e9;

LL a,b,ans;

inline char gc()
{
	return getchar();
}

template<typename T>
inline void read(T *x)
{
	(*x)=0;
	int f=1;
	char ch=gc();
	for(;!isdigit(ch);ch=gc())
		f|=-(ch=='-');
	for(;isdigit(ch);ch=gc())
		(*x)=(*x)*10+(ch&15);
	(*x)*=f;
}

LL pow(LL a,LL b)
{
	if(a==0)
		return 0;
	LL res=1;
	while(b){
		if(b&1){
			if(a==-1)
				return -1;
			else{
				res*=a;
				if(res>INF)
					return -1;
			}
		}
		if(a!=-1)
			a*=a;
		if(a>INF)
			a=-1;
		b>>=1;
	}
	return res;
}

//#define LOCAL

int main()
{
#ifndef LOCAL
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
#endif
	read(&a);
	read(&b);
	ans=pow(a,b);
	printf("%lld",ans);
#ifndef LOCAL
	fclose(stdin);
	fclose(stdout);
#endif
	return 0;
}
