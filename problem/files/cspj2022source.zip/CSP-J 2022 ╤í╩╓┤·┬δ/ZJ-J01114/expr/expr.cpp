#include<bits/stdc++.h>
using namespace std;

const int Len=1e6+5;

string st;
int res,ans[2],len,s[Len],q[Len],t;

bool solve(int l,int r,bool pd)
{
	if(st[l]=='('&&st[r]==')'&&q[r]==l)
		return solve(l+1,r-1,0);
	if(l==r)
		return st[l]-'0';
	int f=-1,id=-1;
	for(int i=r;i>=l;i--)
		if(st[i]=='|'){
			f=1;
			id=i;
			break;
		}else if(st[i]=='&'&&f==-1){
			f=0;
			id=i;
			if(pd)
				break;
		}else if(st[i]==')')
			i=q[i];
	bool pd_=(f==0);
	int lans=solve(l,id-1,pd_);
	if(lans==f){
		ans[f]++;
		return f;
	}else 
		return solve(id+1,r,pd_);
}

//#define LOCAL

int main()
{
#ifndef LOCAL
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
#endif
	cin>>st;
	len=st.size();
	for(int i=0;i<len;i++){
		if(st[i]=='(')
			s[++t]=i;
		else if(st[i]==')')
			q[i]=s[t--];
	}
	res=solve(0,len-1,0);
	printf("%d\n%d %d",res,ans[0],ans[1]);
#ifndef LOCAL
	fclose(stdin);
	fclose(stdout);
#endif
	return 0;
}
