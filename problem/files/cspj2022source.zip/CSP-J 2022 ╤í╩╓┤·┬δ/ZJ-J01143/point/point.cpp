#include<bits/stdc++.h>
int n,k,f[1005][1005],dp[205][205][105];
bool used[1005];int ans;
struct node{
	int x,y;
}a[1005];
int max(int x,int y){
	return x>y?x:y;
}
bool cmp(node x,node y){
	if(x.x^y.x)return x.x<y.x;
	return x.y<y.y;
}
void dfs(int x,int y,int sum,int k){
	ans=max(ans,sum);
	if(sum+n-k+1<ans)return;
	for(int i=k+1;i<=n;i++)
		if((a[i].x==x&&a[i].y==y+1)||(a[i].x==x+1&&a[i].y==y))
			dfs(a[i].x,a[i].y,sum+1,i);
	return;
}
inline void read(int &x){
	#define cg c=getchar()
	int f=1;char cg;x=0;
	while(c>57||c<48)f-=(c==45)<<1,cg;
	while(c>47&&c<58)x=x*10+(c&15),cg;
	x*=f;return;
}
signed main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	read(n);read(k);
	for(int i=1;i<=n;i++)read(a[i].x),read(a[i].y);
	std::sort(a+1,a+1+n,cmp);
	if(!k){
		for(int i=1;i<=n;i++)
			dfs(a[i].x,a[i].y,1,i);
		printf("%d\n",ans);
	}
	else{
		for(int i=1;i<=n;i++)f[a[i].x][a[i].y]=1;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(f[i][j])dp[i][j][0]=1;
		for(int i=1;i<=201;i++)
			for(int j=1;j<=201;j++)
				for(int l=0;l<=k;l++){
					if(l>i*j)break;
					if(f[i][j])dp[i][j][l]=max(dp[i-1][j][l],dp[i][j-1][l])+1;
					else dp[i][j][l]=max(dp[i-1][j][l-1],dp[i][j-1][l-1])+1;
				}
		for(int i=1;i<=k;i++)ans=max(ans,dp[201][201][i]);
		printf("%d",ans);
	}
	return 0;
}