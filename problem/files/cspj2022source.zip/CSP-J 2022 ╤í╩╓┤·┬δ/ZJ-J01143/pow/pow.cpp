#include<bits/stdc++.h>
#define int long long
const int k=1e9;
int a,b,ans=1;
inline void read(int &x){
	#define cg c=getchar()
	int f=1;char cg;x=0;
	while(c>57||c<48)f-=(c==45)<<1,cg;
	while(c>47&&c<58)x=x*10+(c&15),cg;
	x*=f;return;
}
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	read(a);read(b);
	while(b){
		if(b&1)ans*=a;
		if(b^1)a=a*a;b>>=1;
		if(a>k||ans>k)
			return puts("-1"),0;
	}
	printf("%lld",ans);
	return 0;
}