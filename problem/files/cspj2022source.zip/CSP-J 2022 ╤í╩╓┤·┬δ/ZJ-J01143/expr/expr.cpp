#include<bits/stdc++.h>
using namespace std;
char s[1000005];int len;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",&s);
	len=strlen(s);
	if(len<=3){
		if(s[0]=='1'&&s[1]=='|')printf("1\n0 1");
		else if(s[0]=='0'&&s[1]=='&')printf("0\n1 0");
		else{
			int x=s[0]-48,y=s[2]-48;
			if(s[1]=='&')cout<<(x&y)<<'\n';
			else cout<<(x|y)<<'\n';
			puts("0 0");
		}
	}
	else printf("1\n0 1");
	return 0;
}