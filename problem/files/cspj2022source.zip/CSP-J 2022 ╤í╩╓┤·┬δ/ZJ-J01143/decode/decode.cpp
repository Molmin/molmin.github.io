#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,e,d,p,q,T,x;int t;
inline void read(int &x){
	#define cg c=getchar()
	int f=1;char cg;x=0;
	while(c>57||c<48)f-=(c==45)<<1,cg;
	while(c>47&&c<58)x=x*10+(c&15),cg;
	x*=f;return;
}
signed main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	read(T);
	while(T--){
		read(n);read(e);read(d);
		t=(e*d-n-2)*(e*d-n-2)-4*n;
		if(t>=0)x=sqrt(t);
		else{puts("NO");continue;}
		if((x+1)*(x+1)==t)x=x+1;
		if((x-1)*(x-1)==t)x=x-1;
		if((x*x)^t){puts("NO");continue;}
		p=(n-e*d-x+2)/2;q=(n-e*d+x+2)/2;
		if(n==p*q&&p+q==n-e*d+2)
			printf("%lld %lld\n",p,q);
		else puts("NO");
	}
	return 0;
}