#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

int n,k,t[1010][1010],cnt[1010],ans;
bool b[1010]={};
struct A
{
	int x,y;
}q[1010];

void dfs(int idx,int res)
{
	bool flag=true; 
	for (int i=1;i<=cnt[idx];i++)
	{
		if (!b[t[idx][i]]) 
		{
		//	cout<<i<<" "<<idx<<" "<<t[idx][i]<<endl;
			flag=false;
			b[t[idx][i]]=true;
			dfs(t[idx][i],res+1); 
			b[t[idx][i]]=false;
		}
	}
	
	if (flag) ans=max(ans,res);
}

int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	
	for (int i=1;i<=n;i++) 
	{
		scanf("%d%d",&q[i].x,&q[i].y); 
	}		
	
	if (k==0)
	{
		for (int i=1;i<=n;i++)
		{
			for (int j=i+1;j<=n;j++)
			{
				if ((q[i].x==q[j].x)&&(abs(q[i].y-q[j].y)==1)||(q[i].y==q[j].y)&&(abs(q[i].x-q[j].x)==1))
				{
					t[i][++cnt[i]]=j; t[j][++cnt[j]]=i;
				//	cout<<i<<" "<<j<<endl;
				}
			}
		}
		for (int i=1;i<=n;i++)
		{
			b[i]=true; dfs(i,1); b[i]=false;
		}
	}
	
	cout<<ans;
	
	fclose(stdin); fclose(stdout);
	
	return 0;
}