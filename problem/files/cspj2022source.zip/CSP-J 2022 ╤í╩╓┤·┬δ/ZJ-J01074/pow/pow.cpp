#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;

const int N=1e9; 
long long int a,b,ans=1;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	scanf("%lld%lld",&a,&b);
	if (a==1) cout<<1;
	else 
	while (b--)
	{
		if (a>N) 
		{
			ans=-1;
			break;
		} 
		ans*=a;
	}
	
	if (ans>N) cout<<-1;
	else cout<<ans;
	fclose(stdin); fclose(stdout); 
	
	return 0;
}