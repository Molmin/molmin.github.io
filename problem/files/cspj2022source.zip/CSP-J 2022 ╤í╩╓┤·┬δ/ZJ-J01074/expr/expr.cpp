#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std;

const int N=1e6+10;
char s[N];
int cnt1,cnt2,ans,len,c1,c2,c3;

int d1(int l,int r)
{
	if (l==r) return int(s[l])-'0';
	if (s[l]=='('&&s[r]==')') return d1(l+1,r-1); 
	int res=0,i=l,j=l,idx=0;
	while (j<=r)
	{
		if (s[j]=='(') res++; 
		if (s[j]==')') res--; cout<<i<<" "<<j<<endl; 
		//cout<<i<<" "<<j<<endl;
		if (res==0)
		{
			if (i==l) idx=d1(i,j),j=j+2,i=j;
			
			else if (idx==1) 
			{
				cnt1++;j+=2;i=j;
			}
			else if (idx==0) idx=d1(i,j);
		}
		else j++; 
	}
	
	return idx;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout); 
	scanf("%s",s);
	
	len=strlen(s); 
	for (int i=0;s[i];i++)
	{
		if (s[i]=='|') c1++;
		if (s[i]=='&') c2++;
		if (s[i]=='(') c3++;
	}
	
	if (!c3)
	{
		int idx=int(s[0])-'0',i=1;
		while (i<len)
		{
			if (s[i]=='|') 
			{
				if (idx==1) 
				{
					i+=2;
					while (i<len&&s[i]=='&') i+=2;
					cnt1+=1;
				}
				else idx=idx&(int(s[i-1]-'0')); 	
			}	
			if (s[i]=='&')
			{
				i+=2; cnt2+=2;
				if (idx==0)
				{
					while (i<len&&s[i]=='&') i+=2,cnt2+=2;
				}
				else idx=idx&(int(s[i-1]-'0'));
			}
		}
		cout<<idx<<endl<<cnt2<<" "<<cnt1<<endl;
	}
	
	else if (!c2)
	{
		cout<<d1(0,len-1)<<endl<<0<<" "<<cnt1<<endl; 	
	}
	
	fclose(stdin); fclose(stdout);
	return 0;
}