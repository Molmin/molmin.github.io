#include <iostream>
#include <cstdio>
#include <cmath>

using namespace std;

long long int n,e,d,sum,pp,qq,p,q;
int T;

bool check(long long int x)
{
	 p=(x+sum)/2;
	 q=sum-p; 
	
	if (p*q>=n) return false;
	return true;
}

int main()
{
	freopen("decode.in","r",stdin);
    freopen("decode.out","w",stdout); 
	
	scanf("%d",&T); 
	while (T--)
	{
		scanf("%d%d%d",&n,&e,&d); 
		sum=n-e*d+2;
		
		int r=sum,l=0;
		
		while (l<r) 
		{ 
			int mid=l+r>>1; if (mid%2!=sum%2) mid++;  
			
			if (check(mid)) r=mid-1; else l=mid+1;
		}
		pp=(l-1+sum)/2;
		qq=sum-pp;
		if (pp>qq) swap(pp,qq); 
		if (pp*qq==n) cout<<pp<<" "<<qq<<endl;
		else cout<<"NO"<<endl;
	}
	
	fclose(stdin); fclose(stdout); 
	return 0;
}