#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	int i,s,n;
	cin>>a>>b;
	n=a;
	if(a==1){
		cout<<1;
		return 0;
	}
	for(i=2;i<=b;++i){
		a*=n;
		if(a>1000000000){
			cout<<-1;
			return 0;
		}
	}
	s=a;
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
