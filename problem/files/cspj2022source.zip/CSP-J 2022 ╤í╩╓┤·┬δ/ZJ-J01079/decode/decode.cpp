#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k,j,i;
	long long n;
	cin>>k;
	for(i=1;i<=k;++i){
		long long d,e,p,q;
		long long s;
		bool t=1;
		cin>>n>>d>>e;
		for(p=1;p<=sqrt(n);++p){
			if(n%p!=0) continue;
			q=n/p;
			s=e*d;
			if(s==((p-1)*(q-1)+1)){
				cout<<p<<" "<<q<<endl;
				t=0;
				break;
			}
		}
		if(t==1) cout<<"NO"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
