#include<bits/stdc++.h>
using namespace std;
int a[101][101],n,k1,xx[501],yy[501];
long long s=0;
void dfs(int x,int y,long long ans,int k){
	if(x+1<=100&&a[x+1][y]==1){
		dfs(x+1,y,ans+1,k);
	}
	else if(k>0){
		dfs(x+1,y,ans+1,k-1);
	}
	if(y+1<=100&&a[x][y+1]==1){
		dfs(x,y+1,ans+1,k);
	}
	else if(k>0){
		dfs(x,y+1,ans+1,k-1);
	}
	s=max(s,ans);
	return;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int x,y,i,j;
	cin>>n>>k1;
	for(i=1;i<=n;++i){
		cin>>x>>y;
		xx[i]=x;yy[i]=y;
		a[x][y]=1;
	}
	for(i=1;i<=n;++i){
		dfs(xx[i],yy[i],1,k1);
	}
	cout<<s;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
