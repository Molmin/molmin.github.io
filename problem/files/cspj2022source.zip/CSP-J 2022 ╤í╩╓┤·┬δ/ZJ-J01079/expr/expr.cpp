#include<bits/stdc++.h>
using namespace std;
int a=0,b=0,ls=0,lf=0,fs=0,shu[100001],fu[100001],j;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	int n,i;
	cin>>s;
	n=s.length();
	for(i=0;i<n;++i){
		if(s[i]=='0'||s[i]=='1'){
			shu[ls]=s[i]-48;
			ls++;
		}
		else{
			fu[lf]=s[i];
			lf++;
		}
	}
	//cout<<ls<<" "<<lf<<" ";
	for(i=0;i<lf;++i){
		if(fu[i]=='&'){
			if(shu[fs]==0||shu[fs+1]==0){
				a++;ls--;
				shu[fs]=0;
			}
			else{
				ls--;
				shu[fs]=1;
			}
			lf--;
			for(j=fs+1;j<ls;++j){
				shu[j]=shu[j+1];
			}
			for(j=i;j<lf;++j){
				fu[j]=fu[j+1];
			}
			i--;
		}
		else if(fu[i]=='|') fs++;
	}
	fs=0;
	if(ls==1){
		cout<<shu[0]<<endl<<a<<" "<<b;
		return 0;
	}
	for(i=0;i<lf;++i){
		if(fu[i]=='|'){
			if(shu[fs]==1||shu[fs+1]==1){
				b++;
				cout<<1<<endl<<a<<" "<<b;
			}
			else{
				cout<<0<<endl<<a<<" "<<b;
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
