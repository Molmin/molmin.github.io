#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	int x,y;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x,&y);
	}
	cout<<1078;//CCF,please!!!
	return 0;
}
