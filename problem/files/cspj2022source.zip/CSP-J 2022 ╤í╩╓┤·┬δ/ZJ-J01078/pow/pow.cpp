#include<bits/stdc++.h>
using namespace std;
const long long T=31622;
long long Pow(long long a,long long b)
{
	long long ret=a,sum=1;
	while(b!=1)
	{
		if(!(b&1))
		{
			if(ret>T) return -1;
			ret*=ret;
			b/=2;
		}
		else
		{
			if(sum*ret>1e9) return -1;
			sum*=ret;
			b--;
		}
	}
	if(sum*ret>1e9||sum*ret<=0) return -1;
	return sum*ret;
}

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	scanf("%lld%lld",&a,&b);
	cout<<Pow(a,b);
	return 0;
}