#include<bits/stdc++.h>
using namespace std;
bool kuohao(string s)
{
	bool kmp,jmp;
	int ans1=0,ans2=0;stack<bool>st;
	bool yuflag=false,huaflag=false;
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='1'&&yuflag==false)
		{
			st.push(1);
		}
		else if(s[i]=='1'&&yuflag==true)
		{
			kmp&=1;
			st.push(kmp);
			yuflag==false;
		}
		else if(s[i]=='0'&&yuflag==false)
		{
			st.push(0);
		}
		else if(s[i]=='0'&&yuflag==true)
		{
			kmp&=0;
			st.push(kmp);
			yuflag==false;
		}
		else if(s[i]='&')
		{
			kmp=st.top();
			st.pop();
			yuflag=true;
			if(kmp==0) ans1++;
		}
	}
	while(st.size())
	{
		if(st.top()==1) ans2++;
		jmp|=st.top();
		st.pop();
	}
	return jmp;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	bool kmp,jmp;
	int ans1=0,ans2=0;stack<bool>st;
	bool yuflag=false,huaflag=false;
	string cmp="";
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='(')
		{
			for(int j=i+1;;j++)
			{
				if(s[i]==')') break;
				cmp+=s[i];
			}
			bool ct=kuohao(cmp);
			if(ct==1&&yuflag==false)
		{
			st.push(1);
		}
		else if(ct==1&&yuflag==true)
		{
			kmp&=1;
			st.push(kmp);
			yuflag==false;
		}
		else if(ct==0&&yuflag==false)
		{
			st.push(0);
		}
		else if(ct==0&&yuflag==true)
		{
			kmp&=0;
			st.push(kmp);
			yuflag==false;
		}
			continue;
		}
		if(s[i]=='1'&&yuflag==false)
		{
			st.push(1);
		}
		else if(s[i]=='1'&&yuflag==true)
		{
			kmp&=1;
			st.push(kmp);
			yuflag==false;
		}
		else if(s[i]=='0'&&yuflag==false)
		{
			st.push(0);
		}
		else if(s[i]=='0'&&yuflag==true)
		{
			kmp&=0;
			st.push(kmp);
			yuflag==false;
		}
		else if(s[i]='&')
		{
			kmp=st.top();
			st.pop();
			yuflag=true;
			if(kmp==0) ans1++;
		}
	}
	while(st.size())
	{
		if(st.top()==1) ans2++;
		jmp|=st.top();
		st.pop();
	}
	cout<<jmp<<"\n"<<ans1<<" "<<ans2;
	return 0;
}