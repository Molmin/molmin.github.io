#include<bits/stdc++.h>
using namespace std;
long long n,e,d;
long long t;
int k;
bool flag=false;
long long m;
bool check(long long p,long long q)
{
	long long z=(n-p-q+1)+1;
	return z==t;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	//10^9 need O(log(log(n)))
	//buxing n-ed+2<=10^9 so p+q<=10^9 O(n/2); 
	//n=p×q,
	//e×d=(p−1)(q−1)+1
	scanf("%d",&k);
	while(k--)
	{
		flag=false;
		scanf("%lld%lld%lld",&n,&e,&d);
		t=e*d;
		m=n-t+2;
		for(long long i=1;i<=m/2&&i+(n/i)>=m;i++)
		{
			if(n%i==0&&i+(n/i)==m)
			{
				if(check(i,n/i))
				{
					flag=true;
					cout<<i<<" "<<n/i<<"\n";
					break;
				}
			}
		}
		if(!flag) cout<<"NO"<<"\n";
	}
	return 0;
}