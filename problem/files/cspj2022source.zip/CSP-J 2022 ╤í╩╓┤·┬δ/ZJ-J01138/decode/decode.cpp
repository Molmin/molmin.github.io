#include<bits/stdc++.h>
using namespace std;
long long T,a,b,c,d,p;
bool pd(long long x){
	return x==sqrt(x)*sqrt(x);
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&T);
	while(T--){
		scanf("%lld%lld%lld",&a,&b,&c);
		d=a-b*c+2;
		if(d*d<4*a) printf("NO\n");
		else{
			p=(d-sqrt(d*d-4*a))/2;
			if((d-p)*p==a) printf("%lld %lld\n",p,d-p);
			else printf("NO\n");
		}
	}
	return 0;
}
