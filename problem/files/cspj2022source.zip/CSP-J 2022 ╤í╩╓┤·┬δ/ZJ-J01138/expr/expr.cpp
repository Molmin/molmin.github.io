#include<bits/stdc++.h>
using namespace std;
int i,n,t,w,t1,w1,fl,fr,a[100100],el;
char s[100100],b[100100];
bool pd(int x){
	if(b[w]=='&') return 1;
	if(s[x+1]=='&') return 0;
	return 1;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s+1); n=strlen(s+1);
	for(i=1;i<=n;i++){
		if(s[i]=='1' || s[i]=='0'){
			if(el) continue;
			if(fl && pd(i)){t=fl; fl=0; w=fr-1; fr=0;}
			else{
				if(b[w]!='(' && b[w]!=')'){
					if(b[w]=='&'){
						a[t]=(a[t]&(s[i]-48)); w--;
					}
					else if(s[i+1]!='&') a[t]=(a[t]|(s[i]-48)),w--;
					else a[++t]=s[i]-48;
				}
				else a[++t]=s[i]-48;
			}
		}
		else{
			if(fl && s[i]=='(') el++;
			else if(fl && s[i]==')'){
				el--;
				if(!el) t=fl; fl=0; w=fr-1; fr=0;
			}
			else{
				if(el) continue;
				b[++w]=s[i];
				if(s[i]=='&'){
					if(a[t]==0 && !fl) t1++,fl=t,fr=w;
				}
				else if(s[i]=='|'){
					if(a[t]==1 && !fl) w1++,fl=t,fr=w;
				}
				else if(s[i]==')'){
					w--;
					if(s[i+1]=='&'){
						while(w>0 && b[w]!='('){
							if(b[w]=='|') a[t-1]=(a[t-1]|a[t]),t--;
							else if(b[w]=='&') a[t-1]=(a[t-1]&a[t]),t--;
							w--;
						}
					}
					else{
						while(w>0 && b[w]!=')'){
							if(b[w]=='|') a[t-1]=(a[t-1]|a[t]),t--;
							else if(b[w]=='&') a[t-1]=(a[t-1]&a[t]),t--;
							w--;
						}
					}
				}
			}
		}
	}
	while(w>0){
		if(b[w]=='|') a[t-1]=(a[t-1]|a[t]),t--;
		else if(b[w]=='&') a[t-1]=(a[t-1]&a[t]),t--;
		w--;
	}
	printf("%d\n%d %d",a[1],t1,w1);
	return 0;
}
