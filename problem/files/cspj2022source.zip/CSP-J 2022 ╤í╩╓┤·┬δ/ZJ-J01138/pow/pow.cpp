#include<bits/stdc++.h>
using namespace std;
long long i,p,n,m;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	if(n==1){printf("1"); return 0;}
	p=n;
	for(i=2;i<=m;i++)
	    if(p*n<=1000000000) p=p*n;
	    else{
	    	printf("-1"); return 0;
		}
	printf("%lld",p);
	return 0;
}
