#include<bits/stdc++.h>
using namespace std;
struct shuzi
{
	int num,s1,s2;
}a[1000005];
int n,m,ch[1000005];
string st;
inline shuzi jisuan(shuzi a,shuzi b,int c)
{
//	cout<<endl;
//	cout<<a.num<<' '<<a.s1<<' '<<a.s2<<endl;
//	cout<<b.num<<' '<<b.s1<<' '<<b.s2<<endl;
//	cout<<c<<endl;
//	cout<<endl;
	shuzi x;
	if(c==2)
	{
		x.num=a.num|b.num;
		if(a.num==1)
		{
			x.s1=a.s1;
			x.s2=a.s2+1;
		}
		else
		{
			x.s1=a.s1+b.s1;
			x.s2=a.s2+b.s2;
		}
	}
	else if(c==3)
	{
		x.num=a.num&b.num;
		if(a.num==0)
		{
			x.s1=a.s1+1;
			x.s2=a.s2;
	    }
		else
		{
			x.s1=a.s1+b.s1;
			x.s2=a.s2+b.s2;
		}
	}
	return x;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>st;
	st='('+st+')';
	for(int i=0;i<st.length();i++)
	{
		if(st[i]=='(')
		{
			m++;
			ch[m]=1;
		}
		else if(st[i]=='|')
		{
			while(n>1&&m>0&&ch[m]>=2)
			{
				a[n-1]=jisuan(a[n-1],a[n],ch[m]);
				n--;
				m--;
			}
			ch[++m]=2;
		}
		else if(st[i]=='&')
		{
			while(n>1&&m>0&&ch[m]>=3)
			{
				a[n-1]=jisuan(a[n-1],a[n],ch[m]);
				n--;
				m--;
			}
			ch[++m]=3;
		}
		else if(st[i]==')')
		{
			while(n>1&&m>0&&ch[m]!=1)
			{
				a[n-1]=jisuan(a[n-1],a[n],ch[m]);
				n--;
				m--;
			}
			m--;
		}
		else
		{
			a[++n].num=st[i]-'0';
			a[n].s1=0;
			a[n].s2=0;
		}
	}
	cout<<a[1].num<<'\n';
	cout<<a[1].s1<<' '<<a[1].s2<<'\n';
    return 0;
}