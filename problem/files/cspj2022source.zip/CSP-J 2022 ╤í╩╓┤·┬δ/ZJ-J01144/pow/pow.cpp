#include<bits/stdc++.h>
using namespace std;
#define int long long
int a,b,ans;
bool flag;
signed main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a;
	if(a==1)
	{
		puts("1");
		return 0;
	}
	cin>>b;
	ans=1;flag=1;
	for(int i=1;i<=b;i++)
	{
		ans*=a;
		if(ans>1e9)
		{
			flag=0;
			break;
		}
	}
	if(flag) cout<<ans<<'\n';
	else puts("-1");
	return 0;
}