#include<bits/stdc++.h>
using namespace std;
#define int long long
int k,n,e,d,p,q,m,h,_;
inline int read()
{
	int x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}
	return x*f;
}
inline int sqr(int x)
{
	return x*x;
}
signed main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	while(k--)
	{
		n=read(),d=read(),e=read();
		m=n-e*d+2;
		if(sqr(m)<4*n)
		{
			puts("NO");
			continue;
		}
		h=sqr(m)-4*n;
		_=sqrt(h);
		if(sqr(_)!=h)
		{
			puts("NO");
			continue;
		}
		if((m-_)%2!=0)
		{
			puts("NO");
			continue;
		}
		p=(m-_)/2;
		q=(m+_)/2;
		if(p<=0||q<=0)
		{
			puts("NO");
			continue;
		}
		printf("%lld %lld\n",p,q);
	}
	return 0;
}
//n e d
//n=pq
//ed=pq-p-q+2
//ed=n-p-q+2
//m=n-ed+2=p+q
//
//
//p+q=n-ed+2
//pq=n
//
//p=n-ed+2-q
//
//q(n-ed+2-q)=n
//
//-q^2+q(n-ed+2)-n=0;
//
//a=-1 b=n-ed+2 c=-n
