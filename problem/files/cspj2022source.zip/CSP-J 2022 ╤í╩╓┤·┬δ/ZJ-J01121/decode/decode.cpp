#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int k;
ll e,d,n;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%d",&k);
	for(int ii = 1;ii <= k;ii++){
		scanf("%lld%lld%lld",&n,&d,&e);
		ll m = 2 + n - e * d;
		if(m <= 0){
			printf("NO\n");
			continue;
		}
		ll t = m * m - 4 * n;
		if(ll(sqrt(t)) * ll(sqrt(t)) != t){
			printf("NO\n");
			continue;
		}
		m += sqrt(t);
		if(m % 2 != 0){
			printf("NO\n");
			continue;
		}
		printf("%lld %lld\n",n * 2 / m,m / 2);
	}
}