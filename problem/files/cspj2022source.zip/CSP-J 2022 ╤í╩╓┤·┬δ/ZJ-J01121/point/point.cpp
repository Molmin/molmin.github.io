#include<bits/stdc++.h>
using namespace std;
int n,k;
struct node{
	int x,y;
	int tag;
};
node f[510];
node g[510];
int cmp(node a,node b){
	if(a.x == b.x) return a.y < b.y;
	return a.x < b.x;
}
int cmp1(node a,node b){
	if(a.y == b.y) return a.x < b.x;
	return a.y < b.y;
}
struct res{
	int k,l;
	res(int k1,int l1){
		k = k1;
		l = l1;
	}
};
vector <res> dp[510];
int mpf[510],mpg[510];
struct point{
	int l;
	int x,y;
	point(int l1,int x1,int y1){
		l = l1;
		x = x1;
		y = y1;
	}
};
int vis[510];
int tx[2] = {0,1};
int ty[2] = {1,0};
void bfs(point u){
	queue <point> q;
	q.push(u);
	while(!q.empty()){
		point v = q.front();
		q.pop();
		for(int i = 0;i <= 1;i++){
			point to = v;
			to.x += tx[i];
			to.y += ty[i];
			to.l++;
			for(int j = 1;j <= n;j++){
				if(to.x == f[j].x && to.y == f[j].y && !vis[j]){
					q.push(to);
					vis[j] = to.l;
				}
			}
		}
	}
}
void solve(){
	for(int i = 1;i <= n;i++){
		if(!vis[i]){
			bfs(point(1,f[i].x,f[i].y));
		}
	}	
	int ans = -1;
	for(int i = 1;i <= n;i++){
		ans = max(ans,vis[i]);
	}
	printf("%d\n",ans);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i = 1;i <= n;i++){
		scanf("%d%d",&f[i].x,&f[i].y);
		g[i].x = f[i].x;
		g[i].y = f[i].y;
		f[i].tag = g[i].tag = i;
		dp[i].push_back(res(0,1));
	}
	stable_sort(f + 1,f + n + 1,cmp);//x > y
	stable_sort(g + 1,g + n + 1,cmp1);//y > x
	if(k == 0){
		solve();
		return 0;
	}
	for(int i = 1;i <= n;i++){
		mpf[f[i].tag] = i;
		mpg[g[i].tag] = i;
	}
	for(int i = 1;i <= n;i++){
		while(f[i].x == f[i + 1].x){
			for(int j = 0;j < dp[f[i].tag].size();j++){
				if(f[i + 1].y - f[i].y - 1 + dp[f[i].tag][j].k <= k){
					bool flag = 0;
					for(int l = 0;l < dp[f[i + 1].tag].size();l++){
						if(dp[f[i + 1].tag][l].k == f[i + 1].y - f[i].y - 1 + dp[f[i].tag][j].k){
							dp[f[i + 1].tag][l].l = max(dp[f[i + 1].tag][l].l,dp[f[i].tag][j].l + f[i + 1].y - f[i].y);
							flag = 1;
							break;
						}
					}
					if(!flag) dp[f[i + 1].tag].push_back(res(f[i + 1].y - f[i].y - 1 + dp[f[i].tag][j].k,dp[f[i].tag][j].l + f[i + 1].y - f[i].y));
				}
			}
			i++;
		}
	}
	for(int i = 1;i <= n;i++){
		while(g[i].y == g[i + 1].y){
			for(int j = 0;j < dp[g[i].tag].size();j++){
				if(g[i + 1].x - g[i].x - 1 + dp[g[i].tag][j].k <= k){
					int flag = 0;
					int l1;
					for(int l = 0;l < dp[g[i + 1].tag].size();l++){
						if(dp[g[i + 1].tag][l].k == g[i + 1].x - g[i].x - 1 + dp[g[i].tag][j].k){
							if(dp[g[i + 1].tag][l].l < dp[g[i].tag][j].l + g[i + 1].x - g[i].x){//can be update
								l1 = l;
								dp[g[i + 1].tag][l1].l = dp[g[i].tag][j].l + g[i + 1].x - g[i].x;
								flag = 2;
								break;
							}
							flag = 1;
							break;
						}
					}
					if(!flag){
						dp[g[i + 1].tag].push_back(res(g[i + 1].x - g[i].x - 1 + dp[g[i].tag][j].k,dp[g[i].tag][j].l + g[i + 1].x - g[i].x));
						l1 = dp[g[i + 1].tag].size() - 1;
					}
					if(flag == 1) continue;
					int t = mpf[g[i + 1].tag];
					int know = dp[g[i + 1].tag][l1].k;
					while(f[t].x == f[t + 1].x){
						flag = 0;
						for(int m = 0;m < dp[f[t + 1].tag].size();m++){
							if(know + f[t + 1].y - f[t].y - 1 == dp[f[t + 1].tag][m].k){
								dp[f[t + 1].tag][m].l = dp[f[t].tag][l1].l + f[t + 1].y - f[t].y;
								l1 = m;
								flag = 1;
								break;
							}
						}
						if(!flag){
							dp[f[t + 1].tag].push_back(res(know + f[t + 1].y - f[t].y - 1,dp[f[t].tag][l1].l + f[t + 1].y - f[t].y));
						}
						t++;
						know = know + f[t + 1].y - f[t].y - 1;
					}
				}
			}
			i++;
		}
	}
	int ans = -1;
	for(int i = 1;i <= n;i++){
		for(int j = 0;j < dp[i].size();j++){
			ans = max(ans,dp[i][j].l + k - dp[i][j].k);
//			printf("%d   %d   %d\n",i,dp[i][j].l,dp[i][j].k);
		}
	}
	printf("%d\n",ans);
}