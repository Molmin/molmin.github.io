#include<bits/stdc++.h>
using namespace std;
long long x,y;//x^y
typedef long long ll;
int check(ll t){
	if(t > 1000000000 || t == -1) return 1;
	return 0;
}
ll fast_mul(int a,int b){
	ll ans = 0;
	while(b){
		if(b & 1){
			ans = (ans + a);
			if(check(ans)) return -1;
		}
		a <<= 1;
		b >>= 1;
	}
	return ans;
}
ll ksm(int a,int b){
	ll ans = 1;
	while(b){
		if(b & 1){
			ans = fast_mul(ans,a);
			if(check(ans)) return -1;
		}
		b >>= 1;
		a = fast_mul(a,a);
		if(check(a)) return -1;
	}
	return ans;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&x,&y);
	printf("%lld",ksm(x,y));
}