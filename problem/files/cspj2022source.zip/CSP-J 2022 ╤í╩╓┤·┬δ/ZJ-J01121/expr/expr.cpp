#include<bits/stdc++.h>
using namespace std;
char c;
bool fu;//1 == &,0 == |
int las,now;
int land,lor,sum;
string s;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin >> s;
	int len = s.length();
	if(len == 1){
		cout << s[0] << endl;
		printf("0 0\n");
		return 0;
	}
	if(len == 3){
		if(s[1] == '0' || s[1] == '1'){
			cout << s[1] << endl;
			printf("0 0\n");
			return 0;
		}
		else{
			if(s[1] == '&'){
				if(s[0] == '0'){
					printf("0\n1 0\n");
					return 0;
				}
				cout << ((s[0] - '0') & (s[2] - '0') )<< endl;
				printf("0 0\n");
				return 0;
			}
			if(s[1] == '|'){
				if(s[0] == '1'){
					printf("1\n0 1\n");
					return 0;
				}
				cout << ((s[0] - '0') | (s[2] - '0') )<< endl;
				printf("0 0\n");
				return 0;
			}
		}
	}
	if(len == 5){
		if(s[1] == '0' && s[3] == '&'){
			printf("0\n1 0\n");
			return 0;
		}
		if(s[1] == '1' && s[3] == '|'){
			printf("1\n0 1\n");
			return 0;
		}
		if(s[0] == '0' && s[1] == '&'){
			printf("0\n1 0\n");
			return 0;
		}
		if(s[1] == '1' && s[2] == '|'){
			printf("1\n0 1\n");
			return 0;
		}
		if(s[1] == '0' && s[2] == '&'){
			printf("0\n1 0\n");
			return 0;
		}
		if(s[0] == '1' && s[1] == '|'){
			printf("1\n0 1\n");
			return 0;
		}
		if(s[2] == '0' || s[2] == '1'){
			int t;
			if(s[1] == '&') t = (s[0] - '0') & (s[2] - '0');
			if(s[1] == '|') t = (s[0] - '0') | (s[2] - '0');
			if(t == 0 && s[3] == '&'){
				printf("0\n1 0\n");
				return 0;
			}
			if(t == 1 && s[3] == '|'){
				printf("1\n0 1\n");
				return 0;
			}
			if(s[3] == '&') t = t & (s[4] - '0');
			if(s[3] == '|') t = t | (s[4] - '0');
			printf("%d\n0 0",t);
			return 0;
		}
		if(s[2] == ')'){
			int t;
			if(s[3] == '&'){
				t = (s[1] - '0') & (s[4] - '0');
			}
			if(s[3] == '|'){
				t = (s[1] - '0') | (s[4] - '0');
			}
			printf("%d\n0 0",t);
		}
		if(s[2] == '('){
			int t;
			if(s[1] == '&'){
				t = (s[0] - '0') & (s[3] - '0');
			}
			if(s[1] == '|'){
				t = (s[0] - '0') | (s[3] - '0');
			}
			printf("%d\n0 0",t);
		}
		return 0;
	}
	int lst = s[0] - '0';
	int d1 = 0,d2 = 0;
	for(int i = 1;i < len;i += 2){
		if(s[i] == '&'){
			if(lst == 0){
				printf("0\n%d %d\n",d1 + 1,d2);
				return 0;
			}
			else{
				lst = lst & (s[i + 1] - '0');
			}
		}
		if(s[i] == '|'){
			if(lst == 1){
				printf("1\n%d %d\n",d1,d2 + 1);
			}
			else{
				lst = lst | (s[i + 1] - '0');
			}
		}
	}
}