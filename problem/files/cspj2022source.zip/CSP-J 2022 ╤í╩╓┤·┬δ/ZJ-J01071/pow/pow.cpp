#include<bits/stdc++.h>
using namespace std;
#define Rout(A) ((cout<<(A)),0)
long long a,b,c;
const long long MA=1e9;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	c=a;
	for(long long i=1;i<=b;i++){
		if(a>MA)return Rout(-1);
		a*=c;
	}
	cout<<a;
	return 0;
}
