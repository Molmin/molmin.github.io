#include<bits/stdc++.h>
using namespace std;
#define LL long long
LL t,n,d,e,a[1000005];
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&t);
	while(t--){
		scanf("%lld%lld%lld",&n,&d,&e);
		LL i=2,f=1,j=1;
		LL C=n+2-e*d;
		for(;i*i<=n;i++)if(n%i==0&&i+n/i==C){
			cout<<i<<" "<<n/i<<endl,f=0;
			break;
		}
		if(f)
		cout<<"NO"<<endl;
	}
	return 0;
}
