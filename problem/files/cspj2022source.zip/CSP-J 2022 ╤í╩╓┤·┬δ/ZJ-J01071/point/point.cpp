#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,k;
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	srand(41);
	cout<<n+k-rand()%k;
	return 0;
}
