#include<bits/stdc++.h>
#define c0 '0'
#define c1 '1'
#define isd(F) (((F)==c1)||((F)==c0))
#define too(F) (((F)=='|')?1:0)
using namespace std;
inline string sts(char F) {
	string gp="";
	gp+=F;
	return gp;
}
string p;
int a1,a2;
int nxt(int l) {
	char c=p[l];
	if(isd(c))return l;
	if(c=='(') {
		int j=l,ans=0,lp=0;
		for(; j<p.size(); j++) {
			if(p[j]==')')ans++;
			if(p[j]=='(')lp++;
			if(ans==lp)break;
		}
		return j;
	}
}
bool dfs(int l,int r) {
	if(r-l==0)return p[l]-c0;
	int i=l;
	for(int i=l; i<=r; i++)cout<<p[i];
	cout<<endl;
	bool f,pre;
	for(i=l; i<r; i++) {
		if(isd(p[i])) {
			int pi=dfs(i,i);
			if(p[i+1]=='&') {
				int h;
				if(pi==0)a1++,i=nxt(i+2)+2,h=0;
				else h=1&&(dfs(i+2,nxt(i+2))),i=nxt(i+2)+2;
				if(i==l)f=h;
				else f=pre?f|=h:f&=h;
				pre=too(p[i+1]);
			} else {
				int h;
				if(pi==1)a2++,i=nxt(i+2)+2,h=1;
				else h=0||(dfs(i+2,nxt(i+2))),i=nxt(i+2)+2;
				if(i==l)f=h;
				else f=pre?f|=h:f&=h;
				pre=too(p[i+1]);
			}
		}
		if(p[i]=='(') {
			int j=i,ans=0,lp=0;
			for(; j<=r; j++) {
				if(p[j]==')')ans++;
				if(p[j]=='(')lp++;
				if(ans==lp)break;
			}
			int pi=dfs(i+1,j-1);
			i=j;
			if(p[i+1]=='&') {
				int h;
				if(pi==0)a1++,i=nxt(i+2)+2,h=0;
				else h=1&&(dfs(i+2,nxt(i+2))),i=nxt(i+2)+2;
				if(i==l)f=h;
				else f=pre?f|=h:f&=h;
				pre=too(p[i+1]);
			} else {
				int h;
				if(pi==1)a2++,i=nxt(i+2)+2,h=1;
				else h=0||(dfs(i+2,nxt(i+2))),i=nxt(i+2)+2;
				if(i==l)f=h;
				else f=pre?f|=h:f&=h;
				pre=too(p[i+1]);
			}
		}
	}
	return r;
}
int main() {
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>p;
	cout<<dfs(0,p.size()-1)<<endl;
	cout<<a1<<" "<<a2;
	return 0;
}
