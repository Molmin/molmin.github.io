#include <bits/stdc++.h>
using ll = long long;
int t = 0;
ll n = 0, d = 0, e = 0, p = 0, q = 0;
bool check(ll a, ll b) {return a == b;}
void solve() {
	scanf("%lld%lld%lld", &n, &e, &d);
	ll mul = n;
	ll add = n - e * d + 2ll;
	ll red2 = add * add - 4ll * mul;
	if (red2 < 0) return puts("NO"), void();
	ll red = (ll)std::sqrt(red2);
	if (!check(red * red, red2)) return puts("NO"), void();
	if (add + red % 2 == 1) return puts("NO"), void();
	q = (add + red) / 2;
	p = add - q;
	if (p <= 0 || q <= 0) return puts("NO"), void();
	if (p * q != n || (p - 1) * (q - 1) + 1 != e * d) return puts("NO"), void();
	return printf("%lld %lld\n", p, q), void();
}
signed main() {
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	scanf("%d", &t);
	while (t--) solve();
	return 0;
}
