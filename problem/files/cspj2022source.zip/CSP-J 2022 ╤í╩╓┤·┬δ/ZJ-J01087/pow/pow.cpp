#include <bits/stdc++.h>
using ll = long long;
static constexpr int L = 2147483647;
int a = 0, b = 0;
int qpow(int x, int y) {
	ll base = x, power = y, ans = 1;
	for (; power; power >>= 1, base = base * base) {
		if (base > L) return -1;
		if (power & 1) ans = ans * base;
		if (ans > L) return -1;
	}
	return (int)ans;
}
signed main() {
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	scanf("%d%d", &a, &b);
	printf("%d\n", qpow(a, b));
	return 0;
}
