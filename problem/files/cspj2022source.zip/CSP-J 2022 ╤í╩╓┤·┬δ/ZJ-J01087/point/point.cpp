#include <bits/stdc++.h>

#define x first
#define y second

static constexpr int N = 5e2 + 5; 
using pii = std::pair<int, int>;

int n, K, ans; pii p[N];
std::map<pii, bool> map, vis;

struct node {
	int x, y, step, last;
	node(int x = 0, int y = 0, int step = 0, int last = K):
		x(x), y(y), step(step), last(last) {}
	friend bool operator < (const node &a, const node &b) {
		if (a.last == b.last) return a.step > b.step;
		return a.last < b.last;
	}
};

static constexpr int dx[] = {0, 1};
static constexpr int dy[] = {1, 0};

void bfs(int sx, int sy) {
	static std::priority_queue<node> q;
	vis.clear();
	q.emplace(sx, sy);
	
	while (q.size()) {
		auto note = q.top(); q.pop();
		if (note.last == -1) {
			ans = std::max(ans, note.step);
			continue;
		}
		
		bool f1 = !vis.count(pii(note.x + 1, note.y));
		bool f2 = !vis.count(pii(note.x, note.y + 1));
		vis[pii(note.x, note.y + 1)] = true;
		vis[pii(note.x + 1, note.y)] = true;
		
		if (f1 && f2) {
			if (map.count(pii(note.x + 1, note.y))) 
				q.emplace(node(note.x + 1, note.y, note.step + 1, note.last - !map.count(pii(note.x + 1, note.y)))),
				q.emplace(node(note.x, note.y + 1, note.step + 1, note.last - !map.count(pii(note.x, note.y + 1))));
			else
				q.emplace(node(note.x, note.y + 1, note.step + 1, note.last - !map.count(pii(note.x, note.y + 1)))),
				q.emplace(node(note.x + 1, note.y, note.step + 1, note.last - !map.count(pii(note.x + 1, note.y))));
		}
		else if (f2)
			q.emplace(node(note.x, note.y + 1, note.step + 1, note.last - !map.count(pii(note.x, note.y + 1))));
		else if (f1)
			q.emplace(node(note.x + 1, note.y, note.step + 1, note.last - !map.count(pii(note.x + 1, note.y))));
	}
}

signed main() {
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	scanf("%d%d", &n, &K);
	for (int i = 1; i <= n; ++i) scanf("%d%d", &p[i].x, &p[i].y);
	for (int i = 1; i <= n; ++i) map[pii(p[i].x, p[i].y)] = true;
	for (int i = 1; i <= n; ++i) bfs(p[i].x, p[i].y);
	printf("%d\n", ans);
	return 0;
}
