#include <bits/stdc++.h>
static constexpr int N = 1e6 + 5;
int n = 0;
char str[N] = {};
struct node {
	int value, cnt1, cnt2;
	node(int value = 0, int cnt1 = 0, int cnt2 = 0):
		value(value), cnt1(cnt1), cnt2(cnt2) {}
	node operator | (const node &a) const {
		if (value) return node(1, cnt1, cnt2 + 1);
		return node(value | a.value, cnt1 + a.cnt1, cnt2 + a.cnt2);
	}
	node operator & (const node &a) const {
		if (!value) return node(0, cnt1 + 1, cnt2);
		return node(value & a.value, cnt1 + a.cnt1, cnt2 + a.cnt2);
	}
	void print() {
		printf("%d\n", value);
		printf("%d %d\n", cnt1, cnt2);
		return void();
	}
};
std::stack<node> num;
std::stack<int> op;
void calc() {
	int ch = op.top(); op.pop();
	if (ch == 0) return void();
	
	const node &num2 = num.top(); num.pop();
	if (op.size() && op.top() >= ch) calc();
	const node &num1 = num.top(); num.pop();
	
	if (ch == 1) num.emplace(num1 | num2);
	if (ch == 2) num.emplace(num1 & num2);
}
signed main() {
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	scanf("%s", str + 1);
	n = strlen(str + 1);
	str[0] = '('; str[n + 1] = ')';
	for (int i = 0; i <= n + 1; ++i) {
		if (isdigit(str[i])) num.emplace(node(str[i] - '0', 0, 0));
		else if (str[i] == '|') op.emplace(1);
		else if (str[i] == '&') op.emplace(2);
		else if (str[i] == '(') op.emplace(0);
		else if (str[i] == ')') {
			while (op.top() != 0) calc();
			op.pop();
		}
	}
	num.top().print();
	return 0;
}
////0&(1|0)|(1|1|1&0)
//#include <bits/stdc++.h>
//static constexpr int N = 1e6 + 5;
//int n = 0;
//char str[N] = {};
//struct node {
//	int id, value, cnt1, cnt2;
//	node(int id = 0, int value = 0, int cnt1 = 0, int cnt2 = 0):
//		id(id), value(value), cnt1(cnt1), cnt2(cnt2) {}
//	node operator | (const node &a) const {
//		if (value) return node(a.id, 1, cnt1, cnt2 + 1);
//		return node(a.id, value | a.value, cnt1 + a.cnt1, cnt2 + a.cnt2);
//	}
//	node operator & (const node &a) const {
//		if (!value) return node(a.id, 0, cnt1 + 1, cnt2);
//		return node(a.id, value & a.value, cnt1 + a.cnt1, cnt2 + a.cnt2);
//	}
//	bool operator < (const node &a) const {
//		return id < a.id;
//	}
//	void print() {
//		printf("%d\n", value);
//		printf("%d %d\n", cnt1, cnt2);
//		return void();
//	}
//};
//std::set<node> num;
//std::set<int> AND, OR;
//std::stack<int> bracket;
//void calc(int l, int r) {
//	auto it1 = AND.lower_bound(l);
//	while (it1 != AND.end() && *it1 <= r) {
//		auto nit2 = num.lower_bound(node(*it1, 0, 0, 0));
//		auto nit1 = nit2; -- nit1;
//		num.emplace(*nit1 & *nit2);
//	}
//	auto it3 = OR.lower_bound(l);
//	while (it3 != OR.end() && *it3 <= r) {
//		auto nit2 = num.lower_bound(node(*it3, 0, 0, 0));
//		auto nit1 = nit2; -- nit1;
//		num.emplace(*nit1 | *nit2);
//	}
//}
//signed main() {
////	freopen("expr.in", "r", stdin);
////	freopen("expr.out", "w", stdout);
//	scanf("%s", str + 1);
//	n = strlen(str + 1);
//	str[0] = '('; str[n + 1] = ')';
//	// 1&1|1&1|1&1|1
//	for (int i = 0; i <= n + 1; ++i) {
//		if (isdigit(str[i])) num.emplace(node(i, str[i] - '0', 0, 0));
//		else if (str[i] == '|') OR.emplace(i);
//		else if (str[i] == '&') AND.emplace(i);
//		else if (str[i] == '(') bracket.emplace(0);
//		else if (str[i] == ')') {
//			int p = bracket.top(); bracket.pop();
//			calc(p, i);
//		}
//	}
//	node a = *num.begin(); a.print();
//	return 0;
//}
