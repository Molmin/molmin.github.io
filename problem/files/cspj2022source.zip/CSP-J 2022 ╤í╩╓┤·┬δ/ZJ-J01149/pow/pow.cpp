#include <bits/stdc++.h>
using namespace std;
int a, b;
unsigned long long ans;
int main()
{
    freopen("pow.in", "r", stdin);
    freopen("pow.out", "w", stdout);


    cin >> a >> b;

    ans = pow(a, b);

    if(ans > 1000000000 or ans == 0)
    {

        cout << -1 << endl;
        return 0;
    }
    cout << ans << endl;


    return 0;
}
