#include <bits/stdc++.h>
using namespace std;

string str;
int len, ansa, ansb;
stack <int> num;
stack <char> op;

void oper(char ch);

int main()
{
    freopen("expr.in", "r", stdin);
    freopen("expr.out", "w", stdout);

    cin >> str;
    len = str.length();

    for(int i = 0; i < len; i++)
    {
        if(str[i] == '1' or str[i] == '0')
        {
            num.push(str[i] - 48);
        }
        else if(str[i] == '&')
        {
            if(!op.empty())
            {
                if(op.top() == '&')
                {
                    oper('&');
                }
                else if(op.top() == '|' and num.top() == 0)
                {
                     num.pop();
                     if(num.top() == 1)ansa--;
                     num.push(0);
                }
            }
            op.push(str[i]);
        }
        else if(str[i] == '|')
        {
            if(!op.empty())
            {
                oper(op.top());
            }
            op.push(str[i]);
        }
        else if(str[i] == '(')
        {
            op.push(str[i]);
        }
        else
        {
            int flag = 0;
            char c = op.top();
            while(op.top() != '(')
            {
                flag++;
                oper(op.top());
            }
            op.pop();
            if(flag == 1)
            {
                if((op.top() == '&' and num.top() == 0) or (op.top() == '|' and num.top() == 1))
                {
                    ansb--;
                }
            }
        }
    }

    while(!op.empty())
    {
        oper(op.top());
    }

    cout << num.top() << endl;
    cout << ansa << " " << ansb << endl;


    return 0;
}

void oper(char ch)
{
    op.pop();
    if(ch == '&')
    {
        int y = num.top();
        num.pop();
        int x = num.top();
        num.pop();

        if(x == 0)
        {
            ansa++;
        }
        num.push(x&y);
    }
    else if(ch == '|')
    {
        int y = num.top();
        num.pop();
        int x = num.top();
        num.pop();

        if(x == 1)
        {
            ansb++;
        }
        num.push(x|y);
    }
}
