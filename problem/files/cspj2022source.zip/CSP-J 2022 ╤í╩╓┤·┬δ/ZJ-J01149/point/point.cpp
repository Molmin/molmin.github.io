#include <bits/stdc++.h>
using namespace std;

struct node{
    int x, y;
};
node s[505];

int n, k, mp, ans;

void searching(int d, int pos);

int main()
{
    freopen("point.in", "r", stdin);
    freopen("point.out", "w", stdout);

    cin >> n >> k;
    for(mp = 1; mp <= n; mp++)
    {
        cin >> s[mp].x >> s[mp].y;
    }

    for(int i = 1; i <= n; i++)searching(1, i);

    cout << ans << endl;

    return 0;
}

void searching(int d, int pos)
{
    bool isD = false;
    for(int i = 1; i <= mp; i++)
    {
        if((s[i].x == s[pos].x and s[i].y == s[pos].y + 1) or (s[i].y == s[pos].y and s[i].x == s[pos].x + 1))
        {
            isD = true;
            searching(d + 1, i);
        }
        else if(s[i].x + s[i].y <= s[pos].x + s[pos].y + k)
        {
            if(k)
            {
                isD = true;
                mp++;
                s[mp] = {s[pos].x, s[pos].y + 1};
                s[mp] = {s[pos].x + 1, s[pos].y};
                k--;
                searching(d + 1, mp);
                k++;
                mp--;
            }
        }
    }

    if(isD)return ;
    if(k)
    {
        d += k;
    }
    ans = max(ans, d);
}
