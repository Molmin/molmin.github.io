#include <bits/stdc++.h>
using namespace std;
int k, n, e, d;
void judge();

int main()
{
    freopen("decode.in", "r", stdin);
    freopen("decode.out", "w", stdout);

    scanf("%d", &k);
    while(k--)
    {
        scanf("%d %d %d", &n, &e, &d);
        judge();
    }


    return 0;
}

void judge()
{
    int sn = sqrt(n);
    long long ed = e * d, temp;
    for(int i = 1; i <= sn; i++)
    {
        if(n % i) continue;

        temp = (i - 1) * (n / i - 1) + 1;
        if(ed == temp)
        {
            printf("%d %d\n", i, n / i);
            return ;
        }
    }
    cout << "NO\n";
    return ;
}
