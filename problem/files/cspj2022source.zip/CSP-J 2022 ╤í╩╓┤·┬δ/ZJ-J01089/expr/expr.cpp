#include<bits/stdc++.h>
using namespace std;
int ans1=0,ans2=0;
int js(string str)
{
	if(str=="1") return 1;
	if(str=="0") return 0;
	int lens=str.length(),flag=0,j=0,j2=0;
	for(int i=0;i<lens;i++)
	{
		if(str[i]=='(') flag++;
		if(str[i]==')') flag--;
		if(flag==0&&(str[i]=='&'||str[i]=='|')&&j==0)
		{
			j=i;
		}
		if(flag==0&&(str[i]=='&'||str[i]=='|')&&j!=0)
		{
			j2=i;
			break;
		}
	}
	if(str[j]=='&')
	{	
		ans1+=1;
		string s1="",s2="",s3="";
		for(int i=0;i<j;i++)
		{
			s1+=str[i];
		}
		for(int i=j+1;i<j2;i++)
		{
			s2+=str[i];
		}
		for(int i=j2+1;i<lens;i++)
		{
			s3+=str[i];
		}
		if(js(s1)==0)
		{
			if(str[j2]=='&')
			{
				return 0&js(s3);
			}
			else return 0|js(s3);
			
		}
		else
		{
			if(str[j2]=='&')
			{
				return (js(s1)&js(s2))&js(s3);
			}
			else return (js(s1)&js(s2))|js(s3);
		}
	}
	else
	{
		ans2+=1;
		string s1="",s2="",s3="";
		for(int i=0;i<j;i++)
		{
			s1+=str[i];
		}
		for(int i=j+1;i<j2;i++)
		{
			s2+=str[i];
		}
		for(int i=j2+1;i<lens;i++)
		{
			s3+=str[i];
		}
		if(js(s1)==1)
		{
			if(str[j2]=='&')
			{
				return 1&js(s3);
			}
			else return 1|js(s3);	
		}
		else
		{
			if(str[j2]=='&')
			{
				return (js(s1)|js(s2))&js(s3);
			}
			else return (js(s1)|js(s2))|js(s3);
		}
	}
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string s;
	cin>>s;
	cout<<js(s)<<endl;
	cout<<ans1<<" "<<ans2;
	return 0;
}
