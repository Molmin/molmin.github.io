#include<bits/stdc++.h>
using namespace std;
int ma[1100][1100],mx=1e9,py,px,my=1e9,ans,bx=0,by=0,flag[1100][1100];
void search(int xx,int yy,int kk,int step)
{
	if(flag[xx][yy]==1) return;
	if((xx>bx||yy>by)&&kk>=0)
	{
		ans=max(ans,step+kk+1);
		return;
	}
	if(kk<0)
	{
		ans=max(ans,step-1);
		return;
	}
	flag[xx][yy]=1;
	if(ma[xx][yy+1]==1) search(xx,yy+1,kk,step+1);
	else search(xx,yy+1,kk-1,step+1);
	if(ma[xx+1][yy]==1) search(xx+1,yy,kk,step+1);
	else search(xx+1,yy,kk-1,step+1);
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x>>y;
		ma[x][y]=1;
		if(x<mx) mx=x,py=y;
		if(y<my) my=y,px=x;
		if(x>bx) bx=x;
		if(y>by) by=y;
	}
	search(mx,py,k,1);
	memset(flag,0,sizeof(flag));
	search(px,my,k,1);
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
