#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	scanf("%d",&k);
	while(k--)
	{
		long long n,e,d,ans;
		scanf("%lld%lld%lld",&n,&e,&d);
		ans=n-e*d+2;
		long long kk=ans;
		ans*=ans;
		ans-=4*n;
		long long t=sqrt(ans);
		long long a=kk+t,b=kk-t;
		if(ans%t!=0||a%2!=0||b%2!=0)
		{
			printf("NO\n");
			continue;
		}
		else
		{
			printf("%lld %lld\n",min(a/2,b/2),max(a/2,b/2));
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;	
}
