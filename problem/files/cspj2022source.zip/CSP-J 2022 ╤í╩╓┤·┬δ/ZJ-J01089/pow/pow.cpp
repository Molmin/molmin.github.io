#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,c;
	cin>>a>>b;
	if(a==1)
	{
		cout<<"1";
	}
	else
	{
		long long cnt=1;
		while(b--)
		{
			cnt*=a;
			if(cnt>1000000000)
			{
				cout<<"-1";
				return 0;
			}
		}
		cout<<cnt<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
	
}
