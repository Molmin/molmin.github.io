#include<bits/stdc++.h>
#define int long long
#define p_ putchar(' ')
#define pn putchar('\n')
using namespace std;
int read(){
	int s=0,c=1;
	char ch=getchar();
	while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
	if(ch=='-'){
		c=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*c;
}
void write(int x){
	if(x<0){
		putchar('-');
		write(-x);
		return;
	}
	if(x<10){
		putchar(x+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
	return;
}
struct qwq{
	int sum,num1,num2;
}q[2000005];
int q1[2000005],n,n1;
string s;
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	s='('+s+')';
	for(int i=0;i<s.size();){
		if(s[i]=='0'||s[i]=='1'){
			qwq x=(qwq){s[i]-'0',0,0};
			while(q1[n1]==2&&n1!=0){
				if(q[n].sum==0){
					x=(qwq){0,x.num1+q[n].num1,q[n].num2+1};
				}
				else {
					x=(qwq){x.sum&q[n].sum,x.num1+q[n].num1,x.num2+q[n].num2};
				}
				n--;
				n1--;
			}
			q[++n]=x;
			i++;
		}
		else if(s[i]=='|'||s[i]=='&'||s[i]=='('){
			if(s[i]=='|'){
				q1[++n1]=1;
			}
			if(s[i]=='&'){
				q1[++n1]=2;
			}
			if(s[i]=='('){
				q1[++n1]=3;
			}
			i++;
		}
		else if(s[i]==')'){
			i++;
			while(q1[n1]!=3&&n1!=0){
				if(q1[n1]==1){
					if(q[n-1].sum==1){
						q[n-1]=(qwq){1,q[n-1].num1+1,q[n-1].num2+q[n].num2};
					}
					else q[n-1]=(qwq){q[n-1].sum|q[n].sum,q[n-1].num1+q[n].num1,q[n-1].num2+q[n].num2};
				}
				if(q1[n1]==2){
					if(q[n-1].sum==0){
						q[n-1]=(qwq){0,q[n-1].num1+q[n].num1,q[n-1].num2+1};
					}
					else q[n-1]=(qwq){q[n-1].sum&q[n].sum,q[n-1].num1+q[n].num1,q[n-1].num2+q[n].num2};
				}
				n--;n1--;
			}
			n1--;
			while(q1[n1]!=3&&n1!=0){
				if(q1[n1]==1){
					if(q[n-1].sum==1){
						q[n-1]=(qwq){1,q[n-1].num1+1,q[n-1].num2+q[n].num2};
					}
					else q[n-1]=(qwq){q[n-1].sum|q[n].sum,q[n-1].num1+q[n].num1,q[n-1].num2+q[n].num2};
				}
				if(q1[n1]==2){
					if(q[n-1].sum==0){
						q[n-1]=(qwq){0,q[n-1].num1+q[n].num1,q[n-1].num2+1};
					}
					else q[n-1]=(qwq){q[n-1].sum&q[n].sum,q[n-1].num1+q[n].num1,q[n-1].num2+q[n].num2};
				}
				n--;n1--;
			}
		}
	}
	write(q[n].sum);
	pn;
	write(q[n].num2);p_;write(q[n].num1);
}	
/*
#include<bits/stdc++.h>
#define int long long
#define p_ putchar(' ')
#define pn putchar('\n')
using namespace std;
int read(){
	int s=0,c=1;
	char ch=getchar();
	while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
	if(ch=='-'){
		c=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*c;
}
void write(int x){
	if(x<0){
		putchar('-');
		write(-x);
		return;
	}
	if(x<10){
		putchar(x+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
	return;
}
struct qwq{
	int sum,num1,num2;
}q[2000005];
struct qwq1{
	int lef,an;
}q2[2000005];
int q1[2000005],n,n1,n2;
string s;
signed main(){
//	freopen("expr.in","r",stdin);
//	freopen("expr.out","w",stdout);
	cin>>s;
	s='('+s+')';
	for(int i=0;i<s.size();){
		if(s[i]=='0'&&s[i]=='1'){
			q[++n]=(qwq){s[i]-'0',0,0};
			if(q1[n1]==2){
				if(q[n-1].sum==0){
					q[n-1]=(qwq){0,q[n-1].num1,q[n-1].num2+1};
				}
				else q[n-1]=(qwq){q[n-1].sum&q[n].sum,q[n-1].num1+q[n].num1,q[n-1].num2+q[n].num2};
			n1--;
			n--;
			}
			i++;
		}
		else if(s[i]=='|'){
			q1[++n1]=1;
			i++;
		}
		else if(s[i]=='&'){
			q1[++n1]=2;
			i++;
		}
		else if(s[i]=='('){
			q1[++n1]=3;
			q2[++n2]=(qwq1){n1+1,n+1};
			i++;
		}
		else {
			int j=q2[n2].an+1;
			for(int i=q2[n2].lef;i<=n1;i++){
				if(q1[i]==2){
					if(q[j-1].sum==0){
						q[j]=(qwq){0,q[j-1].num1,q[j-1].num2+1};
					}
					else q[j]=(qwq){q[j-1].sum&q[j].sum,q[j-1].num1+q[j].num1,q[j-1].num2+q[j].num2};
				}
				else if(q1[i]==1){
					if(q[j-1].sum==1){
						q[j]=(qwq){1,q[j-1].num1+1,q[j-1].num2};
					}
					else q[j]=(qwq){q[j-1].sum|q[j].sum,q[j-1].num1+q[j].num1,q[j-1].num2+q[j].num2};
				}
			}
			q[q2[n2].an]=q[n];
			n=q2[n2].an;
			n1=q2[n2].lef-1;
			n2--;
			i++;
		}
	}
	write(q[1].sum);pn;
	write(q[1].num2);p_;write(q[1].num1);
}
cnm DEV C++ Ctrl + Z 
*/