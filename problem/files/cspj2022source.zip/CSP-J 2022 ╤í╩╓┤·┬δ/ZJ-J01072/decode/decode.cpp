#include<bits/stdc++.h>
#define int long long
#define p_ putchar(' ')
#define pn putchar('\n')
using namespace std;
int read(){
	int s=0,c=1;
	char ch=getchar();
	while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
	if(ch=='-'){
		c=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*c;
}
void write(int x){
	if(x<0){
		putchar('-');
		write(-x);
		return;
	}
	if(x<10){
		putchar(x+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
	return;
}
int n,d,e,m,L,R,ans,mid,k;
signed main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	for(int i=1;i<=k;i++){
		n=read();d=read();e=read();
		m=n-e*d+2;
		L=1;R=m/2;
		ans=0;
		while(L<=R){
			mid=(L+R)>>1;
			if(mid*(m-mid)>=n){
				ans=mid;
				R=mid-1;
			}
			else L=mid+1;
		}
		if(ans*(m-ans)==n){
			write(ans);p_;write(m-ans);pn;
		}
		else{
			putchar('N');
			putchar('O');
			putchar('\n');
		}
	}
	
}
