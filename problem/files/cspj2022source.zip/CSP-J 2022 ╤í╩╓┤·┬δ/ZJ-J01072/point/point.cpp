#include<bits/stdc++.h>
#define int long long
#define p_ putchar(' ')
#define pn putchar('\n')
using namespace std;
int read(){
	int s=0,c=1;
	char ch=getchar();
	while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
	if(ch=='-'){
		c=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*c;
}
void write(int x){
	if(x<0){
		putchar('-');
		write(-x);
		return;
	}
	if(x<10){
		putchar(x+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
	return;
}
int T,k,n,m,x,y,a[205][205],f[205][205][105],ans;
signed main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	T=read();k=read();
	for(int i=1;i<=T;i++){
		x=read();y=read();
		n=max(n,x);m=max(m,y);
		a[x][y]=1;
		f[x][y][0]=1;
	}
	for(int i=1;i<=n+k;i++){
		for(int j=1;j<=m+k;j++){
			if(!a[i][j]){
				for(int t=1;t<=k;t++){
					f[i][j][t]=max(f[i][j-1][t-1]+1,f[i-1][j][t-1]+1);
					ans=max(ans,f[i][j][t]);
				}
			}
			else {
				for(int t=0;t<=k;t++){
					f[i][j][t]=max(f[i][j-1][t]+1,f[i-1][j][t]+1);
					ans=max(ans,f[i][j][t]);
				}
			}
		}
	}
//	for(int t=0;t<=k;t++){
//		write(t);pn;
//		for(int i=1;i<=n+k;i++){
//			for(int j=1;j<=m+k;j++){
//				write(f[i][j][t]);p_;
//			}
//			pn;
//		}
//	}
	write(ans);
}
