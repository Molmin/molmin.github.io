#include<bits/stdc++.h>
#define int long long
#define p_ putchar(' ')
#define pn putchar('\n')
using namespace std;
int read(){
	int s=0,c=1;
	char ch=getchar();
	while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
	if(ch=='-'){
		c=-1;
		ch=getchar();
	}
	while(ch<='9'&&ch>='0'){
		s=s*10+ch-'0';
		ch=getchar();
	}
	return s*c;
}
void write(int x){
	if(x<0){
		putchar('-');
		write(-x);
		return;
	}
	if(x<10){
		putchar(x+'0');
		return;
	}
	write(x/10);
	putchar(x%10+'0');
	return;
}
int a,b;
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read();b=read();
	int s=1;
	while(b){
		if(b%2==1){
			s=s*a;
		}
		b/=2;
		a=a*a;
		if(s>1000000000){
			write(-1);
			return 0;
		}
	}
	write(s);
}
