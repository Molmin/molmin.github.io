#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b,ans=1;
	cin>>a>>b;
	for(int i=1;i<=b;i++){
		if(ans>100000000){
			cout<<-1;
			return 0;
		}else{
			ans*=a;
		}
	}
	cout<<ans;
	return 0;
}