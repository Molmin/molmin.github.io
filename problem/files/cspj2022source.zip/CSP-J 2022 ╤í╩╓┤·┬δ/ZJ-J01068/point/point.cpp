#include<bits/stdc++.h>
using namespace std;
int a[105][105]={0};
int k;
int maxn=0;
void bfs(int x,int y,int sy,int deep){
	if(deep>maxn){
		maxn=deep;
	}
	if(a[x+1][y]==1) bfs(x+1,y,sy,deep+1);
	else if(sy!=0) bfs(x+1,y,sy-1,deep+1);
	if(a[x][y+1]==1) bfs(x,y+1,sy,deep+1);
	else if(sy!=0) bfs(x,y+1,sy-1,deep+1);
	return;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int x[105],y[105];
	int n;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&x[i],&y[i]);
		a[x[i]][y[i]]=1;
	}
	for(int i=1;i<=n;i++){
		bfs(x[i],y[i],k,1);
	}
	cout<<maxn;
	return 0;
}