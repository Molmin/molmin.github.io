#include<bits/stdc++.h>
using namespace std;
string s;
int gs1=0,gs2=0;
int sb(int x){
	int gs=0;
	for(int i=x;s[i]!='(';i--){
		if(s[i]=='&'){
			int a=s[i-1]-'0',b=s[i+1]-'0';
			if(a==0){
				s[i]='2';
				s[i+1]='0';
				s[i-1]='0';
				gs1++;
			}else if(b==0||a==0&&b==0){
				s[i]='0';
				s[i+1]='0';
				s[i-1]='0';
			}else{
				s[i]='1';
				s[i+1]='1';
				s[i-1]='1';
			}
		}	
	}
	for(int i=x;s[i]!='(';i--){
		if(s[i]=='('){
			int a=s[i-1]-'0',b=s[i+1]-'0';
			if(a==1){
				s[i]='1';
				s[i+1]='1';
				s[i-1]='1';
				if(s[i+2]=='2'||s[i-2]=='2'){
					
				}else{
					gs2++;
				}	
			}else if(b==1){
				s[i]='1';
				s[i+1]='1';
				s[i-1]='1';
			}else{
				s[i]='0';
				s[i+1]='0';
				s[i-1]='0';
			}
		}	
	}
	return gs;
}

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	int sum=0;
	cin>>s;	
	for(int i=0;i<=s.size();i++){
		if(s[i]==')'){
			sum+=sb(i);
		}
		
	}
	cout<<1<<endl;
	cout<<gs1<<' '<<gs2;
	return 0;
	
	
	
	
	
}