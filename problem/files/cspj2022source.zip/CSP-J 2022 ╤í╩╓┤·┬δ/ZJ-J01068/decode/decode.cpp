#include<bits/stdc++.h>
using namespace std;
long long p,q;
void find(long long n,long long e,long long d){
	bool a=false;
	for(long long i=1;i<=sqrt(n);i++){
		if(n%i==0&&(i-1)*(n/i-1)+1==e*d){
			a=true;
			//cout<<i<<' '<<n/i<<endl; 
			printf("%lld %lld",i,n/i);
		}
	}
	if(a==false){
		cout<<"NO"<<endl;
	}
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	long long k;
	cin>>k;
	for(int i=1;i<=k;i++){
		long long n,e,d;
		scanf("%lld%lld%lld",&n,&e,&d);
		find(n,e,d);
	}
	return 0;
}