#include <bits/stdc++.h>

using namespace std;

const int maxn = 1e6 + 10;

int st[maxn], nxt[maxn], top, n; string s;
int bnxt[maxn];

/*
0 --- 0  ) --- 3
1 --- 1  & --- 4
( --- 2  | --- 5
*/

int upd(int x) {
	if (x == nxt[x]) return nxt[x];
	return nxt[x] = upd(nxt[x]);
}

void maTch() {
	top = 0; int pt = 1;
	while (pt <= n) {
		if (s[pt] == '(') st[++ top] = pt;
		else if (s[pt] == ')') 
			nxt[st[top]] = bnxt[st[top]] = pt, top --;
		pt ++;
	}
	
	pt = 1;
	while (pt <= n) {
		if (pt == n || s[pt + 1] == '&') {
			if (pt == n) nxt[pt] = pt;
			else nxt[pt] = pt + 2;
		}
		pt ++;
	}
	
	for (int i = 1; i <= n; i ++) if (nxt[i] == 0) nxt[i] = i;
	for (int i = 1; i <= n; i ++) nxt[i] = upd(i);
}

int err_or, err_and, ans;

int main() {
	
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	
	cin >> s;
	
	n = s.size(); s = " " + s;
	
	maTch();
	
	top = 0; int pt = 1;
	while (pt <= n) {
		if (s[pt] == '(') st[++ top] = 2;
		else if (s[pt] == ')') {
			while (st[top - 1] != 2)
				st[top - 2] |= st[top], top -= 2;
			st[top - 1] = st[top], top --;
		} else if (s[pt] == '0') st[++ top] = 0;
		else if (s[pt] == '1') st[++ top] = 1;
		else if (s[pt] == '&') {
			if (st[top] == 0) {
				err_and ++;
				if (s[pt + 1] == '(') pt = bnxt[pt + 1];
				else pt = pt + 1;
			} else st[++ top] = 4;
		} else {
			if (st[top] == 1) err_or ++, pt = nxt[pt + 1];
			else st[++ top] = 5;
		}
		
		while (top > 2 && st[top - 1] == 4 && st[top] < 2 
		&& st[top - 2] < 2) st[top - 2] &= st[top], top -= 2;
		
		pt ++;
	}
	
	while (top != 1) st[top - 2] |= st[top], top -= 2;
	cout << st[top] << endl << err_and << ' ' << err_or;
	
	return 0;
}