#include <bits/stdc++.h>
#define int long long

using namespace std;

int dp[510][110], n, k;
struct Node { int x, y; } t[510];

bool cmp(Node a, Node b) { return a.x < b.x ||
a.x == b.x && a.y < b.y; }

signed main() {
	
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	
	cin >> n >> k;
	for (int i = 1; i <= n; i ++)
		cin >> t[i].x >> t[i].y;
	
	sort(t + 1, t + n + 1, cmp);
	
	for (int j = 1; j <= n; j ++)
	for (int i = 0; i <= k; i ++) dp[j][i] = 1;
	for (int i = 2; i <= n; i ++) for (int j = 1; j <= i - 1; j ++) {
		if (t[i].y < t[j].y) continue;
		int delta = t[i].x + t[i].y - t[j].x - t[j].y - 1;
		for (int l = delta; l <= k; l ++) 
			dp[i][l] = max(dp[i][l], dp[j][l - delta] + 1);
	}
	
	int ans = 0;
	for (int i = 1; i <= n; i ++) for (int j = 0; j <= k; j ++)
		ans = max(ans, dp[i][j] + k); cout << ans << endl;
	
	return 0;
}