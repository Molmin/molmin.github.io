#include <bits/stdc++.h>
#define int long long

using namespace std;

int q, n, d, e;

signed main() {
	
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	
	cin >> q;
	for (int i = 1; i <= q; i ++) {
		cin >> n >> d >> e;
		int t = n, a = n - e * d + 2;
		
		if (a <= 0) {
			cout << "NO\n";
			continue;
		}
		
		int l = 1, r = sqrt(n);
		while (l + 1 < r) {
			int mid = (l + r) / 2, ano = a - mid;
			if (ano * mid > t) r = mid;
			else l = mid;
		}
		
		int p, q;
		if ((a - r) * r == t) p = r, q = a - r;
		else if ((a - l) * l == t) p = l, q = a - l;
		else {
			cout << "NO\n";
			continue;
		}
		
		if (p > q) swap(q, p);
		cout << p << ' ' << q << endl;
	}
	
	return 0;
}