#include <bits/stdc++.h>
#define int long long

using namespace std;

int a, b, lim = 1e9;

signed main() {
	
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	
	cin >> a >> b;
	
	if (a == 1) {
		cout << 1 << endl;
		return 0;
	}
	
	int tmp = 1;
	for (int i = 1; i <= b; i ++) {
		tmp = tmp * a;
		if (tmp > lim) {
			cout << -1 << endl;
			return 0;
		}
	}
	
	cout << tmp << endl;
	
	return 0;
}