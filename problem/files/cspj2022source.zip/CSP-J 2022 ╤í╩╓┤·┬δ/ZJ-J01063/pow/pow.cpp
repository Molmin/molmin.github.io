#include<bits/stdc++.h>
using namespace std;
const long long Max = 1e9;
long long a, b, res = 1;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin >> a >> b;
	if(a==1) {
		cout << 1 << endl;
		return 0;
	}
	for(long long i = 1; i <= b; i++) {
		res *= a;
		if(res > Max) {
			cout << -1;
			return 0;
		}
	}
	cout << res << endl;
	return 0;
}
