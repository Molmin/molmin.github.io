#include<bits/stdc++.h>
using namespace std;
long long T;
long long n,e,d,p,q;
long long ed;
bool flag;
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin >> T;
	while(T--) {
		flag = false;
		cin >> n >> d >> e;
		ed = d * e;
		for(long long i = 1; i * i <= n; i++) {
			if(n%i) continue;
			p = i;
			q = n / p;
			if((p - 1) * (q - 1) + 1 == ed) {
				cout << p << ' ' << q << endl;
				flag = true;
				break;
			}
		}
		if(!flag) {
			cout << "NO\n";
		}
	}
	return 0;
}

