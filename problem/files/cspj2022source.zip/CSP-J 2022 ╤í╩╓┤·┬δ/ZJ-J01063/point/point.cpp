#include<bits/stdc++.h>
using namespace std;
const long long N = 1e9 + 1;
int n,k;
struct zuobiao {
	int x;
	int y;
};
zuobiao wei[505];
int maxx,maxy;
namespace k_0 {
	int num[50000005];
	bool ok[50000005];
	int now[50000005];
	void mian() {
		for(int i = 1; i <= maxx; i++) {
			for(int j = 1; j <= maxy; j++) {
				bool in_the_wei = false;
				for(int kk = 1; kk <= n; kk++) {
					if(wei[kk].x == i && wei[kk].y == j) {
						in_the_wei = true;
						break;
					}
				}
				if(in_the_wei) {
					num[j] =max(num[j], max(now[j], now[j-1]) + 1);
					ok[j] = 1;
					now[j] =max(now[j], now[j-1]) + 1;
				} else {
					now[j]  = 0;
					ok[j] = 0;
				}
			}
		}
		cout << num[maxy] << endl;
	}
}
namespace k_1 {
	long long dp[105][105][105];
	long long now[105][105][105];
	/*
	dp[i][j][k]��ʾ�ڣ�1,1��~��i,j���õ� k �������󳤶�
	*/
	void mian() {
		for(int i = 1; i<= maxx; i++) {
			for(int j = 1; j<=maxx; j++) {
				for(int kk = 1; kk <= k; kk++) {
					bool in_the_wei = false;
					for(int kkk = 0; kkk <= n; kkk++) {
						if(wei[kkk].x == i && wei[kkk].y == j) {
							in_the_wei = true;
							break;
						}
					}
					if(in_the_wei) now[i][j][k]=max(now[i-1][j][k],now[i][j-1][k]) + 1,dp[i][j][k] = max(dp[i-1][j][k],dp[i][j-1][k]) + 1;
					else if(max(dp[i-1][j][k-1],dp[i][j-1][k-1])+1 > max(dp[i-1][j][k],dp[i][j-1][k])) {
						now[i][j][k] = max(now[i-1][j][k],now[i][j-1][k-1])+1;
						dp[i][j][k] = max(dp[i-1][j][k-1],dp[i][j-1][k-1])+1;
						dp[i][j][k] = max(dp[i][j][k],now[i][j][k]);
						//���ͣ���
					} else {
						now[i][j][k] = 0;
						dp[i][j][k] = max(dp[i-1][j][k],dp[i][j-1][k]);
					}
				}
			}
		}
		long long ans = -1;
		for(int i = 0; i<=k; i++) ans = max(ans,dp[maxx][maxy][i]);
		cout << ans << endl;
	}
}
int main() {
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin >> n >> k;
	for(int i = 1; i<=n; i++) {
		cin >>wei[i].x >> wei[i].y;
		maxx = max(maxx,wei[i].x);
		maxy = max(maxy,wei[i].y);
	}
	if(k == 0) {
		k_0::mian();
	} else {
		k_1::mian();
	}
	return 0;
}

