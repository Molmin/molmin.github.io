#include<bits/stdc++.h>
#define int long long
#define db double
#define erd(i,x) for(int i=head[x];i;i=e[i].nxt)
#define ord(i,l,r) for(int i=l;i<=r;i++)
#define dord(i,r,l) for(int i=r;i>=l;i--)
using namespace std;
inline int read(){
	int x=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	return x*f;
}
int n,d,e,x1,x2,k,at,a,b,c;
void solve(){
	n=read(),d=read(),e=read();
	a=1,b=-(n-e*d+2),c=n;
	at=b*b-4*a*c;
	if(at<0){
		puts("NO");
		return;
	}
	k=sqrt(at);
	x1=(0-b+k)/(2*a),x2=(0-b-k)/(2*a);
	if(x1>x2) swap(x1,x2);
	if(x1<=0||x2<=0||x1*x2!=n||(x1-1)*(x2-1)+1!=e*d){
		puts("NO");
		return ;
	}
	printf("%lld %lld\n",x1,x2);
	return ;
}
signed main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int T=read();
	while(T--) solve();
	return 0;
}