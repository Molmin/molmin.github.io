#include<bits/stdc++.h>
#define int long long
#define db double
#define erd(i,x) for(int i=head[x];i;i=e[i].nxt)
#define ord(i,l,r) for(int i=l;i<=r;i++)
#define dord(i,r,l) for(int i=r;i>=l;i--)
using namespace std;
inline int read(){
	int x=0,f=1;
	char c=getchar();
	while(c<'0'||c>'9'){
		if(c=='-') f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	return x*f;
}
const int AX=1e9;
int Q(int x,int y){
	int sum=1;
	while(y){
		if(y&1){
			if(x==-1||sum*x>AX) return -1;
			else sum=sum*x;
		}
		
		if(x==-1||x*x>AX) x=-1;
		else x=x*x;
		
		y>>=1;
	}
	return sum;
}
signed main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int x=read(),y=read();
	cout<<Q(x,y);
	return 0;
}