#include<bits/stdc++.h>
#define ll long long
#define db double
#define mk(x,y,z) (elem){x,y,z}
#define mkp make_pair
#define PII pair<int,elem>
#define erd(i,x) for(int i=head[x];i;i=e[i].nxt)
#define ord(i,l,r) for(int i=l;i<=r;i++)
#define dord(i,r,l) for(int i=r;i>=l;i--)
using namespace std;
const int N=1e6+20;
char s[N],q1[N];
int n,top1,top2;
struct elem{
	int  v,s1,s2;
}q2[N];
elem D(char op,elem x,elem y){
	if(op=='|'){
		if(x.v==1) return mk(1,x.s1,x.s2+1);
		else return mk(x.v|y.v,x.s1+y.s1,x.s2+y.s2);
	}else{
		if(x.v==0) return mk(0,x.s1+1,x.s2);
		else return mk(x.v&y.v,x.s1+y.s1,x.s2+y.s2);
	}
}
void add(elem x){
	if(top2==0||q1[top1]=='('||q1[top1]=='|') q2[++top2]=x;
	else{
		char op=q1[top1--];
		elem y=q2[top2--];
		add(D(op,y,x));
	}
	return ;
}
signed main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",s+1);
	n=strlen(s+1);
	ord(i,1,n){
		if(s[i]=='('||s[i]=='|'||s[i]=='&') q1[++top1]=s[i];
		if(s[i]==')'){
			int k1=top1,k2=top2;
			while(q1[k1]!='(') k1--,k2--;
			elem val=q2[k2];
			ord(j,k1+1,top1){
				val=D(q1[j],val,q2[k2+j-k1]);
			}
			top1=k1-1;
			top2=k2-1;
			add(val);
		}
		if(s[i]=='0'||s[i]=='1') add(mk(s[i]-'0',0,0));
	}
	elem ans=q2[1];
	ord(i,1,top1){
		ans=D(q1[i],ans,q2[1+i]);
	}
	cout<<ans.v<<endl;
	cout<<ans.s1<<" "<<ans.s2<<endl;
	return 0;
}