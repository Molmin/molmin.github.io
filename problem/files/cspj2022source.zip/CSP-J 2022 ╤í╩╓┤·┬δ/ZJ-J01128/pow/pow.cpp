#include<bits/stdc++.h>
#define PP pair <int, int>
#define LL long long
using namespace std;
const LL p = 1e9;
LL a, b, ans = 1;
int main () {
	freopen ("pow.in", "r", stdin);
	freopen ("pow.out", "w", stdout);
	ios::sync_with_stdio (false);
	cin.tie (0), cout.tie (0);
	cin >> a >> b;
	if (a == 1) {
		cout << 1 << endl;
		return 0;
	}
	for (int i = 1; i <= b; i ++ ) {
		ans *= a;
		if (ans > p) {
			cout << -1 << endl;
			return 0;
		}
	}
	cout << ans << endl;
	return 0;
}