#include<bits/stdc++.h>
#define PP pair <int, int>
#define LL long long
using namespace std;
int T;
int main () {
	freopen ("decode.in", "r", stdin);
	freopen ("decode.out", "w", stdout);
	ios::sync_with_stdio (false);
	cin.tie (0), cout.tie (0);
	cin >> T;
	while (T -- ) {
		LL n, d, e; // n : pq
		cin >> n >> d >> e;
		LL s = n - e * d + 2; // p + q;
		if (s * s - 4 * n < 0) cout << "NO" << endl;
		else {
			if (((LL) sqrt (s * s - 4 * n)) * ((LL) sqrt (s * s - 4 * n)) != s * s - 4 * n) cout << "NO" << endl;
			else {
				bool f = 1;
				LL up1 = s + sqrt (s * s - 4 * n), up2 = s - sqrt (s * s - 4 * n);
				if (up1 % 2 == 0 && up1 > 0) {
					LL x = up1 / 2;
					LL y = s - x;
					if (x > 0 && y > 0) cout << min (x, y) << ' ' << max (x, y) << endl, f = 0;
				}
				else if (up2 % 2 == 0 && up2 > 0) {
					LL x = up1 / 2;
					LL y = s - x;
					if (x > 0 && y > 0) cout << min (x, y) << ' ' << max (x, y) << endl, f = 0;
				}
				if (f) cout << "NO" << endl;
			}
		} 
	}
	return 0;
}