#include<bits/stdc++.h>
using namespace std;

int k;
long long n,e,d,m,l,r,mid,tmp,p,q;

int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		scanf("%lld%lld%lld",&n,&e,&d);
		m=n-e*d+2;
		l=0,r=m/2,p=-1,q=-1;
		while(l<=r){
			mid=(l+r)/2;
			tmp=mid*(m-mid);
			if(tmp==n){
				p=mid;
				q=m-mid;
				break;
			}else if(tmp<n){
				l=mid+1;
			}else{
				r=mid-1;
			}
		}
		if(p==-1){
			printf("NO\n");
		}else{
			printf("%lld %lld\n",p,q);
		}
	}
	return 0;
}