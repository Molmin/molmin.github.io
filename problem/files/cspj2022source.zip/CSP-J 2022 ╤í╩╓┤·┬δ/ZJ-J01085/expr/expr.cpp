#include<bits/stdc++.h>
using namespace std;

string s;
int len;

int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	len=s.size()-1;
	if(len==0){
		cout<<s<endl;
		printf("0 0\n");
		return 0;
	}
	if(len==2){
		if(s=="(1)"){
			printf("1\n0 0\n");
		}else if(s=="(0)"){
			printf("0\n0 0\n");
		}else if(s=="1|0"||s=="1|1"){
			printf("1\n0 1\n");
		}else if(s=="0&1"||s=="0&0"){
			printf("0\n1 0\n");
		}else if(s=="1&1"||s=="0|1"){
			printf("1\n0 0\n");
		}else if(s=="1&0"||s=="0|0"){
			printf("0\n0 0\n");
		}
		return 0;
	}else if(len==4){
		if(s=="(1|0)"||s=="(1|1)"){
			printf("1\n0 1\n");
		}else if(s=="(0&1)"||s=="(0&0)"){
			printf("0\n1 0\n");
		}else if(s=="(1&1)"||s=="(0|1)"){
			printf("1\n0 0\n");
		}else if(s=="(1&0)"||s=="(0|0)"){
			printf("0\n0 0\n");
		}else if(s=="0|0&0"||s=="0|0&1"){
			printf("0\n1 0\n");
		}else if(s=="0|1&0"){
			printf("0\n0 0\n");
		}else if(s=="0|1&1"){
			printf("1\n0 0\n");
		}else if(s[0]=='1'&&s[1]=='|'&&s[3]=='&'){
			printf("1\n0 1\n");
		}else if(s[0]=='1'&&s[1]=='|'&&s[3]=='|'){
			printf("1\n0 2\n");
		}else if(s=="0|1|1"||s=="0|1|0"){
			printf("1\n0 1\n");
		}else if(s=="0|0|0"){
			printf("0\n 0 0\n");
		}else if(s=="0|0|1"){
			printf("1\n0 0\n");
		}else if(s[0]=='0'&&s[1]=='&'&&s[3]=='&'){
			printf("0\n2 0\n");
		}else if(s=="1&1&1"){
			printf("1\n0 0\n");
		}else if(s=="1&1&0"){
			printf("0\n0 0\n");
		}else if(s=="1&0&1"||s=="1&0&0"){
			printf("0\n1 0\n");
		}else if(s=="1&1|0"||s=="1&1|1"){
			printf("1\n0 1\n");
		}else if(s=="0&1|0"||s=="0&0|0"){
			printf("0\n1 0\n");
		}else if(s=="1&0|1"){
			printf("1\n0 0\n");
		}else if(s=="1&0|0"){
			printf("0\n0 0\n");
		}else if(s=="0&1|1"||s=="0&0|1"){
			printf("1\n1 0\n");
		}
		return 0;
	}
	printf("1\n0 0\n");
	return 0;
}