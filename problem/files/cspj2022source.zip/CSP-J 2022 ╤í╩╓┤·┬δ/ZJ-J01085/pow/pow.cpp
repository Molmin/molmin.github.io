#include<bits/stdc++.h>
using namespace std;

long long a,b,ans;

int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	ans=1;
	while(b>0){
		if(b%2==1){
			ans*=a;
		}
		a*=a;
		b/=2;
		if(a>1e9&&b!=0){
			printf("-1\n");
			return 0;
		}
		if(ans>1e9){
			printf("-1\n");
			return 0;
		}
	}
	printf("%lld\n",ans);
	return 0;
}