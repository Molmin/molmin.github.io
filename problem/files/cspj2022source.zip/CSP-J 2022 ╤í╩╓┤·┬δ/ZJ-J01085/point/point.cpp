#include<bits/stdc++.h>
using namespace std;

int n,k;
struct point{
	int x,y;
}p[510];
int ans=0;

bool cmp(point a,point b){
	if(a.x==b.x){
		return a.y<b.y;
	}
	return a.x<b.x;
}

void dfs(int u,int ki,int num){
	if(ki<0){
		return;
	}
	if(num+n-u+ki<ans){
		return;
	}
	ans=max(ans,num+ki);
	for(int i=u+1;i<=n;i++){
		if(p[i].y>=p[u].y){
			dfs(i,ki-(p[i].y-p[u].y)-(p[i].x-p[u].x)+1,num+(p[i].y-p[u].y)+(p[i].x-p[u].x));
		}
	}
}

int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		scanf("%d%d",&p[i].x,&p[i].y);
	}
	sort(p+1,p+n+1,cmp);
	for(int i=1;i<=n;i++){
		dfs(i,k,1);
	}
	printf("%d\n",ans);
	return 0;
}