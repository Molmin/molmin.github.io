#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("decode.in", "r", stdin);
	freopen("decode.out", "w", stdout);
	int k;
	cin >> k;
	long long n, e, d;
	long long sum = 0, t = 0;
	for(int i = 1; i <= k; i ++)
	{
		scanf("%lld%lld%lld", &n, &e, &d);
		sum = n - e * d + 2;
		t = -n;
		int q1 = (-sum + sqrt(sum * sum + 4 * t)) / (-2);
		int q2 = (-sum - sqrt(sum * sum + 4 * t)) / (-2);
		int ans = -1;
		if(q1 > 0) ans = q1;
		else if(q2 > 0) ans = q2;
		else {
			puts("NO");
			continue;
		}
		if(ans * (sum - ans) != n) puts("NO");
		else {
			int x = sum - ans;
			if(ans > x) printf("%d %d\n", x, ans);
			else printf("%d %d\n", ans, x);
		}
	}
	return 0;
}