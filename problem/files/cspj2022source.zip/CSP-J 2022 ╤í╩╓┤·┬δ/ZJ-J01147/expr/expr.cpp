#include<bits/stdc++.h>
using namespace std;

int main()
{
	freopen("expr.in", "r", stdin);
	freopen("expr.out", "w", stdout);
	string s;
	getline(cin, s);
	int num1 = s[0] - '0', num2 = s[2] - '0';
	char op = s[1];
	int cnt1 = 0, cnt2 = 0;
	for(int i = 2; i < s.size(); i += 2)
	{
		num2 = s[i] - '0';
		op = s[i - 1];
		if(op == '&')
		{
			if(num1 == 0) cnt1 ++;
			num1 = num1 & num2;
		}
			
		if(op == '|')
		{
			if(num1 == 1) cnt2 ++;
			num1 = num1 | num2;
		}
	}
	cout << num1 << endl;
	cout << cnt1 << " " << cnt2 << endl;
	return 0;
}