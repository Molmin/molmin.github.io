#include<bits/stdc++.h>
using namespace std;

int qmi(int n, int k)
{
	long long res = 1;
	int t = n;
	while(k)
	{
		if(t > sqrt(1e9) && k > 1) return -1;
		if(k & 1) res *= t;
		if(res > 1e9) return -1;
		k >>= 1;
		t *= t;
	}
	return res;
}

int main()
{
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	int n, k;
	cin >> n >> k;
	cout << qmi(n, k) << endl;
	return 0;
}