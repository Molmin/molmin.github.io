#include<bits/stdc++.h>
using namespace std;

const int N = 5e4 + 5;
bool a[N][2], b[N][2];
typedef pair<int, int> PII;
PII c[610];

#define x first
#define y second

int n, k;
int dx[] = {0, 1}, dy[] = {1, 0};

bool cmp(PII a, PII b)
{
	if(a.x != b.x) return a.x < b.x;
	return a.y < b.y;
}

int dfs(int p, int q, int sum)
{
	sum ++;
	for(int i = 0; i < 2; i ++)
	{
		int fx = p + dx[i], fy = q + dy[i];
		if(a[fx % N][fx / N] && b[fy % N][fy / N])
			sum = max(sum, dfs(fx, fy, sum));
	}
	return sum - 1;
}

int main()
{
	freopen("point.in", "r", stdin);
	freopen("point.out", "w", stdout);
	cin >> n >> k;
	for(int i = 1; i <= n; i ++)
	{
		int p, q;
		scanf("%d%d", &p, &q);
		a[p % N][p / N] = 1; b[q % N][q / N] = 1;
		c[i] = {p, q};
	}
	sort(c + 1, c + n + 1);
	int res = 0;
	for(int i = 1; i <= n; i ++)
		res = max(res, dfs(c[i].x, c[i].y, 0));
	cout << res << endl;
	return 0;
}