#include<bits/stdc++.h>
using namespace std;
int n,k,x[1007],y[1007];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
	
	return 0;
}
