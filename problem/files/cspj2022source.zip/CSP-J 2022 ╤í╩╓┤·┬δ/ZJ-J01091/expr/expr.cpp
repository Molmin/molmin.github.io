#include<bits/stdc++.h>
using namespace std;
int orn=0,andn=0,len,sl[1000007];
string a,b[1000007];
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	len=a.length();
	for(int i=1;i<=len;i++) b[i]=a[i-1];
	for(int i=1;i<=len;i++){
		if(b[i]=="0") sl[i]=0;
		if(b[i]=="1") sl[i]=1;
		if(b[i]=="&") sl[i]=3;
		if(b[i]=="|") sl[i]=4;
		if(b[i]=="(") sl[i]=11;
		if(b[i]==")") sl[i]=12;
	}
	if(len<=3){
		if(sl[2]==3){
			if(sl[1]==0)
				cout<<(sl[1]&sl[3])<<"\n"<<1<<" "<<0;
			else cout<<(sl[1]&sl[3])<<"\n"<<0<<" "<<0;
		}	
		else{
			if(sl[1]==1)
				cout<<(sl[1]|sl[3])<<"\n"<<0<<" "<<1;
			else cout<<(sl[1]|sl[3])<<"\n"<<0<<" "<<0;
		}
	}
	else if(len<=5){
		if(sl[1]==11){
			if(sl[3]==3){
				if(sl[2]==0)
					cout<<(sl[2]&sl[4])<<"\n"<<1<<" "<<0;
				else cout<<(sl[2]&sl[4])<<"\n"<<0<<" "<<0;
		}	
		else{
			if(sl[2]==1)
				cout<<(sl[2]|sl[4])<<"\n"<<0<<" "<<1;
			else cout<<(sl[2]|sl[4])<<"\n"<<0<<" "<<0;
			}
		}
	}
	return 0;
}
