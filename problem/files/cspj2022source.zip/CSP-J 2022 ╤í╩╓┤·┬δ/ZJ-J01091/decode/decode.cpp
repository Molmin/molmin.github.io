#include<bits/stdc++.h>
using namespace std;
long long k,n,e,d,p,q,a;
bool fi=false;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	while(k--){
		fi=false;
		cin>>n>>e>>d;
		a=n-e*d+2;
		for(int i=1;i<=a&&i*i<=n;i++){
			if(n%i==0){
				if(i+n/i==a){
					cout<<i<<" "<<n/i<<"\n";
					fi=true;
				}
			}
		}
		if(fi) continue;
		cout<<"NO"<<"\n";
	}
	return 0;
}
