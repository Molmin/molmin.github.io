#include<bits/stdc++.h>
using namespace std;
const int m=1e9;
long long a,b,p=0;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	p=pow(a,b);
	if(p>m||p<-2) cout<<-1;
	else cout<<p;
	return 0;
}
