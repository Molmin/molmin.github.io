#include<iostream>
using namespace std;
int main()
{
//	freopen("pow.in","r",stdin);
//	freopen("pow.out","w",stdout);
	int a,b;
	cin>>a>>b;
	int ans=1;
	if(a>10&&b>9)
	{
		cout<<-1;
		return 0;
	}
	if(a>=2&&b>29)
	{
		cout<<-1;
		return 0;
	}
	if(a==1)
	{
		cout<<1;
		return 0;
	}
	for(int i=1;i<=b;i++)
	{
		ans*=a;
	}
	if(ans>1000000000||ans<0)
	{
		cout<<-1;
		return 0;
	}
	cout<<ans;
//	fclose(stdin);
//	fclose(stdout);
	return 0;
} 
