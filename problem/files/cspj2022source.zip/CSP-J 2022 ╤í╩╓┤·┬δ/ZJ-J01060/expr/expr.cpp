#include<iostream>
#include<cstring>
using namespace std;
bool s1[1000005]={ };
string s;
int s2[1000005]={ };
void kh1(int x)
{
	int i=x+1;
	while(s[i]!=')')
	{
		if(s[i]=='(')
		{
			kh1(i);
		}
		else if(s[i]=='&')
		{
			int p,q;
			for(int j=i;j>=0;j--)
			{
				if(s[j]=='1'||s[j]=='0')
				{
					p=j;
					break;
				}
			}
			for(int j=i;j<=s.size();j++)
			{
				if(s[j]=='1'||s[j]=='0')
				{
					q=j;
					break;
				}
			}
			if(s2[p]==0||s2[q]==0)
			{
				s2[p]=0;
				s2[q]=0;
			}
			else
			{
				s2[p]=1;
				s2[q]=1;
			}
		}
	}
}
void kh2(int x)
{
	int i=x+1;
	while(s[i]!=')')
	{
		if(s[i]=='(')
		{
			kh2(i);
		}
		else if(s[i]=='|')
		{
			int p,q;
			for(int j=i;j>=0;j--)
			{
				if(s[j]=='1'||s[j]=='0')
				{
					p=j;
					break;
				}
			}
			for(int j=i;j<=s.size();j++)
			{
				if(s[j]=='1'||s[j]=='0')
				{
					q=j;
					break;
				}
			}
			if(s2[p]==0||s2[q]==0)
			{
				s2[p]=0;
				s2[q]=0;
			}
			else
			{
				s2[p]=1;
				s2[q]=1;
			}
		}
	}
}
int main()
{
//	freopen("expr.in","r",stdin);
//	freopen("expr.out","w",stdout);
	cin>>s;
	for(int i=1;i<=s.size();i++)
	{
		if(s[i]=='1'||s[i]=='0')
		{
			s2[i]=s[i]-'0';
		}
	}
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='(')
		{
			kh1(i);
		}
		else if(s[i]=='&')
		{
			if(s2[i-1]==0||s2[i+1]==0)
			{
				s2[i-1]=0;
				s2[i+1]=0;
			}
			else
			{
				s2[i-1]=1;
				s2[i+1]=1;
			}
		}
	}
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='(')
		{
			kh2(i);
		}
		else if(s[i]=='|')
		{
			if(s2[i-1]==1||s2[i+1]==1)
			{
				s2[i-1]=1;
				s2[i+1]=1;
			}
			else
			{
				s2[i-1]=0;
				s2[i+1]=0;
			}
		}
	}
	for(int i=0;i<s.size();i++)
	{
		if(s[i]=='1'||s[i]=='0')
		{
			cout<<s2[i]<<endl;
			break;
		}
	}
//	fclose(stdin);
//	fclose(stdout);
	return 0;
} 
