#include<iostream>
#include<queue>
using namespace std;
bool a[1000000005][1000000005]={ };
int t[4][2]={0,1,1,0,0,-1,-1,0};
int bfs(int x,int y)
{
	queue<int> q;
	int nowa=a[x][y];
	q.push(nowa);
	int ans1=0;
	while(!q.empty())
	{
		int nowb=q.front();
		for(int i=1;i<=4;i++)
		{
			int nx=x+t[i][0],ny=y+t[i][1];
			if(a[nx][ny]!=0)
			{
				q.push(nowb);
				ans1++;
			}
		}
		q.pop();
	}
	return ans1;
}
int main()
{
//	freopen("point.in","r",stdin);
//	freopen("point.out","w",stdout);
	int n,k;
	cin>>n>>k;
	int x[205],y[205];
	for(int i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
		a[x[i]][y[i]]=1;
	}
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		int p=bfs(x[i],y[i]);
		if(p>ans)
		{
			ans=p;
		}
	}
	cout<<ans;
//	fclose(stdin);
//	fclose(stdout);
	return 0;
} 
