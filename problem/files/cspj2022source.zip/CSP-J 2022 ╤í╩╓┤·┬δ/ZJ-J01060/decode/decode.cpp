#include<iostream>
using namespace std;
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		long long n,e,d;
		cin>>n>>e>>d;
		bool f=0;
		for(int j=1;j<=n;j++)
		{
			int p=j,q=n/p;
			if(p*q==n&&e*d==((p-1)*(q-1)+1))
			{
				cout<<p<<' '<<q<<endl;
				f=1;
				break;
			}
		}
		if(!f)
		{
			cout<<"NO"<<endl;
		}
	} 
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
