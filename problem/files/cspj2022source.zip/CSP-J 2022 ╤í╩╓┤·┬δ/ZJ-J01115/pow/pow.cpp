#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n, m;

const ll maxn = 1000000000;

int main()
{

    freopen("pow.in", "r", stdin);
    freopen("pow.out", "w", stdout);

    cin >> n >> m;

    ll ans = 1;

    while(m--)
    {

        ans *= n;

        if(ans > maxn)
        {

            cout<< -1 <<endl;

            return 0;

        }

    }

    cout<<ans<<endl;

    return 0;

}