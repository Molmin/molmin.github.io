#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n, d, e;

int main()
{

    freopen("decode.in", "r", stdin);
    freopen("decode.out", "w", stdout);

    cin.sync_with_stdio(0);

    ll T;

    cin>>T;

    while(T--)
    {

        cin>>n>>d>>e;

        ll pls = n - d * e + 2; // p + q

        ll sqr = pls * pls;

        ll misqr = sqr - 4 * n;

        ll misqrt = (ll)floor(sqrt(misqr));

        if(misqrt * misqrt != misqr)
        {

            cout<<"NO"<<endl;
            continue;

        }

        ll q = (pls + misqrt) / 2;
        ll p = (pls - misqrt) / 2;

        if(p > q) swap(p, q);

        cout<<p<<" "<<q<<endl;

    }

    return 0;

}