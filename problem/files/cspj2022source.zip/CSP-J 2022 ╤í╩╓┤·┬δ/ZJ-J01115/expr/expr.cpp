#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

#define For(i, b, n) for(int i = b; i <= n; ++i)

string s1;

ll len1;

int dl[1000010]; // '(' position to ')'

string s;
ll len;

int adcnt[1000010];

void Pre()
{

    stack<int> st;

    For(i, 1, len)
    {

        if(s[i] == '(')
        {

            st.push(i);

        }
        else if(s[i] == ')')
        {

            int ps = st.top();

            dl[ps] = i;
            dl[i]  = ps;

            st.pop();

        }
        else
        {

            dl[i] = i;

        }

    }

}

// jump | ignored &
int JumpAnd(int l)
{

    int dep = 0;

    For(i, l, len)
    {

        if(s[i] == '(') dep++;
        else if(s[i] == ')') dep--;

        if(dep == 0) return i;

    }

    return -1;

}

// count & and |
ll acnt, bcnt;

// return the result of expression
int calc(int l, int r)
{

    if(l >= r) return 0;

    int now;

    int bl;

    if(s[l] == '(') 
    {

        now = calc(l + 1, dl[l] - 1);
        bl = dl[l] + 1;

    }
    else now = s[l] - '0', bl = l + 1;

    For(i, bl, r)
    {

        if(s[i] == '|')
        {

            if(now == 1)
            {

                bcnt++;
                i = dl[i + 1];

                while(s[i + 1] == '&')
                {

                    i = JumpAnd(i + 2);

                }

            }
            else
            {

                bool flag = 0;
                int tmp;

                if(s[i + 1] == '(') now = calc(i + 2, dl[i + 1] - 1);
                else 
                {

                    if(s[i + 2] == '&')
                    {

                        now = calc(i + 1, tmp = JumpAnd(i + 3));
                        flag = true;

                    }
                    else now = s[i + 1] - '0';

                }

                if(!flag) i = dl[i + 1];
                else i = tmp;

            }

        }
        else if(s[i] == '&')
        {

            if(now == 0)
            {

                acnt++;
                i = dl[i + 1];

                // if(s[i + 1] == '&')
                // {

                //     i = JumpAnd(i + 2);

                // }

            }
            else
            {

                if(s[i + 1] == '(') now = calc(i + 2, dl[i + 1] - 1);
                else now = s[i + 1] - '0';

                i = dl[i + 1];

            }

        }
        else
        {

            cout<<"Error"<<endl;

        }

    }

    return now;

}

int main()
{

    freopen("expr.in", "r", stdin);
    freopen("expr.out", "w", stdout);

    cin.sync_with_stdio(0);

    cin >> s;

    len = s.length();

    s = " " + s;

    Pre();

    cout << calc(1, len) << endl;

    cout<<acnt<<" "<<bcnt<<endl;

    return 0;

}
// (((((1|1)&0)&1)|1)&1)