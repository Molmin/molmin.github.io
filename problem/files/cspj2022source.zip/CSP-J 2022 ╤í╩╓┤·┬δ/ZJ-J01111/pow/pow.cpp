
#include<iostream>
using namespace std;

int main(){
	
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	
	long long a,b,ans=1;
	cin>>a>>b;
	while(b--){
		if(ans*a>1000000000){
			cout<<"-1";
			return 0;
		}
		ans*=a;
	}
	
	cout<<ans;
	return 0;
}
