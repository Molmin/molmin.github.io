#include<bits/stdc++.h>
using namespace std;
char sxpra[1000005];
int ans1,ans2,dl=0,dy=0;
bool dfs(int s,int e){
	//cout<<1;
	int i,a,b,n=0;
	if(s==e){//danzi
	//	cout<<0;
		if(sxpra[s]=='1')return true;
		return false;
	}

	i=e;
	while(i>=s){//jisuan |
		if(sxpra[i]==')')n++;
		if(sxpra[i]=='(')n--;
		if(sxpra[i]=='|'&&n==0){
			a=dfs(s,i-1);
		//	cout<<a;
			if(a){
				dl++;
				return true;
			}
			b=dfs(i+1,e);
		//	cout<<b;
			if(b)return true;
			return false;
		}
		i--;
	}
	i=e;
	while(i>=s){//jisuan &
		if(sxpra[i]==')')n++;
		if(sxpra[i]=='(')n--;
		if(sxpra[i]=='&'&&n==0){
			a=dfs(s,i-1);
			//<<a;
			if(a==false){
				dy++;
				return false;
			}
			b=dfs(i+1,e);
			//cout<<b;
			if(b==false)return false;
			return true;
		}
		i--;
	}
	return dfs(s+1,e-1);
}


int main(){
	
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>sxpra;
	int m=strlen(sxpra),ans=0;
	if(dfs(0,m-1))ans=1;
	cout<<ans<<endl<<dy<<" "<<dl;
	return 0;
}

	/*while(i<e){		
		if(sxpra[i]=='('){//kuohaonei
			int j=i;
			while(j++)(
				if(sxpra[j]==')'){
					break;
				}
			)
			dfs_(i+1,j-1)
			i=j;
		}
		i++;
	}*/
