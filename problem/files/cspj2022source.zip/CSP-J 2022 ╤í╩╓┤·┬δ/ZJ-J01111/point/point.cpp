#include<iostream>
using namespace std;
//baolichuqiji
int zp[1000][10000];
int xn[1000],rn[10000];
int  n,k,x,y,mx,my,ans=0;
dfs(int a,int b,int lk){
	//cout<<"?";
	int r,u;
	if(lk==-1)return 0;
	if(a<mx){
		if(zp[a+1][b]==1){
			u=dfs(a+1,b,lk);
		}
		else{
			u=dfs(a+1,b,lk-1);
		}
	}
	else{
		u=lk;
	}
	if(b<my){
		if(zp[a][b+1]==1){
			r=dfs(a,b+1,lk);
		}
		else{
			r=dfs(a,b+1,lk-1);
		}
	}
	else{
		r=lk;
	}
	//cout<<"("<<u<<","<<r<<","<<lk<<")";
	return max(u,r)+1;
}

int main(){
	
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int ans=0;
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>x>>y;
		zp[x][y]=1;
		xn[i]=x;
		rn[i]=y;
		if(x>mx)mx=x;
		if(y>my)my=y;
	}
	for(int i=0;i<n;i++){
		
		ans=max(ans,dfs(xn[i],rn[i],k));
		//cout<<ans<<endl;
	}
	cout<<ans;
	return 0;
}
