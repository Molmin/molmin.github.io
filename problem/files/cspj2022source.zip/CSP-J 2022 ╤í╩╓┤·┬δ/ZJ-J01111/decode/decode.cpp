#include<iostream>
using namespace std;




int main(){
	
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	long long n,e,d;
	cin>>k;
	for(int i=1;i<=k;i++){
		cin>>n>>e>>d;
		long long m=n+2-e*d,j=1;
		while(true){
			if(j*(m-j)==n){
				cout<<j<<" "<<m-j<<endl;
				break;
			}
			if(j*2>m){
				cout<<"NO"<<endl;
				break;
			}
			j++;
		}
	}
	return 0;
}
