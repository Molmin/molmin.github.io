#include<bits/stdc++.h>
using namespace std;
int a,b;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	int c=pow(a,b);
	if(c<0)
	{
		cout<<"-1";
	}
	else
	{
		cout<<c;
	}
	return 0;
}