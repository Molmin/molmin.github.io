#include<bits/stdc++.h>
using namespace std;
struct zhl{
	int n,e,d,z;
};
int k;
zhl a[114514];
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	cin>>k;
	for(int i=1;i<=k;i++)
	{
		cin>>a[i].n>>a[i].d>>a[i].e;
		a[i].z=a[i].n-a[i].d*a[i].e+2;
	}
	int flag=0;
	for(int i=1;i<=k;i++)
	{
		flag=0;
		for(int j=1;j<=a[i].z;j++)
		{
			if(j*(a[i].z-j)==a[i].n)
			{
				cout<<j<<" "<<a[i].z-j<<endl;
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}