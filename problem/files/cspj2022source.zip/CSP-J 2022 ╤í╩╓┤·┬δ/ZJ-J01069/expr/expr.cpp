#include<bits/stdc++.h>
using namespace std;
struct zhl{
	int zkh,left,right,zoo;
};
zhl a[114514];
string s;
int len;
int cnt=0;
int ckt=0;
//int f(int x,int y)
//{
//	int tsg[114514];
//	int ctt=0;
//	int flagn=0;
//	for(int i=x+1;i<y;i++)
//	{
//		if(s[i]=='1')
//		{
//			ctt++;
//			tsg[ctt]=1;
//		}
//		if(s[i]=='0')
//		{
//			ctt++;
//			tsg[ctt]=0;
//		}
//		if(s[i]=='&')
//		{
//			flagn=1;
//		}
//		if(flagn==1)
//		{
//			flagn=0;
//			if(tsg[ctt]==1&&tsg[ctt-1]==1)
//			{
//				tsg[ctt-1]=1;
//			}
//			else
//			{
//				tsg[ctt-1]=0;
//			}
//			ctt--;
//		}
//	}
//	for(int i=1;i<=ctt;i++)
//	{
//		if(tsg[i]==1)
//		{
//			return 1;
//		}
//	}
//	return 0;
//}
int h(int x,int y)
{
	int mad[114514];
	int cmt=0;
	int flagm=0;
	for(int i=x;i<y;i++)
	{
		if(s[i]=='1')
		{
			cmt++;
			mad[cmt]=1;
		}
		if(s[i]=='0')
		{
			cmt++;
		}
		if(s[i]=='(')
		{
			for(int j=1;j<=ckt;j++)
			{
				if(a[j].left==i)
				{
					cmt++;
					mad[cmt]=h(a[j].left,a[j].right);
				}
			}
			
		}
		if(s[i]=='&')
		{
			flagm=1;
		}
		if(flagm==1)
		{
			flagm=0;
			if(mad[cmt]==1&&mad[cmt-1]==1)
			{
				mad[cmt-1]=1;
			}
			else
			{
				mad[cmt-1]=0;
			}
			cmt--;
		}
	}
	for(int i=1;i<=cmt;i++)
	{
		if(mad[i]==1)
		{
			return 1;
		}
	}
	return 0;
}
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	len=s.size();
	int cnt=0;
	int ckt=0;
	for(int i=0;i<len;i++)
	{
		if(s[i]=='(')
		{
			cnt++;
			a[cnt].zkh=i;
		}
		if(s[i]==')')
		{
			ckt++;
			a[ckt].left=a[cnt].zkh;
			a[ckt].right=i;
			cnt--;
		}
	}
	cout<<h(0,len-1)<<endl;
	int cab=0,cob=0;
	for(int i=0;i<len;i++)
	{
		if(s[i]=='0'&&s[i+1]=='&')
		{
			cab++;
			if(s[i+2]=='1'&&s[i+2]=='0')
			{
				i=i+2;
				s[i]='0';
				i--;
			}
			if(s[i+2]=='(')
			{
				for(int j=1;j<=ckt;j++)
			    {
				    if(a[j].left==i+2)
				    {
					    i=a[j].right;
					    s[i]='0';
					    i--;
				    }
			    }
			}
		}
		if(s[i]=='1'&&s[i+1]=='|')
		{
			cob++;
			if(s[i+2]=='1'&&s[i+2]=='0')
			{
				i=i+2;
				s[i]='1';
				i--;
			}
			if(s[i+2]=='(')
			{
				for(int j=1;j<=ckt;j++)
			    {
				    if(a[j].left==i+2)
				    {
					    i=a[j].right;
					    s[i]='1';
					    i--;
				    }
			    }
			}
		}
	}
	cout<<cab<<" "<<cob;
//	cout<<s;
	return 0;
}