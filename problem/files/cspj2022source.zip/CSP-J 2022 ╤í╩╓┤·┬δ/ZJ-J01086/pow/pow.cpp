#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin >> a >> b;
	if(a == 1)
		cout << 1;
	else
	{
		long long c = 1;
		for(long long i = 1;i <= b && c <= 1000000001;i++)
			c *= a;
		if(c > 1000000001)
			cout << -1;
		else
			cout << c;
	}
	return 0;
}