#include <bits/stdc++.h>
using namespace std;

int f1 = 0;
int f2 = 0;

bool f(string a)
{
//	cout << f1 << ' ' << f2 << ' ' << a << endl;
	int l = a.length();
	if(l == 1)
		return a[0] - '0';
	if(l == 3)
	{         
		if(a[1] == '&')
		{
			if(a[0] - '0' == 0)
			{
				f1++;
				return 0;
			}
			else
				return a[2] - '0';
		}
		if(a[1] == '|')
		{
			if(a[0] - '0' == 1)
			{
				f2++;
				return 1;
			}
			else
				return a[2] - '0';
		}
	}
	else
	{
		int stack = 0;
	 	for(int i = l - 1;i >= 0;i--)  
	 	{
			if(a[i] == '(')
				stack++;      
			if(a[i] == ')')
				stack--;      
			if(stack == 0 && a[i] == '|')
			{
				if(f(a.substr(0,i)))
				{
					f2++;
					return 1;
				}
				else
					return f(a.substr(i + 1,l - i));
			}
		}                                            
		for(int i = l - 1;i >= 0;i--)
		{
			if(a[i] == '(')
				stack++;
			if(a[i] == ')')
				stack--;
			if(stack == 0 && a[i] == '&')
			{
				if(f(a.substr(0,i)) == 0)
				{
					f1++;
					return 0;
				}
				else
					return f(a.substr(i + 1,l - i));
			}
		}                                     
		return f(a.substr(1,l - 2));
	}               
	return -1;
}

int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	string a;
	cin >> a;
	cout << f(a) << endl << f1 << ' ' << f2;
	return 0;
}