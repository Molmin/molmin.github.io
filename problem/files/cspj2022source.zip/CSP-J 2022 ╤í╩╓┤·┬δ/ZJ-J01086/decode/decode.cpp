#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin >> k;
	while(k--)
	{
		long long n,d,e;
		long long sqrtn = sqrt(n);
		bool fang = 1;
		cin >> n >> d >> e;
		long long f = d * e - 1;
		for(int i = 1;i <= sqrtn;i++)
		{
			int p = i,q = n / i;
			if(p * q == n && (p - 1) * (q - 1) == f)
			{
				cout << i << ' ' << n / i << endl;
				fang = 0;
				break;
			}
		}
		if(fang)
			cout << "NO" << endl;
	}
	return 0;
}