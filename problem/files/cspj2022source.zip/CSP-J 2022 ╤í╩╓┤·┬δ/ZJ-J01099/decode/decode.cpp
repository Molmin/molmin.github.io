#include<bits/stdc++.h>
#define ll long long 
using namespace std;
ll n,d,e;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		scanf("%lld%lld%lld",&n,&d,&e);
		ll he=n-e*d+2;
		ll l=1,r=he/2;
		ll mid,ans=-1;
		while(l<=r){
			mid=(l+r)/2;
			if(n%mid==0&&n%(he-mid)==0&&mid*(he-mid)==n){
				ans=mid;
				break;
			}
			if(mid>n/(he-mid))
				r=mid-1;
			else 
				l=mid+1;
		}
		if(ans!=-1)
			printf("%lld %lld\n",ans,n/ans);
		else
			printf("NO\n");
	}
	return 0;
}
