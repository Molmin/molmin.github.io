#include<bits/stdc++.h>
//
using namespace std;
string a;
int len;
int ans1=0,ans2=0;
int dfs(int l,int r){
	int now;
	for(int i=l;i<=r;++i){
		if(a[i]=='1'){
			now=1;
			continue;
		}
		if(a[i]=='0'){
			now=0;
			continue;
		}
		bool flag=false;
		if(a[i]=='('){
			int k=1;
			int pos=i+2;
			for(int j=i+1;j<=r;++j){
				if(a[j]==')')
					k--;
				if(k==0){
					pos=j;
					break;
				}
				if(a[j]=='(')
					k++;
			}
			now=dfs(i+1,pos-1);
			i=pos;
		}
		if(a[i]=='&'){
			if(a[i+1]!='('&&a[i+1]!=')'&&a[i+2]!='&'){
				if(now==0)
					ans1++;
				int x=a[i+1]-'0';
				now=now&&x;
				i++;
				flag=true;
			}
			if(flag==false){
				int k=0;
				int pos=i+2;
				for(int j=i+1;j<=r;++j){
					if(a[j]==')')
						k--;
					if(a[j]=='(')
						k++;
					if(k==0){
						pos=j;
						break;
					}
				}
				if(now==0){
					ans2++;
					i=pos;
				}
				else{
					now=now&&dfs(i+2,pos-1);
					i=pos;
				}			
			}
		}
		if(a[i]=='|'){
			if(a[i+1]!='('&&a[i+1]!=')'&&a[i+2]!='&'){
				if(now==1)
					ans1++;
				int x=a[i+1]-'0';
				now=now||x;
				i++;
				flag=true;
			}
			if(flag==false){
				int k=0;
				int pos=i+2;
				if(a[i+2]=='&'){
					for(int j=i+3;j<=r;++j){
						if(a[j]=='|'){
							pos=j-1;
							break;
						}
						if(a[j]=='('){
							k=1;
							int pos1=j+2;
							for(int l=j+1;l<=r;++l){
								if(a[l]==')')
									k--;
								if(a[l]=='(')
									k++;
								if(k==0){
									pos1=l;
									break;
								}
							}
							j=pos1;
						}
						pos=j;
					}
				}
				else{
					for(int j=i+1;j<=r;++j){
						if(a[j]==')')
							k--;
						if(a[j]=='(')
							k++;
						if(k==0){
							pos=j;
							break;
						}
					}	
				}
				if(now==1){
					ans1++;
					i=pos;
				}
				else{		
					now=now||dfs(i+2,pos-1);
					i=pos;	
				}		
			}
		}
	}
	return now;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>a;
	cout<<dfs(0,a.size()-1)<<endl;
	cout<<ans2<<' '<<ans1;
	return 0;
}
