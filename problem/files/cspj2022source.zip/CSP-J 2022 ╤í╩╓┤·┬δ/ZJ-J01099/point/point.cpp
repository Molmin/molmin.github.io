#include<bits/stdc++.h>
#define MAXN 20
using namespace std;
struct node{
	int x,y;
};
node a[MAXN];
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i){
		scanf("%d%d",&a[i].x,&a[i].y);
	}
	cout<<n+k;
	return 0;
}
