#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b;
ll ans=0;
bool flag=false;
ll f(ll a,ll b){
	if(b==0)
		return 1;
	if(b==1)
		return a;
	ll x=f(a,b/2);
	if(b%2==1){
		if(x>(ll)(sqrt(1000000000/a))){
			flag=true;
			printf("-1");
			exit(0);
		}
		return x*x*a;
	}
	if(b%2==0){
		if(x>31622){
			flag=true;
			printf("-1");
			exit(0);
		}
		return x*x;
	}
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ans=f(a,b);
	if(flag==true){
		printf("-1");
		return 0;
	}
	printf("%lld",ans);
	return 0;
}
