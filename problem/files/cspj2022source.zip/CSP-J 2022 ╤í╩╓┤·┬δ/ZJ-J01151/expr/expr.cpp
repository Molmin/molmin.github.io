#include<bits/stdc++.h>
using namespace std;
string s;
int l,s1,s2,ans;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	l=s.length();
	for(int i=0;i<l;i++){
		if(a[i]=='&'&&a[i-1]=='0')s1++;
		if(a[i]=='|'&&a[i-1]=='1')s2++;
		if(s[i]==48||s[i]==49)ans=s[i]-48;
	}
	cout<<ans<<"\n"<<s1<<" "<<s2;
	return 0;
}