#include<bits/stdc++.h>
using namespace std;
long long k,n,d,e,t1,t2;
bool flag=0;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	for(int i=1;i<=k;i++){
		flag=0;
		scanf("%lld%lld%lld",&n,&d,&e);
		t1=(n-e*d+2)/2;
		t2=n-e*d+2;
		for(long long j=t1;j>=1;j--){
			if(j*(t2-j)==n){
				printf("%lld %lld\n",j,t2-j);
				flag=1;
				break;
			}
		}
		if(!flag)printf("NO\n");
	}
	return 0;
}