#include<bits/stdc++.h>
using namespace std;
long long a,b,ans=1;
bool flag=0;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	cin>>a>>b;
	if(a==1)cout<<1;
	else{
		for(int i=1;i<=b;i++){
			ans*=a;
			if(ans>1e9){
				flag=1;
				break;
			}
		}
		if(flag)cout<<-1;
		else cout<<ans;
	}
	return 0;
}