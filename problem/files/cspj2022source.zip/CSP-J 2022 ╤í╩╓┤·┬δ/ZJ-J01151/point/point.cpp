#include<bits/stdc++.h>
using namespace std;
int n,k,mxt,mxtk,mxn;
struct node{
	int x,y;
}a[510];
struct dp{
	int mx,tk;
}f[510];
bool cmp(node a,node b){
	if(a.x!=b.x)return a.x<b.x;
	else return a.y<b.y;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)cin>>a[i].x>>a[i].y;
	sort(a+1,a+n+1,cmp);
	for(int i=1;i<=n;i++){
		mxt=0;
		mxtk=0;
		f[i].tk=k;
		for(int j=1;j<i;j++){
			if(a[j].y<=a[i].y){
				if(mxt+mxtk<f[j].mx-(a[i].x-a[j].x+(a[i].y-a[j].y)-1)+f[j].tk&&f[j].tk-(a[i].x-a[j].x+(a[i].y-a[j].y)-1)>=0){
					mxt=f[j].mx;
					mxtk=f[j].tk-(a[i].x-a[j].x+(a[i].y-a[j].y)-1);
				}
			}
		}
		f[i].mx=mxt+1;
		if(i!=1)f[i].tk=mxtk;
	}
	for(int i=1;i<=n;i++){
		if(f[i].mx+f[i].tk>=mxn){
			mxn=f[i].mx+f[i].tk;
		}
	}
	cout<<mxn;
	return 0;
}