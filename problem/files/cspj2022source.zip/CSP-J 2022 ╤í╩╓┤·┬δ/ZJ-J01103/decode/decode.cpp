#include<bits/stdc++.h>
using namespace std;
inline int read(){
	char ch=getchar();int res=0,f=1;
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0')res=res*10+ch-'0',ch=getchar();
	return f*res;
}
struct data{
	int n,e,d;
	int p,q;
	double m;
	double s;
	bool ifans=true;
}a[100005];
int k;
int x,y,xx,yy;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	for(int i=1;i<=k;i++){
		x=0,y=0,xx=0,yy=0;
		a[i].n=read();
		a[i].d=read();
		a[i].e=read();
		a[i].m=a[i].n-a[i].e*a[i].d+2;
		a[i].s=sqrt(a[i].m*a[i].m-4*a[i].n);
		if(a[i].s!=(int)a[i].s)a[i].ifans=false;
		else {
			x=max(a[i].m,a[i].s);
			y=min(a[i].m,a[i].s);
			xx=(x+y)/2;
			yy=(x-y)/2;
			a[i].p=yy;
			a[i].q=xx;
		}
	}
	for(int i=1;i<=k-1;i++){
		if(!a[i].ifans){
			cout<<"No"<<endl;
		}else{
			cout<<a[i].p<<' '<<a[i].q<<endl;
		}
	}
	if(!a[k].ifans){
		cout<<"No";
	}else{
		cout<<a[k].p<<' '<<a[k].q;
	}
	return 0;
}
