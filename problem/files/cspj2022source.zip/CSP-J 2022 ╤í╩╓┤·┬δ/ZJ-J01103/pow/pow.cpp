#include<bits/stdc++.h>
using namespace std;
const long long Mn=2147483647;
inline int read(){
	char ch=getchar();int res=0,f=1;
	while(ch>'9'||ch<'0'){if(ch=='-')f=-1;ch=getchar();}
	while(ch<='9'&&ch>='0')res=res*10+ch-'0',ch=getchar();
	return f*res;
}
long long a,b,i=1;
long long ans=1;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read();b=read();
	if(a==1){
		cout<<1;
		return 0;
	}
	while(i<=b&&ans<=Mn){
		ans*=a;
		i++;
	}
	if(ans>Mn)cout<<-1;
	else cout<<ans;
	return 0;
}
