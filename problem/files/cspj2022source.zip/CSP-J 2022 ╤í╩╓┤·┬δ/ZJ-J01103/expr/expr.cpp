#include<bits/stdc++.h>
using namespace std;
bool orr(bool a,bool b){if(a==b&&b==0)return false;return true;}
bool andd(bool a,bool b){if(a==b&&b==1)return true;return false;}
struct data{
	int nxt,lst;
	char val;
}bo[1000010];
int n=1;
int ansor,ansand;
void findch(int i,bool ifis){
	int fir=i-1;
	bool nowf=true;
	while(bo[i].val!=')'){
		i=bo[i-1].nxt;
		if(bo[i].val=='('){findch(i+1,ifis);i-=2;}
		if(bo[i].val=='1'&&bo[i+1].val=='|'){
			if(!ifis)ansor++,ifis=true;
			if(bo[i+2].val=='('){
				findch(i+2,ifis);
			}
			if(bo[i+2].val=='1'||bo[i+2].val=='0'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='1';
				nowf=true;
			}
		}
		if(bo[i].val=='0'&&bo[i+1].val=='&'){
			if(!ifis)ansor++,ifis=true;
			if(bo[i+2].val=='0'){
				findch(i+2,ifis);
			}
			if(bo[i+2].val=='1'||bo[i+2].val=='0'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='0';
				nowf=false;
			}
		}
		if(bo[i].val=='1'&&bo[i+1].val=='&'){
			if(bo[i+2].val=='('){
				findch(i+2,ifis);
			}
			if(bo[i+2].val=='1'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='1';
				nowf=true;
			}
			if(bo[i+2].val=='0'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='0';
				nowf=false;
			}
		}
		if(bo[i].val=='0'&&bo[i+1].val=='|'){
			if(bo[i+2].val=='('){
				findch(i+2,ifis);
			}
			if(bo[i+2].val=='1'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='1';
				nowf=true;
			}
			if(bo[i+3].val=='0'){
				bo[i+4].lst=i-1;
				bo[i-1].nxt=i+3;
				bo[i].lst=i+2;
				bo[i+3].nxt=i;
				bo[i-1].val='0';
				nowf=false;
			}
		}
	}
	bo[i+1].lst=fir;
	bo[fir].nxt=i;	
	bo[fir+1].nxt=i;
	bo[i].lst=fir+1;
	if(nowf)bo[fir].val='1';
	else bo[fir].val='0';
}
void mems(){
	bo[1].val='(',bo[n+1].val=')';
	bo[1].nxt=2,bo[n+1].lst=n;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char ch=getchar();
	while(ch!='\n'){
		bo[++n].val=ch;
		bo[n].nxt=n+1;
		bo[n].lst=n-1;
		ch=getchar(); 
	}
	mems();
	findch(2,false);
	cout<<bo[1].val<<endl<<ansand<<' '<<ansor;
	return 0;
}
