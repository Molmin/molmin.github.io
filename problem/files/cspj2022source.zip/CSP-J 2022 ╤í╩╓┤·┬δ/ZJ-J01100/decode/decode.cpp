#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
inline ll read()
{
	register char ch;
	while((ch=getchar())<'0'||ch>'9');
	register ll res=ch&15;
	while((ch=getchar())>='0'&&ch<='9')
		res=(res<<3)+(res<<1)+(ch&15);
	return res;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	ll k=read();
	while(k--)
	{
		ll n=read(),e=read(),d=read();
		ll m=n-e*d+2;
		ll dt=m*m-(n<<2);
		if(dt<0)printf("NO\n");
		else{
			ll t=sqrt(dt);
			if(t*t!=dt||(m-t)%2==1)printf("NO\n");
			else printf("%lld %lld\n",m-t>>1,m+t>>1);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
