#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	int a,b;
	cin>>a>>b;
	long long p=1;
	for(int i=1;i<=b;i++)
	{
		p*=a;
		if(p>1e9)break;
	}
	if(p<=1e9)cout<<p;
	else cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
