#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct node{
	int x,y;
}data[501];
int n,k,dp[501][101];
bool cmp(node a,node b){
	if(a.x==b.x) return a.y<b.y;
	else return a.x<b.x;
}
bool check(int i,int j,int k){
	int a=data[j].x-data[i].x+data[j].y-data[i].y;
	return (data[j].x-data[i].x>=0)&&(data[j].y-data[i].y>=0)&&(a==k+1);
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&data[i].x,&data[i].y);
	}
	sort(data+1,data+1+n,cmp);
	for(int i=0;i<501;i++){
		for(int j=0;j<101;j++){
			dp[i][j]=1;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<i;j++){
			if(check(j,i,0)) dp[i][0]=max(dp[j][0]+1,dp[i][0]);
		}
	}
	for(int i=1;i<=k;i++){
		for(int j=1;j<=n;j++){
			for(int a=1;a<j;a++){
				if(check(a,j,1)) dp[j][i]=max(dp[j][i],dp[a][i-1]+2);
			}                                                  
		} 
	} 
	printf("%d",dp[n][k]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
