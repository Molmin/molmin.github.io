#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll a,b,ans;
ll my_pow(ll a,ll b){
	if(b==1) return a;
	if(b&1==1){
		return a*my_pow(a*a,b/2);
	}else{
		return my_pow(a*a,b/2);
	}
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	ans=my_pow(a,b);
	if(ans>0&&ans<=1000000000){
		printf("%lld",ans);
	}else{
		printf("-1");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
