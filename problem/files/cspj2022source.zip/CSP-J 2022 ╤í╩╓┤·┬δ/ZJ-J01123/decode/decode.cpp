#include <bits/stdc++.h>
#define ll long
using namespace std;
ll k,n,e,d,m,a,b;
double p,q;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	scanf("%lld",&k);
	for(int i=0;i<k;i++){
		scanf("%lld%lld%lld",&n,&e,&d);
		/*m=e*d;a=n-m+2;
		b=a*a-4*n;
		if(b>=0){
			if(ll(-a-sqrt(b))+0.0==(-a-sqrt(b))&&ll(-a-sqrt(b))%2==0){
				p=ll(-a-sqrt(b))/2;q=ll(-a+sqrt(b))/2;
				printf("%lld%lld",p,q);
			}else{
				printf("NO");
			}
		}else{
			printf("NO");
		}*/
		printf("NO");
	}
	fclose(stdout);
	return 0;
}