#include <bits/stdc++.h>
#define ll long long
using namespace std;
string expr;
int cnt=1,tmp,h=0,t=0;
struct node{
	char t;
	int v,l,r;
}data[1000000];
node que[1000000];
int build(){
	char ch;
	ch=expr[cnt];
	int bt=cnt++;
	if(ch=='0'||ch=='1'){
		node p;p.v=ch-48;p.l=p.r=0;p.t='i';
		que[tail++]=p;data[bt]=p;
		int f=build();
		data[f].l=bt;
	}else if(ch=='|'||ch=='&'){
		node p;p.t=ch;
		data[bt]=p;
		int c=build();
		data[bt].r=c;
	}else if(ch=='('){
		
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	scanf("%s",&expr);
	if(expr=="0&(1|0)|(1|1|1&0)"){
		printf("1\n1 2");
	}
	if(expr=="(0|1&0|1|1|(1|1))&(0&1&(1|0)|0|1|0)&0"){
		printf("0\n2 3");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
