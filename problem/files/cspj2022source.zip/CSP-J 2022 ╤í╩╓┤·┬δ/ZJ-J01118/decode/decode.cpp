#include<bits/stdc++.h>
using namespace std;

int main() {
	freopen("decode.in","r",stdin);
	freopen("deocde.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int k;
	cin>>k;
	int n[10005],a[10005],b[100005];
	for(int i=0;i<k;i++){
		cin>>n[i]>>a[i]>>b[i];
	}
	for(int i=0;i<k;i++){
		bool flag=false;
		for(int j=1;j*j<=n[i];j++){
			if(n[i]%j==0&&a[i]*b[i]==((j-1)*(n[i]/j-1)+1)){
				cout<<j<<' '<<n[i]/j<<endl;
				flag=true;
			}
		}
		if(flag==false){
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
