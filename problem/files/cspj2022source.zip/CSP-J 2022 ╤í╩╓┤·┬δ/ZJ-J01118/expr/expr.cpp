#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(false);
	int ans1=0;
	int ans2=0;
	cin.tie(0);
	cout.tie(0);
	string s;
	cin>>s;
	if(s[0]=='1'&&s[1]=='|'){
		cout<<1<<endl;
		cout<<0<<' '<<1<<endl;
		return 0;
	}
	if(s[0]=='0'&&s[1]=='|'&&s[2]=='1'){
		cout<<1<<endl;
		cout<<0<<' '<<0<<endl;
		return 0;
	}
	if(s[0]=='1'&&s[1]=='&'&&s[2]=='1'){
		cout<<1<<endl;
		cout<<0<<' '<<0<<endl;
		return 0;
	}
	if(s[0]=='0'&&s[1]=='&'){
		cout<<0<<endl;
		cout<<1<<' '<<0<<endl;
		return 0;
	}
	if(s[0]=='0'&&s[1]=='|'&&s[2]=='0'){
		cout<<0<<endl;
		cout<<0<<' '<<0<<endl;
	}
	if(s[0]=='1'&&s[1]=='&'&&s[2]=='0'){
		cout<<0<<endl;
		cout<<0<<' '<<0<<endl;
	}
	return 0;
}
