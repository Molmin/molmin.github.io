#include<bits/stdc++.h>
using namespace std;
void fast(int x,int y){
	if(x>1e9){
		cout<<-1<<endl;
		return;
	}
	if(x==1){
		cout<<-1<<endl;
		return;
	}
	int a[10005];
	int p=0;
	int sum=1;
	while(y!=0){
		sum*=2;
		if(sum==y){
			y-=sum;
			a[p]=sum;
			break;
		}
		if(sum>y){
			sum/=2;
			a[p]=sum;
			y-=sum;
			sum=1;
			p++;
			
			
		}
	}
	long long sum2=1;
	for(int i=0;i<p;i++){
		long long sum1=x;
		for(int j=1;j<a[i];j*=2){
			sum1*=sum1;
			if(sum1>1e9){
				cout<<-1<<endl;
				return;
			}
		}
		sum2*=sum1;
		if(sum2>1e9){
			cout<<-1<<endl;
			return;
		}
	}
	cout<<sum2<<endl;
}
int main() {
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int a,b;
	cin>>a>>b;
	fast(a,b);
	return 0;
}
