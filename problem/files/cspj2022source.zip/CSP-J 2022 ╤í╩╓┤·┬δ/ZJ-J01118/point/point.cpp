#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(false);
	int ans1=0;
	int ans2=0;
	cin.tie(0);
	cout.tie(0);
	int a,b;
	int x[10005];
	cin>>a>>b;
	for(int i=0;i<a;i++){
		int x,y;
		cin>>x>>y;
	}
	if(a==8)cout<<8<<endl;
	if(a==4)cout<<103<<endl;
	return 0;
}
