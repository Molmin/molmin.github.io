#include<bits/stdc++.h>
using namespace std;
string sll;
int suma=0,lene,sumb=0;
bool chek(int i,int j){
	int y=0;
	for(int u=i;u<=j;++u){
		if(sll[u]=='(')y++;
		if(sll[u]==')')y--;
		if(y<0)return 0;
	}
	return 1;
}
int chec(int i,int j){
	if(j-i+1==3)return i+1;
	int f=-1,y=0;
	for(int u=i;u<=j;u++){
		if(sll[u]=='|'&&y==0)return u;
		if(sll[u]=='&'&&y==0){
			if(f==-1)f=u;
		}
		if(sll[u]=='(')y++;
		if(sll[u]==')')y--;
	}
	return f;
}
bool jisun(int i,int j){
	if(sll[i]=='('&&sll[j]==')'&&chek(i+1,j-1))i++,j--;
	if(i==j){
		if(sll[i]=='0')return 0;
		else return 1;
	}
	int u=chec(i,j);
	if(sll[u]=='&'){
		suma++;
		if(jisun(i,u-1)){
			return jisun(u+1,j);
		}
		else return 0;
	}
	else{
		sumb++;
		if(jisun(i,u-1)==0){
			return jisun(u+1,j);
		}
		else return 1;
	}
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>sll;
	cout<<jisun(0,sll.size()-1);
	printf("\n%d %d",suma,sumb);
	return 0;
}
