#include<bits/stdc++.h>
using namespace std;
long long n,e,d,m,MX=1000000000;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%lld%lld%lld",&n,&e,&d);
		m=n-e*d+2;
		if(n>MX){
			int y=m/2;
			if(y*y==n)
				printf("%lld %lld\n",y,y);
			else
				printf("NO\n");
		}
		else{
			bool f=1;
			for(long long j=1;j<=m/4+1;j++){
				e=j;
				d=m-j;
				if(e*d==n){
					printf("%lld %lld\n",e,d);
					f=0;
					break;
				}
				e=j*2;
				d=m-e;
				if(e*d==n){
					printf("%lld %lld\n",e,d);
					f=0;
					break;
				}
			}
			if(f)
				printf("NO\n");
		}
	}
	return 0;
}
