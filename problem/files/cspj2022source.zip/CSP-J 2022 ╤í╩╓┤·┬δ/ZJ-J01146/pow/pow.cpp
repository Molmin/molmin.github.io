#include<bits/stdc++.h>
using namespace std;
const long long MX=1000000000;
long long a,b,la,lb;
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	if(a==1){
		printf("1\n");
		return 0;
	}
	if(b>=30||a>MX){
		printf("-1\n");
		return 0;
	}
	la=a;
	for(int i=2;i<=b;i++){
		a*=la;
		if(a>MX){
			printf("-1\n");
			return 0;
		}
	}
	printf("%lld\n",a);
	return 0;
}
