#include <bits/stdc++.h>
#include <stack>
using namespace std;
stack<char> r;
stack<bool> nu;
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	char x[1000005],xx[1000005],ll=-1;
	cin>>x;
	int l=strlen(x),s=1,s1=0,s2=0;
	for(int i=0;i<l;i++){
		if(x[i]=='|'||x[i]=='&'||x[i]=='(') r.push(x[i]);
		if(x[i]=='0'||x[i]=='1') xx[++ll]=x[i];
		if(x[i]==')'){
			char t=r.top();
			r.pop();
			while(t!='('){
				xx[++ll]=t;
				t=r.top();
				r.pop();
			}
		}
	}
	//for(int i=0;i<=ll;i++) printf("%c",xx[i]);
	for(int i=0;i<=ll;i++){
		if(xx[i]=='0') nu.push(0);
		else if(xx[i]=='1') nu.push(1);
		if(xx[i]=='|'){
			bool t1=nu.top();
			nu.pop();
			bool t2=nu.top();
			nu.pop();
			bool st=t1|t2;
			if(t2==1) s2++;
			nu.push(st);
		}
		else if(xx[i]=='&'){
			bool t1=nu.top();
			nu.pop();
			bool t2=nu.top();
			nu.pop();
			bool st=t1&t2;
			if(t2==0) s1++;
			nu.push(st);
		}
	}
	int ans;
	if(nu.top()==0) ans=0;
	else if(nu.top()==1) ans=1;
	printf("%d\n%d %d",ans,s1,s2);
	fclose(stdin);
	fclose(stdout);
	return 0;
}