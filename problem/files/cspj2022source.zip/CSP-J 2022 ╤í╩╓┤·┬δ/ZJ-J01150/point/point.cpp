#include <bits/stdc++.h>
using namespace std;
struct point{
	int x,y;
}p[605];
int dp[605][105];
bool cmp(point a,point b){
	if(a.y==b.y) return a.x<b.x;
	return a.y<b.y;
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	int n,k,maxn=-1;
	cin>>n>>k;
	for(int i=1;i<=605;i++)
		for(int j=0;j<=105;j++) dp[i][j]=1;
	for(int i=1;i<=n;i++) scanf("%d%d",&p[i].x,&p[i].y);
	sort(p+1,p+1+n,cmp);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int kj=k;kj>=0;kj--){
				if((p[j].x==p[i].x+1&&p[j].y==p[i].y)||(p[j].x==p[i].x&&p[j].y==p[i].y+1)){
					dp[j][kj]=max(dp[j][kj],dp[i][kj]+1);
				}
				else if((p[j].x-p[i].x)+(p[j].y-p[i].y)<=kj+1){
					dp[j][kj-((p[j].x-p[i].x)+(p[j].y-p[i].y)-1)]=max(dp[j][kj],dp[i][kj]+((p[j].x-p[i].x)+(p[j].y-p[i].y)));
				}
			}
		}
	}
	for(int i=0;i<=605;i++)
		for(int j=0;j<=105;j++)
			if(dp[i][j]>maxn) maxn=dp[i][j];
	printf("%d",maxn);
	fclose(stdin);
	fclose(stdout);
	return 0;
}