#include <bits/stdc++.h>
#define LL long long int
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int k;
	cin>>k;
	while(k--){
		LL n,e,d,su,che,t1,ans1,ans2;
		scanf("%lld%lld%lld",&n,&e,&d);
		su=n+2-e*d;
		che=sqrt(su*su-4*n);
		if((che*che)!=(su*su-4*n)){
			printf("NO\n");
			continue;
		}
		t1=su+che;
		bool f=0;
		if(t1%2==0&&(n%(t1/2))==0){
			f=1;
			ans1=min(t1/2,(n/(t1/2))),ans2=max(t1/2,(n/(t1/2)));
			printf("%lld %lld\n",ans1,ans2);
		}
		t1=su-che;
		if(f==0&&t1%2==0&&(n%(t1/2))==0){
			f=1;
			ans1=min(t1/2,(n/(t1/2))),ans2=max(t1/2,(n/(t1/2)));
			printf("%lld %lld\n",ans1,ans2);
		}
		if(f==0) printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}