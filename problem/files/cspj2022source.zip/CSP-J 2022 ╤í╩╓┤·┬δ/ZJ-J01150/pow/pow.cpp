#include <bits/stdc++.h>
#define LL long long int
using namespace std;
LL m=1000000000;
LL fpow(LL a,LL b){
	LL s=1;
	//b>>=1;
	while(b>1){
		if(a>m) return -1;
		if(b%2==1) s=s*a;
		a=a*a;
		//printf("%lld %lld\n",a,b);
		//s=s*a;
		b>>=1;
	}
	s=s*a;
	return s;	
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	LL x,y;
	cin>>x>>y;
	printf("%lld",fpow(x,y));
	fclose(stdin);
	fclose(stdout);
	return 0;
}