#include<bits/stdc++.h>
using namespace std;
int n,k,ans;
bool flag[110];
struct Node{
	int x,y;
}a[510];
int read()
{
	int num=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		f=ch=='-'?-1:1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		num=(num<<1)+(num<<3)+ch-'0';
		ch=getchar();
	}
	return num*f;
}
bool cmp(Node a,Node b)
{
	if(a.x==b.x&&a.y<b.y) return true;
	else if(a.x<b.x) return true;
	return false;
}
int sou(int x,int y)
{
	int t=1,w=n,mid;
	while(t<=w)
	{
		mid=(t+w)>>1;
		if(a[mid].x<x) t=mid+1;
		else if(a[mid].x>x)	w=mid-1;
		else
		{
			if(a[mid].y<y) t=mid+1;
			else if(a[mid].y>y) w=mid-1;
			else return mid;
		}
	}
	return -1;
}
int sou2(int x,int y)
{
	int t=1,w=n,mid;
	while(t<=w)
	{
		mid=(t+w)>>1;
		if(a[mid].x<x) t=mid+1;
		else if(a[mid].x>x)	w=mid-1;
		else
		{
			if(a[mid].y<y) t=mid+1;
			else if(a[mid].y>y) w=mid-1;
			else return true;
		}
	}
	return false;
}
void dfs1(int hao,int sum)
{
	ans=sum>ans?sum:ans;
	int xx=a[hao].x,yy=a[hao].y,h;
	h=sou(xx+1,yy);
	if(h!=-1) dfs1(h,sum+1);
	h=sou(xx,yy+1);
	if(h!=-1) dfs1(h,sum+1);
}
void dfs2(int x,int y,int sum,int kk)
{
	int h=sou(x,y);
	if(h==n) 
	{
		ans=sum+kk>ans?sum+kk:ans;
		return;
	}
	ans=sum>ans?sum:ans;
	bool hh;
	hh=sou2(x+1,y);
	if(hh) dfs2(x+1,y,sum+1,kk);
	else if(kk>0) dfs2(x+1,y,sum+1,kk-1);
	hh=sou2(x,y+1);
	if(hh) dfs2(x,y+1,sum+1,kk);
	else if(kk>0) dfs2(x,y+1,sum+1,kk-1);
}
void dfs3(int hao,int sum,int kk)
{
	int jia;
	if(hao==n) ans=sum+kk>ans?sum+kk:ans;
	else ans=sum>ans?sum:ans;
	for(int i=hao+1;i<=n;++i)
	if(a[i].x>=a[hao].x&&a[i].y>=a[hao].y)
	{
		jia=abs(a[i].x-a[hao].x)+abs(a[i].y-a[hao].y)-1;
		if(k>=jia) dfs3(i,sum+jia+1,kk-jia);
	}
}
int main()
{
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	n=read();k=read();
	for(int i=1;i<=n;++i)
	{
		a[i].x=read();
		a[i].y=read();
	}
	sort(a+1,a+1+n,cmp);
	if(k==0)
	{
		for(int i=1;i<=n;++i)
		if(!flag[i]) dfs1(i,1);
	}
	else if(n<100||k>=27)
	{
		for(int i=1;i<=n;++i)
			dfs3(i,1,k);
	}
	else 
	{
		for(int i=1;i<=n;++i)
			dfs2(a[i].x,a[i].y,1,k);
	}
	printf("%d\n",ans);
	return 0;
}