#include<bits/stdc++.h>
using namespace std;
long long k,chen,di,ei,he,cha,da,xiao;
long long read()
{
	long long num=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		f=ch=='-'?-1:1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		num=(num<<1)+(num<<3)+ch-'0';
		ch=getchar();
	}
	return num*f;
}
int main()
{
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	k=read();
	while(k--)
	{
 		chen=read();di=read();ei=read();
		he=chen-(di*ei-2);
		if(he*he>=4*chen) cha=sqrt(he*he-4*chen);
		else cha=0;
		da=(he+cha)>>1;
		xiao=(he-cha)>>1;
		if(da>=0&&xiao>0&&da>=xiao)
		{
			if(da*xiao==chen&&ei*di==(da-1)*(xiao-1)+1)
				printf("%lld %lld\n",xiao,da);
			else printf("NO\n");
		}
		else printf("NO\n");
	}
	return 0;
}
