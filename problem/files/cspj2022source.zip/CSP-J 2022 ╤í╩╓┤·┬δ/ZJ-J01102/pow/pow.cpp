#include<bits/stdc++.h>
using namespace std;
long long a,b,Mod=1000000000,gee,c[50],ge,anss,ans[50];
long long read()
{
	long long num=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		f=ch=='-'?-1:1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		num=(num<<1)+(num<<3)+ch-'0';
		ch=getchar();
	}
	return num*f;
}
int main()
{
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	a=read();b=read();
	while(b)
	{
		ge++;
		c[ge]=b%2;
		if(c[ge]==1) gee++;
		b/=2;
	}
	ans[1]=a;anss=1;
	for(int i=2;i<=ge;++i) 
	{
		ans[i]=ans[i-1]*ans[i-1];
		if((ans[i]>Mod)||(ans[i]==Mod&&gee!=1)) 
		{
			printf("-1\n");
			return 0;
		}
	}
	for(int i=1;i<=ge;++i)
	{
		if(c[i]==1)
		anss=anss*ans[i];
		if(anss>Mod)
		{
			printf("-1\n");
			return 0;
		}
	}
	printf("%lld\n",anss);
	return 0;
}
