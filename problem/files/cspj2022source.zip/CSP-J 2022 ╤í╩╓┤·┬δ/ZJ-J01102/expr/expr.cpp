#include<bits/stdc++.h>
using namespace std;
string s;
bool xo,xa;
int x,ans;
int main()
{
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>s;
	x=s.size();
	if(x==1)
	{
		if(s[0]=='1') cout<<1<<"\n"<<0<<" "<<0<<"\n";
		if(s[0]=='0') cout<<0<<"\n"<<0<<" "<<0<<"\n";
	}
	else 
	if(x==3)
	{
		if(s[0]=='1')
		{
			if(s[1]=='|') cout<<1<<"\n"<<0<<" "<<1<<"\n";
			else if(s[2]=='0') cout<<0<<"\n"<<0<<" "<<0<<"\n";
			else cout<<1<<"\n"<<0<<" "<<0<<"\n";
		}
		else if(s[0]=='0')
		{
			if(s[1]=='&') cout<<0<<"\n"<<1<<" "<<0<<"\n";
			else if(s[2]=='1') cout<<1<<"\n"<<0<<" "<<0<<"\n";
			else cout<<0<<"\n"<<0<<" "<<0<<"\n";
		}
		else if(s[0]=='(')
		{
			if(s[1]=='1') cout<<1<<"\n"<<0<<" "<<0<<"\n";
			if(s[1]=='0') cout<<0<<"\n"<<0<<" "<<0<<"\n";
		}
	}
	else if(x==5)
	{
		if(s[0]=='1')
		{
			if(s[1]=='|') cout<<1<<"\n"<<0<<" "<<1<<"\n";
			else if(s[3]=='0') cout<<0<<"\n"<<0<<" "<<0<<"\n";
			else cout<<1<<"\n"<<0<<" "<<0<<"\n";

		}
		else if(s[0]=='0')
		{
			if(s[1]=='&') cout<<0<<"\n"<<1<<" "<<0<<"\n";
			else if(s[3]=='1') cout<<1<<"\n"<<0<<" "<<0<<"\n";
			else cout<<0<<"\n"<<0<<" "<<0<<"\n";
		}
		else if(s[0]=='(')
		{
			if(s[1]=='1')
			{
				if(s[3]=='|') cout<<1<<"\n"<<0<<" "<<1<<"\n";
				else if(s[4]=='0') cout<<0<<"\n"<<0<<" "<<0<<"\n";
				else cout<<1<<"\n"<<0<<" "<<0<<"\n";
			}
			else if(s[1]=='0')
			{
				if(s[3]=='&') cout<<0<<"\n"<<1<<" "<<0<<"\n";
				else if(s[4]=='1') cout<<1<<"\n"<<0<<" "<<0<<"\n";
				else cout<<0<<"\n"<<0<<" "<<0<<"\n";
			}
		}
	}
	else
	{
		for(int i=0;i<x;++i)
		if(s[i]=='|') xo=true;
		else if(s[i]=='&') xa=true;
		if(!xo)
		{
			for(int i=0;i<x;++i)
			if(s[i]=='0')
			{
				xo=true;
				cout<<0<<"\n";
				break;
			}
			if(!xo) cout<<1<<"\n";
			for(int i=0;i<x;++i)
				if(s[i]=='0'&&s[i+1]=='&') ans++;
			cout<<ans<<" "<<0<<"\n"; 
		}
		if(!xa)
		{
			for(int i=0;i<x;++i)
			if(s[i]=='1')
			{
				xa=true;
				cout<<1<<"\n";
				break;
			}
			if(!xa) cout<<0<<"\n";
			for(int i=0;i<x;++i)
				if(s[i]=='1'&&s[i+1]=='|') ans++;
			cout<<0<<" "<<ans<<"\n";
		}
	}
	return 0;
}