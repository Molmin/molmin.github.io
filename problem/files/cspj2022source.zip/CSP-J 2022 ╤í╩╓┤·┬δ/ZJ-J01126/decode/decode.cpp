#include <iostream>
using namespace std;

int main() {
    freopen("decode.in", "r", stdin);
    freopen("decode.out", "w", stdout);

    int k;
    cin >> k;
    for (int i = 0; i < k; i++) {
        int n, d, e;
        cin >> n >> d >> e;
        int p = 1, q = 114514;
        bool found = false;
        while (p < q) {
            if (n % p) {
                p++;
                continue;
            }
            q = n / p;
            if (((p - 1) * (q - 1) + 1) == e * d) {
                found = true;
                break;
            } else {
                p++;
            }
        }
        if (!found) {
            cout << "NO\n";
        } else {
            cout << p << ' ' << q << endl;
        }
    }
}
