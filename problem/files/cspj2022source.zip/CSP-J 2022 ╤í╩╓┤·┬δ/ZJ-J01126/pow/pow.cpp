#include <iostream>
#include <cmath>
using std::cout;
using std::cin;
using std::endl;
using std::sqrt;

static const long double SQRT_O_1E9 = sqrt(1e9);

long long quick_pow_under_1e9(long long a, long long b) {
	if (a > 10 && b > 9) {
		// If so, the result value must be bigger than 1e9
		return -1;
	} else {
		if (b == 1) {
			return a;
		}
		if (b == 2) {
			return a * a;
		}
		if (b == 3) {
			return a * a * a;
		}
		if (b % 2) {
			// Odd
			long long mid = quick_pow_under_1e9(a, (b - 1) / 2);
			if (mid > SQRT_O_1E9 || mid == -1) {
				return -1;
			}
			return mid * mid * a;
		} else {
			// Even
			long long mid = quick_pow_under_1e9(a, b / 2);
			if (mid > SQRT_O_1E9 || mid == -1) {
				return -1;
			}
			return mid * mid;
		}
	}
}

int main() {
	
	// Redirect stdin and stdout.
	freopen("pow.in", "r", stdin);
	freopen("pow.out", "w", stdout);
	
	// Main program goes here.
	long long a, b;
	cin >> a >> b;
	long long result = quick_pow_under_1e9(a, b);
	cout << result << endl;
	return 0;
}