#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstdlib>
#include <utility>

using std::cin;
using std::cout;
using std::endl;
using std::cerr;
using std::string;
using std::vector;
using std::pair;

static std::ofstream out;
static std::ifstream in;

#define R_PANICF(b) {b;exit(-1);}
#define R_UNIT Unit()

struct Unit {};

template <typename T, typename E>
struct Result {
	private:
	union ResultInner {
		T success;
		E failure;
		~ResultInner() {}
		ResultInner() {}
	}; 
	ResultInner _inner;
	bool _failure;
	Result() {
	}
	
	public:
	~Result() {}
	Result(const Result<T, E>& r) {
		this->_failure = r._failure;
		if (r._failure) {
			this->_inner.failure = r.unwrap_err();
		} else {
			this->_inner.success = r.unwrap();
		}
	}
	static Result ok(T value) {
		Result r;
		r._failure = false;
		r._inner.success = value;
		return r;
	}
	
	static Result err(E value) {
		Result r;
		r._failure = true;
		r._inner.failure = value;
		return r;
	}
	
	bool is_ok() const {
		return !this->_failure;
	}
	
	bool is_err() const {
		return this->_failure;
	}
	
	T unwrap() const {
		if (this->_failure) {
			R_PANICF({
				cerr << "Failed while unwrapping value. " << endl;
			});
		} else {
			return this->_inner.success;
		}
	}
	E unwrap_err() const {
		if (!this->_failure) {
			R_PANICF({
				cerr << "Failed while unwrapping value to err. " << endl;
			});
		} else {
			return this->_inner.failure;
		}
	}
	T expect(string msg) const {
		if (this->_failure) {
			R_PANICF({
				cerr << "Unexpected err: " << msg << endl;
			});
		} else {
			return this->_inner.success;
		}
	}
	T unwrap_or(T def) const {
		if (this->_failure) {
			return def;
		} else {
			return this->_inner.success;
		}
	}
	E unwrap_err_or(E def) const {
		if (!this->_failure) {
			return def;
		} else {
			return this->_inner.failure;
		}
	}
}; 

namespace tokenize {
	class Token {
		
		public:
		enum class TokenType {
			UNEXPECTED_TOKEN,  // Unexpected token like @ or { or something similar 
			                   // (Unused because we have Result<T, E>)
			OP_OR,             // '|'
			OP_AND,            // '&'
			OP_LEFT_PTH,       // '('
			OP_RIGHT_PTH,      // ')'
			DIG_ONE,           // '1'
			DIG_ZERO           // '0'
		};
		
		private:
		TokenType _type;
		
		public:
		Token(TokenType tk) {
			this->_type = tk;
		}
		TokenType get_type() const {
			return this->_type;
		}
	};
	enum class TokenizationError {
		UNEXPECTED_TOKEN_OCCURRED,
		UNKNOWN
	};
	Result<vector<Token>, TokenizationError> tokenize(std::string input) {
		vector<Token> res;
		for (char i : input) {
			switch (i) {
				case '|':
					res.push_back(Token(Token::TokenType::OP_OR));
					break;
				case '&':
					res.push_back(Token(Token::TokenType::OP_AND));
					break;
				case '(':
					res.push_back(Token(Token::TokenType::OP_LEFT_PTH));
					break;
				case ')':
					res.push_back(Token(Token::TokenType::OP_RIGHT_PTH));
					break;
				case '1':
					res.push_back(Token(Token::TokenType::DIG_ONE));
					break;
				case '0':
					res.push_back(Token(Token::TokenType::DIG_ZERO));
					break;
				case ' ':
				case '\r':
				case '\n':
				case '\t':
					break;
				default:
					return Result<vector<Token>, TokenizationError>::err(TokenizationError::UNEXPECTED_TOKEN_OCCURRED);
			}
		}
		return Result<vector<Token>, TokenizationError>::ok(res);
	}

}

namespace ast {
	struct AstNode {
		enum class AstNodeType {
			EXPR,     // An expression, such as 1&1|(1&0)
			VALUE,	  // A value, 1 or 0
		};

		enum class AstExprOp {
			OP_AND,
			OP_OR,
			LITERAL,
		};

		private:

		AstNodeType _type;

		// Value, if exists
		bool _value;

		// Expressions, if exists
		AstNode* _lexpr;
		AstNode* _rexpr;
		AstExprOp _optype;

		public:
		AstNode(bool value) {
			this->_lexpr = nullptr;
			this->_rexpr = nullptr;
			this->_optype = AstExprOp::LITERAL;
			this->_value = value;
			this->_type = AstNodeType::VALUE;
		}
		AstNode(AstNode* l, AstNode* r, AstExprOp _optype) {
			this->_lexpr = l;
			this->_rexpr = r;
			this->_optype = _optype;
			this->_value = false;
			this->_type = AstNodeType::EXPR;
		}
		~AstNode() {
			// Release the two children
			if (this->_lexpr) {
				delete _lexpr;
			}
			if (this->_rexpr) {
				delete _rexpr;
			}
		}
		bool is_value() {
			return this->_type == AstNodeType::VALUE;
		}
		bool is_expr() {
			return this->_type == AstNodeType::EXPR;
		}
		Result<AstNode*, Unit> left_expr() {
			if (this->is_expr()) {
				return Result<AstNode*, Unit>::ok(this->_lexpr);
			} else {
				return Result<AstNode*, Unit>::err(R_UNIT);
			}
		}
		Result<AstNode*, Unit> right_expr() {
			if (this->is_expr()) {
				return Result<AstNode*, Unit>::ok(this->_rexpr);
			} else {
				return Result<AstNode*, Unit>::err(R_UNIT);
			}
		}
		Result<AstExprOp, Unit> op_type() {
			if (this->is_expr()) {
				return Result<AstExprOp, Unit>::ok(this->_optype);
			} else {
				return Result<AstExprOp, Unit>::err(R_UNIT);
			}
		}
		Result<bool, Unit> value() {
			if (this->is_value()) {
				return Result<bool, Unit>::ok(this->_value);
			} else {
				return Result<bool, Unit>::err(R_UNIT);
			}
		}
		pair<bool, int> eval(int& or_cir, int& and_cir) {
			if (this->is_value()) {
				return std::make_pair(this->value().unwrap(), 0);
			} else {
				auto op_type = this->op_type().unwrap();
				if (op_type == AstExprOp::OP_OR) {
					auto result_l = this->left_expr().unwrap()->eval(or_cir, and_cir);
					if (result_l.first) {
						or_cir++;
						return std::make_pair(result_l.first, result_l.second + 1);
					} else {
						auto result_r = this->right_expr().unwrap()->eval(or_cir, and_cir);
						return std::make_pair(result_r.first, result_l.second + result_r.second);
					}
				}
				if (op_type == AstExprOp::OP_AND) {
					auto result_l = this->left_expr().unwrap()->eval(or_cir, and_cir);
					if (!result_l.first) {
						and_cir++;
						return std::make_pair(result_l.first, result_l.second + 1);
					} else {
						auto result_r = this->right_expr().unwrap()->eval(or_cir, and_cir);
						return std::make_pair(result_r.first, result_l.second + result_r.second);
					}
				}
			}
			return std::make_pair(true, 0);
		}
	};
	AstNode* parse(const vector<tokenize::Token>& tk_list, int begin, int end) {
		int pth_skipper = 0;
		while (tk_list[begin].get_type() == tokenize::Token::TokenType::OP_LEFT_PTH && tk_list[end-1].get_type() == tokenize::Token::TokenType::OP_RIGHT_PTH) {
			begin++;
			end--;
		}
		if (end - begin == 1) {
			return new AstNode(tk_list[begin].get_type() == tokenize::Token::TokenType::DIG_ONE ? true : false);
		}
		for (int i = end - 1; i >= begin; i--) {
			if (pth_skipper) {
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_LEFT_PTH) {
					pth_skipper--;
				} else if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_RIGHT_PTH) {
					pth_skipper++;
				}
			} else {
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_RIGHT_PTH) {
					pth_skipper++;
					continue;
				}
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_OR) {
					AstNode* r = parse(tk_list, i+1, end);
					AstNode* l = parse(tk_list, begin, i);
					return new AstNode(l, r, ast::AstNode::AstExprOp::OP_OR);
				}
			}
		}
		for (int i = end - 1; i >= begin; i--) {
			if (pth_skipper) {
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_LEFT_PTH) {
					pth_skipper--;
				} else if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_RIGHT_PTH) {
					pth_skipper++;
				}
			} else {
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_RIGHT_PTH) {
					pth_skipper++;
					continue;
				}
				if (tk_list[i].get_type() == tokenize::Token::TokenType::OP_AND) {
					AstNode* r = parse(tk_list, i+1, end);
					AstNode* l = parse(tk_list, begin, i);
					return new AstNode(l, r, ast::AstNode::AstExprOp::OP_AND);
				}
			}
		}
		return nullptr;
	}
};


void pre_stage() {
	// freopen("expr.in", "r", stdin);
	// freopen("expr.out", "w", stdout);
	out = std::ofstream("./expr.out");
	in = std::ifstream("./expr.in");
}

void print_ast(ast::AstNode* root) {
	if (root->is_expr()) {
		cout << "(" << (root->op_type().unwrap() == ast::AstNode::AstExprOp::OP_AND ? "op_and" : "op_or") << " ";
		auto le = root->left_expr().unwrap();
		auto re = root->right_expr().unwrap();
		if (le) {
			print_ast(le);
		} else {
			cout << "nullptr";
		}
		cout << " ";
		if (re) {
			print_ast(re);
		} else {
			cout << "nullptr";
		}
		cout << ")";
	} else {
		if (root->value().unwrap()) {
			cout << 1;
		} else {
			cout << 0;
		}
	}
}

Result<Unit, int> main_stage() {
	// Main code goes here.
	string buf;
	std::getline(in, buf);
	
	vector<tokenize::Token> token_list = tokenize::tokenize(buf).expect("Invalid token occurred! ");
	ast::AstNode* ast = ast::parse(token_list, 0, token_list.size());
	// print_ast(ast);
	// out << endl;
	int or_cir = 0, and_cir = 0;
	auto eval_result = ast->eval(or_cir, and_cir);
	out << eval_result.first << endl;
	out << and_cir << ' ' << or_cir << endl;
	delete ast;
	// out << "OK" << endl;
	return Result<Unit, int>::ok(R_UNIT);
}

int main() {
	pre_stage();
	return main_stage().unwrap_err_or(0);
}
