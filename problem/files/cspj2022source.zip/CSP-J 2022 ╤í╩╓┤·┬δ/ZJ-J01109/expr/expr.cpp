#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define inf INT_MAX
#define Len 1000005
ll n,m,ans=0,x,y,l,r,z;
ll ans1,ans2;
string s;
struct point{
	ll opt;
	ll s;
	ll w;
	ll l,r;
//	bool operator < (const point o)const{
//		if (l==o.l) return r<o.r;
//		else return l<o.l;	
//	}
}a[Len];
struct Seg{
	ll l,r;
	ll w;
	bool operator < (const Seg o)const{
		if (l==o.l) return r<o.r;
		else return l<o.l;	
	}
};
ll cnt=0;
set<Seg> se;
template<typename T>inline void read(T &n){
	T w=1;
	n=0;
	char ch=getchar();
	while (!isdigit(ch) && ch!=EOF){
		if (ch=='-') w=-1;
		ch=getchar();
	}
	while (isdigit(ch) && ch!=EOF){
		n=n*10+ch-'0';
		ch=getchar();
	}
	n*=w;
	return ;
}
template<typename T>inline void write(T x){
	if (x==0){
		putchar('0');
		return ;
	}
	T tmp;
	if (x<0){
		putchar('-');
		tmp=-x;
	}
	else tmp=x;
	long long cnt=0;
	char F[105];
	while (tmp>0){
		cnt++;
		F[cnt]=tmp%10;
		tmp/=10;
	}
	while (cnt>0){
		putchar(F[cnt]+'0');
		cnt--;
	}
	return ;
}
struct List{
	struct node{
		ll l,r;
	}a[Len];
	ll n;
	void init(string s){
		n=s.size()-1;
		ll i;
		ll x=0;
		for (i=1; i<=n; i++){
			a[i].l=x;
			if (s[i]=='&' || s[i]=='|') x=i; 
		}
		a[n+1].l=x;
		x=n+1;
		for (i=n; i>=1; i--){
			a[i].r=x;
			if (s[i]=='&' || s[i]=='|') x=i; 
		}
		a[0].r=x;
		return ;
	}
	ll nx(ll x){
		return a[x].r;
	}
	ll pr(ll x){
		return a[x].l;
	}
	void del(ll x){
		if (x<1 || x>n) return ;
		a[a[x].l].r=a[x].r;
		a[a[x].r].l=a[x].l;
		return ;
	}
}ls;
bool check(char ch){
	if (ch=='(' || ch==')') return true;
	if (ch=='&' || ch=='|') return true;
	if (ch=='0' || ch=='1') return true;
	return false;
}
void GET_str(string &s){
	char ch=getchar();
	s="";
	while (!check(ch)) ch=getchar();
	while (check(ch)) {
		s+=ch;
		ch=getchar();
	}
	return ;
}
bool cmp(point x,point y){//��С�������򣬴����㵽�������� 
	if (x.s==y.s){
		if (x.opt==y.opt){
			return x.w<y.w;
		}
		else {
			if (x.opt==1) return true;
			if (x.opt==2) return false;
		}
	}
	else{
		return x.s>y.s;
	}
}
ll find_w(ll l,ll r){
	Seg p;
	p.l=l; p.r=r;
	set<Seg>::iterator it;
	it=se.find(p);
	if (it==se.end()) return -1;
	return (*it).w;
}
ll work(ll l,ll r){
	if (l==r){
		if (s[l]=='1') return 1;
		else return 0;
	}
	ll w=find_w(l,r);
	if (w==-1){
		for (ll i=l; i<=r; i++){
			if (s[i]=='1') return 1;
			if (s[i]=='0') return 0;
		}
		return 0;
	}
	if (s[w]=='&'){
		if (!work(l,w-1)){
			ans1++;
			return 0;
		} 
		return work(w+1,r);
	}
	else{
		if (work(l,w-1)){
			ans2++;
			return 1;
		}
		return work(w+1,r);
	}
	return 0;
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	ll i,j;
	GET_str(s);
	s=" "+s;
	x=0;
	for (i=1; i<s.size(); i++){
		if (s[i]=='(') 
			x++;
		if (s[i]==')')
			x--;
		if (s[i]=='&') {
			cnt++;
			a[cnt].opt=1;
			a[cnt].s=x;
			a[cnt].w=i;
		}
		if (s[i]=='|'){
			cnt++;
			a[cnt].opt=2;
			a[cnt].s=x;
			a[cnt].w=i;
		}
	}
	sort(a+1,a+1+cnt,cmp); 
	ls.init(s);
	for (i=1; i<=cnt; i++){
		a[i].l=ls.pr(a[i].w)+1;
		a[i].r=ls.nx(a[i].w)-1;
		ls.del(a[i].w);
	}
	for (i=1; i<=cnt; i++){
		Seg p;
		p.l=a[i].l;
		p.r=a[i].r;
		p.w=a[i].w;
		se.insert(p); 
	}
	ans1=ans2=0;
	x=work(1,s.size()-1);
	write(x); putchar('\n');
	write(ans1); putchar(' '); write(ans2); 
	return 0;
}
