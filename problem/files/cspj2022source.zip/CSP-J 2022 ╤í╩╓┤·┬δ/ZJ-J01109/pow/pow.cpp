#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define inf INT_MAX
ll lim=1e9;
ll n,m,ans=0,x,y,l,r,s,z;
template<typename T>inline void read(T &n){
	T w=1;
	n=0;
	char ch=getchar();
	while (!isdigit(ch) && ch!=EOF){
		if (ch=='-') w=-1;
		ch=getchar();
	}
	while (isdigit(ch) && ch!=EOF){
		n=n*10+ch-'0';
		ch=getchar();
	}
	n*=w;
	return ;
}
template<typename T>inline void write(T x){
	if (x==0){
		putchar('0');
		return ;
	}
	T tmp;
	if (x<0){
		putchar('-');
		tmp=-x;
	}
	else tmp=x;
	long long cnt=0;
	char F[105];
	while (tmp>0){
		cnt++;
		F[cnt]=tmp%10;
		tmp/=10;
	}
	while (cnt>0){
		putchar(F[cnt]+'0');
		cnt--;
	}
	return ;
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	ll i,j;
	read(n); read(m);
	if (n==1){
		write(1); 
		return 0;
	}
	ans=1;
	for (i=1; i<=m; i++){
		ans*=n;
		if (ans>lim){
			write(-1);
			return 0;
		}
	}
	write(ans);
	return 0;
}
