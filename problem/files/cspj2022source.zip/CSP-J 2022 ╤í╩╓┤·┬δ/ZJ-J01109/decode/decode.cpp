#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define inf INT_MAX
ll m,ans=0,x,y,l,r,s,z;
ll k,n,d,e,p,q,A,B;
template<typename T>inline void read(T &n){
	T w=1;
	n=0;
	char ch=getchar();
	while (!isdigit(ch) && ch!=EOF){
		if (ch=='-') w=-1;
		ch=getchar();
	}
	while (isdigit(ch) && ch!=EOF){
		n=n*10+ch-'0';
		ch=getchar();
	}
	n*=w;
	return ;
}
template<typename T>inline void write(T x){
	if (x==0){
		putchar('0');
		return ;
	}
	T tmp;
	if (x<0){
		putchar('-');
		tmp=-x;
	}
	else tmp=x;
	long long cnt=0;
	char F[105];
	while (tmp>0){
		cnt++;
		F[cnt]=tmp%10;
		tmp/=10;
	}
	while (cnt>0){
		putchar(F[cnt]+'0');
		cnt--;
	}
	return ;
}
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	ll i,j;
	read(k);
	while (k--){
		read(n); read(d); read(e);
		A=n-e*d+2;
		B=n;
//		printf(" A = %lld , B = %lld \n",A,B);
		if (A*A<4*B){
			printf("NO\n");
			continue;
		}
		s=sqrt(A*A-4*B);
//		printf(" s = %lld \n",s);
		if (s*s!=A*A-4*B) {
			printf("NO\n");
			continue;
		}
		p=(A+s)/2;
		q=(A-s)/2;
//		printf(" p = %lld , q = %lld \n",p,q);
		if (p>q) swap(p,q);
		if (p<=0 || q<=0) {
			printf("NO\n");
			continue;
		}
		if (n!=p*q){
			printf("NO\n");
			continue;
		}
		if ((p-1)*(q-1)+1!=e*d){
			printf("NO\n");
			continue;
		}
		if (!(p<=q)) swap(p,q);
		write(p); putchar(' '); write(q); putchar('\n');
	}
	return 0;
}
