#include<bits/stdc++.h>
using namespace std;
int a[100010],f[100010],i,na,nb,t;
string s;
inline bool qjj(int x,int y){
int i,j;
bool t,tt;
	if(s[x]=='(')i=a[x],t=qjj(x+1,a[x]-1);else t=s[x]-48,i=x;
	i++;
	while(i<=y){
		if(s[i]=='&'&&!t&&s[i+1]=='(')i=a[i+1]+1,na++;else
			if(s[i]=='|'&&t&&s[i+1]=='(')i=a[i+1]+1,nb++;else
				if(s[i]=='&'&&t&&s[i+1]=='(')t=qjj(i+2,a[i+1]-1),i=a[i+1]+1;else
					if(s[i]=='|'&&!t&&s[i+1]=='(')t=qjj(i+2,a[i+1]-1),i=a[i+1]+1;else
						if(s[i]=='&')na+=t?0:1,t=t&&(s[i+1]-48),i+=2;else
							if(s[i]=='|'&&s[i+2]=='&'){
								tt=s[i+1]-48;
								j=i+2;
							  while(s[j]=='&'&&j<y){
								  if(s[j+1]=='('&&!tt)j=a[j+1]+1,na+=(!t)?1:0;else
									  if(s[j+1]=='(')tt=qjj(j+2,a[j+1]-1),j=a[j+1]+1;
										  else na+=(!tt&&!t)?1:0,tt=tt&&(s[j+1]-48),j+=2;
								}
								nb+=t?1:0;i=j;t=t||tt;
							}else if(s[i]=='|')nb+=t?1:0,t=(s[i+1]-48)||t,i+=2;
	}
	return t;
}
int main(){
  freopen("expr.in","r",stdin);
  freopen("expr.out","w",stdout);
  cin>>s;
  for(i=0;s[i]!='\0';i++){
	  if(s[i]=='(')t++,f[t]=i;
		if(s[i]==')')a[f[t]]=i,t--;
	}
	if(qjj(0,i-1))cout<<1;else cout<<0;
  cout<<'\n'<<na<<' '<<nb;
}
