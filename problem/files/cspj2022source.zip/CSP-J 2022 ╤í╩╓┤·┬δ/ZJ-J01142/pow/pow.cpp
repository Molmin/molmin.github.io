#include<bits/stdc++.h>
using namespace std;
long long a,b,t,x=1e9,f;
inline void read(long long &x){
  char ch=getchar();
  x=0;
  while(ch<'0'||ch>'9')ch=getchar();
  while(ch>='0'&&ch<='9')x=x*10+ch-48,ch=getchar();
}
int main(){
  freopen("pow.in","r",stdin);
  freopen("pow.out","w",stdout);
  read(a);read(b);t=1;
  while(b>1){
  	if(b%2)t*=a;
  	b/=2;a=a*a;
  	if(a>x){f=1;break;}
	}
	if(f||a*t>x)cout<<-1;else cout<<a*t;
}
