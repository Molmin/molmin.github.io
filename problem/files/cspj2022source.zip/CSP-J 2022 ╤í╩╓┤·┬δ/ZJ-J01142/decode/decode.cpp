#include<bits/stdc++.h>
using namespace std;
long long n,x,y,z,i,a,b,c,p,q;
inline void read(long long &x){
  int f=0;
  char ch=getchar();
  x=0;
  while(ch<'0'||ch>'9')f=(ch=='-')?1:0,ch=getchar();
  while(ch>='0'&&ch<='9')x=x*10+ch-48,ch=getchar();
  x=f?-x:x;
}
int main(){
  freopen("decode.in","r",stdin);
  freopen("decode.out","w",stdout);
  read(n);
	for(i=1;i<=n;i++){
		read(x);read(y);read(z);
		a=x-y*z+2;
		b=a*a-4*x;
		c=sqrt(b);
		if(c*c==b&&(a+c)%2==0)cout<<(a-c)/2<<' '<<(a+c)/2<<'\n';else cout<<"NO\n";
	}
}
