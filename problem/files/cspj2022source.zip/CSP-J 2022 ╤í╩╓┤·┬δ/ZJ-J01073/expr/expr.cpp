#include <iostream>
using namespace std;
int yi,yu;
string s;
void check(int x){
	if(s[x]=='|'&&s[x-1]=='1') yi++;
	if(s[x]=='&'&&s[x-1]=='0') yu++;
	int t1=s[x-1]-'0',t2=s[x+1]-'0';
	if(s[x]=='|'){
		s[x-1]=t1|t2;
		s[x-1]+='0';
		s[x+1]=s[x-1];
	}
	if(s[x]=='&'){
		s[x-1]=t1&t2;
		s[x-1]+='0';
		s[x+1]=s[x-1];
	} 
}
int main(){
	freopen("expr.in","r",stdin);
	freopen("expr.out","w",stdout);
	cin>>s;
	bool ok1=true,ok2=true,ok3=true;
	for(int i=0;i<s.size();i++){
		if(s[i]=='&')ok1=false;
		if(s[i]=='|')ok2=false;
		if(s[i]=='(')ok3=false;
	}
	if(s.size()==3){
		check(1);
		cout<<yu<<" "<<yi;
		return 0;
	}
	if(s.size()==5){
		if(s[1]=='|'&&s[3]=='&'){
			check(3);
			check(1);
			cout<<yu<<" "<<yi;
			return 0;
		}
		check(1);
		check(3);
		cout<<yu<<" "<<yi;
		return 0;
	}
	if(ok3){
		for(int i=0;i<s.size();i++){
			if(s[i]=='&') check(i);
		}
		for(int i=0;i<s.size();i++){
			if(s[i]=='|') check(i);
		}
		cout<<yu<<" "<<yi<<endl;
		return 0;
	}
	cout<<0<<" "<<0;
	return 0;
}
