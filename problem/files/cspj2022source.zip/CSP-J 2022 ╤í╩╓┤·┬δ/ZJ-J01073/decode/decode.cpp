#include <iostream>
#include <algorithm>
using namespace std;
int main(){
	freopen("decode.in","r",stdin);
	freopen("decode.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		int a[100005];
		int num=0;
		int n,e,d;
		cin>>n>>d>>e;
		for(int i=1;i*i<=n;i++){
			if(n%i==0)a[++num]=i;
		}
		sort(a+1,a+1+num);
		int t=n+2-e*d;
		int p=-1,q=-1;
		for(int i=1;i<=num;i++){
			if(a[i]+n/a[i]==t){
				p=min(a[i],n/a[i]);
				q=max(a[i],n/a[i]);
			}
		}
		if(p==-1){
			cout<<"NO"<<endl;
		}else{
			cout<<p<<" "<<q<<endl;
		}
	}
	return 0;
}
