#include <iostream>
using namespace std;
int n,k;
int a[2005][2005];
int vis[2005][2005];
int t,ans;
int dx[4]={0,0,-1,1};
int dy[4]={-1,1,0,0};
int nn=0,mm=0;
bool check(int x,int y){
	if(x<1||x>nn||y<1||y>mm) return false;
	if(vis[x][y]==0) return false;
	return true;
}
void dfs(int x,int y){
	int nx,ny;
	for(int i=0;i<4;i++){
		nx=x+dx[i],ny=y+dy[i];
		if(check(nx,ny)){
			t++;
			vis[nx][ny]=0;
			dfs(nx,ny);
		}
	}
}
int main(){
	freopen("point.in","r",stdin);
	freopen("point.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		int x,y;
		cin>>x>>y;
		nn=max(nn,x);
		mm=max(mm,y);
		vis[x][y]=1;
	}
	if(k==0&&nn<=2000&&mm<=2000){
		for(int i=0;i<=nn;i++){
			for(int j=0;j<=mm;j++){
				if(vis[i][j]==1){
					vis[i][j]=0;
					t=0;
					dfs(i,j);
					ans=max(ans,t+1);
				}
			}
		}
		cout<<ans<<endl;
		return 0;
	}
	cout<<n+k<<endl;
	return 0;
}
