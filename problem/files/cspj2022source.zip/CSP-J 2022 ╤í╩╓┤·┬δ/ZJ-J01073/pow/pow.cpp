#include<iostream>
using namespace std;
long long pow_(long long a,long long b){
	if(b==0){
		return 1;
	}
	int t=pow_(a,b/2);
	if(b%2==0){
		if(t*t>1e9){
			return 0;
		}
		return t*t;
	}
	if(t*t*a>1e9){
		return 0;
	}
	return t*t*a; 
}
int main(){
	freopen("pow.in","r",stdin);
	freopen("pow.out","w",stdout);
	long long a,b;
	cin>>a>>b;
	int t=pow_(a,b);
	if(t==0) cout<<-1;
	else cout<<t;
	return 0;
}
