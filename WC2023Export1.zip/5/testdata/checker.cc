#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define mp make_pair
typedef pair<int,int> pii;
typedef long long ll;
typedef double ld;
typedef vector<int> vi;
#define fi first
#define se second
#define FO(x) {freopen(#x".in","r",stdin);freopen(#x".out","w",stdout);}
#define Edg int M=0,fst[SZ],vb[SZ],nxt[SZ];void ad_de(int a,int b){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;}void adde(int a,int b){ad_de(a,b);ad_de(b,a);}
#define Edgc int M=0,fst[SZ],vb[SZ],nxt[SZ],vc[SZ];void ad_de(int a,int b,int c){++M;nxt[M]=fst[a];fst[a]=M;vb[M]=b;vc[M]=c;}void adde(int a,int b,int c){ad_de(a,b,c);ad_de(b,a,c);}
#define es(x,e) (int e=fst[x];e;e=nxt[e])
#define esb(x,e,b) (int e=fst[x],b=vb[e];e;e=nxt[e],b=vb[e])
#define SZ 666666
int m;
string os[SZ];
ll as[SZ],bs[SZ];
ll xs[SZ],xn;
ll bb[SZ];
void edt(int x,ll y) {
    for(;x<SZ;x+=x&-x) bb[x]+=y;
}
ll qry(int x) {
    ll s=0;
    for(;x;x-=x&-x) s+=bb[x];
    return s;
}
template<class T>
bool chk(T&in,ll t,int qid) {
    ll x=in.readLong(),y=in.readLong();
    if(x==-1&&y==-1) return false;
    #define ensf(y,...) if(!(y)) in.quitf(_wa,__VA_ARGS__)
    ensf(x>=1&&y>=1,"query %d: not a cell",qid);
    int g=upper_bound(xs+1,xs+xn+1,x)-xs-1;
    ll qg=qry(g);
    ensf(qg>=y,"query %d: not a cell",qid);
    int l=g,r=xn;
    while(l<r) {
        int mid=(l+r+1)>>1;
        if(qry(mid)>=y) l=mid;
        else r=mid-1;
    }
    ll hook=xs[l+1]-x+qg-y;
    ensf(hook==t,"query %d: expected %lld but got %lld",qid,t,hook);
    #undef ensf
    return true;
}
int main(int argc,char* argv[]) {
    registerTestlibCmd(argc,argv);
    m=inf.readInt();
    xs[++xn]=1;
    for(int i=1;i<=m;++i) {
        os[i]=inf.readToken();
        if(os[i]=="+"||os[i]=="-") {
            as[i]=inf.readInt(),bs[i]=inf.readInt();
            if(os[i]=="+") ++as[i];
            xs[++xn]=as[i];
        }
        else if(os[i]=="?"||os[i]=="R")
            as[i]=inf.readLong();
        else quitf(_fail,"invalid operator");
    }
    sort(xs+1,xs+xn+1);
    xn=unique(xs+1,xs+xn+1)-xs-1;
    for(int i=1;i<=m;++i) {
        if(os[i]=="+"||os[i]=="-")
            as[i]=lower_bound(xs+1,xs+xn+1,as[i])-xs;
        if(os[i]=="+") {
            edt(1,bs[i]);
            edt(as[i],-bs[i]);
        }
        else if(os[i]=="-") {
            int cl=as[i];
            while(cl<=xn) {
                auto u=min(qry(cl),bs[i]);
                int l=cl,r=xn;
                while(l<r) {
                    int mid=(l+r+1)>>1;
//                    cerr<<min(qry(mid),bs[i])<<"  "<<u<<" "<<l<<"~"<<r<<"\n";
                    if(min(qry(mid),bs[i])==u) l=mid;
                    else r=mid-1;
                }
                // cout<<cl<<"~"<<l<<":"<<u<<"\n";
                edt(cl,-u);
                edt(l+1,u);
                cl=l+1;
            }
        }
        else if(os[i]=="R") {
            long long s=as[i];
            assert(s>=1&&s<i);
            for(int j=i-1;j>=i-s;--j) {
                if(os[j]=="?") continue;
                assert(os[j]=="+");
                edt(1,-bs[j]);
                edt(as[j],bs[j]);
            }
        }
        else {
            bool ans_rst=chk(ans,as[i],i);
            bool out_rst=chk(ouf,as[i],i);
            if(ans_rst&&!out_rst) quitf(_wa,"std found soln");
            if(!ans_rst&&out_rst) quitf(_fail,"participant found soln");
        }
    }
    quitf(_ok,"ok");
}